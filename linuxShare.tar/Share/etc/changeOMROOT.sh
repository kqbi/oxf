#!/bin/sh

for f in  $* ; do
   echo $f | grep "\.mak">/dev/null
   if [ $? -eq 0 ] ; then
      awk ' { if($1 ~ /^OMROOT=/) { print "OMROOT=\"" omroot "\"";} else { print }}' omroot=$1 $f > $f.tmp
      if { cmp -s $f $f.tmp; } then
         rm $f.tmp
      else
         echo changing OMROOT to $1
         mv -f $f.tmp $f
      fi
   fi
done
