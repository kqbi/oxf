#!/bin/sh
if [ $# -eq 0 ] ; then
echo Usage: $0 files
exit
fi
etcDir=`dirname $0`
for f in  $* ; do
$etcDir/dos2unix  -n $f $f.tmp 2>/dev/null
if { cmp -s $f $f.tmp; } then
  rm $f.tmp
else
  echo strip CR from  $f
  mv -f $f.tmp $f
fi
done
