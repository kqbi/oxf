/*********************************************************************
	Rhapsody	: 7.6 
	Login		: ehudho
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMDataFlow
//!	Generated Date	: Mon, 23, Apr 2012  
	File Path	: ../OMDataFlow.h
*********************************************************************/

#ifndef OMDataFlow_H
#define OMDataFlow_H

//## dependency AOMSAttributes
//#[ ignore
#ifdef _OMINSTRUMENT

//#]
#include <aommsg.h>
#endif // _OMINSTRUMENT
//## auto_generated
#include "OMActivity.h"
//## auto_generated
#include "OMActivityNode.h"
//## dependency OMAction
#include "OMAction.h"
//## class OMDataFlow
#include "OMActivityEdge.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## auto_generated
class OMActivity;

//## auto_generated
class OMActivityNode;

//## package Activities

//## class OMDataFlow
template <class T> class OMDataFlow : public OMActivityEdge {
public :

    //## auto_generated
    virtual ~OMDataFlow(void);
    
    //## operation OMDataFlow(OMString,OMActivity,OMActivityNode,OMActivityNode)
    OMDataFlow(const OMString& id, OMActivity& parentActivity, OMActivityNode& fromAction, OMActivityNode& toAction);
    
    //## operation offerToken()
    virtual void offerToken(void);
    
    //## operation acceptToken()
    virtual void acceptToken(void);
    
    //## operation isOfferingToken()
    virtual bool isOfferingToken(void);
    
    //## operation isControl()
    virtual bool isControl(void);

protected :

    //## operation enqueueToken(T)
    void enqueueToken(T token);
    
    //## operation dequeueToken()
    T dequeueToken(void);
    
    //## operation giveToken()
    virtual void giveToken(void) = 0;
    
    //## operation takeToken()
    virtual void takeToken(void) = 0;

public :

    //## operation getTokenCount()
    virtual int getTokenCount(void);
    
    ////    Attributes    ////
    
    OMList<T> mTokens;		//## attribute mTokens
};

//## package Activities

//## class OMDataFlow
template <class T> OMDataFlow<T>::OMDataFlow(const OMString& id, OMActivity& parentActivity, OMActivityNode& fromAction, OMActivityNode& toAction) : OMActivityEdge(id, parentActivity, fromAction, toAction) {
    //#[ operation OMDataFlow(OMString,OMActivity,OMActivityNode,OMActivityNode)
    //#]
}

template <class T> void OMDataFlow<T>::offerToken(void) {
    //#[ operation offerToken()
    takeToken();
    
    OMString id = getId();
    mParentActivity->notifyTokenReady(id);
    
    if (mTargetAction->isReady())
    {
    	mTargetAction->visit();
    }
    //#]
}

template <class T> void OMDataFlow<T>::acceptToken(void) {
    //#[ operation acceptToken()
    if (isOfferingToken())
    {
    	giveToken();
    
    	OMString id = getId();
    	mParentActivity->notifyTokenConsumed(id);
    }
    //#]
}

template <class T> bool OMDataFlow<T>::isOfferingToken(void) {
    //#[ operation isOfferingToken()
    return mTokens.getCount() > 0;
    //#]
}

template <class T> bool OMDataFlow<T>::isControl(void) {
    //#[ operation isControl()
    return false;
    //#]
}

template <class T> void OMDataFlow<T>::enqueueToken(T token) {
    //#[ operation enqueueToken(T)
    mTokens.add(token);
    //#]
}

template <class T> T OMDataFlow<T>::dequeueToken(void) {
    //#[ operation dequeueToken()
    T token = mTokens.getFirstConcept();
    mTokens.removeFirst();
    return token;
    //#]
}

template <class T> int OMDataFlow<T>::getTokenCount(void) {
    //#[ operation getTokenCount()
    return mTokens.getCount();
    //#]
}

template <class T> OMDataFlow<T>::~OMDataFlow(void) {
}

#endif
/*********************************************************************
	File Path	: ../OMDataFlow.h
*********************************************************************/
