/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMSendEventAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMSendEventAction.h
*********************************************************************/

#ifndef OMSendEventAction_H
#define OMSendEventAction_H

//## class OMSendEventAction
#include "OMAction.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMSendEventAction
class OMSendEventAction : public OMAction {
public :

    //## auto_generated
    virtual ~OMSendEventAction(void);
    
    //## operation OMSendEventAction(OMString,OMActivity)
    OMSendEventAction(const OMString& id, OMActivity& parentActivity);
    
    //## operation execute()
    virtual void execute(void);
    
    //## operation sendEvent()
    virtual void sendEvent(void) = 0;
};

#endif
/*********************************************************************
	File Path	: ../OMSendEventAction.h
*********************************************************************/
