/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMFlowFinalNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMFlowFinalNode.cpp
*********************************************************************/

//## auto_generated
#include "OMFlowFinalNode.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMFlowFinalNode
OMFlowFinalNode::~OMFlowFinalNode(void) {
}

OMFlowFinalNode::OMFlowFinalNode(const OMString& id, OMActivity& parentActivity) : OMControlNode(id, parentActivity) {
    //#[ operation OMFlowFinalNode(OMString,OMActivity)
    //#]
}

void OMFlowFinalNode::control(void) {
    //#[ operation control()
    consumeTokens();
    //#]
}

bool OMFlowFinalNode::canControl(void) {
    //#[ operation canControl()
    return atLeastOneInputHasToken();
    //#]
}

OMList<OMString> OMFlowFinalNode::filterPassableFlows(void) {
    //#[ operation filterPassableFlows()
    // no flows are expected to exist
    OMList<OMString> ans;
    return ans;
    //#]
}

/*********************************************************************
	File Path	: ../OMFlowFinalNode.cpp
*********************************************************************/
