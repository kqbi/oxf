/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMDecisionNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMDecisionNode.cpp
*********************************************************************/

//## auto_generated
#include "OMDecisionNode.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMDecisionNode
OMDecisionNode::~OMDecisionNode(void) {
}

OMDecisionNode::OMDecisionNode(const OMString& id, OMActivity& parentActivity) : OMControlNode(id, parentActivity) {
    //#[ operation OMDecisionNode(OMString,OMActivity)
    //#]
}

bool OMDecisionNode::canControl(void) {
    //#[ operation canControl()
    return atLeastOneInputHasToken();
    //#]
}

void OMDecisionNode::produceTokens(void) {
    //#[ operation produceTokens()
    OMList<OMString> flowIds = filterPassableFlows();
    
    OMString flowId = flowIds.getFirstConcept();
    OMActivityEdge* flow = mOutputFlows[flowId];
    if (flow)
    {
    	flow->offerToken();
    }
    //#]
}

/*********************************************************************
	File Path	: ../OMDecisionNode.cpp
*********************************************************************/
