/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMControlNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMControlNode.h
*********************************************************************/

#ifndef OMControlNode_H
#define OMControlNode_H

//## class OMControlNode
#include "OMActivityNode.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMControlNode
class OMControlNode : public OMActivityNode {
public :

    //## auto_generated
    virtual ~OMControlNode(void);
    
    //## operation OMControlNode(OMString,OMActivity)
    OMControlNode(const OMString& id, OMActivity& parentActivity);
    
    //## operation visit()
    virtual void visit(void);
    
    //## operation isInitiallyReady()
    virtual bool isInitiallyReady(void);

protected :

    //## operation canControl()
    virtual bool canControl(void) = 0;
    
    //## operation control()
    virtual void control(void);
    
    //## operation atLeastOneInputHasToken()
    bool atLeastOneInputHasToken(void);

public :

    //## operation isReady()
    virtual bool isReady(void);
};

#endif
/*********************************************************************
	File Path	: ../OMControlNode.h
*********************************************************************/
