/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMMergeNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMMergeNode.cpp
*********************************************************************/

//## auto_generated
#include "OMMergeNode.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMMergeNode
OMMergeNode::~OMMergeNode(void) {
}

OMMergeNode::OMMergeNode(const OMString& id, OMActivity& parentActivity) : OMControlNode(id, parentActivity) {
    //#[ operation OMMergeNode(OMString,OMActivity)
    //#]
}

bool OMMergeNode::canControl(void) {
    //#[ operation canControl()
    return atLeastOneInputHasToken();
    //#]
}

/*********************************************************************
	File Path	: ../OMMergeNode.cpp
*********************************************************************/
