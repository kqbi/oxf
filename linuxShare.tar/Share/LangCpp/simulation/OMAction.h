/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMAction.h
*********************************************************************/

#ifndef OMAction_H
#define OMAction_H

//## class OMAction
#include "OMActivityNode.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMAction
class OMAction : public OMActivityNode {
public :

    //## auto_generated
    virtual ~OMAction(void);
    
    //## operation OMAction(OMString,OMActivity)
    OMAction(const OMString& id, OMActivity& parentActivity);
    
    //## operation execute()
    virtual void execute(void) = 0;
    
    //## operation visit()
    virtual void visit(void);
    
    //## operation isInitiallyReady()
    virtual bool isInitiallyReady(void);
    
    //## operation isReady()
    virtual bool isReady(void);
};

#endif
/*********************************************************************
	File Path	: ../OMAction.h
*********************************************************************/
