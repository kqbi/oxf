/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMInitialAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMInitialAction.h
*********************************************************************/

#ifndef OMInitialAction_H
#define OMInitialAction_H

//## class OMInitialAction
#include "OMControlNode.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMInitialAction
class OMInitialAction : public OMControlNode {
public :

    //## auto_generated
    virtual ~OMInitialAction(void);
    
    //## operation OMInitialAction(OMString,OMActivity)
    OMInitialAction(const OMString& id, OMActivity& parentActivity);
    
    //## operation isInitiallyReady()
    virtual bool isInitiallyReady(void);

protected :

    //## operation canControl()
    virtual bool canControl(void);
    
    //## operation filterPassableFlows()
    virtual OMList<OMString> filterPassableFlows(void);
};

#endif
/*********************************************************************
	File Path	: ../OMInitialAction.h
*********************************************************************/
