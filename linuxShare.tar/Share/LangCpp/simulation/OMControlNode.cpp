/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMControlNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMControlNode.cpp
*********************************************************************/

//## auto_generated
#include "OMControlNode.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMControlNode
OMControlNode::~OMControlNode(void) {
}

OMControlNode::OMControlNode(const OMString& id, OMActivity& parentActivity) : OMActivityNode(id, parentActivity) {
    //#[ operation OMControlNode(OMString,OMActivity)
    //#]
}

void OMControlNode::visit(void) {
    //#[ operation visit()
    mParentActivity->notifyEnterControlNode(mId);
    	
    control();
    	
    mParentActivity->notifyExitControlNode(mId);
    //#]
}

bool OMControlNode::isInitiallyReady(void) {
    //#[ operation isInitiallyReady()
    return false;
    //#]
}

void OMControlNode::control(void) {
    //#[ operation control()
    consumeTokens();
    produceTokens();
    //#]
}

bool OMControlNode::atLeastOneInputHasToken(void) {
    //#[ operation atLeastOneInputHasToken()
    bool ans = false;
    
    for (OMIterator<OMActivityEdge*> iter(mInputFlows); iter.value(); iter++)
    {
    	OMActivityEdge* flow = iter.value();
    	if (flow && flow->isOfferingToken())
    	{
    		ans = true;
    		break;
    	}
    }
    
    return ans;
    //#]
}

bool OMControlNode::isReady(void) {
    //#[ operation isReady()
    return canControl();
    //#]
}

/*********************************************************************
	File Path	: ../OMControlNode.cpp
*********************************************************************/
