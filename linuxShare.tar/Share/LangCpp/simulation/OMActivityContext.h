/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: chaimcoh
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMActivityContext
//!	Generated Date	: Wed, 2, May 2012  
	File Path	: ../OMActivityContext.h
*********************************************************************/

#ifndef OMActivityContext_H
#define OMActivityContext_H

//## dependency OMAcceptEventAction
#include "OMAcceptEventAction.h"
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityFinalNode
#include "OMActivityFinalNode.h"
//## class OMActivityContext
#include "OMActivityManager.h"
//## dependency OMCallBehaviorAction
#include "OMCallBehaviorAction.h"
//## dependency OMContextualAction
#include "OMContextualAction.h"
//## dependency OMControlFlow
#include "OMControlFlow.h"
//## dependency OMDataFlow
#include "OMDataFlow.h"
//## dependency OMDecisionNode
#include "OMDecisionNode.h"
//## dependency OMFlowFinalNode
#include "OMFlowFinalNode.h"
//## dependency OMForkNode
#include "OMForkNode.h"
//## dependency OMInitialAction
#include "OMInitialAction.h"
//## dependency OMJoinNode
#include "OMJoinNode.h"
//## dependency OMMergeNode
#include "OMMergeNode.h"
//## dependency OMObjectNode
#include "OMObjectNode.h"
//## class OMActivityContext
#include <oxf/omreactive.h>
//## dependency OMSendEventAction
#include "OMSendEventAction.h"
// To enable generated "reusable" statechart (which uses OMState)
//## dependency OMState
#include <oxf/state.h>
//## dependency OMTimeEventAction
#include "OMTimeEventAction.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency AnimServices
class AnimServices;

//## package Activities

//## class OMActivityContext
class OMActivityContext : virtual public OMReactive, virtual public OMActivityManager {
public :

    //## operation OMActivityContext()
    OMActivityContext(void);
    
    //## operation ~OMActivityContext()
    virtual ~OMActivityContext(void);
    
    // initialize the reactive instance state machine
    //## operation startBehavior()
    virtual bool startBehavior(void);
    
    //## operation sendTimeEvent(int,OMString)
    virtual IOxfTimeout* sendTimeEvent(int duration, const OMString& action);

protected :

    //## operation rootState_entDef()
    virtual void rootState_entDef(void);
    
    // Argument IOxfEvent* ev :
    // The event to process
    //## operation processEvent(IOxfEvent)
    virtual IOxfReactive::TakeEventStatus processEvent(IOxfEvent* ev);
    
    //## operation createMainActivity()
    virtual OMActivity* createMainActivity(void);
    
    ////    Relations and components    ////
    
    OMActivity* mMainActivity;		//## link mMainActivity
};

#endif
/*********************************************************************
	File Path	: ../OMActivityContext.h
*********************************************************************/
