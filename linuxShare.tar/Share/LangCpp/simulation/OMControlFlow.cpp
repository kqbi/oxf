/********************************************************************
	Rhapsody	: 7.6 
	Login		: ehudho
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMControlFlow
//!	Generated Date	: Mon, 23, Apr 2012  
	File Path	: ../OMControlFlow.cpp
*********************************************************************/

//## auto_generated
#include "OMControlFlow.h"
//## dependency AOMSAttributes
//#[ ignore
#ifdef _OMINSTRUMENT

//#]
#include <aommsg.h>
#endif // _OMINSTRUMENT
//## auto_generated
#include "OMActivity.h"
//## auto_generated
#include "OMActivityNode.h"
//## package Activities

//## class OMControlFlow
OMControlFlow::~OMControlFlow(void) {
}

OMControlFlow::OMControlFlow(const OMString& id, OMActivity& parentActivity, OMActivityNode& fromAction, OMActivityNode& toAction) : OMActivityEdge(id, parentActivity, fromAction, toAction), mOfferedTokens(0) {
    //#[ operation OMControlFlow(OMString,OMActivity,OMActivityNode,OMActivityNode)
    //#]
}

void OMControlFlow::offerToken(void) {
    //#[ operation offerToken()
    mOfferedTokens++;
    
    OMString id = getId();
    mParentActivity->notifyTokenReady(id);
    
    if (mTargetAction->isReady())
    {
    	mTargetAction->visit();
    }
    //#]
}

void OMControlFlow::acceptToken(void) {
    //#[ operation acceptToken()
    if (isOfferingToken())
    {
    	mOfferedTokens--;
    	
    	OMString id = getId();
    	mParentActivity->notifyTokenConsumed(id);
    }
    //#]
}

bool OMControlFlow::isOfferingToken(void) {
    //#[ operation isOfferingToken()
    return mOfferedTokens > 0;
    //#]
}

bool OMControlFlow::isControl(void) {
    //#[ operation isControl()
    return true;
    //#]
}

int OMControlFlow::getTokenCount(void) {
    //#[ operation getTokenCount()
    return mOfferedTokens;
    //#]
}

/*********************************************************************
	File Path	: ../OMControlFlow.cpp
*********************************************************************/
