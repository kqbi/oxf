/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMObjectNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMObjectNode.h
*********************************************************************/

#ifndef OMObjectNode_H
#define OMObjectNode_H

//## class OMObjectNode
#include "OMActivityNode.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMObjectNode
class OMObjectNode : public OMActivityNode {
public :

    //## auto_generated
    virtual ~OMObjectNode(void);
    
    //## operation OMObjectNode(OMString,OMActivity)
    OMObjectNode(const OMString& id, OMActivity& parentActivity);
    
    //## operation isInitiallyReady()
    virtual bool isInitiallyReady(void);
    
    //## operation visit()
    virtual void visit(void);
    
    //## operation isReady()
    virtual bool isReady(void);
};

#endif
/*********************************************************************
	File Path	: ../OMObjectNode.h
*********************************************************************/
