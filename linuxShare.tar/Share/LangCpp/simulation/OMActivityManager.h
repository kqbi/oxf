/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: chaimcoh
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMActivityManager
//!	Generated Date	: Sun, 20, May 2012  
	File Path	: ../OMActivityManager.h
*********************************************************************/

#ifndef OMActivityManager_H
#define OMActivityManager_H

//## auto_generated
#include <oxf/omlist.h>
//## auto_generated
#include <aom/aommsg.h>
//## dependency AnimServices
//#[ ignore
#ifdef _OMINSTRUMENT

//#]
class AnimServices;

//#[ ignore


#endif // _OMINSTRUMENT
//#]
//## link mActivities
class OMActivity;

//## package Activities

//## class OMActivityManager

class IOxfTimeout;

class OMActivityManager {
    ////    Constructors and destructors    ////
    
public :

    //## operation ~OMActivityManager()
    virtual ~OMActivityManager(void);
    
    ////    Operations    ////
    
    //## operation deregisterActivity(OMActivity)
    void deregisterActivity(OMActivity& activity);
    
    //## operation getMe()
    virtual void * getMe(void);
    
    //## operation registerActivity(OMActivity)
    void registerActivity(OMActivity& activity);
    
    // This is a stub operation in case the activity wants to send timeout via its context.
    //## operation sendTimeEvent(int,OMString)
    virtual IOxfTimeout* sendTimeEvent(int, const OMString&);
    
    //## operation serializeActions(AOMSState)
    //#[ ignore
    #ifdef _OMINSTRUMENT
    
    //#]
    void serializeActions(AOMSState* aomState);
    //#[ ignore
    
    #endif // _OMINSTRUMENT
    //#]
    
    //## operation serializeFlows(AOMSAttributes&)
    //#[ ignore
    #ifdef _OMINSTRUMENT
    
    //#]
    void serializeFlows(AOMSAttributes& flows);
    //#[ ignore
    
    #endif // _OMINSTRUMENT
    //#]
    
    //## operation serializeTokens(AOMSAttributes&,const OMString&)
    //#[ ignore
    #ifdef _OMINSTRUMENT
    
    //#]
    void serializeTokens(AOMSAttributes& tokens, const OMString& elemId);
    //#[ ignore
    
    #endif // _OMINSTRUMENT
    //#]
    
    ////    Relations and components    ////

protected :

    OMList<OMActivity*> mActivities;		//## link mActivities
};

#endif
/*********************************************************************
	File Path	: ../OMActivityManager.h
*********************************************************************/
