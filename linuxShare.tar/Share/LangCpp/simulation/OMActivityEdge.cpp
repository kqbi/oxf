/********************************************************************
	Rhapsody	: 7.6 
	Login		: ehudho
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMActivityEdge
//!	Generated Date	: Mon, 23, Apr 2012  
	File Path	: ../OMActivityEdge.cpp
*********************************************************************/

//## auto_generated
#include "OMActivityEdge.h"
//## dependency AOMSAttributes
//#[ ignore
#ifdef _OMINSTRUMENT

//#]
#include <aommsg.h>
//#[ ignore


#endif // _OMINSTRUMENT
//#]
//## link mParentActivity
#include "OMActivity.h"
//## package Activities

//## class OMActivityEdge
OMActivityEdge::OMActivityEdge(const OMString& id, OMActivity& parentActivity, OMActivityNode& fromAction, OMActivityNode& toAction) : mId(id), mParentActivity(&parentActivity) {
    //#[ operation OMActivityEdge(OMString,OMActivity,OMActivityNode,OMActivityNode)
    mParentActivity->manage(*this);
    
    mSourceAction = &fromAction;
    mTargetAction = &toAction;
    
    mSourceAction->connectOutputFlow(*this);
    mTargetAction->connectInputFlow(*this);
    //#]
}

OMActivityEdge::~OMActivityEdge(void) {
    //#[ operation ~OMActivityEdge()
    //#]
}

OMString OMActivityEdge::getId(void) {
    //#[ operation getId()
    return mId;
    //#]
}

//#[ ignore
#ifdef _OMINSTRUMENT

//#]
void OMActivityEdge::serializeTokens(AOMSAttributes&) {
    //#[ operation serializeTokens(AOMSAttributes&)
    //#]
}
//#[ ignore


#endif // _OMINSTRUMENT
//#]

/*********************************************************************
	File Path	: ../OMActivityEdge.cpp
*********************************************************************/
