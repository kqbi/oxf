/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMContextualAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMContextualAction.h
*********************************************************************/

#ifndef OMContextualAction_H
#define OMContextualAction_H

//## class OMContextualAction
#include "OMAction.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMContextualAction
class OMContextualAction : public OMAction {
public :

    //## auto_generated
    virtual ~OMContextualAction(void);
    
    //## operation OMContextualAction(OMString,OMActivity)
    OMContextualAction(const OMString& id, OMActivity& parentActivity);
    
    //## operation execute()
    virtual void execute(void);

protected :

    //## operation invokeContextMethod()
    virtual void invokeContextMethod(void) = 0;
};

#endif
/*********************************************************************
	File Path	: ../OMContextualAction.h
*********************************************************************/
