/*********************************************************************
	Rhapsody	: 7.6 
	Login		: ehudho
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMActivity
//!	Generated Date	: Mon, 23, Apr 2012  
	File Path	: ../OMActivity.h
*********************************************************************/

#ifndef OMActivity_H
#define OMActivity_H

//## auto_generated
#include "ommap.h"
//## auto_generated
#include "omlist.h"
//## dependency IOxfReactive
#include "oxf/IOxfReactive.h"
//## dependency OMAcceptEventAction
#include "OMAcceptEventAction.h"
//## dependency OMReactive
#include "oxf/omreactive.h"
//## dependency AOMSAttributes
//#[ ignore
#ifdef _OMINSTRUMENT

//#]
class AOMSAttributes;

//#[ ignore


#endif // _OMINSTRUMENT
//#]
//## dependency AOMSState
//#[ ignore
#ifdef _OMINSTRUMENT

//#]
class AOMSState;

//#[ ignore


#endif // _OMINSTRUMENT
//#]
//## dependency AnimServices
//#[ ignore
#ifdef _OMINSTRUMENT

//#]
class AnimServices;

//#[ ignore


#endif // _OMINSTRUMENT
//#]
//## link mReadyActions
class OMAction;

//## link mManagedFlows
class OMActivityEdge;

//## link mContext
class OMActivityManager;

//## link mManagedNodes
class OMActivityNode;

//## dependency OMControlNode
class OMControlNode;

//## package Activities

//## class OMActivity
class OMActivity {
public :

    //## operation OMActivity(OMActivityManager*)
    OMActivity(OMActivityManager* context = NULL);
    
    //## operation ~OMActivity()
    virtual ~OMActivity(void);
    
    //## operation activate()
    virtual void activate(void);
    
    //## operation terminate()
    void terminate(void);
    
    //## operation hasTerminated()
    bool hasTerminated(void);
    
    // Argument IOxfEvent* ev :
    // The event to process
    //## operation handleEvent(IOxfEvent)
    virtual IOxfReactive::TakeEventStatus handleEvent(IOxfEvent* ev);
    
    //## operation sendTimeEvent(int,OMString)
    IOxfTimeout* sendTimeEvent(int duration, const OMString& action);
    
    //## operation manage(OMActivityNode)
    void manage(OMActivityNode& node);
    
    //## operation manage(OMActivityEdge)
    void manage(OMActivityEdge& flow);
    
    //## operation notifyStepStart()
    virtual void notifyStepStart(void);
    
    //## operation notifyStepEnd()
    virtual void notifyStepEnd(void);
    
    //## operation notifyEnterAction(OMString)
    void notifyEnterAction(OMString& actionId);
    
    //## operation notifyExitAction(OMString)
    void notifyExitAction(OMString& actionId);
    
    //## operation notifyEnterAcceptEvent(OMString)
    void notifyEnterAcceptEvent(OMString& actionId);
    
    //## operation notifyExitAcceptEvent(OMString)
    void notifyExitAcceptEvent(OMString& actionId);
    
    //## operation notifyEnterControlNode(OMString)
    void notifyEnterControlNode(OMString& actionId);
    
    //## operation notifyExitControlNode(OMString)
    void notifyExitControlNode(OMString& actionId);
    
    //## operation notifyTokenReady(OMString)
    void notifyTokenReady(OMString& flowId);
    
    //## operation notifyTokenConsumed(OMString)
    void notifyTokenConsumed(OMString& flowId);
    
    //## operation serializeActions(AOMSState) const
    //#[ ignore
    #ifdef _OMINSTRUMENT
    
    //#]
    void serializeActions(AOMSState& aomState) const;
    //#[ ignore
    
    #endif // _OMINSTRUMENT
    //#]
    
    //## operation serializeTokens(AOMSAttributes&,const OMString&)
    //#[ ignore
    #ifdef _OMINSTRUMENT
    
    //#]
    void serializeTokens(AOMSAttributes& tokens, const OMString& elemId);
    //#[ ignore
    
    #endif // _OMINSTRUMENT
    //#]
    
    //## operation serializeFlows(AOMSAttributes&)
    //#[ ignore
    #ifdef _OMINSTRUMENT
    
    //#]
    void serializeFlows(AOMSAttributes& flows);
    //#[ ignore
    
    #endif // _OMINSTRUMENT
    //#]

protected :

    //## operation prepareInitialNodes()
    void prepareInitialNodes(void);
    
    //## operation execute()
    virtual void execute(void);

private :

    //## operation addReadyAction(OMAction)
    void addReadyAction(OMAction& action);
    
    //## operation removeReadyAction(OMAction)
    void removeReadyAction(OMAction& action);
    
    //## operation registerEventAcceptor(OMAcceptEventAction)
    void registerEventAcceptor(OMAcceptEventAction& acceptor);
    
    //## operation deregisterEventAcceptor(OMAcceptEventAction)
    void deregisterEventAcceptor(const OMAcceptEventAction& acceptor);
    
    ////    Attributes    ////

public :

    int mTokenCount;		//## attribute mTokenCount

private :

    bool mIsActive;		//## attribute mIsActive
    
    ////    Relations and components    ////

protected :

    OMActivityManager* mContext;		//## link mContext
    
    OMMap<OMAcceptEventAction::AcceptEventID, OMAcceptEventAction*> mEventAcceptors;		//## link mEventAcceptors
    
    OMMap<OMString, OMActivityEdge*> mManagedFlows;		//## link mManagedFlows
    
    OMMap<OMString, OMActivityNode*> mManagedNodes;		//## link mManagedNodes
    
    OMList<OMAction*> mReadyActions;		//## link mReadyActions
};

#endif
/*********************************************************************
	File Path	: ../OMActivity.h
*********************************************************************/
