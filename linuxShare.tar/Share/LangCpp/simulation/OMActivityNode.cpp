/********************************************************************
	Rhapsody	: 7.6 
	Login		: ehudho
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMActivityNode
//!	Generated Date	: Mon, 23, Apr 2012  
	File Path	: ../OMActivityNode.cpp
*********************************************************************/

//## auto_generated
#include "OMActivityNode.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMActivityNode
OMActivityNode::OMActivityNode(const OMString& id, OMActivity& parentActivity) : mId(id), mIsActive(false), mParentActivity(&parentActivity), mInputFlows(), mOutputFlows() {
    //#[ operation OMActivityNode(OMString,OMActivity)
    mParentActivity->manage(*this);
    //#]
}

OMActivityNode::~OMActivityNode(void) {
    //#[ operation ~OMActivityNode()
    //#]
}

OMString OMActivityNode::getId(void) {
    //#[ operation getId()
    return mId;
    //#]
}

void OMActivityNode::activate(void) {
    //#[ operation activate()
    mIsActive = true;
    //#]
}

void OMActivityNode::deactivate(void) {
    //#[ operation deactivate()
    mIsActive = false;
    //#]
}

bool OMActivityNode::isActive(void) {
    //#[ operation isActive()
    return mIsActive;
    //#]
}

void OMActivityNode::connectOutputFlow(OMActivityEdge& flow) {
    //#[ operation connectOutputFlow(OMActivityEdge)
    mOutputFlows.add(flow.getId(), &flow);
    //#]
}

void OMActivityNode::connectInputFlow(OMActivityEdge& flow) {
    //#[ operation connectInputFlow(OMActivityEdge)
    mInputFlows.add(flow.getId(), &flow);
    //#]
}

OMActivityEdge* OMActivityNode::getOutputFlow(const OMString& id) {
    //#[ operation getOutputFlow(OMString)
    return mOutputFlows.getKey(id);
    //#]
}

OMActivityEdge* OMActivityNode::getInputFlow(const OMString& id) {
    //#[ operation getInputFlow(OMString)
    return mInputFlows.getKey(id);
    //#]
}

void OMActivityNode::produceTokens(void) {
    //#[ operation produceTokens()
    OMList<OMString> flowIds = filterPassableFlows();
    for (OMIterator<OMString> flowId(flowIds); flowId.value(); flowId++)
    {   
    	OMActivityEdge* flow = mOutputFlows[flowId.value()];
    	if (flow)
    	{
    		flow->offerToken();
    	}
    }
    //#]
}

void OMActivityNode::consumeTokens(void) {
    //#[ operation consumeTokens()
    for (OMIterator<OMActivityEdge*> iter(mInputFlows); iter.value(); iter++)
    {   
    	OMActivityEdge* flow = iter.value();
    	if (flow)
    	{
    		flow->acceptToken();
    	}
    }
    //#]
}

bool OMActivityNode::allInputsHaveToken(void) {
    //#[ operation allInputsHaveToken()
    bool ans = true;
    
    for (OMIterator<OMActivityEdge*> iter(mInputFlows); ans && iter.value(); iter++)
    {   
    	OMActivityEdge* flow = iter.value();
    	if (flow && !flow->isOfferingToken())
    	{
    		ans = false;
    	}
    }
    
    return ans;
    //#]
}

//#[ ignore
#ifdef _OMINSTRUMENT

//#]
void OMActivityNode::serializeTokens(AOMSAttributes&) {
    //#[ operation serializeTokens(AOMSAttributes&)
    //#]
}
//#[ ignore


#endif // _OMINSTRUMENT
//#]

/*********************************************************************
	File Path	: ../OMActivityNode.cpp
*********************************************************************/
