/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMContextualAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMContextualAction.cpp
*********************************************************************/

//## auto_generated
#include "OMContextualAction.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMContextualAction
OMContextualAction::~OMContextualAction(void) {
}

OMContextualAction::OMContextualAction(const OMString& id, OMActivity& parentActivity) : OMAction(id, parentActivity) {
    //#[ operation OMContextualAction(OMString,OMActivity)
    //#]
}

void OMContextualAction::execute(void) {
    //#[ operation execute()
    consumeTokens();
    invokeContextMethod();
    mParentActivity->notifyExitAction(mId);
    produceTokens();
    //#]
}

/*********************************************************************
	File Path	: ../OMContextualAction.cpp
*********************************************************************/
