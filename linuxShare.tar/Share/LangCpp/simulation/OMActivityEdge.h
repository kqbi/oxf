/*********************************************************************
	Rhapsody	: 7.6 
	Login		: ehudho
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMActivityEdge
//!	Generated Date	: Mon, 23, Apr 2012  
	File Path	: ../OMActivityEdge.h
*********************************************************************/

#ifndef OMActivityEdge_H
#define OMActivityEdge_H

//## dependency OMActivityNode
#include "OMActivityNode.h"
//## auto_generated
#include "OXFTypes.h"
//## dependency AOMSAttributes
//#[ ignore
#ifdef _OMINSTRUMENT

//#]
class AOMSAttributes;

//#[ ignore


#endif // _OMINSTRUMENT
//#]
//## link mParentActivity
class OMActivity;

//## package Activities

//## class OMActivityEdge
class OMActivityEdge {
public :

    //## operation OMActivityEdge(OMString,OMActivity,OMActivityNode,OMActivityNode)
    OMActivityEdge(const OMString& id, OMActivity& parentActivity, OMActivityNode& fromAction, OMActivityNode& toAction);
    
    //## operation ~OMActivityEdge()
    virtual ~OMActivityEdge(void);
    
    //## operation getId()
    OMString getId(void);
    
    //## operation offerToken()
    virtual void offerToken(void) = 0;
    
    //## operation acceptToken()
    virtual void acceptToken(void) = 0;
    
    //## operation isOfferingToken()
    virtual bool isOfferingToken(void) = 0;
    
    //## operation isControl()
    virtual bool isControl(void) = 0;
    
    //## operation getTokenCount()
    virtual int getTokenCount(void) = 0;
    
    //## operation serializeTokens(AOMSAttributes&)
    //#[ ignore
    #ifdef _OMINSTRUMENT
    
    //#]
    virtual void serializeTokens(AOMSAttributes&);
    //#[ ignore
    
    #endif // _OMINSTRUMENT
    //#]
    
    ////    Attributes    ////

private :

    OMString mId;		//## attribute mId
    
    ////    Relations and components    ////

protected :

    OMActivity* mParentActivity;		//## link mParentActivity
    
    OMActivityNode* mSourceAction;		//## link mSourceAction
    
    OMActivityNode* mTargetAction;		//## link mTargetAction
};

#endif
/*********************************************************************
	File Path	: ../OMActivityEdge.h
*********************************************************************/
