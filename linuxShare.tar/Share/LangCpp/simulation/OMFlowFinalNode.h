/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMFlowFinalNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMFlowFinalNode.h
*********************************************************************/

#ifndef OMFlowFinalNode_H
#define OMFlowFinalNode_H

//## class OMFlowFinalNode
#include "OMControlNode.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMFlowFinalNode
class OMFlowFinalNode : public OMControlNode {
public :

    //## auto_generated
    virtual ~OMFlowFinalNode(void);
    
    //## operation OMFlowFinalNode(OMString,OMActivity)
    OMFlowFinalNode(const OMString& id, OMActivity& parentActivity);

protected :

    //## operation control()
    virtual void control(void);
    
    //## operation canControl()
    virtual bool canControl(void);
    
    //## operation filterPassableFlows()
    virtual OMList<OMString> filterPassableFlows(void);
};

#endif
/*********************************************************************
	File Path	: ../OMFlowFinalNode.h
*********************************************************************/
