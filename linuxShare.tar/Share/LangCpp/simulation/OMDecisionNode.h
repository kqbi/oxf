/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMDecisionNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMDecisionNode.h
*********************************************************************/

#ifndef OMDecisionNode_H
#define OMDecisionNode_H

//## class OMDecisionNode
#include "OMControlNode.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMDecisionNode
class OMDecisionNode : public OMControlNode {
public :

    //## auto_generated
    virtual ~OMDecisionNode(void);
    
    //## operation OMDecisionNode(OMString,OMActivity)
    OMDecisionNode(const OMString& id, OMActivity& parentActivity);

protected :

    //## operation canControl()
    virtual bool canControl(void);
    
    //## operation produceTokens()
    virtual void produceTokens(void);
};

#endif
/*********************************************************************
	File Path	: ../OMDecisionNode.h
*********************************************************************/
