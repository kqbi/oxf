/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMForkNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMForkNode.h
*********************************************************************/

#ifndef OMForkNode_H
#define OMForkNode_H

//## class OMForkNode
#include "OMControlNode.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMForkNode
class OMForkNode : public OMControlNode {
public :

    //## auto_generated
    virtual ~OMForkNode(void);
    
    //## operation OMForkNode(OMString,OMActivity)
    OMForkNode(const OMString& id, OMActivity& parentActivity);

protected :

    //## operation canControl()
    virtual bool canControl(void);
};

#endif
/*********************************************************************
	File Path	: ../OMForkNode.h
*********************************************************************/
