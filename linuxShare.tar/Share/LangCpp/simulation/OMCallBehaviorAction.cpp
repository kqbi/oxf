/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMCallBehaviorAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMCallBehaviorAction.cpp
*********************************************************************/

//## auto_generated
#include "OMCallBehaviorAction.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMCallBehaviorAction
OMCallBehaviorAction::OMCallBehaviorAction(const OMString& id, OMActivity& parentActivity, OMActivity& referencedActivity) : OMAction(id, parentActivity), mReferencedActivity(&referencedActivity) {
    //#[ operation OMCallBehaviorAction(OMString,OMActivity,OMActivity)
    //#]
}

OMCallBehaviorAction::~OMCallBehaviorAction(void) {
    //#[ operation ~OMCallBehaviorAction()
    delete mReferencedActivity;
    //#]
}

void OMCallBehaviorAction::execute(void) {
    //#[ operation execute()
    consumeTokens();
    
    if (mReferencedActivity)
    {                       
    	setParametersFromPins();	
    	mReferencedActivity->activate();
     
     	mParentActivity->notifyExitAction(mId);                        
    	
    	if (mReferencedActivity->hasTerminated())
    	{
    		setPinsFromParameters();                                                  	
    		produceTokens();
    	}                       
    }
    //#]
}

/*********************************************************************
	File Path	: ../OMCallBehaviorAction.cpp
*********************************************************************/
