/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMAction.cpp
*********************************************************************/

//## auto_generated
#include "OMAction.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMAction
OMAction::~OMAction(void) {
}

OMAction::OMAction(const OMString& id, OMActivity& parentActivity) : OMActivityNode(id, parentActivity) {
    //#[ operation OMAction(OMString,OMActivity)
    //#]
}

void OMAction::visit(void) {
    //#[ operation visit()
    mParentActivity->notifyEnterAction(mId);
    //#]
}

bool OMAction::isInitiallyReady(void) {
    //#[ operation isInitiallyReady()
    return mInputFlows.isEmpty() ? true : false;
    //#]
}

bool OMAction::isReady(void) {
    //#[ operation isReady()
    return !mInputFlows.isEmpty() && allInputsHaveToken(); // without flows, an action is never ready (except "initiallyReady")
    //#]
}

/*********************************************************************
	File Path	: ../OMAction.cpp
*********************************************************************/
