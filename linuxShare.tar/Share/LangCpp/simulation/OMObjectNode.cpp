/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMObjectNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMObjectNode.cpp
*********************************************************************/

//## auto_generated
#include "OMObjectNode.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMObjectNode
OMObjectNode::~OMObjectNode(void) {
}

OMObjectNode::OMObjectNode(const OMString& id, OMActivity& parentActivity) : OMActivityNode(id, parentActivity) {
    //#[ operation OMObjectNode(OMString,OMActivity)
    //#]
}

bool OMObjectNode::isInitiallyReady(void) {
    //#[ operation isInitiallyReady()
    return false;
    //#]
}

void OMObjectNode::visit(void) {
    //#[ operation visit()
    mParentActivity->notifyEnterControlNode(mId);
    	
    consumeTokens();
    produceTokens();
    	
    mParentActivity->notifyExitControlNode(mId);
    //#]
}

bool OMObjectNode::isReady(void) {
    //#[ operation isReady()
    return true;
    //#]
}

/*********************************************************************
	File Path	: ../OMObjectNode.cpp
*********************************************************************/
