/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMTimeEventAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMTimeEventAction.h
*********************************************************************/

#ifndef OMTimeEventAction_H
#define OMTimeEventAction_H

//## class OMTimeEventAction
#include "OMAcceptEventAction.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMTimeEventAction
class OMTimeEventAction : public OMAcceptEventAction {
public :

    //## auto_generated
    virtual ~OMTimeEventAction(void);
    
    //## operation OMTimeEventAction(OMString,OMActivity,int)
    OMTimeEventAction(const OMString& id, OMActivity& parentActivity, int duration);
    
    //## operation visit()
    virtual void visit(void);
    
    //## operation execute()
    virtual void execute(void);
    
    //## operation getAcceptEventId() const
    virtual OMAcceptEventAction::AcceptEventID getAcceptEventId(void) const;
    
    //## operation acceptEventData()
    virtual void acceptEventData(void);
    
    ////    Attributes    ////

private :

    OMAcceptEventAction::AcceptEventID mAcceptEventId;		//## attribute mAcceptEventId
    
    int mDuration;		//## attribute mDuration
};

#endif
/*********************************************************************
	File Path	: ../OMTimeEventAction.h
*********************************************************************/
