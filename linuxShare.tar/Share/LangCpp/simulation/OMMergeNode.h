/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMMergeNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMMergeNode.h
*********************************************************************/

#ifndef OMMergeNode_H
#define OMMergeNode_H

//## class OMMergeNode
#include "OMControlNode.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMMergeNode
class OMMergeNode : public OMControlNode {
public :

    //## auto_generated
    virtual ~OMMergeNode(void);
    
    //## operation OMMergeNode(OMString,OMActivity)
    OMMergeNode(const OMString& id, OMActivity& parentActivity);

protected :

    //## operation canControl()
    virtual bool canControl(void);
};

#endif
/*********************************************************************
	File Path	: ../OMMergeNode.h
*********************************************************************/
