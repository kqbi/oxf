/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMTimeEventAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMTimeEventAction.cpp
*********************************************************************/

//## auto_generated
#include "OMTimeEventAction.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMTimeEventAction
OMTimeEventAction::~OMTimeEventAction(void) {
}

OMTimeEventAction::OMTimeEventAction(const OMString& id, OMActivity& parentActivity, int duration) : OMAcceptEventAction(id, parentActivity, OMTimeoutEventId), mAcceptEventId(""), mDuration(duration) {
    //#[ operation OMTimeEventAction(OMString,OMActivity,int)
    //#]
}

void OMTimeEventAction::visit(void) {
    //#[ operation visit()
    consumeTokens();
    
    IOxfTimeout* sentEvent = mParentActivity->sendTimeEvent(mDuration, mId);
    mAcceptEventId = sentEvent;
    
    mParentActivity->notifyEnterAcceptEvent(mId);
    //#]
}

void OMTimeEventAction::execute(void) {
    //#[ operation execute()
    mParentActivity->notifyExitAcceptEvent(mId);
    produceTokens();
    //#]
}

OMAcceptEventAction::AcceptEventID OMTimeEventAction::getAcceptEventId(void) const {
    //#[ operation getAcceptEventId() const
    return mAcceptEventId;
    //#]
}

void OMTimeEventAction::acceptEventData(void) {
    //#[ operation acceptEventData()
    //#]
}

/*********************************************************************
	File Path	: ../OMTimeEventAction.cpp
*********************************************************************/
