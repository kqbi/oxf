/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMSendEventAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMSendEventAction.cpp
*********************************************************************/

//## auto_generated
#include "OMSendEventAction.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMSendEventAction
OMSendEventAction::~OMSendEventAction(void) {
}

OMSendEventAction::OMSendEventAction(const OMString& id, OMActivity& parentActivity) : OMAction(id, parentActivity) {
    //#[ operation OMSendEventAction(OMString,OMActivity)
    //#]
}

void OMSendEventAction::execute(void) {
    //#[ operation execute()
    consumeTokens();
    sendEvent();
    mParentActivity->notifyExitAction(mId);
    produceTokens();
    //#]
}

/*********************************************************************
	File Path	: ../OMSendEventAction.cpp
*********************************************************************/
