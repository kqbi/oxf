/********************************************************************
	Rhapsody	: 7.6 
	Login		: ehudho
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMActivity
//!	Generated Date	: Mon, 13, Aug 2012  
	File Path	: ../OMActivity.cpp
*********************************************************************/

//## auto_generated
#include "OMActivity.h"
//## dependency AnimServices
//#[ ignore
#ifdef _OMINSTRUMENT

//#]
#include <aom/AnimServices.h>
//#[ ignore


#endif // _OMINSTRUMENT
//#]
//## dependency AOMSAttributes
//#[ ignore
#ifdef _OMINSTRUMENT

//#]
#include <aommsg.h>
//#[ ignore


#endif // _OMINSTRUMENT
//#]
//## link mReadyActions
#include "OMAction.h"
//## link mManagedFlows
#include "OMActivityEdge.h"
//## link mContext
#include "OMActivityManager.h"
//## link mManagedNodes
#include "OMActivityNode.h"
//## dependency OMControlNode
#include "OMControlNode.h"
//## package Activities

//## class OMActivity

//#[ ignore
#define eventNotConsumed IOxfReactive::eventNotConsumed
#define eventConsumed IOxfReactive::eventConsumed

//#]


OMActivity::OMActivity(OMActivityManager* context) : mIsActive(false), mContext(context), mEventAcceptors(), mManagedFlows(), mManagedNodes() {
    //#[ operation OMActivity(OMActivityManager*)
    if (mContext)
    {
    	mContext->registerActivity(*this);
    }
    //#]
}

OMActivity::~OMActivity(void) {
    //#[ operation ~OMActivity()
    terminate();
    
    if (mContext)
    {
    	mContext->deregisterActivity(*this);
    }
    
    for (OMIterator<OMActivityEdge*> managedFlowsIterator(mManagedFlows); managedFlowsIterator.value(); managedFlowsIterator++)
    {
    	OMActivityEdge* flow = managedFlowsIterator.value();
    	delete flow;
    	flow = NULL;
    }
    mManagedFlows.removeAll();
    
    
    for (OMIterator<OMActivityNode*> managedNodesIterator(mManagedNodes); managedNodesIterator.value(); managedNodesIterator++)
    {
    	OMActivityNode* node = managedNodesIterator.value();
    	delete node;
    	node = NULL; 
    }                         
    mManagedNodes.removeAll();
    //#]
}

void OMActivity::activate(void) {
    //#[ operation activate()
    mTokenCount = 0;
    mIsActive = true;
    
    prepareInitialNodes();
    execute();
    //#]
}

void OMActivity::terminate(void) {
    //#[ operation terminate()
    //terminate all ready actions
    OMList<OMAction*> readyActionsCopy(mReadyActions);
    for (OMIterator<OMAction*> readyActionsIterator(readyActionsCopy); readyActionsIterator.value(); readyActionsIterator++)
    {
    	OMAction* action = readyActionsIterator.value();
    	OMString id = action->getId();
    	notifyExitAction(id);
    }
    mReadyActions.removeAll();
    
    // terminate all remaining (control) nodes
    OMMap<OMString, OMActivityNode*> nodes(mManagedNodes);
    for (OMIterator<OMActivityNode*> nodesIterator(nodes); nodesIterator.value(); nodesIterator++)
    {
    	OMActivityNode* node = nodesIterator.value();
    	if (node->isActive())
    	{
    		OMString id = node->getId();
    		notifyExitControlNode(id);
    	}
    }
    
    // terminate all acceptEvents
    OMMap<OMAcceptEventAction::AcceptEventID, OMAcceptEventAction*> eventAcceptorsCopy(mEventAcceptors);
    for (OMIterator<OMAcceptEventAction*> acceptorsIterator(eventAcceptorsCopy); acceptorsIterator.value(); acceptorsIterator++)
    {
    	OMAcceptEventAction* acceptor = acceptorsIterator.value();
    	OMString id = acceptor->getId();
    	notifyExitAcceptEvent(id);
    }                         
    mEventAcceptors.removeAll();
     
    // terminate all flows - i.e., offered tokens
    for (OMIterator<OMActivityEdge*> managedFlowsIterator(mManagedFlows); managedFlowsIterator.value(); managedFlowsIterator++)
    {
    	OMActivityEdge* flow = managedFlowsIterator.value();
    	if (flow)
    	{
    		flow->acceptToken();	
    	}
    }
    
    mIsActive = false;
    //#]
}

bool OMActivity::hasTerminated(void) {
    //#[ operation hasTerminated()
    return !mIsActive || (mTokenCount == 0);
    //#]
}

IOxfReactive::TakeEventStatus OMActivity::handleEvent(IOxfEvent* ev) {
    //#[ operation handleEvent(IOxfEvent)
    IOxfReactive::TakeEventStatus status = eventNotConsumed;
    
    if (mIsActive && ev)
    {   
    	OMAcceptEventAction::AcceptEventID key(ev);
    	OMAcceptEventAction* acceptor = mEventAcceptors.getKey(key);
    	
    	if (acceptor)
    	{   
    		notifyStepStart();
    		acceptor->execute();
    		notifyStepEnd();
    		
    		// revisit to make it ready again, if possible
    		if (acceptor->isReady())
    		{
    			notifyStepStart();
    			acceptor->visit();
    			notifyStepEnd();
    		}
    		
    		// synch. execution - execute whatever possible before returning the control
    		execute();
    		
    		status = eventConsumed;
    	}
    }
    
    return status;
    //#]
}

IOxfTimeout* OMActivity::sendTimeEvent(int duration, const OMString& action) {
    //#[ operation sendTimeEvent(int,OMString)
    return mContext->sendTimeEvent(duration, action);
    //#]
}

void OMActivity::manage(OMActivityNode& node) {
    //#[ operation manage(OMActivityNode)
    mManagedNodes.add(node.getId(), &node);
    //#]
}

void OMActivity::manage(OMActivityEdge& flow) {
    //#[ operation manage(OMActivityEdge)
    mManagedFlows.add(flow.getId(), &flow);
    //#]
}

void OMActivity::notifyStepStart(void) {
    //#[ operation notifyStepStart()
    #ifdef _OMINSTRUMENT
    if (mContext)
    {
    	AnimServices::notifyActionStepStarted(mContext);
    }
    #endif // _OMINSTRUMENT
    //#]
}

void OMActivity::notifyStepEnd(void) {
    //#[ operation notifyStepEnd()
    #ifdef _OMINSTRUMENT
    if (mContext)
    {
    	AnimServices::notifyActionStepEnd();
    }
    #endif // _OMINSTRUMEN
    //#]
}

void OMActivity::notifyEnterAction(OMString& actionId) {
    //#[ operation notifyEnterAction(OMString)
    if (mIsActive)
    {
    	OMAction* action = (OMAction*)(mManagedNodes.getKey(actionId));
    	if (action)
    	{
    		if (!action->isActive())
    		{
    			addReadyAction(*action);
    			action->activate();
    		
    			#ifdef _OMINSTRUMENT
    			if (mContext)
    			{
    				AnimServices::notifyActionReady(mContext, actionId);
    			}
    			#endif // _OMINSTRUMENT
    		}
    	}
    }
    //#]
}

void OMActivity::notifyExitAction(OMString& actionId) {
    //#[ operation notifyExitAction(OMString)
    if (mIsActive)
    {
    	OMAction* action = (OMAction*)(mManagedNodes.getKey(actionId));
    	if (action)
    	{   
    		if (action->isActive())
    		{
    			removeReadyAction(*action);
    			action->deactivate();
    			
    			#ifdef _OMINSTRUMENT
    			if (mContext)
    			{
    				AnimServices::notifyActionDone(mContext, actionId);
    			}
    			#endif // _OMINSTRUMENT
    		}
    	}
    }
    //#]
}

void OMActivity::notifyEnterAcceptEvent(OMString& actionId) {
    //#[ operation notifyEnterAcceptEvent(OMString)
    if (mIsActive)
    {
    	OMAcceptEventAction* eventAcceptor = (OMAcceptEventAction*)(mManagedNodes.getKey(actionId));
    	if (eventAcceptor)
    	{
    		if (!eventAcceptor->isActive())
    		{
    			registerEventAcceptor(*eventAcceptor);
    			eventAcceptor->activate();                                       
    		
    			#ifdef _OMINSTRUMENT
    			if (mContext)
    			{
    				AnimServices::notifyActionReady(mContext, actionId);
    			}
    			#endif // _OMINSTRUMENT
    		}
    	}
    }
    //#]
}

void OMActivity::notifyExitAcceptEvent(OMString& actionId) {
    //#[ operation notifyExitAcceptEvent(OMString)
    if (mIsActive)
    {
    	OMAcceptEventAction* eventAcceptor = (OMAcceptEventAction*)(mManagedNodes.getKey(actionId));
    	if (eventAcceptor)
    	{   
    		if (eventAcceptor->isActive())
    		{
    			deregisterEventAcceptor(*eventAcceptor);
    			eventAcceptor->deactivate(); 
    		
    			#ifdef _OMINSTRUMENT
    			if (mContext)
    			{
    				AnimServices::notifyActionDone(mContext, actionId);
    			}
    			#endif // _OMINSTRUMENT
    		}
    	}
    }
    //#]
}

void OMActivity::notifyEnterControlNode(OMString& actionId) {
    //#[ operation notifyEnterControlNode(OMString)
    if (mIsActive)
    {
    	OMControlNode* controlNode = (OMControlNode*)(mManagedNodes.getKey(actionId));
    	if (controlNode) // prevent double activation 
    	{   
    		if (!controlNode->isActive())
    		{
    			controlNode->activate();
    			
    			#ifdef _OMINSTRUMENT
    			if (mContext)
    			{
    				AnimServices::notifyActionReady(mContext, actionId);
    			}
    			#endif // _OMINSTRUMENT
    		}
    	}
    }
    //#]
}

void OMActivity::notifyExitControlNode(OMString& actionId) {
    //#[ operation notifyExitControlNode(OMString)
    if (mIsActive)
    {
    	OMControlNode* controlNode = (OMControlNode*)(mManagedNodes.getKey(actionId));
    	if (controlNode)  // prevent double deactivation
    	{   
    		if (controlNode->isActive())
    		{
    			controlNode->deactivate();
    			
    			#ifdef _OMINSTRUMENT
    			if (mContext)
    			{
    				AnimServices::notifyActionDone(mContext, actionId);
    			}
    			#endif // _OMINSTRUMENT
    		}
    	}
    }
    //#]
}

void OMActivity::notifyTokenReady(OMString& flowId) {
    //#[ operation notifyTokenReady(OMString)
    if (mIsActive)
    {
    	OMActivityEdge* flow = mManagedFlows.getKey(flowId);
    	if (flow)
    	{
    		mTokenCount++;
    		
    		#ifdef _OMINSTRUMENT
    		if (mContext)
    		{   
    			int tokenCount = flow->getTokenCount();
    			AnimServices::notifyTokenReady(mContext, flowId, tokenCount);
    		}
    		#endif // _OMINSTRUMENT
    	}
    }
    //#]
}

void OMActivity::notifyTokenConsumed(OMString& flowId) {
    //#[ operation notifyTokenConsumed(OMString)
    if (mIsActive)
    {
    	OMActivityEdge* flow = mManagedFlows.getKey(flowId);
    	if (flow)
    	{
    		mTokenCount--;
    		
    		#ifdef _OMINSTRUMENT
    		if (mContext /*&& !flow->isOfferingToken()*/)
    		{  
    			int tokenCount = flow->getTokenCount();
    			AnimServices::notifyTokenConsumed(mContext, flowId, tokenCount);
    		}
    		#endif // _OMINSTRUMENT
    	}
    }
    //#]
}

//#[ ignore
#ifdef _OMINSTRUMENT

//#]
void OMActivity::serializeActions(AOMSState& aomState) const {
    //#[ operation serializeActions(AOMSState) const
    for (OMIterator<OMActivityNode*> activityNodesIterator(mManagedNodes); activityNodesIterator.value(); activityNodesIterator++)
    {
    	OMActivityNode* node = activityNodesIterator.value();
    	if (node->isActive())
    	{
    		OMString id = node->getId();
    		aomState.addState(id);
    	}
    }
    //#]
}
//#[ ignore


#endif // _OMINSTRUMENT
//#]

void OMActivity::prepareInitialNodes(void) {
    //#[ operation prepareInitialNodes()
    if (mIsActive)
    {
    	notifyStepStart();
    	
    	for (OMIterator<OMActivityNode*> managedNodesIterator(mManagedNodes); managedNodesIterator.value(); managedNodesIterator++)
    	{   
    		OMActivityNode* node = managedNodesIterator.value();
    		if (node && node->isInitiallyReady())          
    		{
    			node->visit();
    		}
    	}
    	
    	notifyStepEnd();
    }
    //#]
}

void OMActivity::execute(void) {
    //#[ operation execute()
    while (mIsActive && !mReadyActions.isEmpty())
    {   
    	OMAction* action = mReadyActions.getFirstConcept();
    	
    	if (action)          
    	{ 
    		notifyStepStart();
    		action->execute();
    		notifyStepEnd();   
    		
    		// revisit to make it ready again, if possible
    		if (action->isReady())
    		{
    			notifyStepStart();
    			action->visit();
    			notifyStepEnd();
    		}
    	}                          
    }
    //#]
}

void OMActivity::addReadyAction(OMAction& action) {
    //#[ operation addReadyAction(OMAction)
    mReadyActions.add(&action);
    //#]
}

void OMActivity::removeReadyAction(OMAction& action) {
    //#[ operation removeReadyAction(OMAction)
    mReadyActions.remove(&action);
    //#]
}

void OMActivity::registerEventAcceptor(OMAcceptEventAction& acceptor) {
    //#[ operation registerEventAcceptor(OMAcceptEventAction)
    mEventAcceptors.add(acceptor.getAcceptEventId(), &acceptor);
    //#]
}

void OMActivity::deregisterEventAcceptor(const OMAcceptEventAction& acceptor) {
    //#[ operation deregisterEventAcceptor(OMAcceptEventAction)
    mEventAcceptors.remove(acceptor.getAcceptEventId());
    //#]
}

//#[ ignore
#ifdef _OMINSTRUMENT

//#]
void OMActivity::serializeTokens(AOMSAttributes& tokens, const OMString& elemId) {
    //#[ operation serializeTokens(AOMSAttributes&,const OMString&)
    OMActivityNode* node = (OMActivityNode*)(mManagedNodes.getKey(elemId));
    if(node)
    {
    	node->serializeTokens(tokens);
    }
    else
    {   
    	OMActivityEdge* flow = mManagedFlows.getKey(elemId);
        if (flow)
     	{
    		flow->serializeTokens(tokens);
    	}   	
    }
    //#]
}
//#[ ignore


#endif // _OMINSTRUMENT
//#]

//#[ ignore
#ifdef _OMINSTRUMENT

//#]
void OMActivity::serializeFlows(AOMSAttributes& flows) {
    //#[ operation serializeFlows(AOMSAttributes&)
    for (OMIterator<OMActivityEdge*> managedFlowsIterator(mManagedFlows); managedFlowsIterator.value(); managedFlowsIterator++)
    {
        OMActivityEdge* flow = managedFlowsIterator.value();
        if (flow && flow->getTokenCount() > 0)  
        {     
           	char* tokenCountStr = new char[10]; //would be deleted in 'flows.addAttribute'
           	OMitoa(flow->getTokenCount(), tokenCountStr, 10);
           	flows.addAttribute(flow->getId(), tokenCountStr);
        }
    }
    //#]
}
//#[ ignore


#endif // _OMINSTRUMENT
//#]

/*********************************************************************
	File Path	: ../OMActivity.cpp
*********************************************************************/
