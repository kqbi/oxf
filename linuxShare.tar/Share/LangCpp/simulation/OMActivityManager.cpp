/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: chaimcoh
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMActivityManager
//!	Generated Date	: Sun, 20, May 2012  
	File Path	: ../OMActivityManager.cpp
*********************************************************************/

//## auto_generated
#include "OMActivityManager.h"
//## dependency AnimServices
//#[ ignore
#ifdef _OMINSTRUMENT

//#]
#include <aom/AnimServices.h>
//#[ ignore


#endif // _OMINSTRUMENT
//#]
//## link mActivities
#include "OMActivity.h"
//## package Activities

//## class OMActivityManager
OMActivityManager::~OMActivityManager(void) {
    //#[ operation ~OMActivityManager()
    mActivities.removeAll();
    //#]
}

void OMActivityManager::deregisterActivity(OMActivity& activity) {
    //#[ operation deregisterActivity(OMActivity)
    mActivities.remove(&activity);
    //#]
}

void * OMActivityManager::getMe(void) {
    //#[ operation getMe()
    return this;
    //#]
}

void OMActivityManager::registerActivity(OMActivity& activity) {
    //#[ operation registerActivity(OMActivity)
    mActivities.add(&activity);
    //#]
}

IOxfTimeout* OMActivityManager::sendTimeEvent(int, const OMString&) {
    //#[ operation sendTimeEvent(int,OMString)
    return NULL;
    //#]
}

//#[ ignore
#ifdef _OMINSTRUMENT

//#]
void OMActivityManager::serializeActions(AOMSState* aomState) {
    //#[ operation serializeActions(AOMSState)
    if (aomState)
    {   
    	for (OMIterator<OMActivity*> activitiesIterator(mActivities); activitiesIterator.value(); activitiesIterator++)
    	{
    		OMActivity* activity = activitiesIterator.value();
    		activity->serializeActions(*aomState);
    	}
    }
    //#]
}
//#[ ignore


#endif // _OMINSTRUMENT
//#]

//#[ ignore
#ifdef _OMINSTRUMENT

//#]
void OMActivityManager::serializeFlows(AOMSAttributes& flows) {
    //#[ operation serializeFlows(AOMSAttributes&)
    for (OMIterator<OMActivity*> activitiesIterator(mActivities); activitiesIterator.value(); activitiesIterator++)
    {
       	OMActivity* activity = activitiesIterator.value();
       	activity->serializeFlows(flows);
    }
    //#]
}
//#[ ignore


#endif // _OMINSTRUMENT
//#]

//#[ ignore
#ifdef _OMINSTRUMENT

//#]
void OMActivityManager::serializeTokens(AOMSAttributes& tokens, const OMString& elemId) {
    //#[ operation serializeTokens(AOMSAttributes&,const OMString&)
    for (OMIterator<OMActivity*> activitiesIterator(mActivities); activitiesIterator.value(); activitiesIterator++)
    {
       	OMActivity* activity = activitiesIterator.value();
       	activity->serializeTokens(tokens, elemId);
    }
    //#]
}
//#[ ignore


#endif // _OMINSTRUMENT
//#]

/*********************************************************************
	File Path	: ../OMActivityManager.cpp
*********************************************************************/
