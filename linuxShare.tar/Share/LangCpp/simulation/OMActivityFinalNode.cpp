/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMActivityFinalNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMActivityFinalNode.cpp
*********************************************************************/

//## auto_generated
#include "OMActivityFinalNode.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMActivityFinalNode
OMActivityFinalNode::~OMActivityFinalNode(void) {
}

OMActivityFinalNode::OMActivityFinalNode(const OMString& id, OMActivity& parentActivity) : OMControlNode(id, parentActivity) {
    //#[ operation OMActivityFinalNode(OMString,OMActivity)
    //#]
}

void OMActivityFinalNode::control(void) {
    //#[ operation control()
    consumeTokens();
    mParentActivity->terminate();
    //#]
}

bool OMActivityFinalNode::canControl(void) {
    //#[ operation canControl()
    return atLeastOneInputHasToken();
    //#]
}

/*********************************************************************
	File Path	: ../OMActivityFinalNode.cpp
*********************************************************************/
