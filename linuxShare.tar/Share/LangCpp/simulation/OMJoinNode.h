/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMJoinNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMJoinNode.h
*********************************************************************/

#ifndef OMJoinNode_H
#define OMJoinNode_H

//## class OMJoinNode
#include "OMControlNode.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMJoinNode
class OMJoinNode : public OMControlNode {
public :

    //## auto_generated
    virtual ~OMJoinNode(void);
    
    //## operation OMJoinNode(OMString,OMActivity)
    OMJoinNode(const OMString& id, OMActivity& parentActivity);

protected :

    //## operation canControl()
    virtual bool canControl(void);
    
    //## operation control()
    virtual void control(void);
};

#endif
/*********************************************************************
	File Path	: ../OMJoinNode.h
*********************************************************************/
