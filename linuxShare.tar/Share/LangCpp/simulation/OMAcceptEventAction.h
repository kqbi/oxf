/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMAcceptEventAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMAcceptEventAction.h
*********************************************************************/

#ifndef OMAcceptEventAction_H
#define OMAcceptEventAction_H

//## dependency Events
#include <oxf/OXFEvents.h>
//## class OMAcceptEventAction
#include "OMAction.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## dependency OMTimeout
class OMTimeout;

//## package Activities

//## class OMAcceptEventAction
class OMAcceptEventAction : public OMAction {
public :

    //## class OMAcceptEventAction::AcceptEventID
    class AcceptEventID {
    public :
    
        //## auto_generated
        ~AcceptEventID(void);
        
        //## operation AcceptEventID(IOxfEvent)
        AcceptEventID(IOxfEvent* ev);
        
        //## operation AcceptEventID(ID)
        AcceptEventID(IOxfEvent::ID eventId);
        
        //## operation AcceptEventID(const char*)
        AcceptEventID(const char* id);
        
        //## operation AcceptEventID(OMString)
        AcceptEventID(const OMString& id);
        
        //## operation AcceptEventID(AcceptEventID)
        AcceptEventID(const AcceptEventID& other);
        
        //## operation operator==(AcceptEventID)
        bool operator==(const AcceptEventID& other);
        
        //## operation operator>=(AcceptEventID)
        bool operator>=(const AcceptEventID& other);
        
        //## operation operator<=(AcceptEventID)
        bool operator<=(const AcceptEventID& other);
        
        //## operation operator<(AcceptEventID)
        bool operator<(const AcceptEventID& other);
        
        //## operation operator>(AcceptEventID)
        bool operator>(const AcceptEventID& other);
        
        ////    Attributes    ////
    
    protected :
    
        OMString mID;		//## attribute mID
    };
    
    //## auto_generated
    virtual ~OMAcceptEventAction(void);
    
    //## operation OMAcceptEventAction(OMString,OMActivity,ID)
    OMAcceptEventAction(const OMString& id, OMActivity& parentActivity, IOxfEvent::ID eventExpected);
    
    //## operation visit()
    virtual void visit(void);
    
    //## operation execute()
    virtual void execute(void);
    
    //## operation getAcceptEventId() const
    virtual AcceptEventID getAcceptEventId(void) const;
    
    //## operation acceptEventData()
    virtual void acceptEventData(void) = 0;
    
    //## operation isReady()
    virtual bool isReady(void);
    
    ////    Attributes    ////

private :

    IOxfEvent::ID mEventExpected;		//## attribute mEventExpected
};

#endif
/*********************************************************************
	File Path	: ../OMAcceptEventAction.h
*********************************************************************/
