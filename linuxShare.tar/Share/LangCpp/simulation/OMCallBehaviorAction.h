/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMCallBehaviorAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMCallBehaviorAction.h
*********************************************************************/

#ifndef OMCallBehaviorAction_H
#define OMCallBehaviorAction_H

//## class OMCallBehaviorAction
#include "OMAction.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMCallBehaviorAction
class OMCallBehaviorAction : public OMAction {
public :

    //## operation OMCallBehaviorAction(OMString,OMActivity,OMActivity)
    OMCallBehaviorAction(const OMString& id, OMActivity& parentActivity, OMActivity& referencedActivity);
    
    //## operation ~OMCallBehaviorAction()
    ~OMCallBehaviorAction(void);
    
    //## operation execute()
    virtual void execute(void);

protected :

    //## operation setParametersFromPins()
    virtual void setParametersFromPins(void) = 0;
    
    //## operation setPinsFromParameters()
    virtual void setPinsFromParameters(void) = 0;
    
    ////    Relations and components    ////
    
    OMActivity* mReferencedActivity;		//## link mReferencedActivity
};

#endif
/*********************************************************************
	File Path	: ../OMCallBehaviorAction.h
*********************************************************************/
