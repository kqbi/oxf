/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMJoinNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMJoinNode.cpp
*********************************************************************/

//## auto_generated
#include "OMJoinNode.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMJoinNode
OMJoinNode::~OMJoinNode(void) {
}

OMJoinNode::OMJoinNode(const OMString& id, OMActivity& parentActivity) : OMControlNode(id, parentActivity) {
    //#[ operation OMJoinNode(OMString,OMActivity)
    //#]
}

bool OMJoinNode::canControl(void) {
    //#[ operation canControl()
    return allInputsHaveToken();
    //#]
}

void OMJoinNode::control(void) {
    //#[ operation control()
    bool onlyControls = true;
    
    for (OMIterator<OMActivityEdge*> iter(mInputFlows); iter.value(); iter++)
    {   
    	OMActivityEdge* flow = iter.value();
    	if (flow->isControl())
    	{
    		flow->acceptToken();
    	}
    	else
    	{
    		flow->acceptToken();
    		produceTokens();
    		
    		onlyControls = false;	
    	}
    }
    
    if (onlyControls)
    {
    	produceTokens();
    }
    //#]
}

/*********************************************************************
	File Path	: ../OMJoinNode.cpp
*********************************************************************/
