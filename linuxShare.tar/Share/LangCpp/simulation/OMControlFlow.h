/*********************************************************************
	Rhapsody	: 7.6 
	Login		: ehudho
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMControlFlow
//!	Generated Date	: Mon, 23, Apr 2012  
	File Path	: ../OMControlFlow.h
*********************************************************************/

#ifndef OMControlFlow_H
#define OMControlFlow_H

//## class OMControlFlow
#include "OMActivityEdge.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## auto_generated
class OMActivity;

//## auto_generated
class OMActivityNode;

//## package Activities

//## class OMControlFlow
class OMControlFlow : public OMActivityEdge {
public :

    //## auto_generated
    virtual ~OMControlFlow(void);
    
    //## operation OMControlFlow(OMString,OMActivity,OMActivityNode,OMActivityNode)
    OMControlFlow(const OMString& id, OMActivity& parentActivity, OMActivityNode& fromAction, OMActivityNode& toAction);
    
    //## operation offerToken()
    virtual void offerToken(void);
    
    //## operation acceptToken()
    virtual void acceptToken(void);
    
    //## operation isOfferingToken()
    virtual bool isOfferingToken(void);
    
    //## operation isControl()
    virtual bool isControl(void);
    
    //## operation getTokenCount()
    virtual int getTokenCount(void);
    
    ////    Attributes    ////

protected :

    int mOfferedTokens;		//## attribute mOfferedTokens
};

#endif
/*********************************************************************
	File Path	: ../OMControlFlow.h
*********************************************************************/
