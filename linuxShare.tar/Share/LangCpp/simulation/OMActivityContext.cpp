/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: chaimcoh
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMActivityContext
//!	Generated Date	: Wed, 2, May 2012  
	File Path	: ../OMActivityContext.cpp
*********************************************************************/

//## auto_generated
#include "OMActivityContext.h"
//## dependency AnimServices
//#[ ignore
#ifdef _OMINSTRUMENT

//#]
#include <aom/AnimServices.h>
//#[ ignore


#endif // _OMINSTRUMENT
//#]
//## dependency AOMSAttributes
#include <aommsg.h>
//## package Activities

//## class OMActivityContext
OMActivityContext::OMActivityContext(void) : mMainActivity(NULL) {
    //#[ operation OMActivityContext()
    //#]
}

OMActivityContext::~OMActivityContext(void) {
    //#[ operation ~OMActivityContext()
    if (mMainActivity)
    {
    	delete mMainActivity;
    	mMainActivity = NULL;
    }
    //#]
}

bool OMActivityContext::startBehavior(void) {
    //#[ operation startBehavior()
    if (mMainActivity == NULL)
    	mMainActivity = createMainActivity();
    
    return OMReactive::startBehavior();
    //#]
}

IOxfTimeout* OMActivityContext::sendTimeEvent(int duration, const OMString& action) {
    //#[ operation sendTimeEvent(int,OMString)
    return scheduleTimeout(duration, action.GetBuffer(0 /* dummy */));
    //#]
}

void OMActivityContext::rootState_entDef(void) {
    //#[ operation rootState_entDef()
    if (mMainActivity)
    {
    	mMainActivity->activate();
    }
    else
    {
    	OMReactive::rootState_entDef();
    }
    //#]
}

IOxfReactive::TakeEventStatus OMActivityContext::processEvent(IOxfEvent* ev) {
    //#[ operation processEvent(IOxfEvent)
    IOxfReactive::TakeEventStatus status = eventNotConsumed;
    
    if (ev && mMainActivity)
    {   
    	setCurrentEvent(ev);
    	status = mMainActivity->handleEvent(ev);
    	setCurrentEvent(NULL);
    }
    
    if (status == eventNotConsumed)
    {
    	OMReactive::processEvent(ev);
    }
    
    return status;
    //#]
}

OMActivity* OMActivityContext::createMainActivity(void) {
    //#[ operation createMainActivity()
    return NULL;
    //#]
}

/*********************************************************************
	File Path	: ../OMActivityContext.cpp
*********************************************************************/
