/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMInitialAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMInitialAction.cpp
*********************************************************************/

//## auto_generated
#include "OMInitialAction.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMInitialAction
OMInitialAction::~OMInitialAction(void) {
}

OMInitialAction::OMInitialAction(const OMString& id, OMActivity& parentActivity) : OMControlNode(id, parentActivity) {
    //#[ operation OMInitialAction(OMString,OMActivity)
    //#]
}

bool OMInitialAction::isInitiallyReady(void) {
    //#[ operation isInitiallyReady()
    return true;
    //#]
}

bool OMInitialAction::canControl(void) {
    //#[ operation canControl()
    return true;
    //#]
}

OMList<OMString> OMInitialAction::filterPassableFlows(void) {
    //#[ operation filterPassableFlows()
    // all flows are passable
    OMList<OMString> ans;
    for (OMIterator<OMActivityEdge*> iter(mOutputFlows); iter.value(); iter++)
    {   
    	ans.add(iter.value()->getId());	
    }
    return ans;
    //#]
}

/*********************************************************************
	File Path	: ../OMInitialAction.cpp
*********************************************************************/
