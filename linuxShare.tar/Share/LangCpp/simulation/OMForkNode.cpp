/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMForkNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMForkNode.cpp
*********************************************************************/

//## auto_generated
#include "OMForkNode.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## package Activities

//## class OMForkNode
OMForkNode::~OMForkNode(void) {
}

OMForkNode::OMForkNode(const OMString& id, OMActivity& parentActivity) : OMControlNode(id, parentActivity) {
    //#[ operation OMForkNode(OMString,OMActivity)
    //#]
}

bool OMForkNode::canControl(void) {
    //#[ operation canControl()
    return atLeastOneInputHasToken();
    //#]
}

/*********************************************************************
	File Path	: ../OMForkNode.cpp
*********************************************************************/
