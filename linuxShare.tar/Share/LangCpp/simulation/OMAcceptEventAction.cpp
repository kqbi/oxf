/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMAcceptEventAction
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMAcceptEventAction.cpp
*********************************************************************/

//## auto_generated
#include "OMAcceptEventAction.h"
//## dependency AOMSAttributes
#include <aommsg.h>
//## dependency OMActivity
#include "OMActivity.h"
//## dependency OMActivityEdge
#include "OMActivityEdge.h"
//## dependency OMTimeout
#include <oxf/OMTimeout.h>
//## package Activities

//## class OMAcceptEventAction
//## class OMAcceptEventAction::AcceptEventID
OMAcceptEventAction::AcceptEventID::~AcceptEventID(void) {
}

OMAcceptEventAction::AcceptEventID::AcceptEventID(IOxfEvent* ev) {
    //#[ operation AcceptEventID(IOxfEvent)
    char key[256];
    
    if (ev && ev->isTypeOf(OMTimeoutEventId))
    {               
    	sprintf(key, "%p", ev); // time events use their address to get identified
    }
    else
    {
        OMitoa(ev->getId(), key, 10);
    }
    mID = key;	
    //#]
}

OMAcceptEventAction::AcceptEventID::AcceptEventID(IOxfEvent::ID eventId) {
    //#[ operation AcceptEventID(ID)
    char key[256];
    OMitoa(eventId, key, 10);
    
    mID = key;
    //#]
}

OMAcceptEventAction::AcceptEventID::AcceptEventID(const char* id) {
    //#[ operation AcceptEventID(const char*)
    mID = id;
    //#]
}

OMAcceptEventAction::AcceptEventID::AcceptEventID(const OMString& id) {
    //#[ operation AcceptEventID(OMString)
    mID = id.GetBuffer(0 /* dummy */);
    //#]
}

OMAcceptEventAction::AcceptEventID::AcceptEventID(const OMAcceptEventAction::AcceptEventID& other) : mID(other.mID) {
    //#[ operation AcceptEventID(AcceptEventID)
    //#]
}

bool OMAcceptEventAction::AcceptEventID::operator==(const OMAcceptEventAction::AcceptEventID& other) {
    //#[ operation operator==(AcceptEventID)
    return this->mID == other.mID;
    //#]
}

bool OMAcceptEventAction::AcceptEventID::operator>=(const OMAcceptEventAction::AcceptEventID& other) {
    //#[ operation operator>=(AcceptEventID)
    return this->mID >= other.mID;
    //#]
}

bool OMAcceptEventAction::AcceptEventID::operator<=(const OMAcceptEventAction::AcceptEventID& other) {
    //#[ operation operator<=(AcceptEventID)
    return this->mID <= other.mID;
    //#]
}

bool OMAcceptEventAction::AcceptEventID::operator<(const OMAcceptEventAction::AcceptEventID& other) {
    //#[ operation operator<(AcceptEventID)
    return this->mID < other.mID;
    //#]
}

bool OMAcceptEventAction::AcceptEventID::operator>(const OMAcceptEventAction::AcceptEventID& other) {
    //#[ operation operator>(AcceptEventID)
    return this->mID > other.mID;
    //#]
}

OMAcceptEventAction::~OMAcceptEventAction(void) {
}

OMAcceptEventAction::OMAcceptEventAction(const OMString& id, OMActivity& parentActivity, IOxfEvent::ID eventExpected) : OMAction(id, parentActivity), mEventExpected(eventExpected) {
    //#[ operation OMAcceptEventAction(OMString,OMActivity,ID)
    //#]
}

void OMAcceptEventAction::visit(void) {
    //#[ operation visit()
    mParentActivity->notifyEnterAcceptEvent(mId);
    //#]
}

void OMAcceptEventAction::execute(void) {
    //#[ operation execute()
    consumeTokens();
    acceptEventData();
    mParentActivity->notifyExitAcceptEvent(mId);
    produceTokens();
    //#]
}

OMAcceptEventAction::AcceptEventID OMAcceptEventAction::getAcceptEventId(void) const {
    //#[ operation getAcceptEventId() const
    AcceptEventID ans(mEventExpected);
    return ans;
    //#]
}

bool OMAcceptEventAction::isReady(void) {
    //#[ operation isReady()
    return allInputsHaveToken();
    //#]
}

/*********************************************************************
	File Path	: ../OMAcceptEventAction.cpp
*********************************************************************/
