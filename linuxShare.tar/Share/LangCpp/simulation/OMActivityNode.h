/*********************************************************************
	Rhapsody	: 7.6 
	Login		: ehudho
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMActivityNode
//!	Generated Date	: Mon, 23, Apr 2012  
	File Path	: ../OMActivityNode.h
*********************************************************************/

#ifndef OMActivityNode_H
#define OMActivityNode_H

//## auto_generated
#include "ommap.h"
//## auto_generated
#include "OXFTypes.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMActivityNode
class OMActivityNode {
public :

    //## operation OMActivityNode(OMString,OMActivity)
    OMActivityNode(const OMString& id, OMActivity& parentActivity);
    
    //## operation ~OMActivityNode()
    virtual ~OMActivityNode(void);
    
    //## operation getId()
    OMString getId(void);
    
    //## operation visit()
    virtual void visit(void) = 0;
    
    //## operation activate()
    void activate(void);
    
    //## operation deactivate()
    void deactivate(void);
    
    //## operation isActive()
    bool isActive(void);
    
    //## operation isInitiallyReady()
    virtual bool isInitiallyReady(void) = 0;
    
    //## operation isReady()
    virtual bool isReady(void) = 0;
    
    //## operation connectOutputFlow(OMActivityEdge)
    virtual void connectOutputFlow(OMActivityEdge& flow);
    
    //## operation connectInputFlow(OMActivityEdge)
    virtual void connectInputFlow(OMActivityEdge& flow);
    
    //## operation getOutputFlow(OMString)
    OMActivityEdge* getOutputFlow(const OMString& id);
    
    //## operation getInputFlow(OMString)
    OMActivityEdge* getInputFlow(const OMString& id);

protected :

    //## operation produceTokens()
    virtual void produceTokens(void);
    
    //## operation consumeTokens()
    void consumeTokens(void);
    
    //## operation allInputsHaveToken()
    bool allInputsHaveToken(void);
    
    //## operation filterPassableFlows()
    virtual OMList<OMString> filterPassableFlows(void) = 0;

public :

    //## operation serializeTokens(AOMSAttributes&)
    //#[ ignore
    #ifdef _OMINSTRUMENT
    
    //#]
    virtual void serializeTokens(AOMSAttributes&);
    //#[ ignore
    
    #endif // _OMINSTRUMENT
    //#]
    
    ////    Attributes    ////

protected :

    OMString mId;		//## attribute mId
    
    bool mIsActive;		//## attribute mIsActive
    
    ////    Relations and components    ////
    
    OMActivity* mParentActivity;		//## link mParentActivity
    
    OMMap<OMString, OMActivityEdge*> mInputFlows;		//## link mInputFlows
    
    OMMap<OMString, OMActivityEdge*> mOutputFlows;		//## link mOutputFlows
};

#endif
/*********************************************************************
	File Path	: ../OMActivityNode.h
*********************************************************************/
