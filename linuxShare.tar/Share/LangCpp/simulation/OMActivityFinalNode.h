/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: eldadpal
	Component	: simulation 
	Configuration 	: generic
	Model Element	: OMActivityFinalNode
//!	Generated Date	: Wed, 7, Mar 2012  
	File Path	: ../OMActivityFinalNode.h
*********************************************************************/

#ifndef OMActivityFinalNode_H
#define OMActivityFinalNode_H

//## class OMActivityFinalNode
#include "OMControlNode.h"
//## dependency AOMSAttributes
class AOMSAttributes;

//## dependency OMActivity
class OMActivity;

//## dependency OMActivityEdge
class OMActivityEdge;

//## package Activities

//## class OMActivityFinalNode
class OMActivityFinalNode : public OMControlNode {
public :

    //## auto_generated
    virtual ~OMActivityFinalNode(void);
    
    //## operation OMActivityFinalNode(OMString,OMActivity)
    OMActivityFinalNode(const OMString& id, OMActivity& parentActivity);

protected :

    //## operation control()
    virtual void control(void);
    
    //## operation canControl()
    virtual bool canControl(void);
};

#endif
/*********************************************************************
	File Path	: ../OMActivityFinalNode.h
*********************************************************************/
