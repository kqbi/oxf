#ifndef OMOSCONFIG_H
#define OMOSCONFIG_H "$Id: omosconfig.h 1.9 2007/05/28 07:45:33 ilvler Exp $"
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/osconfig/VxWorks/rcs/omosconfig.h $
//	file version:	$Revision: 1.9 $
//
//	purpose:	 	VxWorks adaptor OS configuration file
//
//
//	author(s):		Amos Ortal
//
//	date started:	July 2002
//
//	date changed:	$Date: 2007/05/28 07:45:33 $
//	last change by:	$Author: ilvler $
//
//	Licensed Materials - Property of IBM
//	� Copyright IBM Corporation 2002, 2008. All Rights Reserved.
//

//////////////////////////////////
// flags
//////////////////////////////////
#ifdef __DCC__					// DIAB compiler
#define COPY_STRSTREAM_BUFFER
#define OM_OS_OSTRSTREAM_WITHOUT_FREEZE_INTEFACE
#endif

#define OMUseNullBlockContainer
#define USE_STDIO
#define NEED_INLINE_IN_TEMPLATE
#if !defined(_OMINSTRUMENT) && !defined(OMANIMATOR) && !defined(OMTRACER)
#define OM_NO_TEMPLATES_USAGE
#endif
#define OM_NO_TYPENAME_SUPPORT
#define OM_USE_VX_QUEUES
//////////////////////////////////
// includes
//////////////////////////////////
#include <vxWorks.h>

#ifdef OM_APEX
#define OM_POSTPONE_INIT_EPILOG_CALL
#include <apex/apexLib.h>
#include <apex/apexQueuing.h>
typedef  PROCESS_ID_TYPE  OMOSHandle;
#else
#include <pthread.h>
typedef  pthread_t OMOSHandle;
#endif

#include <version.h>
#if ((_WRS_VXWORKS_MAJOR >5) && (_WRS_VXWORKS_MINOR >5))
#ifdef _WRS_KERNEL
#include <cpuPwrLib.h>
/* power mode */
typedef CPU_PWR_P_STATE  OMPowerMode_t;
#define OMPwrModeNone cpuPwrCurrentTaskPState
#else
typedef enum {OMPwrModeNone} OMPowerMode_t;
#endif

#else
typedef enum {OMPwrModeNone} OMPowerMode_t;
#endif // VXWORKS_VERSION_6_6_OR_BETTER

//////////////////////////////////
// macros
//////////////////////////////////
#define OMitoa(val,str,radix) sprintf(str,"%lu",(unsigned long)val)

#define OM_SEARCH_ENV(name,searchpath,path) 

#define OM_NOTIFY_ERROR(call,func) 

typedef  void * gen_ptr;

#endif // OMOSCONFIG_H

//$Log: omosconfig.h $
//Revision 1.9  2007/05/28 07:45:33  ilvler
//Empty macro OM_NOTIFY_ERROR added. User can fill it in by any needed stuff to analyze failed system calls in VxWorks adapter
//Revision 1.8  2007/03/11 12:51:34  ilgiga
//Change copyright comment
//Revision 1.7  2007/03/01 16:23:30  ilgiga
//Telelogic instead of i-Logix
//Revision 1.6  2006/03/20 12:22:53  amos
//Replace UseNullBlockContainter with OMUseNullBlockContainer
//Revision 1.5  2004/07/18 17:49:21  gio
//Added define OM_NO_TYPENAME_SUPPORT
//Revision 1.4  2004/01/19 14:00:28  eldad
//OM_SEARCH_ENV
//Revision 1.3  2003/10/28 14:11:08  vova
//__DIAB flag has been replaced by its native __DCC__
//Revision 1.2  2003/06/29 11:47:16  vova
//63043: Comments fixed
//Revision 1.1  2002/07/09 11:31:46  amos
//Initial revision
