#ifndef OMOSCONFIG_H
#define OMOSCONFIG_H "$Id: omosconfig.h 1.9 2007/03/11 12:51:33 ilgiga Exp $"
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/osconfig/OSE/rcs/omosconfig.h $
//	file version:	$Revision: 1.9 $
//
//	purpose:	 	OSE adaptor OS configuration file
//
//
//	author(s):		Amos Ortal
//
//	date started:	July 2002
//
//	date changed:	$Date: 2007/03/11 12:51:33 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2002, 2008. All Rights Reserved.
//

/////////////////////////
// flags
/////////////////////////
#define OM_NO_STD_STRING
#define OM_OS_USE_FREE

#ifndef _OM_NO_IOSTREAM
#ifndef USE_IOSTREAM
#define USE_IOSTREAM
#endif // USE_IOSTREAM
#endif // _OM_NO_IOSTREAM

#ifndef __DCC__								// DIAB compiler
#define OM_NEW_OPERATOR_NEEDS_DUMMY_PARAM // add dummy parameter to operator new()
#define COPY_STRSTREAM_BUFFER
#define OM_OS_OSTRSTREAM_WITHOUT_FREEZE_INTEFACE
#else
#define OM_STD_IFSTREAM_CREATION
#define __DISABLE_LONG_LONG  //remove Diab 5.0.3 warning on long long type
#define NEED_INLINE_IN_TEMPLATE
#define NEED_DELETE_OPERATOR_FOR_STATIC_ALLOC
#define OM_NO_TYPENAME_SUPPORT
#endif

#ifdef WIN32
#define OM_OS_SHORT_STRSTREAM_FILE_NAME
#endif

/////////////////////////
// includes
/////////////////////////
#include <stdio.h>

/////////////////////////
// macros
/////////////////////////
#define OMitoa(val,str,radix) sprintf(str,"%d",val)

#define OM_SEARCH_ENV(name,searchpath,path) 

typedef  void * gen_ptr;
typedef  void * OMOSHandle;
typedef enum {OMPwrModeNone = 0}  OMPowerMode_t;

#endif // OMOSCONFIG_H

//$Log: omosconfig.h $
//Revision 1.9  2007/03/11 12:51:33  ilgiga
//Change copyright comment
//Revision 1.8  2007/03/01 16:23:29  ilgiga
//Telelogic instead of i-Logix
//Revision 1.7  2004/08/31 15:01:44  amos
//Revision 1.6  2004/01/19 14:00:25  eldad
//OM_SEARCH_ENV
//Revision 1.5  2003/10/28 14:10:25  vova
//__DIAB flag has been replaced by its native __DCC__
//Revision 1.4  2003/06/01 08:05:17  gio
//Added define for Diab 5 vs Dab 4 comatibility:
//NEED_DELETE_OPERATOR_FOR_STATIC_ALLOC
//Revision 1.3  2003/05/29 10:36:57  gio
//Added define for Diab 5:
//#define NEED_INLINE_IN_TEMPLATE
//Revision 1.2  2003/05/27 12:13:39  gio
//Added defines for Diab 5.
//Revision 1.1  2002/07/09 16:42:46  amos
//Initial revision
