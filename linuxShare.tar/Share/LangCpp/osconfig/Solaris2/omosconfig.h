#ifndef OMOSCONFIG_H
#define OMOSCONFIG_H "$Id: omosconfig.h 1.12 2007/03/29 15:24:30 ilvler Exp $"
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/osconfig/Solaris2/rcs/omosconfig.h $
//	file version:	$Revision: 1.12 $
//
//	purpose:	 	Solaris adaptor OS configuration file
//
//
//	author(s):		Amos Ortal
//
//	date started:	July 2002
//
//	date changed:	$Date: 2007/03/29 15:24:30 $
//	last change by:	$Author: ilvler $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2002, 2008. All Rights Reserved.
//

//////////////////////////////////
// flags
//////////////////////////////////
#if (defined __SUNPRO_CC && (__SUNPRO_CC < 0x520))
#define OM_NO_SERIALIZE_GLOBAL_VARS
#endif

#ifdef __GNUC__
#include <ansidecl.h>
#define OMUseNullBlockContainer
#define OM_NO_TYPENAME_SUPPORT
#else // !__GNUC__
#define HAS_EXP_NOT_CATCHING_SIGNALS
#endif // __GNUC__

#define OM_NEW_OPERATOR_NEEDS_DUMMY_PARAM // add dummy parameter to operator new()
#define NO_IOSTREAM_FOR_X2STRING_IMPLEMENTATION
#define OM_CATCH_SIGBUS
#define OM_CATCH_SIGFPE
#define OM_CATCH_SIGABRT
#define OM_CATCH_SIGILL
#define OM_STD_IFSTREAM_CREATION
#if GCC_VERSION >= 3004
#define OM_OS_SSTREAM_FILE_NAME
#define OM_STL
#endif // GCC_VERSION >= 3004

//Define this flag in order to use SIGALRM signal for the timer mechanism. If not, nanosleep will be used instead.
//The SIGALRM signal for the timer mechanism is not supported from Solaris 9.
//#define OM_USE_SIGALRM_BASED_TIMER

//////////////////////////////////
// includes
//////////////////////////////////
#include <unistd.h>
#include <stdio.h>

#ifdef _WINDU_SOURCE
// Needed for smooth porting to UNIX under Bristol
#include <windu_platform.h>
#endif

//////////////////////////////////
// Macros
//////////////////////////////////
#define OMitoa(val,str,radix) sprintf(str,"%d",val)

#define OM_SEARCH_ENV(name,searchpath,path) 

typedef  void * gen_ptr;
typedef  void * OMOSHandle;
typedef enum {OMPwrModeNone = 0}  OMPowerMode_t;

#endif // OMOSCONFIG_H

//$Log: omosconfig.h $
//Revision 1.12  2007/03/29 15:24:30  ilvler
//101892 - sstream usage in gcc 3.4 and higher
//Revision 1.11  2007/03/11 12:51:34  ilgiga
//Change copyright comment
//Revision 1.10  2007/03/01 16:23:30  ilgiga
//Telelogic instead of i-Logix
//Revision 1.9  2007/02/28 15:24:18  ilgiga
//bug fix 97779
//Revision 1.8.1.3  2007/02/28 15:23:12  ilgiga
//bug fix 97779
//Revision 1.8.1.2  2007/02/28 13:54:53  ilgiga
//bug fix 97779
//Revision 1.8  2006/03/20 12:22:53  amos
//Replace UseNullBlockContainter with OMUseNullBlockContainer
//Revision 1.7  2004/09/05 07:24:14  amos
//Avoid the typename keyword when using GNU to compile the Solaris libraris.
//Revision 1.6  2004/01/21 08:26:46  eldad
//Fix build
//Revision 1.5  2004/01/19 14:00:28  eldad
//OM_SEARCH_ENV
//Revision 1.4  2003/06/29 11:47:48  vova
//63043: comments shanged
//Revision 1.3  2003/01/20 15:18:32  avrahams
//bug fix 61035 - add more signals catchings for omtry
//Revision 1.2  2003/01/09 12:30:37  Eldad
//Fix b#61053
//Revision 1.1  2002/07/09 11:30:43  amos
//Initial revision
