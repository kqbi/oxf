#ifndef OMOSCONFIG_H
#define OMOSCONFIG_H "$Id: omosconfig.h 1.6 2007/03/11 12:51:33 ilgiga Exp $"
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/osconfig/QNX/rcs/omosconfig.h $
//	file version:	$Revision: 1.6 $
//
//	purpose:	 	Microsoft adaptor OS configuration file
//
//
//	author(s):		Amos Ortal
//
//	date started:	July 2002
//
//	date changed:	$Date: 2007/03/11 12:51:33 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2002, 2008. All Rights Reserved.
//

///////////////////////////
// flags
///////////////////////////
#define OM_NEW_OPERATOR_NEEDS_DUMMY_PARAM
#define NO_IOSTREAM_FOR_X2STRING_IMPLEMENTATION
#define OM_CATCH_SIGBUS
#define OM_STD_IFSTREAM_CREATION
#define OM_NO_TYPENAME_SUPPORT

#ifdef __GNUC__
#define OMUseNullBlockContainer
#else // !__GNUC__
#define HAS_EXP_NOT_CATCHING_SIGNALS
#endif // __GNUC__

//////////////////////////////////
// includes
//////////////////////////////////
#include <unistd.h>
#include <stdio.h>

//////////////////////////////////
// Macros
//////////////////////////////////
#define OMitoa itoa

#define OM_SEARCH_ENV(name,searchpath,path) 

typedef  void * gen_ptr;
typedef  void * OMOSHandle;
typedef enum {OMPwrModeNone = 0}  OMPowerMode_t;

#endif // OMOSCONFIG_H

//$Log: omosconfig.h $
//Revision 1.6  2007/03/11 12:51:33  ilgiga
//Change copyright comment
//Revision 1.5  2007/03/01 16:23:30  ilgiga
//Telelogic instead of i-Logix
//Revision 1.4  2006/03/20 12:22:52  amos
//Replace UseNullBlockContainter with OMUseNullBlockContainer
//Revision 1.3  2004/07/18 17:49:15  gio
//Added define OM_NO_TYPENAME_SUPPORT
//Revision 1.2  2004/01/19 14:00:27  eldad
//OM_SEARCH_ENV
//Revision 1.1  2002/07/09 11:30:43  amos
//Initial revision
