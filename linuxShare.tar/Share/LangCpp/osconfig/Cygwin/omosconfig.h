#ifndef OMOSCONFIG_H
#define OMOSCONFIG_H "$Id: omosconfig.h 1.6 2007/03/11 12:51:32 ilgiga Exp $"
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/osconfig/Cygwin/rcs/omosconfig.h $
//	file version:	$Revision: 1.6 $
//
//	purpose:	 	Microsoft adaptor OS configuration file
//
//
//	author(s):		Amos Ortal
//
//	date started:	July 2002
//
//	date changed:	$Date: 2007/03/11 12:51:32 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2002, 2008. All Rights Reserved.
//

//////////////////////////////////
// flags
//////////////////////////////////
#if !(defined OMOMATE && defined _DEBUG)
#define HAS_EXP_CATCHING_SIGNALS	// support exceptions
#endif // !(defined OMOMATE && defined _DEBUG)
#define USE_IOSTREAM	// use iostreams


#define __USE_CREATE_THREAD__
#ifndef __USE_W32_SOCKETS
#define __USE_W32_SOCKETS
#endif // __USE_W32_SOCKETS

#include <ansidecl.h>

#define OM_NO_TYPENAME_SUPPORT
#define OM_SEARCH_ENV(name,searchpath,path)
#define OM_OS_SSTREAM_FILE_NAME
#define OM_STL
#define OM_USE_STL_STRING_STREAM

#ifdef unix // For Rhapsody on Solaris
#define OM_CATCH_SIGBUS
#define OM_CATCH_SIGFPE
#define OM_CATCH_SIGABRT
#define OM_CATCH_SIGILL
#define OM_STD_IFSTREAM_CREATION
#endif // unix


////////////////////////////////
// include files 
////////////////////////////////

#ifdef unix
#include <unistd.h>
#include <stdio.h>
#endif // unix

/////////////////////////////////
// Macros
/////////////////////////////////

#ifdef unix
#define OMitoa(val,str,radix) sprintf(str,"%lu",(unsigned long)val)
#endif // unix

#ifndef OMitoa
#define OMitoa _itoa
#endif

typedef  void * gen_ptr;
typedef  void * OMOSHandle;

typedef enum {OMPwrModeNone = 0}  OMPowerMode_t;

#define OM_NOTIFY_ERROR(call,func)

#endif // OMOSCONFIG_H

//$Log: omosconfig.h $
//Revision 1.6  2007/03/11 12:51:32  ilgiga
//Change copyright comment
//Revision 1.5  2007/03/01 16:23:29  ilgiga
//Telelogic instead of i-Logix
//Revision 1.4  2006/10/30 10:58:28  eldad
//Fixed crash due to Cygwin bug
//Revision 1.3  2006/07/06 06:20:38  eldad
//Allow use of streams for serialization methods in omCom in Linux and Cygwin
//Revision 1.2  2005/04/04 15:47:34  vova
//81873:Warning eleiminated while compilation because of multyple definition of _OM_NO_IOSTREAM
//Revision 1.1  2005/04/03 14:27:05  vova
//Initial revision
//Revision 1.2  2005/03/30 14:37:23  vova
//sstream is used instead of deprecated strstream
//Revision 1.1  2005/03/10 15:58:43  vova
//Initial revision
//Revision 1.9  2004/01/19 14:00:31  eldad
//OM_SEARCH_ENV
//Revision 1.8.1.2  2004/01/19 13:34:43  vova
//Revision 1.8  2003/10/08 14:33:55  vova
//Multiple definition of OM_WIN32_COMPILER_DISABLE_WARNING_4244 removed
//Revision 1.7  2003/01/20 15:18:48  avrahams
//bug fix 61035 - add more signals catchings for omtry
//Revision 1.6  2003/01/09 12:29:53  Eldad
//Fix b#61053
//Revision 1.5  2002/12/03 13:34:25  amos
//remove the block on loading of "OMTracer.cfg" in Borlad 5.5
//Revision 1.4  2002/12/02 17:49:46  gio
//Added for Borland BCC55 adapter:
//#define OM_NO_TRACER_FILE
//Revision 1.3  2002/11/27 12:18:02  gio
//Definitions for Borland bcc55 adapter:
//#define OM_OS_NEEDS_CONST_VOID_DUMP_OPERATOR
//Revision 1.2  2002/07/15 12:32:14  avrahams
//Set OM_STL when compiled by .NET
//Revision 1.1  2002/07/09 14:36:24  amos
//Initial revision
