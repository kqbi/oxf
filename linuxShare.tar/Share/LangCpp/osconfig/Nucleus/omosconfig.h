#ifndef OMOSCONFIG_H
#define OMOSCONFIG_H "$Id: omosconfig.h 1.8 2007/03/11 12:51:33 ilgiga Exp $"
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/osconfig/Nucleus/rcs/omosconfig.h $
//	file version:	$Revision: 1.8 $
//
//	purpose:	 	Nucleus adaptor OS configuration file
//
//
//	author(s):		Amos Ortal
//
//	date started:	July 2002
//
//	date changed:	$Date: 2007/03/11 12:51:33 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2002, 2008. All Rights Reserved.
//


//////////////////////////////////
// flags
//////////////////////////////////
#ifdef __DCC__		// DIAB compiler
#define COPY_STRSTREAM_BUFFER
#define DIAB_DTOR_BUG
#define OM_OS_OSTRSTREAM_WITHOUT_FREEZE_INTEFACE
#define OM_NO_TYPENAME_SUPPORT
#define OM_NO_COMPILER_SUPPORT_FOR_REPLACEMENT_DELETE
#endif

#define OM_NO_NOTHROW_NEW_SUPPORT
//////////////////////////////////
// includes
//////////////////////////////////
#ifdef __cplusplus
extern "C"
{
#endif //__cplusplus

#include <stdio.h>

#ifdef __cplusplus
}
#endif //__cplusplus

//////////////////////////////////
// macros
//////////////////////////////////
#define OMitoa(val,str,radix) sprintf(str,"%d",val)

#define OM_SEARCH_ENV(name,searchpath,path) 

#define OM_NO_SPECIAL_SERIALIZE_LONG_DOUBLE

typedef  void * gen_ptr;
typedef  void * OMOSHandle;
typedef enum {OMPwrModeNone = 0}  OMPowerMode_t;

#endif // OMOSCONFIG_H

//$Log: omosconfig.h $
//Revision 1.8  2007/03/11 12:51:33  ilgiga
//Change copyright comment
//Revision 1.7  2007/03/01 16:23:29  ilgiga
//Telelogic instead of i-Logix
//Revision 1.6  2006/03/20 14:37:52  amos
//add #define OM_NO_COMPILER_SUPPORT_FOR_REPLACEMENT_DELETE
//Revision 1.5  2005/10/19 08:00:18  eldad
//#define OM_NO_SPECIAL_SERIALIZE_LONG_DOUBLE
//Revision 1.4  2005/05/19 14:34:54  vova
//No typename support added
//Revision 1.3  2004/01/19 14:00:25  eldad
//OM_SEARCH_ENV
//Revision 1.2  2003/10/28 14:10:13  vova
//__DIAB flag has been replaced by its native __DCC__
//Revision 1.1  2002/07/09 11:25:03  amos
//Initial revision
