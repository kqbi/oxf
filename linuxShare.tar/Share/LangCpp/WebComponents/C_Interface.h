/*
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*/

#ifndef C_INTREFACE_H
#define C_INTREFACE_H

//////////////////////////////////////////////////////////////////
//							                                    //
//                      WebServices C API  		                //
//                                                              //
//////////////////////////////////////////////////////////////////

extern "C" {
enum {NOACCESS_PERMISSION=0, READ_PERMISSION=1, WRITE_PERMISSION=2, READ_WRITE_PERMISSION=3};

int C_RegisterFunc(const char* name, void * operation);

// instance interface elements registration functions
unsigned short C_RegisterWebUnsignedLong(const char* NameOfComp,void *pAdapter);
unsigned short C_RegisterWebInteger(const char* NameOfComp,void *pAdapter);
unsigned short C_RegisterWebChar(const char* NameOfComp,void *pAdapter);
unsigned short C_RegisterWebBool(const char* NameOfComp,void *pAdapter);
unsigned short C_RegisterWebLong(const char* NameOfComp,void *pAdapter);
unsigned short C_RegisterWebULong(const char* NameOfComp,void *pAdapter);
unsigned short C_RegisterWebButton(const char* NameOfComp,void *pAdapter);
unsigned short C_RegisterWebDouble(const char* NameOfComp,void *pAdapter);
unsigned short C_RegisterWebString(const char* NameOfComp,void *pAdapter);
unsigned short C_RegisterWebAggregate(const char* NameOfComp,void *pAdapter);
unsigned short C_RegisterWebChoiceList(const char* NameOfComp,void *pAdapter, const char** choices);
                                                     
void C_AssociateParentWithChild(unsigned short parentID,unsigned short childId);
void C_SeparateParentFromChild(unsigned short parentID,unsigned short childId);
void C_BreakAllAssociations(unsigned short elementID);
void C_UnregisterWebComponent(unsigned short nID);

int ABSFileSave(const char *name, char data[], int len);

void C_PreInit();
int WebMain();
}

#endif /* C_INTREFACE_H */

