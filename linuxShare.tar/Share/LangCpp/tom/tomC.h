#ifndef tomC_H
#define tomC_H "$Id: tomC.h 1.7 2007/03/11 13:14:40 ilgiga Exp $"

/*
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomC.h $
//	file version:	$Revision: 1.7 $
//
//	purpose:	Interface for C.
//
//	author(s):	  Amos Ortal
//
//	date started:	31.5.1999
//	date changed:	$Date: 2007/03/11 13:14:40 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1999, 2008. All Rights Reserved.
//
*/

#ifdef USING_DLL
#include <RP_ANIM_DLL/rp_anim_dll_definition.h>
#else
#define RP_ANIM_DLL
#endif

#include <oxf/rp_framework_dll_definition.h>

#ifdef __cplusplus
extern "C" {
#endif

	/** handle a message **/
	RP_ANIM_DLL void TOMDispatcher_handleMessage(char * msg);

	/** close the TOM **/
	RP_ANIM_DLL void TOMDispatcher_quitTOM();

	/** psos x86 init iostream entry point **/
#ifdef USE_IOSTREAM
#ifdef OM_NEED_INIT_IOSTREAMS_RIC_TRACE
	
	/** init iostream entry point (pSOS) **/
	void TRiCInitIOStream(int,int,int,int);

#endif /* OM_NEED_INIT_IOSTREAMS_RIC_TRACE */
#endif /* USE_IOSTREAM */

#ifdef __cplusplus
}
#endif

#endif	/* tomC_H */

/*
// $Log: tomC.h $
// Revision 1.7  2007/03/11 13:14:40  ilgiga
// Change copyright comment
// Revision 1.6  2007/03/04 15:07:28  ilgiga
// Telelogic instead of i-Logix
// Revision 1.5  2002/07/11 13:02:00  amos
// do not include omosconfig.h directly
// Revision 1.3.1.1  2002/07/09 12:01:27  amos
// framework cleanup from RTOS specific code - back to r41 main branch
// Revision 1.4.1.2  2002/07/09 12:01:27  amos
// replace adaptor specific #ifdef with generic statements
// Revision 1.4.1.1  2000/11/06 10:16:29  amos
// Duplicate revision
// Revision 1.3  1999/11/08 15:09:34  zvika
// Add DLLs.
// Revision 1.2  1999/10/17 14:53:34  amos
// add new method TRiCInitIOStream() which init the iostream for psos x86 in C.
// Revision 1.1  1999/05/31 12:52:58  amos
// Initial revision

*/
