#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomsilent.cpp 1.5 2007/03/11 13:14:46 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomsilent.cpp $
//	file version:	$Revision: 1.5 $
//
//	purpose:	run silent
//
//	author(s):		Beery Holstein
//	date started:	10.98
//	date changed:	$Date: 2007/03/11 13:14:46 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1998, 2008. All Rights Reserved.
//
#include "tomsilent.h"
#include "tomproxy.h"

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomsilent_H;
#endif

OMBoolean TOMSilent::execute(TOMProxyItem & proxy)
{
	proxy.goSilent();
	return TRUE;
}

OMBoolean TOMLoud::execute(TOMProxyItem & proxy)
{
	proxy.goLoud();
	return TRUE;
}


//
// $Log: tomsilent.cpp $
// Revision 1.5  2007/03/11 13:14:46  ilgiga
// Change copyright comment
// Revision 1.4  2007/03/04 15:07:37  ilgiga
// Telelogic instead of i-Logix
// Revision 1.3  2005/08/23 14:50:47  amos
// bugfix 85444 to main branch
// Revision 1.2.1.2  2005/08/22 10:05:42  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.2  2000/07/11 09:23:51  amos
// changes related to modify char* to const char*.
// Revision 1.1  1998/11/30 12:36:34  beery
// Initial revision
//
