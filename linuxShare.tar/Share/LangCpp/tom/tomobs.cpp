#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomobs.cpp 1.33 2007/03/11 13:14:43 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomobs.cpp $
//	file version:	$Revision: 1.33 $
//
//	purpose: 
//
//	author(s):		Yachin Pnueli
//	date started:	8.9.96
//	date changed:	$Date: 2007/03/11 13:14:43 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "tomobs.h"
#include "tomsys.h"
#include "tominst.h"

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomobs_H;
#endif

void TOMOrderedCOIList::addInPlace(TOMCreateObserverItem *i) {
/*
	if (isEmpty() || i->getSize() <= getFirstConcept()->getSize())
		addFirst(i);
	else if (i->getSize() >= getLastConcept()->getSize())
		add(i);
	else {
		// Here we know we have at least two elements in the list
		// and i should be placed somewhere between them
		OMListItem<TOMCreateObserverItem*> *item, *current, *next;
		// 1. Create a new list item
		item = new OMListItem<TOMCreateObserverItem *>(i);
		// 2. Find the position for it
		current = first;
		do {
			next = current->getNext();
			if (i->getSize() <= getCurrent(next)->getSize()) {
				// Place item between current and next
				current->connectTo(item);
				item->connectTo(next);
				return;
			}
			current = next;
		} while (current!=last);  // Should never happen
	}
*/
	// currently we simply add.
	add(i);
}

TOMCreateObserver::~TOMCreateObserver() { 
	for (OMIterator<TOMCreateObserverItem*> i(l); (*i); ++i)
		delete (*i);
	l.removeAll(); 
	createObserver = NULL;
}

/*
// Auxillery functions for notifyNewItem
// Skip multiplicit yindicators and white spaces
void skipMultAndSpaces(char *&c) {
	if (*c=='[') {
		do { c++; } while (*c!=']');
		c++;
	}
	while (isspace(*c)) c++;
}
// Determines if the found item was found via an all composite
// navigation expression
OMBoolean isCompositeNavExpItem(char * expression, TOMInstance *item) {
	if (item->getContext()==OMSystemContext)
		return FALSE; // item is not composite
	OMString name;
	item->outputFullName(name);
	char * myName = name.GetBuffer(0);
	// Note that without multiplicties either myName will differ
	// from expression before end of expression 
	// or myName will be shorter than expression
	do {
		if (*myName!=*expression) return FALSE;
		myName++;
		expression++;
		skipMultAndSpaces(myName);
		skipMultAndSpaces(expression);
	} while (*myName!='\0');
	while (isspace(*expression)) expression++;
	return (*expression=='\0' || *expression==':');
}
*/

void TOMCreateObserver::notifyNewItem() {
	// Some new item was create - try to reRegister each of 
	// the waiting elements
	OMList<TOMCreateObserverItem*> tuplesToRemove;
	OMIterator<TOMCreateObserverItem*> iter(l);
	for( ; *iter; ++iter) {
		TOMCreateObserverItem* tuple = (*iter);
		// Look for the item matching this tuple
		TOMInstance * item = (TOMInstance *)
			TOMSystem::instance()->tryToRegisterObserver(
				tuple->myObserver,
				tuple->myMask,
				tuple->myName.GetBuffer(0));
		if ( isRealItem(item) ) { 
			// Item was found and Registration succeeded
			// Notify the observer appropriately ...
			tuple->myObserver->notifyInstanceFound(item);
			// ... and mark tuple for removal
			tuplesToRemove.add(tuple);
		}
		/* Debugging purposes only ...
		else if (item == OMGarbage) {
			// Item was found to be "never to be found"
			OMString errMsg = "Expression ";
			errMsg += tuple->myName;
			errMsg += " Ignored - Cannot be mapped to run time object";
			tomSendError(errMsg);
		} */
		else if (item == OMGarbage) {
			// Item was found to be "never to be found"
			// ... and mark tuple for removal
			tuplesToRemove.add(tuple);
		}
	}
	// Now remove those tuples marked for removal
	for(iter.reset(tuplesToRemove);	*iter; ++iter) {
		TOMCreateObserverItem* tuple = (*iter);
		l.remove(tuple);
		delete tuple;
	}
}

void TOMCreateObserver::removeObserver(TOMUniversalObserver* theObserver,
									   char* theName) {
	// Remove the entry theObserver, theName from list

	// Search for the item
	for (OMIterator<TOMCreateObserverItem*> iter(l); (*iter); ++iter) {
		TOMCreateObserverItem* tuple = (*iter);
		if ( tuple->myObserver==theObserver &&
			 tuple->myName==theName) {
			l.remove(tuple);
			delete (tuple);
			return;
		}
	}
}

// The global "create observer" initialized by tomSystem
TOMCreateObserver* createObserver = NULL;

TOMShowObserver::TOMShowObserver(TOMProxyItem * theObserved,
								TOMUniversalObserver * theObserver,
								int theMask)
								: myMask(theMask)
{
	myObserved = theObserved;
	myObserver = theObserver;
	theObserved->registerShowObserver(this);
}

void TOMShowObserver::removeYourSelf() 
{
	myObserved->deregisterShowObserver(this);
	delete this;
}

void TOMShowObserver::notifyEventQueueValues(OMSData * msg) {
	myObserver->notifyEventQueueValues(msg);
	myMask=OMInterestMask(OMNoInterest);
}

void TOMShowObserver::notifyCallStackValues(OMSData * msg) {
	myObserver->notifyCallStackValues(msg);
	myMask=OMInterestMask(OMNoInterest);
}

void TOMShowObserver::notifyClassValues(TOMClass *) {
	// Why do we need this routine ??????
//	myObserver->notifyClassValues(c);
	myMask=OMInterestMask(OMNoInterest);
}

void TOMShowObserver::notifyStateConfiguration(const TOMInstance * i,
							  OMList<OMHandle *>*l,
							  OMBoolean t) {
	myObserver->notifyStateConfiguration(i,l,t);
	myMask -= OMStateInterest;
}
void TOMShowObserver::notifyRelationsValues(TOMInstance* item) {
	myObserver->notifyRelationsValues(item);
	myMask -= OMRelationInterest;
}
void TOMShowObserver::notifyAttributeValues(
							OMList<TOMAttributeItem *> *l, 
						   const TOMProxyItem *i, 
						   OMBoolean t) {
	myObserver->notifyAttributeValues(l,i,t);
	myMask -= OMAttributesInterest;
}

//
// $Log: tomobs.cpp $
// Revision 1.33  2007/03/11 13:14:43  ilgiga
// Change copyright comment
// Revision 1.32  2007/03/04 15:07:33  ilgiga
// Telelogic instead of i-Logix
// Revision 1.31  2005/08/23 14:50:45  amos
// bugfix 85444 to main branch
// Revision 1.30.1.2  2005/08/22 10:05:40  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.30  2002/11/18 10:15:49  Eldad
// Removed letter to Yachin from comments.
// Revision 1.29  2002/11/06 12:00:46  Eldad
// 1.28.1.3 to main branch.
// Revision 1.28.1.3  2002/11/05 12:35:41  Eldad
// Added as comment the prev. fragment
// Revision 1.28.1.2  2002/10/30 14:16:11  Eldad
// Removed error as it makes no sense...
// Revision 1.28  2000/12/25 10:39:51  amos
// move to warning level 4
// Revision 1.27  2000/07/11 09:23:50  amos
// changes related to modify char* to const char*.
// Revision 1.26  1998/11/19 17:55:45  beery
// Revision 1.24  1998/08/02 15:07:45  beery
// Revision 1.23  1998/04/21 10:36:47  yachin
// Fix spelling mistake
// Revision 1.22.1.1  1997/08/13 09:51:50  yachin
// Duplicate revision
// Revision 1.21  1997/08/12 08:37:26  yachin
// fix dynphil name recognition bug
// Revision 1.20  1997/08/07 05:51:26  yachin
// Remove "impossible expressions" from createObserver list
// 
// Revision 1.19  1997/07/20 11:36:38  yachin
// Adding globals to animation
// Revision 1.18  1997/02/20 12:18:46  yachin
// Fix removeObserver
// Revision 1.17  1997/02/16 09:29:06  yachin
// remove theClass parameter from instanceCreated/delted notifies.
// make inverseRelationConnect cascade from relations and not the createObserver
// Revision 1.16  1997/02/11 12:54:37  yachin
// Adding Name spaces
// Revision 1.15  1997/02/05 13:38:52  yachin
// Bug fixes
// Revision 1.14  1997/01/29 09:43:58  yachin
// bug fix for connect --> connectTo
// Revision 1.13  1997/01/21 10:52:49  yachin
// User Threads part I
// Revision 1.12  1996/12/22 13:13:53  yachin
// Revision 1.10  1996/12/19 13:15:13  yachin
// Revision 1.9  1996/11/24 12:40:41  yachin
// Revision 1.8  1996/10/09 07:37:09  yachin
// Revision 1.7  1996/10/03 08:38:07  yachin
// Another fix for the "early relations"  bug
// Revision 1.6  1996/10/02 08:40:54  yachin
// Hopefully fixed "early" relation registration bug
// Revision 1.5  1996/09/30 10:05:29  yachin
// Revision 1.4  1996/09/26 09:01:49  yachin
// Fix bug wiht interest masks
// Change instance count to star tat 0
// Revision 1.3  1996/09/19 08:04:07  yachin
// Proper deletion when animation is terminated
// Revision 1.2  1996/09/16 09:28:33  yachin
// Revision 1.1  1996/09/08 13:29:46  yachin
// Initial revision
//
