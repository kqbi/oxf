#ifndef tomrefresh_H
#define tomrefresh_H "$Id: tomrefresh.h 1.3 2007/03/11 13:14:45 ilgiga Exp $"

//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomrefresh.h $
//	file version:	$Revision: 1.3 $
//
//	purpose:	TOM List and derived class (proxy relations, proxy classes)
//
//	author(s):		Beery Holstein
//	date started:	10.98
//	date changed:	$Date: 2007/03/11 13:14:45 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1998, 2008. All Rights Reserved.
//

#include "tomvisitor.h"
#include "tomproxy.h"
#include "tomobs.h"

class TOMRefresh: public TOMProxyVisitor1Arg  {
public:
	virtual OMBoolean execute(TOMProxyItem & proxy);
};

class TOMRefresher: public TOMUniversalObserver {
	TOMProxyItem * myProxy;
public:
	TOMRefresher();
	TOMRefresher(TOMProxyItem * aProxy);
	void setProxy(TOMProxyItem * proxy) { myProxy = proxy; }
	void notifyStateConfiguration(const TOMInstance *,
								  OMList<OMHandle *>*,
								  OMBoolean);
	virtual void notifyAttributeValues(OMList<TOMAttributeItem *> *, 
							   const TOMProxyItem *, 
							   OMBoolean);
	virtual void notifyRelationsValues(TOMInstance* item);
	virtual void notifyCallStackValues(OMSData *);
	virtual void notifyEventQueueValues(OMSData * msg);
};



//
// $Log: tomrefresh.h $
// Revision 1.3  2007/03/11 13:14:45  ilgiga
// Change copyright comment
// Revision 1.2  2007/03/04 15:07:36  ilgiga
// Telelogic instead of i-Logix
// Revision 1.1  1998/11/30 12:36:35  beery
// Initial revision
//

#endif

