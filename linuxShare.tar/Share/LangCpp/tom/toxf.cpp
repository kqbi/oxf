#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: toxf.cpp 1.10 2007/03/11 13:14:48 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/toxf.cpp $
//	file version:	$Revision: 1.10 $
//
//	purpose: Some global TOM strings and string routines
//
//	author(s):		Yachin Pnueli
//	date started:	15.7.99
//	date changed:	$Date: 2007/03/11 13:14:48 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1999, 2008. All Rights Reserved.
//
#include "toxf.h"

#ifdef OMANIMATOR
#include <Foundtn/util/toolmode.h>
#include <Foundtn/project/workspace.h>
#include <Foundtn/project/project.h>
#include <Foundtn/project/cgconfig.h>
#endif


const char* objectCallString	 =	".";
const char* packageCallString	 =	"::";

#ifdef OMANIMATOR

OMBoolean isLangC() {
	OMBoolean isLangC = FALSE;
    IProject *prj = CurrentWorkspace::GetActiveProject();
	if(prj)
    {
		isLangC = (IDObject::isLangC(prj->getConfiguration()) == TRUE);
    }
	return isLangC;
}

OMBoolean isLangAda() {
	OMBoolean langAda = FALSE;
    IProject *prj = CurrentWorkspace::GetActiveProject();
	if(prj)
    {
		langAda = (IDObject::isLangAda(prj->getConfiguration()) == TRUE);
    }
	return langAda;
}

#else 

OMBoolean isLangC() {
#ifdef RIC_APP	// C app
	return TRUE;
#else
	return FALSE;
#endif //RIC_APP
}

OMBoolean isLangAda() {
#ifdef RIC_APP	// C app
	return TRUE;
#else
	return FALSE;
#endif //RIC_APP
}

#endif //OMANIMATOR 

const char* getInstaceCallString() {
#ifdef OMANIMATOR
	const char* cppInstanceCallString	 =	"->";
	if (isLangC() || isLangAda()) // Go by tool mode
		return objectCallString;
	else
		return cppInstanceCallString;
#else
#ifdef RIC_APP	// C app
	return objectCallString;
#else
	const char* cppInstanceCallString	 =	"->";
	return cppInstanceCallString; // Go by languague of this file (C++)
#endif
#endif
}

const char* getClassCallString() {
	const char* classCallString	 =	"::";
#ifdef OMANIMATOR
	if (isLangC() || isLangAda()) // Go by tool mode
		return objectCallString;
	else
		return classCallString;
#else
	return classCallString; // Go by languague of this file (C++)
#endif
}


OMBoolean isXString(const char * c, const char* x) {
	for(int i=0; x[i]!='\0'; i++) {
		if (c[i]!=x[i])
			return FALSE;
	}
	return TRUE;
}

char* skipXString(char*& c, const char* x) {
	for(int i=0; x[i]!='\0'; i++) {
		c++;
	}
	return c;
}

void tomTrimCarriageReturn(OMString& s)
{
	tomTrimCarriageReturn(s.GetBuffer(0));
}

void tomTrimCarriageReturn(char* s)
{
	size_t length = strlen(s);
	if (length>0)
	{
		if (s[length-1] == '\r')
		{
			s[length-1] = 0;
		}
	}
}






//
// $Log: toxf.cpp $
// Revision 1.10  2007/03/11 13:14:48  ilgiga
// Change copyright comment
// Revision 1.9  2007/03/04 15:07:39  ilgiga
// Telelogic instead of i-Logix
// Revision 1.8  2006/04/06 14:23:43  yzharkovsky
// Fix for Linux compilation error.
// Revision 1.7  2006/04/04 13:55:20  yzharkovsky
// Multi language refactoring:
// isLang static calls were changed to context related calls.
// Revision 1.6  2005/08/23 14:50:49  amos
// bugfix 85444 to main branch
// Revision 1.5.1.2  2005/08/22 10:05:44  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.5  2001/05/13 07:37:19  vova
// Compilation warnings in pSOS:Const string declaration placed under ifdef operator(#44325)
// Revision 1.4  2000/07/11 09:20:08  amos
// changes related to modify char* to const char*.
// Revision 1.3  1999/09/08 10:58:33  yachin
// Fix bugs 31581,31662,31958
// Revision 1.2  1999/08/30 11:31:44  yachin
// Fix bug 'rhapsody gets stuck on show #Thread @@SubB[0]->#Eventqueue
// Revision 1.1  1999/07/15 13:42:17  yachin
// Initial revision
//
