#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomdisp.cpp 1.40 2007/03/11 13:14:42 ilgiga Exp $";
#endif 
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomdisp.cpp $
//	file version:	$Revision: 1.40 $
//
//	purpose: Methods of Class TOMDispatcher	 	
//
//	author(s):		Yachin Pnueli
//	date started:	28.5.96
//	date changed:	$Date: 2007/03/11 13:14:42 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "toxf.h"

#include "tomdisp.h"

#ifdef RIC_APP	// C app
typedef struct RiCSData RiCSData;
extern "C" {
RiCSData * RiCSData_string2RiCSData(const char * data);
void ARCSD_instance();
void ARCSD_putMessage(RiCSData*);
}
#else	// C++
#include <aom/aomdisp.h>
#endif 

#include "tommsg.h"
#include "tomsys.h"
#include "tommask.h"
#include <omcom/omexp.h>

#ifdef OMANIMATOR
#include "tomExtern.h"
#endif // OMANIMATOR


#include <omcom/RiCppAnimMessages.h>
#include <omcom/AnimRhapTranslator.h>
#include <omcom/AnimPointerField.h>
#include <omcom/AnimRegisterOperations.h>
#include <omcom/AnimOperationData.h>
#include <omcom/AnimOpCallReply.h>
#include <omcom/AnimDebuggerBreakPoint.h>
#include <omcom/AnimForeignMessage.h>
#include <omcom/AnimNameValueData.h>
#include <omcom/AnimOpReturn.h>

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomdisp_H;
#endif 



TOMDispatcher* TOMDispatcher::theDispatcher = NULL;

extern TOMProxyItem* lastDeleted;


void dummy()
{
	AnimRegisterOperations dummy1;
	AnimOperationData dummy2;
	AnimOpCallReply dummy3;
	AnimDebuggerBreakPoint dummy4;
	AnimForeignMessage dummy5;
	AnimNameValueData dummy6;
	AnimOpReturn dummy7;
}

TOMDispatcher::TOMDispatcher() : m_msgTime(0) { 

	theDispatcher = this; 
	// hookup with the message translator
	animMessageTranslator = AnimTranslatorFactory::instance()->getTranslatorInstance("Rhapsody");

}

TOMDispatcher::~TOMDispatcher()
{ 
	theDispatcher = NULL; 
}


void TOMDispatcher::handleMessage(OMSData* rawS, void* pSocket ) {
	// Handle a single simple message

	AnimMessage *animMessage = NULL;

	animMessage = animMessageTranslator->decodeMessage(rawS);

	if (animMessage != NULL) { 

		AnimPointerField *pF = animMessage->getDestOrSource();
		// pF should never be NULL
		gen_ptr dest = pF->getValue();
		if (animMessage->isConstructionMessage())
		{
			dest = (gen_ptr)TOMSystem::instance()->getInstanceByReal(dest);
		}
		if (dest == NULL) {
			TOMSystem::instance()->handleMessage(animMessage);
		}
		else {
			if (tomIsValidItem((void*)(rhp_long64_t)dest)) {
				((TOMProxyItem *)(rhp_long64_t)dest)->handleMessage(animMessage);
			}
		}
		// cleanup
		delete animMessage;
#ifdef OMANIMATOR
		delete rawS;
#endif

	}
	else 
	{
		TOMSData* s = (TOMSData*)rawS;
		// Notify TOMProxyConsole about new message 
		// needed so we can print the same mult=2 message more than
		// once if it comes from different aom messages
		if (TOMProxyConsole::instance())
			TOMProxyConsole::instance()->notifyNewMessage();


		OMSPosition position = s->getFirst();
		// first handle the time stamp
		// if the message come back from an another TOM element this the message do not have the time stamp
		if (s->isTimeUnit(position)) {
			timeUnit time = s->safeGetTimeUnit(position);
			if (m_msgTime != time)
			{
				m_msgTime = time;
				TOMSystem::instance()->notifyTimeChange(time);
			}
			// get the original mesage and posistion
			TOMSData* tmp = s->safeGetOMSData(position);
#ifdef OMANIMATOR
			// delete the old message.
			// In animator the socket creates s item so we must delete it
			// In tracer we use the "memory" of the caller to handle
			delete s;
#endif 
			// reset s
			s = tmp;
			position = s->getFirst();
		}

		// Get the destination of the message
		void *dest = s->safeGetPointer(position);
		// Could be a message predating proxy creation

		// Get the Notify/Command of the message
		OMNotify msgCode = s->safeGetOMNotify(position);

		// If message has no destination send it to TOMSystem::instance()
		if (dest==NULL)
			TOMSystem::instance()->handleMessage(msgCode,s,position,pSocket);
		else if (tomIsValidItem(dest)) { // Hope item is o.k.
			((TOMProxyItem *)dest)->handleMessage(msgCode,s,position);
		} else {
			// This should never happen
 			OMString msg = "Tracer/Animator Received a command for an invalid instance. Message Code: ";
			msg += (char*)omnotify2String(msgCode);
			tomSendWarning(msg);
#ifdef OMANIMATOR
			OMString dbg;
			dbg.Format("Destination: = %x", dest);;
			tomSendWarning(dbg);
#endif
		}



#ifdef OMANIMATOR
		// In animator the socket creates s item so we must delete it
		// In tracer we use the "memory" of the caller to handle
		if (s!=NULL) delete s;
#endif 
	}
}

void TOMDispatcher::encodeAndSendMessage(AnimMessage *msg)
{
	if (msg != NULL) {
		OMSData *omsData = (OMSData *)(animMessageTranslator->encodeMessage(msg));
		sendMessage(omsData);
	}
	delete msg;
}

void TOMDispatcher::sendMessage(OMSData* m)
{
#ifdef OMTRACER

#ifdef RIC_APP		// C app
	RiCSData * s = RiCSData_string2RiCSData(m->getRawData());
	ARCSD_instance();
	ARCSD_putMessage(s);
#else
	AOMSchedDispatcher::instance()->putMessage(m);
#endif // RIC_APP

#endif // OMTRACER

#ifdef OMANIMATOR
	(void)TOMExterns::Anim()->omAnimSendMessage(m->getRawData(),m->getLength());
	delete m;
#endif 
}


void TOMDispatcher::quitTOM() {

	TOMProxyConsole * pcons = TOMProxyConsole::instance();
	if (pcons) {
		delete pcons;
	}
	TOMSystem *tsys =  TOMSystem::instance();
	if (tsys) {
		delete tsys;
	}
}

void TOMDispatcher::sendForeignMessage(OMString& payload, gen_ptr destOrSource /* = NULL */)
{
	AnimForeignMessage *msg = new AnimForeignMessage();
	if (msg != NULL) 
	{
		msg->setPayload(payload);
		if (destOrSource != NULL)
			msg->setDestOrSource(destOrSource);
		encodeAndSendMessage(msg);
	}
}


#ifdef OMOMATE
void sendError(const char * s) { tomSendError(s); }
#endif 

//
// $Log: tomdisp.cpp $
// Revision 1.40  2007/03/11 13:14:42  ilgiga
// Change copyright comment
// Revision 1.39  2007/03/04 15:07:31  ilgiga
// Telelogic instead of i-Logix
// Revision 1.38  2007/02/08 10:38:38  ilelpa
// Added the ability to get time notifications to observer. This is used for test conductor
// to get the time from Rhapsody instead of relying on the OS clock.
// Revision 1.37  2006/10/31 08:58:51  ccohen
// support running multiple animation processes.
// Revision 1.36  2006/09/27 11:47:34  eldad
// Foreign messages to application
// Revision 1.35  2005/08/23 14:50:43  amos
// bugfix 85444 to main branch
// Revision 1.34.2.2  2005/08/22 10:05:39  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.34  2003/05/15 07:02:00  Eldad
// Serailization of output params and return value
// Revision 1.33.1.1  2003/05/08 10:07:43  Eldad
// Duplicate revision
// Revision 1.32.1.1  2002/09/26 08:09:58  Eldad
// Duplicate revision
// Revision 1.31.1.2  2002/09/24 12:42:51  Eldad
// Revision 1.31.1.1  2002/07/31 08:51:23  Eldad
// Duplicate revision
// Revision 1.30  2002/07/30 11:17:00  Eldad
// If an exception occures while decoding a message in tracer - catch it and try the
// old decoding...
// Revision 1.29  2002/07/29 09:40:45  Eldad
// Anim Operation Calls.
// Revision 1.28  2002/04/23 14:17:26  Eldad
// 1.27.1.2 to main branch.
// Revision 1.27.1.2  2002/04/12 14:34:55  Eldad
// Revision 1.27.1.1  2001/05/02 12:46:47  Eldad
// Duplicate revision
// Revision 1.26  2000/08/06 07:46:11  amos
// merge 1.24.1.1 (36668,36667) into 1.25
// Revision 1.25  2000/05/26 06:51:30  yachin
// Remove DLL dependencies
// Revision 1.24.1.1  2000/07/11 09:23:50  amos
// changes related to modify char* to const char*.
// Revision 1.24  2000/01/31 09:51:48  amos
// back to main branch
// Revision 1.23.1.3  2000/01/30 07:44:40  amos
// handle memory leaks
// Revision 1.23.1.2  2000/01/27 09:42:18  amos
// add handling of the message time stamp header in TOMDispatcher::handleMessage()
// The time stamp header is added to each message send by AOM, and is used to print the time stamp of an event.
// Revision 1.23.1.1  2000/01/20 07:07:59  amos
// Duplicate revision
// Revision 1.22  1999/06/02 16:15:36  amos
// enable connection with C project
// Revision 1.21  1999/02/16 05:56:54  yachin
// Speed up of constructors
// Revision 1.20  1997/02/06 13:33:49  yachin
// Switched from try to tomIsValidItem
// Revision 1.19  1996/12/22 13:13:51  yachin
// Revision 1.17  1996/11/24 12:40:36  yachin
// Revision 1.16  1996/10/10 08:01:24  yachin
// Revision 1.15  1996/10/09 07:37:05  yachin
// Revision 1.14  1996/10/02 13:55:47  yachin
// Fix the double event bug
// Revision 1.13  1996/09/18 06:53:06  ofer
// interface with tomanim is done via global functions
// added omAnimationStart and omSendMessage whih are called by
// tomanim (tomdisp.cpp tomstep.cpp)
// Revision 1.12  1996/09/16 13:44:27  yachin
// Revision 1.11  1996/09/16 09:28:29  yachin
// Revision 1.10  1996/09/08 13:28:55  yachin
// Registeration of items which do not yet exist
// Revision 1.9  1996/08/29 07:04:06  ofer
// Revision 1.8  1996/08/08 08:23:27  yachin
// Revision 1.7  1996/08/06 12:52:05  yachin
// Version for Prototype 4
// Revision 1.6  1996/07/22 11:30:29  yachin
// Revision 1.5  1996/07/10 05:50:08  yachin
// Reprecussion of reorganizatio nof AOM
// Revision 1.4  1996/06/24 11:19:35  yachin
// Removed TOMTimer - currently not needed
// Revision 1.3  1996/06/20 10:23:09  yachin
// Revision 1.2  1996/06/19 10:21:26  yachin
// Revision 1.1  1996/06/17 05:40:41  yachin
// Initial revision
//
