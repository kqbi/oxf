#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomproxy.cpp 1.64 2007/03/11 13:14:45 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomproxy.cpp $
//	file version:	$Revision: 1.64 $
//
//	purpose: Methods of Class TOMProxyItem	 	
//
//	author(s):		Yachin Pnueli
//	date started:	20.5.96
//	date changed:	$Date: 2007/03/11 13:14:45 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "tomsys.h"
#include "tomproxy.h"
#include <omcom/omexp.h>
#include "tomsys.h"
#include "tomdisp.h"
#include "tomobs.h"
#include "tommask.h"

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomproxy_H;
#endif

// Needed for the try catch to work properly
#ifdef OMANIMATOR
	extern void OM_enableSE();
	extern void OM_disableSE();
#endif

OMBoolean tomIsValidItem(const void * const i) {
#ifdef OMANIMATOR
	OM_disableSE();
#endif
	OMTRY {
		// Check:	1. That we can "cast"
		//			2. That the virtual table is valid
		//			3. That the object is not marked deleted
		if (isCodeItem(i)) {
#ifdef OMANIMATOR
			OM_enableSE();
#endif
			return FALSE;
		}
		OMBoolean a =	((TOMProxyItem *)i)->isValid();
//		if (!a)
//			tomSendError("Found invalid item");
#ifdef OMANIMATOR
		OM_enableSE();
#endif
		return a==TRUE;
	} OMCATCH_ALL { 
//			tomSendError("Found Crash invalid item");
#ifdef OMANIMATOR
			OM_enableSE();
#endif
			return FALSE;
	}
}


short TOMProxyItem::MagicCookie = 0x3299;

TOMProxyItem::TOMProxyItem(	char * theName,
							OMProxyType theType,
							const TOMProxyItem * theContext) 
  : myLastSentMask(OMNoInterest), mySilentMode(TOMInLoud), mySocket(NULL), myAppName(NULL)
{
	myRefresher.setProxy(this);
	myCookie = TOMProxyItem::MagicCookie;
	setName(theName, theType, theContext);
	setReal(OMNoInterest, NULL);
	if (TOMSystem::sysInSilentMode()) {
		goSilent();
	}
}

TOMProxyItem::TOMProxyItem(	gen_ptr theReal,
							 char * theName,
							 OMProxyType theType,
							 OMInterestMask theMask,
							 const TOMProxyItem * theContext) 
  : myLastSentMask(OMNoInterest), mySilentMode(TOMInLoud), mySocket(NULL), myAppName(NULL)
{
	myRefresher.setProxy(this);
	myCookie = TOMProxyItem::MagicCookie;
	setName(theName, theType, theContext);
	setReal(theMask, theReal);
	if (TOMSystem::sysInSilentMode()) {
		goSilent();
	}
}


void TOMProxyItem::clearObserversNotify() {
	// Clear observer - but notify them before they are cleared
	// USE with "Dynamic" proxyItem (instance,eventqueue,callStack)
#ifdef OMANIMATOR
	// Notify all my observers about my deletion
	// Since their response is to deregister themselves
	// we do this one at a time
	while (!observerList.isEmpty()) {
		// Notify the observer about the deletion
		TOMUniversalObserver * obs = 
			observerList.getFirstConcept()->getObserver();
		obs->notifyItemDeleted(this);
		// Delete the observer if it did not deregister itself
		if (!observerList.isEmpty() &&
			observerList.getFirstConcept()->getObserver() == obs){
			delete observerList.getFirstConcept();
			observerList.removeFirst();
		}
	}
#endif
}


void TOMProxyItem::clearObserversWithoutNotify() {
	// Clear observer - do notify them before they are cleared
	// USE with "Static" proxyItem (inclasses breakpoint Manager etc.)
#ifdef OMANIMATOR
		for(OMIterator<TOMMaskedObserver*> j(observerList); *j; ++j)
			delete (*j);
		observerList.removeAll();
#endif
}

OMBoolean TOMProxyItem::isValid() const {
	return (TOMProxyItem::MagicCookie == myCookie) && (myReal!=(gen_ptr)(rhp_long64_t)OMInDestruction);
}


TOMProxyItem::~TOMProxyItem() {
	// Mark item itself as deleted
	myName = NULL;
	myReal = (gen_ptr)(rhp_long64_t)OMInDestruction;

	// Clear my regular observers
	if (TOMSystem::animationIsActive())
		clearObserversNotify();
	else
		clearObserversWithoutNotify();

	// Clear my show observers
	// Notify them and they delete themselves
	for(OMIterator<TOMShowObserver*> i(showObserverList); (*i); ++i)
		(*i)->notifyItemDeleted(this);
	showObserverList.removeAll();

	// Mark item itself as deleted
	myCookie = 0;

	mySocket = NULL;
	if(myAppName)
		delete [] myAppName;
	myAppName = NULL;
}


void TOMProxyItem::setReal(OMInterestMask theMask, gen_ptr theReal) {
	// Store your "real"
	myReal = theReal;
	
	// Set Your interest mask
	OMInterestMask sendMask;
	if (inSilentMode()) {
		myMask = OMExistInterest && getMask();
		setSavedInterestMask(theMask);
		sendMask = OMExistInterest && getMask();
	}
	else {
		myMask = theMask;
		setSavedInterestMask(OMNoInterest);
		sendMask = getFullMask();
	}
	
	if (myReal!=NULL) {
		// Notify "real" that your are ready (send "this" + interestMask)
		OMSData *s = new OMSData(myReal, proxyCreated, (gen_ptr)(rhp_long64_t)this);
		s->addItem(sendMask.toInt());
		// this is the mask that my proxy knows anout
		myLastSentMask = sendMask;
		// Send it to otherside
		TOMDispatcher::instance()->sendMessage(s);
	}
}

/*
void TOMProxyItem::setInterestMask(OMInterestMask newMask) {
	if (newMask!=myMask) {
		myMask = newMask;
		if (myReal!=NULL) {
			// Create a message with the new interestMask
			OMInterestMask sentMask = getFullMask();
			OMSData *s = new OMSData(myReal, newInterestMask, 
												sentMask.toInt());
			// Send it to otherside
			TOMDispatcher::instance()->sendMessage(s);
		}
	}
}
*/


void TOMProxyItem::setInterestMask(OMInterestMask newMask) {
	myMask = newMask;
	// update my real
	if (myReal!=NULL) {
		OMInterestMask sendMask;
		if (inSilentMode()) {
			// in silent mode we ignore the defaults
			sendMask = newMask;
		}
		else {
			// consider the defaults, too
			sendMask = getFullMask();
		}
		if (sendMask != myLastSentMask) 
		{
			myLastSentMask = sendMask;
			// Create a message with the new interestMask
			OMSData *s = new OMSData(myReal, newInterestMask, 
												sendMask.toInt());

			// Send it to otherside
			TOMDispatcher::instance()->sendMessage(s);
		}
	}
}

#ifdef OMTRACER
#define registerToTrace_param_base
#else // !OMTRACER
#ifdef OMANIMATOR
#define registerToTrace_param_base base
#endif // OMANIMATOR
#endif // OMTRACER

void TOMProxyItem::registerToTrace(TOMProxyItem * registerToTrace_param_base)
{
#ifdef OMTRACER
	// in lazy registration, make sure that the console is registered for the newly added class
	// For the mask calculation see TOMProxyConsole::TOMProxyConsole() and TOMSystem::registerObserver()
	TOMProxyItem* sys = TOMSystem::instance();
	registerObserver(TOMProxyConsole::instance(),	sys->getMask());
#else // !OMTRACER
#ifdef OMANIMATOR
	// in lazy registration, make sure that initially the class reports to the console "at the same" level as the package
	// find the proxy console oberver of the package
	if (registerToTrace_param_base != NULL) {
		TOMMaskedObserver * proxyConsoleObserver = registerToTrace_param_base->getObserver(TOMProxyConsole::instance());
		if (proxyConsoleObserver != NULL) {
			// get the relevant mask
			OMInterestMask proxyConsoleObserverMask = proxyConsoleObserver->getMask();
			// set the new class with the same mask
			registerObserver(TOMProxyConsole::instance(),	proxyConsoleObserverMask);
		}
	}
#endif // OMANIMATOR
#endif // OMTRACER
}

inline void TOMProxyItem::_registerObserver(TOMUniversalObserver* obs, 
											OMInterestMask theMask)
{
#ifdef OMANIMATOR
	observerList.add(new TOMMaskedObserver(obs,theMask));
#else
	if (obs && theMask.toInt()) { /* unreferenced formal parameter warning */ }
#endif
}

inline void TOMProxyItem::_deregisterObserver(TOMMaskedObserver* item)
{
#ifdef OMANIMATOR
		observerList.remove(item);
		delete item;
#else
	if (item) { /* unreferenced formal parameter warning */ }
#endif
}

inline void TOMProxyItem::_updateObserver(TOMUniversalObserver* obs,
										  TOMMaskedObserver* item, 
										  OMInterestMask theMask)
{
#ifdef OMANIMATOR
	if (item!=NULL) // Observer was present Update it's mask
		item->setMask(theMask);
	else // Observer Not preset - Add it
		_registerObserver(obs,theMask);
#else
	if (obs && item && theMask.toInt()) { /* unreferenced formal parameter warning */ }
#endif
}

void TOMProxyItem::registerObserver(TOMUniversalObserver* obs, 
									OMInterestMask theMask)
{
	TOMProxyItem::reRegisterObserver(obs,theMask);
}

void TOMProxyItem::reRegisterObserver(TOMUniversalObserver* obs,
									  OMInterestMask theMask)
{
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	// First check if we should reRegister or deRegister
	if ( !(theMask.isInteresting()) ) { 
		TOMProxyItem::deregisterObserver(obs);
		return;
	}

	// Loop over all existing threads
	// Find the item to be reRegistered and compute the remaining mask
	OMInterestMask newMask = theMask;

#ifdef OMANIMATOR
	TOMMaskedObserver *item=NULL;
	for(OMIterator<TOMMaskedObserver *> iter(observerList); *iter; iter++) {
		if ((*iter)->getObserver()==obs)
			item = (*iter);
		else
			newMask += ((*iter)->getMask());
	}
	_updateObserver(obs, item,theMask);
#endif

	// Update my interest mask

	if (inSilentMode()) {
		setSavedInterestMask(newMask.toInt());
	}
	else {
		setInterestMask(newMask);
	}
}

void TOMProxyItem::addToObserver(TOMUniversalObserver* obs,
								 OMInterestMask addMask)
{
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	// find the item to be added to and compute its mask
#ifdef OMANIMATOR
	TOMMaskedObserver *item=NULL;
	for(OMIterator<TOMMaskedObserver *> iter(observerList); *iter; iter++) {
		if ((*iter)->getObserver()==obs) {
			item = (*iter);
			break;
		}
	}
	if (item==NULL)
		_updateObserver(obs, NULL, addMask);
	else
		_updateObserver(obs, item, item->getMask()+addMask);
#else
	if (obs) { /* unreferenced formal parameter warning */ }
#endif

	// Update my interest mask
	if (inSilentMode()) {
		setSavedInterestMask(getSavedMask()+addMask.toInt());
	}
	else {
		setInterestMask(myMask+addMask);
	}
}

void TOMProxyItem::subtractFromObserver(TOMUniversalObserver* obs,
										OMInterestMask subtructMask)
{
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	// find the item to be reRegistered and compute the remaining mask
	OMInterestMask baseMask;
	if (inSilentMode()) {
		baseMask = getSavedMask();
	}
	else {
		baseMask = getMask();
	}
	OMInterestMask newMask = baseMask - subtructMask;

#ifdef OMANIMATOR
	TOMMaskedObserver *item=NULL;
	for(OMIterator<TOMMaskedObserver *> iter(observerList); *iter; iter++) {
		if ((*iter)->getObserver()==obs)
			item = (*iter);
		else
			newMask += (*iter)->getMask();
	}

	if (item!=NULL) {
		// Update the observer's mask
		item->setMask(item->getMask() - subtructMask);
		if (item->getMask().isInteresting())
			// Item is still interesting update my mask to it
			newMask += item->getMask();
		else
			// Item is not interesting remove it from list
			_deregisterObserver(item);
	}
#else
	if (obs) { /* unreferenced formal parameter warning */ }
#endif

	if (inSilentMode()) {
		setSavedInterestMask(newMask);
	}
	else {
		setInterestMask(newMask);
	}
}


void TOMProxyItem::deregisterObserver(TOMUniversalObserver * obs,
									  OMInterestMask) {
	// The OMInterestMask parameter is redundent here.
	// It is present for the TOMClass case -- see there what it does

	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	// find the item to be deleted and compute the remaining mask
	OMInterestMask newMask;

#ifdef OMANIMATOR
	TOMMaskedObserver *item=NULL;
	for(OMIterator<TOMMaskedObserver *> iter(observerList); *iter; iter++) {
		if ((*iter)->getObserver()==obs)
			item = (*iter);
		else
			newMask += (*iter)->getMask();
	}

	// Remove the observer
	if (item!=NULL)
		_deregisterObserver(item);
#else
	if (obs) { /* unreferenced formal parameter warning */ }
#endif
	// Update my interest mask
	if (inSilentMode()) {
		setSavedInterestMask(newMask);
	}
	else {
		setInterestMask(newMask);
	}
}

TOMMaskedObserver * TOMProxyItem::getObserver(TOMUniversalObserver* observer) const
{
	TOMMaskedObserver * obs = NULL;
	for(OMIterator<TOMMaskedObserver *> iter(observerList); *iter; iter++) {
		if ((*iter)->getObserver() == observer) {
			obs = (*iter);
			break;
		}
	}
	return obs;
}


OMBoolean TOMProxyItem::showYourself(TOMUniversalObserver* obs,
								   int theMask) {
//	cout << "showYourself theMask = " << theMask << endl;
	// Notify any info I have locally in store
	_showYourself(obs,theMask);
	// Here theMask contains only subjects that need to be sent
	if (( theMask ) && (getReal() != NULL)) {
		// Create the observer which will "capture" the returned messsage
		MAKE_SHOW_OBSERVER(this, obs, theMask);
		// Send the info request
		TOMDispatcher::instance()->sendMessage(
			new OMSData(getReal(), sendYourself, theMask) );
#ifdef OMANIMATOR
		return TRUE; // This is so we wait for the answer
#endif
	}
	return FALSE;
}

int TOMProxyItem::getRealMask() const 
{
	int mask;
	if (inSilentMode()) {
		// the real mask is the saved one
		mask = getSavedMask();
	}
	else {
		// use the mask for show
		mask = getMask();
	}
	return mask;
}

void TOMProxyItem::setRealMask(int mask)
{
	if (inSilentMode()) {
		// the real mask is the saved one
		setSavedInterestMask(mask);
	}
	else {
		// use the mask for show
		setInterestMask(mask);
	}
}

/*
OMBoolean TOMProxyItem::showYourself(TOMUniversalObserver* obs) 
{
	int mask = getRealMask();
	return showYourself(obs,mask);
}
*/

void TOMProxyItem::notifyLostFocus() {
	SAFE_NOTIFY_OBSERVERS(OMExistInterest,notifyLostFocus(this));
}

void TOMProxyItem::goSilent(OMInterestMask newMask) 
{ 
	// going silent should be done only once
	// i.e. if already silent - skip
	if (mySilentMode != TOMInSilent) {
		// mark as silent
		mySilentMode = TOMInSilent;
		// take the current "real" mask
		OMInterestMask currMask = getMask();
		// save the "real" mask
		setSavedInterestMask(currMask);
		// set the silent mask 
		setInterestMask(currMask & newMask);
	}
}

void TOMProxyItem::goLoud(OMInterestMask newSavedMask) 
{ 
	// going loud should be done only once
	// i.e. if already loud - skip
	if (mySilentMode != TOMInLoud ) {
		// mark as loud
		mySilentMode = TOMInLoud;
		// load the saved mask
		OMInterestMask savedMask = getSavedMask();
		// make it the current mask
		setInterestMask(savedMask);
		// save a new mask 
		setSavedInterestMask(newSavedMask);
	}
}

OMBoolean TOMProxyItem::refresh() 
{
	// the refresh is done base on the full real mask
	int mask = getFullRealMask();
	// show what you know, base on the mask, to the refresher.
	// The refresher will propagete the information to all my observers
	TOMProxyItem::showYourself(&myRefresher,mask);
	return TRUE;
}

// For debugging only
void TOMProxyItem::showObservers(
				OMList<TOMMaskedObserver *>*& theObserverList,
				OMList<TOMShowObserver *>*&theShowObserverList,
				OMInterestMask& theMask)
{
#ifdef OMANIMATOR
	theObserverList = &observerList;
#else
	if (theObserverList) { /* unreferenced formal parameter warning */ }
#endif
	theShowObserverList = &showObserverList;
	theMask = myMask;
}

void TOMProxyItem::setMyAppName(char* pAppName)
{
	if(myAppName)
		delete [] myAppName;
	size_t nSize = strlen(pAppName);
	myAppName = new char[nSize + 1];
	strcpy(myAppName, pAppName);
	myAppName[nSize] = '\0';
}

omostream& operator<<(omostream& os, TOMProxyItem *item) {
	OMString s;									   
	item->outputFullName(s);
	return os<<s;
}

//
// $Log: tomproxy.cpp $
// Revision 1.64  2007/03/11 13:14:45  ilgiga
// Change copyright comment
// Revision 1.63  2007/03/04 15:07:36  ilgiga
// Telelogic instead of i-Logix
// Revision 1.62  2006/11/06 09:46:28  ccohen
// fixed compilation errors/warnings in vxworks/integrity.
// Revision 1.61  2006/10/31 08:58:53  ccohen
// support running multiple animation processes.
// Revision 1.60  2005/08/23 14:50:47  amos
// bugfix 85444 to main branch
// Revision 1.59.1.2  2005/08/22 10:05:42  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.59  2004/05/11 08:08:35  vova
// Linux warnings: order of initializers changed
// Revision 1.58  2002/07/15 12:29:33  avrahams
// Back to main
// Revision 1.57  2002/07/09 14:47:27  amos
// framework cleanup from RTOS specific code - back to r41 main branch
// Revision 1.56.3.2  2002/07/09 14:47:27  amos
// replace adaptor specific #ifdef with generic statements
// Revision 1.56.3.1  2000/12/25 10:59:10  amos
// Revision 1.56.2.2  2002/07/04 11:20:54  avrahams
// Cleanup std namespace usage
// Revision 1.56.2.1  2000/12/25 10:59:10  avrahams
// Duplicate revision
// Revision 1.56  2000/12/25 10:59:10  amos
// move to warning level 4
// Revision 1.55  2000/07/11 09:23:51  amos
// changes related to modify char* to const char*.
// Revision 1.54  1999/09/23 15:04:13  sasha
// Fixing Psos problem
// Revision 1.53  1999/09/07 23:19:00  yachin
// Remember 'global interstMask' in TOMSystem for lazy tom creations
// Revision 1.52  1999/06/18 09:07:47  beery
// due to lazy evaluation, make sure that new package/class/classevent are observed my the console 
// so when a new object or event are created they "inherite" their initial mask from their logical parent
// Revision 1.51  1999/02/18 11:27:13  yachin
// Fix regression on initial call stack entry
// Revision 1.50  1998/11/25 13:38:19  beery
// Revision 1.49  1998/11/25 12:56:55  beery
// Revision 1.48  1998/11/23 17:35:38  beery
// Revision 1.46  1998/11/22 15:54:21  beery
// Revision 1.45  1998/11/22 14:18:06  beery
// Revision 1.44  1998/11/19 17:58:22  beery
// Revision 1.43  1998/11/17 13:49:55  beery
// Revision 1.42  1998/11/17 12:44:18  beery
// Revision 1.41  1998/08/02 15:06:36  beery
// changing boolean->OMBoolean
// Revision 1.40  1998/06/30 09:01:00  yachin
// fix bug 6579 - added magic cookie to TOMProxyItem
// Revision 1.39  1998/06/15 12:39:33  yachin
// Fix bug 6231 - name2item for relations return only valid objects of 'possibleButNonExistant'
// Revision 1.38  1997/10/28 08:11:50  yachin
// try/catch(...) replaced by OMTRY and OMCATCH 
// so we catch bus-error segmentation-fault on UNIX 
// Revision 1.37  1997/02/24 08:32:27  yachin
// Bug fix in tomIsValid
// Revision 1.36  1997/02/20 08:52:06  yachin
// Revision 1.35  1997/02/19 11:19:56  yachin
// Add isAnimationActive mode to all observer operations
// Revision 1.34  1997/02/18 13:25:55  yachin
// Output message on "catch" in ~ProxyItem()
// Revision 1.33  1997/02/18 11:30:49  yachin
// Bug fixes
// Revision 1.32  1997/02/11 12:54:37  yachin
// Adding Name spaces
// Revision 1.31  1997/01/27 09:41:56  yachin
// Enter foreign threads
// Revision 1.30  1997/01/21 11:08:49  yachin
// changed _int32 to int
// Revision 1.29  1997/01/20 06:48:44  yachin
// Revision 1.28  1997/01/19 11:19:50  yachin
// Revision 1.27  1996/12/30 09:56:47  yachin
// Multi Thread support part III
// Revision 1.26  1996/12/25 13:38:31  yachin
// Multi-Threading first shot
// Revision 1.25  1996/11/24 12:40:43  yachin
// Revision 1.24  1996/11/10 13:40:25  yachin
// Revision 1.23  1996/11/07 10:04:53  yachin
// Revision 1.22  1996/11/06 08:54:37  yachin
// registerObserver changed to reRegisterObserver
// Revision 1.21  1996/11/05 07:20:20  yachin
// Fixed crash in "end animation"
// Revision 1.20  1996/10/29 08:28:47  yachin
// Revision 1.19  1996/10/27 13:30:01  yachin
// Bug fix
// Revision 1.18  1996/10/24 12:56:39  yachin
// Rewrite of observer registration mechanism + new instance iterators
// Revision 1.17  1996/10/22 12:04:59  yachin
// Revision 1.16  1996/10/09 07:37:10  yachin
// Revision 1.15  1996/10/01 06:56:23  yachin
// Fixing the "show class all" bug
// Revision 1.14  1996/09/26 10:57:57  yachin
// Revision 1.13  1996/09/24 08:21:20  ofer
// first deleting the item only then remove it from oList
// in ~TOMProxy (tomproxy.cpp)
// Revision 1.12  1996/09/24 07:33:58  yachin
// Bug fixes + single thread AOM
// Revision 1.11  1996/09/16 09:28:35  yachin
// Revision 1.10  1996/09/08 13:28:59  yachin
// Registeration of items which do not yet exist
// Revision 1.9  1996/09/05 13:35:57  yachin
// Revision 1.8  1996/09/03 12:01:16  yachin
// Alow show #callStack
// Revision 1.7  1996/08/29 11:26:00  ofer
// Revision 1.6  1996/08/14 12:40:25  yachin
// Seperate TOM Masks from AOM Masks. Fix bugs with attr. and states
// Revision 1.5  1996/08/08 08:23:30  yachin
// Revision 1.4  1996/08/06 12:52:09  yachin
// Version for Prototype 4
// Revision 1.3  1996/07/22 11:30:33  yachin
// Revision 1.2  1996/06/19 10:21:32  yachin
// Revision 1.1  1996/06/17 05:40:51  yachin
// Initial revision
//
