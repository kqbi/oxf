#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomstate.cpp 1.28 2007/03/11 13:14:46 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomstate.cpp $
//	file version:	$Revision: 1.28 $
//
//	purpose: Methods of Class TOMState	 	
//
//	author(s):		Yachin Pnueli
//	date started:	28.7.96
//	date changed:	$Date: 2007/03/11 13:14:46 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "tomstate.h"
#include "tominst.h"

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomstate_H;
#endif

inline OMBoolean TOMState::updateList(OMHandleList& lIn, 
							 OMHandleList& lOut,
							 OMHandle * theCurrent) {
	lIn.add(theCurrent);
	// remove it from the "Out" list 
	for(OMIterator<OMHandle *> i(lOut); *i; ++i) {
		if ( !strcmp(*i,theCurrent) ) {
			char * toDelete=(*i);
			lOut.remove(toDelete);
			delete toDelete;
			return TRUE;
		}
	}
	return FALSE;
}

void TOMState::enteredState(OMSData * s, OMSPosition& p) {
	// Get the state
	current = s->getChar(p);

	updateInsatnceLastMsgTimeStamp(s,p);
	
	// If it is already in currentStates do nothing
	for(OMIterator<OMHandle *> i(currentStates); *i; ++i)
		if ( !strcmp(*i,current) ) {
			// Prevent memory leak ...
			delete current;
			// .. but leave it pointing to the correct stateName
			current = (*i);
			return;
		}
	
	// Else add it to currentStates, remove it from oldStates
	updateList(currentStates, oldStates, current);
	// No check on status as current may either be or not in old
}


void TOMState::exitedState(OMSData * s, OMSPosition& p) {
	// Get the state
	current = s->getChar(p);

	updateInsatnceLastMsgTimeStamp(s,p);

	// Add it to oldStates, remove it from currentStates
	OMBoolean status = updateList(oldStates, currentStates, current);
	if (!status) {
		OMString dummy;
		OMString errMsg	= "Warning - Instance ";
		errMsg			+= myInstance->outputFullName(dummy);
		errMsg			+= ": Statechart lost synchronization with application\n";
		errMsg			+= "(to resync. close and open the statechart)";
//		errMsg			+= ": Exiting from state ";
//		errMsg			+= current;
//		errMsg			+= " Without Entering it first";
		tomSendWarning(errMsg);
	}
}


void TOMState::startBehaviourStep() {
	inBehavior++;
	if (inBehavior>1)
		return; // This is a superflous "start"
	// Forget the "old" state
	if (!activeTransitions.isEmpty()) {
//		OMString errMsg	= 
//		"New step started before all previous transitions finished";
//		tomSendError(errMsg);
		activeTransitions.removeAll();
	}
	oldStates.removeAll();
	currentTransitions.removeAll();
}

void TOMState::startNullStep() {
	// Forget the "old" state
	if (!activeTransitions.isEmpty()) {
//		OMString errMsg	= 
//		"New step started before all previous transitions finished";
//		tomSendError(errMsg);
		activeTransitions.removeAll();
	}
	oldStates.removeAll();
	currentTransitions.removeAll();
}


void TOMState::endedTransition(OMSData * s, OMSPosition& p) {
	// Get the state
	current = s->getChar(p);
	updateInsatnceLastMsgTimeStamp(s,p);

	// add it to currentTransitions
	// remove it from activeTransitions
	/* OMBoolean status = */ (void) updateList(currentTransitions, activeTransitions, current);
//	if (!status) {
//		OMString errMsg	= "Finished Transition ";
//		errMsg			+= current;
//		errMsg			+= " Without Starting it first";
//		tomSendError(errMsg);
//	}
}



void TOMState::handleStateConfiguration(OMSData * s, OMSPosition& p)
{
	// Read the list of states and update it
	int stateCount = s->safeGetInt(p);
	if (stateCount==0) return; // Not reactive or no startBehavior

	// Get the Termination status
	terminated = (s->safeGetCode(p) != 0);

	for(int i=0; i<stateCount; i++) {
		// Read a state
		OMHandle * state = s->getChar(p);
		// add it to the list of current states
		currentStates.add(state);
	}
	// Question what do we do with the termination connecters ?
	// above inside or encode in a separate list ?

}

OMBoolean TOMState::isSameCurrentStates(TOMState& state)
{
	OMList<OMHandle*>* otherStates = state.getCurrentStates();
	if (!otherStates) return FALSE;
	
	if (currentStates.getCount() != otherStates->getCount()) return FALSE;

	// compare content of both lists
	OMIterator<OMHandle *> i(currentStates);
	OMIterator<OMHandle *> j(*otherStates);
	for(; *i || *j; ++i, ++j) {
		if(strcmp(*i,*j)) return FALSE;
	}

	return TRUE;
}

void TOMState::startedTransition(OMSData * s, OMSPosition& p)
{
	// Get the state
	current = s->getChar(p);
	// add it to the list of current states
	activeTransitions.add(current);

	updateInsatnceLastMsgTimeStamp(s,p);
}

void TOMState::updateInsatnceLastMsgTimeStamp(OMSData * s, OMSPosition& p)
{
	if (s->isTimeUnit(p) && myInstance) 
	{
		timeUnit time = s->safeGetTimeUnit(p);
		myInstance->setLastMsgTimeStamp(time);
	}
}

//
// $Log: tomstate.cpp $
// Revision 1.28  2007/03/11 13:14:46  ilgiga
// Change copyright comment
// Revision 1.27  2007/03/04 15:07:37  ilgiga
// Telelogic instead of i-Logix
// Revision 1.26  2005/08/23 14:50:48  amos
// bugfix 85444 to main branch
// Revision 1.25.1.2  2005/08/22 10:05:42  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.25  2004/06/27 15:30:18  amos
// move to model-based oxf in RiC++
// Revision 1.24.1.2  2004/02/09 09:05:48  amos
// changes due to OMBoolean type change
// Revision 1.24.1.1  2001/10/01 10:21:02  amos
// Duplicate revision
// Revision 1.23.1.2  2001/09/26 00:48:46  Eldad
// Changed some of the erros to warnings that are not to be shown in popup 
// message box.
// Revision 1.23.1.1  2001/05/13 12:42:17  Eldad
// Duplicate revision
// Revision 1.22  2001/05/10 08:24:09  amos
// fix the state message handling algorithm in TOMInstance::handleStateConfiguration()
//   the new algorithm updata the state when the existing state is out-of-date as well as when there is no state.
// Revision 1.21  2001/04/29 07:55:57  Eldad
// syncronization -> synchronization.
// Revision 1.20  2000/12/25 10:39:51  amos
// move to warning level 4
// Revision 1.19.1.2  2001/05/09 18:26:16  sasha
// Added new oprtation isSameCurrentStates for compare TOM states.
// Revision 1.19  2000/07/11 09:23:51  amos
// changes related to modify char* to const char*.
// Revision 1.18  2000/01/13 09:50:46  amos
// support animation of Null Transition
// Revision 1.17  1998/08/02 15:06:37  beery
// changing boolean->OMBoolean
// Revision 1.16  1998/06/14 12:17:16  yachin
// Fix bug 6241 - startMask in animation is now 'larger'
// Revision 1.15  1998/02/18 13:20:23  yachin
// Bug fix 4966
// Revision 1.14  1997/03/31 09:18:50  yachin
// Fix Unix warnings
// Revision 1.13  1997/03/13 13:41:36  yachin
// Fix memory leaks
// Revision 1.12  1997/01/01 08:48:18  yachin
// Avoid double printing of ROOT
// Revision 1.11  1996/12/19 13:15:14  yachin
// Revision 1.10  1996/12/08 10:15:41  yachin
// Revision 1.9  1996/12/03 07:12:35  yachin
// Fixed "triggered op/notify behavior step" bug
// Revision 1.8  1996/11/24 12:40:44  yachin
// Revision 1.7  1996/10/09 07:37:11  yachin
// Revision 1.6  1996/09/18 13:00:48  yachin
// Revision 1.5  1996/09/16 09:28:36  yachin
// Revision 1.4  1996/09/08 13:29:00  yachin
// Registeration of items which do not yet exist
// Revision 1.3  1996/08/28 05:38:02  ofer
// Revision 1.2  1996/08/06 12:55:56  yachin
// Revision 1.1  1996/08/06 12:53:24  yachin
// Initial revision
//
