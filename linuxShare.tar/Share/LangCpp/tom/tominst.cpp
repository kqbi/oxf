#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tominst.cpp 1.125 2007/03/11 13:14:42 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tominst.cpp $
//	file version:	$Revision: 1.125 $
//
//	purpose: Methods of Class TOMInstance	 	
//
//	author(s):		Yachin Pnueli
//	date started:	22.5.96
//	date changed:	$Date: 2007/03/11 13:14:42 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//

#include <stdio.h>

#include "tominst.h"
#include <omcom/om2str.h>
#include "tomlist.h"
#include "tomattr.h"
#include "tomstate.h"
#include "tomobs.h"
#include "tomstr.h"
#include "tomsys.h"
#include "tomclass.h"
#include "tomdisp.h"
#include "tommsg.h"
#include "tompack.h"
#include "tommask.h"

#include <omcom/RiCppAnimMessages.h>
#include <omcom/AnimAllocateCore.h>
#include <omcom/AnimIntField.h>

#ifdef OMANIMATOR
#include "tomExtern.h"
#endif // OMANIMATOR

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tominst_H;
#endif

// Hack should be placed as par tof the "hasControl enum
#define TOMIsDead -1


#ifdef OMANIMATOR
	int initialMask = OMExistInterest | OMRelationInterest | OMMethodsInterest
					| OMConstructorsInterest | OMDestructorsInterest
					| OMTimeoutsInterest | OMParameterInterest;
#else
	int initialMask = OMNoInterest;
#endif 


TOMPackage* TOMInstance::getPackage() const {
	return myClass->getPackage(); 
}


TOMInstance::~TOMInstance() {
	
	if (tomInstancePartObserver != NULL) {
		removePartObserverRecursive(tomInstancePartObserver);
		delete tomInstancePartObserver;
	}
	tomInstancePartObserver = NULL;
	
	// replace all my appearances in call stack by 'indestruction'
	TOMSystem::instance()->replaceItemByDestroyed(this);
	// Take care of my 'attributes'
	if (attributes!=NULL) delete attributes;
	if (myState!=NULL) delete myState;
	// delete the links
	for(OMIterator<TOMList *> i(myLinks); *i; i++)
		delete (*i);
	// remove from renamed instances and free memory allocated for the name
	if (TOMSystem::instance()->isRenamedInstance(this)) {
		TOMSystem::instance()->removeRenamedInstance(this);
		delete[] myName;
		myName = NULL;
	}


}

TOMInstance::TOMInstance(gen_ptr theReal):TOMProxyItem((char*)(""),omProxyInstance) {
	// "" is the in construction name
	myClass = NULL;

	// Set my paramters to default values
	myState=NULL;
	attributes=NULL;
	hasControl = FALSE;
	// Set real
	setReal(initialMask,theReal);

	// initialize the tomInstancePartObserver
	tomInstancePartObserver = new TOMInstancePartObserver(this);

	if (TOMSystem::sysInSilentMode()) {
		goSilent();
	}

	lastMsgTimeStamp = 0;
	myAffinity = 0;
	myPowerMode = 0;

#ifdef OMANIMATOR
	duringOpeningView = false;
#endif
}


void TOMInstance::setClass(char * theName, 
						 const int theMultiplicity, 
						 OMInterestMask theMask,
						 TOMClass * theClass,
						 const TOMProxyItem * theContext) {
	myClass = theClass;
	// Set my name
	setName(theName, theMultiplicity, theContext);

	// Notify my real I'm ready
	if (inSilentMode()) {
		setSavedInterestMask(theMask);
	}
	else {
		setInterestMask(theMask);
	}
	// Notes:
	// 1. Relations where already sent by "real" so no need to ask 
	//    for them
	// 2. This is TOMInstance::setInterestMask which also "sends" for
	//     state/attribute info if needed
}


OMInterestMask TOMInstance::_setInterestMask(OMInterestMask theMask) {
	//
	// Do the "book keeping" associated with changing an interest
	// mask for a TOMInstance
	//
	OMInterestMask sendMask; // What should we "send" for

	// Observe the "myState" paradigm
	// If states have became interesting Send for them
	// If states have became uninteresting delete them
	if (theMask.isInteresting(OMStateInterest)) {
		if (myState==NULL)
			sendMask += OMStateInterest;
	} else if (myState!=NULL) {
		delete myState;
		myState=NULL;
	}

	// Observe the "attributes" paradigm
	// If attributes became interesting Send for them
	// If attributes have became uninteresting delete them
	if (theMask.isInteresting(OMAttributesInterest)) {
		if (attributes==NULL)
			sendMask += OMAttributesInterest;
	} else if ( attributes!=NULL ) {
		delete attributes;
		attributes=NULL;
	}

#ifdef OMANIMATOR
	if(TOMExterns::Anim() && TOMExterns::Anim()->ShouldAutoOpenBehavioralDiagrams())
		sendMask += OMStateInterest;
#endif

	return sendMask;
}


void TOMInstance::setInterestMask(OMInterestMask theMask) {
	if (hasControl==TOMIsDead) return;
	if (theMask.toInt()!=0)
		theMask = theMask + OMExistInterest;

	// Do TOMInstance set mask things (findout what info you need
	OMInterestMask sendMask; 
	sendMask = _setInterestMask(theMask);

	// Actually Set my Mask
	TOMProxyItem::setInterestMask(theMask);

	// Send for the necessay information (attr & state info)
	if (sendMask != myLastSentMask) 
		{
			myLastSentMask = sendMask;
			TOMDispatcher::instance()->sendMessage( new OMSData(
						getReal(), sendYourself, sendMask.toInt() ) );
	}
}


void TOMInstance::notifyNewName(OMString* oldName/*=NULL*/) {
	// Notify my observers of the change
	NOTIFY_OBSERVERS(OMExistInterest,notifyNewName(this,oldName));
	// Notify my "components" of the change (to their names)
	// Scan all my relations
	for(OMIterator<TOMList *> i(myLinks); *i; i++) {
		TOMList *l = *i;
		if (l->composite()) // Composite rel. - scan all instances
			for(OMIterator<TOMInstance *> j(*l); *j; j++) {
				if ((*j) != this)
					(*j)->notifyNewName();
			}
	}
}

void TOMInstance::setName(char * theName, 
						  int theMultiplicity, 
						  const TOMProxyItem * theContext) {
	// Change the name of the instnace. Currently only by a "name Giver" 
	// In future by user also.
	OMString oldName;

	// Remember the old name
	if (myMask.isInteresting(OMExistInterest))
		outputFullName(oldName);

	//check if another instance from a different application already has this name, 
	//if so append to the name '@<Application_Name>', so the instance name will be unique.
	if(myClass && theName && strcmp(theName, myClass->getFirstName()) != 0)
	{
		TOMPackage* pPkg = myClass->getPackage();
		if(pPkg)
		{
			OMString className(myClass->getFirstName());
			OMList<TOMClass*> classes;
			TOMClass* pTomClass = NULL;
			bool bStop = false;
			pPkg->name2Classes(className, classes);
			unsigned int j = 0, nCount = 0;
			nCount = classes.getCount();
			for(j = 0 ; j < nCount && (nCount > 1) && !bStop; j++)
			{
				pTomClass = classes.getAt(j);
				for(OMIterator<TOMInstance *> i(pTomClass->getTomNameGiver()); *i; i++)
				{
					//check if the instances have the same name and are from different 
					//application (i.e. have different sockets)
					if((strcmp((*i)->getFirstName(),theName) == 0) && ((*i)->getMySocket() != getMySocket()))
					{
						// add myself to the system renamed instances
						TOMSystem::instance()->addRenamedInstance(this);

						OMString newName(theName);
						newName += "@";
						newName += myAppName;
						char* pNewName = new char[newName.GetLength() + 1];
						strcpy(pNewName,newName.GetBuffer(0));
						pNewName[newName.GetLength()] = '\0';
						delete [] theName;
						theName = pNewName;
						bStop = true;
						break;
					}
				}
			}
		}
	}

	// Rename myself
	myName = theName;
	myContext = theContext;
	multiplicity = theMultiplicity;

	// if we are in the context of an instance we should observe
	// its parts
	if ((theContext != NULL) && (theContext->getType() == omProxyInstance))
	{
		TOMInstance *tomInstance = (TOMInstance *)(theContext);
		if (tomInstance != NULL)
		{
			addPartObserver(tomInstance->getTomInstancePartObserver());
			notifyPartConnected(tomInstance, this);		
		}
	}

	notifyNewName(&oldName);
}						


static const char * inConstruction = "<under construction>";

OMString& TOMInstance::outputMultiplicity(OMString& s) const { 
	if (multiplicity!=TOMNoMultiplicity) {
		char buf[20];
		OMitoa(multiplicity, buf, 10); // 10 here is the base
		s+='[';
		s+=buf;
		s+=']';
	}
	return s;
}

OMString& TOMInstance::outputFirstName(OMString& s) const { 
	if (myName[0]=='\0') // The unborn case
		s += (char*)inConstruction;
	else {
		s+=(char*)myName;
		outputMultiplicity(s);
	}
	return s;
}


OMString& TOMInstance::
		outputFullName(OMString& s, const TOMProxyItem * theContext) const {
	if (myClass==NULL || myContext==NULL)
		// The no prefix cases
		return outputFirstName(s);
	if (myContext->getType()==omProxyPackage) {
		// The name derived from class case
		myClass->outputFullName(s,theContext);
		outputMultiplicity(s);
		return s;
	} else {
		// The component case
		if (theContext==OMSystemContext || 
							((theContext != myContext) && (theContext != NULL) &&
							 (theContext->getContext() != myContext))) {
			// avoid infinite loop, in case myContext == this
			if (myContext != this)
				tominstance2String(myContext, s, theContext);
			/*
			else { // use myClass as the context
				if (myClass != NULL) {
					tominstance2String(myClass->getContext(), s, theContext);
				}
			}
			*/
			s += (char*)getInstaceCallString();
		}
		return outputFirstName(s);
	}
}


TOMProxyItem* TOMInstance::name2Item(char *& name) const {
	if (isInstanceOrObjectCallString(name)) {
		// Get the name of the relation
		name = skipInstanceOrObjectCallString(name);	// Eat the "->"
		OMString relName;
		eatOneToken(name,relName);
		// Should check if name == one of my links
		TOMList * l = getLinkByName(relName);
		if (l==NULL) {
#ifdef OMANIMATOR
			if (isLangC() || isLangAda()) // Go by tool mode
			{
				return TOMPossibleButNonExistent;
			}
#endif
			OMString errMsg = "No relation named ";
			errMsg += relName;
			tomSendError(errMsg);
			return OMGarbage;
		} else
			return l->name2Item(name);
	}
	else  {
		// Error about bad format
		OMString errMsg = "Instance may handle only -> named objects ";
		tomSendError(errMsg);
		return OMGarbage;
	}
}



TOMList * TOMInstance::getLinkByName(OMString linkName) const{
	// OMMap would be more efficient ?
	for(OMIterator<TOMList *> i(myLinks); *i; ++i) {
		if ((*i)->getName()==linkName)
			return *i;
	}
	return NULL;
}


TOMList * TOMInstance::addLink(char * linkName,
									 OMBoolean isComposite, 
									 OMBoolean isSingleton) {
	TOMList * l;
	if (isComposite)
		l = new TOMCompositeLink(linkName, isSingleton, this);
	else
		l = new TOMRelation(linkName, isSingleton);

	// Add the new link to the link list
	myLinks.add(l);
	return l;
}


void TOMInstance::createRelationsFirstInstance(TOMSData * s) {
	// In this case the class still does not know what are the
	// relation names. Therefore do not compare with the class
	// on the other hand went done we tell this info to the class
	// Note we do not delete relation names as they are used.

	// first reset the list of links - to prevent multiply apprences of the base classes links
	for(OMIterator<TOMList *> iter(myLinks); *iter; iter++) {
		delete (*iter);
	}
	myLinks.removeAll();
	
	OMSPosition p = s->getFirst();
	int relCount = s->safeGetInt(p);
	for(int i=0; i<relCount; i++) {
		// Read the relation
		char * relationName = s->safeGetChar(p);
		OMBoolean isComposite = (s->getCode(p) != 0);
		OMBoolean isSingleton = (s->getCode(p) != 0);

		// Create the relation
		TOMList * rel = addLink(relationName,isComposite,isSingleton);
		// Add the items of this list
		rel->update(s,p);
	}
	// Tell the class what are the relations
	myClass->setRelations(&myLinks);
}

void TOMInstance::createRelations(TOMSData * s) {
	const OMList<char *>* relList = myClass->getRelations();
	OMIterator<char *> relI(relList);

	OMSPosition p = s->getFirst();
	int relCount = s->safeGetInt(p);
	for(int i=0; i<relCount; i++) {
		// Check that we should have another relation
		char * relationName = (*relI);
		if (NULL==relationName) {
			OMString errMsg = "Extra relation create in object ";
			outputFullName(errMsg);
			tomSendError(errMsg);
			return;
		}
		// Read the relation
		char * actualRelationName = s->safeGetChar(p);
		OMBoolean isComposite = (s->getCode(p) != 0);
		OMBoolean isSingleton = (s->getCode(p) != 0);
		// Compare name we expect to name we got
		if (strcmp(relationName,actualRelationName)) {
			OMString errMsg = "Relation message mismatch in object ";
			outputFullName(errMsg);
			tomSendError(errMsg);
			return;
		}
		// Name o.k. create the relation and update it
		TOMList * rel = addLink(relationName,isComposite,isSingleton);
		rel->update(s,p);
		// Cleanup and move to next relation
		delete actualRelationName;
		++relI;
	}
}


void TOMInstance::handleRelations(TOMSData * s, OMSPosition& p) {
	OMIterator<TOMList *> relI(myLinks);

	int relCount = s->safeGetInt(p);
	for(int i=0; i<relCount; i++) {
		// Get the current relation
		TOMList *rel = (*relI);
		if (NULL==rel) {
			OMString errMsg = "Extra relation update in object ";
			outputFullName(errMsg);
			tomSendError(errMsg);
			return;
		}
		// Read the relation
		char * actualRelationName = s->safeGetChar(p);
		/* OMBoolean isComposite = (OMBoolean) */ (void) s->getCode(p);
		/* OMBoolean isSingleton = (OMBoolean) */ (void) s->getCode(p);
		// Get the current relation name
		char * relationName = rel->getName();
		// Compare name we expect to name we got
		if (strcmp(relationName,actualRelationName)) {
			OMString errMsg = "Update Relation mismatch in object ";
			outputFullName(errMsg);
			tomSendError(errMsg);
			return;
		}
		rel->update(s,p);
		// Cleanup and move to next relation
		delete actualRelationName;
		++relI;
	}
}


inline TOMAttributes *TOMInstance::getAttributes() {
	if (attributes==NULL)
		attributes = new TOMAttributes(this);
	return attributes;
}

void TOMInstance::handleStateConfiguration(TOMSData * s, OMSPosition p)
{
	// Create the new State object
	TOMState* newState = new TOMState(this);
	// Let it handle the message
	newState->handleStateConfiguration(s,p);

	OMBoolean bFirstStateConfig = FALSE;

	// check existing myState against the the new
	if(myState) {
		if(myState->isSameCurrentStates(*newState)) {
			delete newState;
			newState = NULL;
		}
		else {
			// delete the wrong (old) myState
			delete myState;
			myState = NULL;
		}
	}
	else
		bFirstStateConfig = TRUE;
	
	if (newState != NULL) {
		// set the new state as myState
		myState	= newState;

#ifdef OMANIMATOR
		if(bFirstStateConfig)
		{
			//make sure 'myMask' has the 'OMStateInterest' if we are in AutoOpenBehavioralDiagrams
			if(TOMExterns::Anim() && TOMExterns::Anim()->ShouldAutoOpenBehavioralDiagrams())
				myMask += OMStateInterest;
			
			OMList<OMHandle *>* currentStates = myState->getCurrentStates();
			OMIterator<OMHandle *> i(*currentStates);
			char* firstState = (char*)(*i);
			if(firstState && !strcmp(firstState, "ROOT"))
			{
				i++;
				firstState = (char*)(*i);
			}
			if(firstState && TOMExterns::Anim())
				TOMExterns::Anim()->OpenAnimatedViewIfNeeded(firstState, this);
		}
#endif

		// Notify my show Observers
		if(myState != NULL)
		{
			NOTIFY_SHOW_OBSERVERS(notifyStateConfiguration(this,
												myState->getCurrentStates(),
												myState->isTerminated()) );
		}

		if (!myMask.isInteresting(OMStateInterest)) {
			// Clear myState as Instance is not interested in states
			delete myState;
			myState = NULL;
		}

		if(myState && bFirstStateConfig)
		{
			OMBoolean bFirstState = TRUE;
			OMList<OMHandle *>* currentStates = myState->getCurrentStates();
			OMIterator<OMHandle *> i(*currentStates);
			for(; *i; i++) 
			{
				char* stateName = (char*)(*i);

				//don't notify entering to the first state in the list (i.e. the ROOT state), since we've 
				//already been notified on it
				if(bFirstState /*&& !strcmp(stateName, "ROOT")*/)
				{
					bFirstState = FALSE;
					continue;
				}

				
				NOTIFY_OBSERVERS(OMStateInterest,
					notifyEnteredState(this, stateName) );
			}
		}
	}
}

void TOMInstance::handleMessage(OMNotify msgCode, 
								TOMSData * s, 
								OMSPosition p) {
	// Am I ready to receive messages ??
	if (myClass==NULL)
		return;
	// Perform the operation appropriate to this message code
	switch (msgCode) {
		// State messages -- delegate to the myState object
		// Notify my observers
	case enteredState:
		if (myState) {
			myState->enteredState(s,p);

#ifdef OMANIMATOR
			if(TOMExterns::Anim())
				TOMExterns::Anim()->OpenAnimatedViewIfNeeded(myState->getCurrent(), this);
#endif

			// this is first to allow the part observers to make 
			// sure they are registered correctly
			TOMInstance *receiverOwner = getOwnerInstance();
			if ((receiverOwner != NULL) && tomIsValidItem(receiverOwner))
			{
				receiverOwner->notifyPartEnteredState(this, myState->getCurrent(), receiverOwner);
			}

			NOTIFY_OBSERVERS(OMStateInterest,
				notifyEnteredState(this, myState->getCurrent()) );
		}
		return;
	case exitedState:
		if (myState) {
			myState->exitedState(s,p);

#ifdef OMANIMATOR
			if(TOMExterns::Anim())
				TOMExterns::Anim()->OpenAnimatedViewIfNeeded(myState->getCurrent(), this);
#endif

			NOTIFY_OBSERVERS(OMStateInterest,
				notifyExitedState(this, myState->getCurrent()) );
		}
		return;
	case terminationReached:
		if (myState) {
			myState->terminationReached(s,p);
			NOTIFY_OBSERVERS(OMStateInterest,
				notifyTerminationReached(this) );
		}
		return;
	case startedTransition:
		if (myState)
			myState->startedTransition(s,p);
		return;
	case endedTransition:
		if (myState)
			myState->endedTransition(s,p);
		return;
	case stateConfiguration:
		handleStateConfiguration(s,p);
		return;
	case relationConnected: {
		// Get message information
		char * relationName = s->safeGetChar(p);
		TOMInstance * item = (TOMInstance *)s->safeGetPointer(p);
		//OMBoolean isComposite = (OMBoolean)s->getCode(p);
		//OMBoolean isSingleton = (OMBoolean)s->getCode(p);

		// Check if we have this relation
		TOMList *rel = getLinkByName(relationName);
		if (NULL==rel) {
			// The relation is probably being reported too soon -
			//   while the instace is still registered as its base class.
			// This can happen if an instance was temporaraly registered as its base class,
			//   and then one of its relations was set (in the real class CTOR body).
			// Therefore just quitly ignore this scenario.

			// OMString errMsg = "Relation Connect mismatch in object ";
			// outputFullName(errMsg);
			// tomSendError(errMsg);
			return;
		}

		// Observers must be notified before actual connection
		// to ensure that the "old name" is used in the message

		// Notify my observers
		NOTIFY_OBSERVERS(OMRelationInterest,notifyRelationConnected(this,
												 relationName, 
												 item,
												 rel->singleton(),
												 rel->composite()));
		// Register in the relation
		//if (isRealItem(item))
			rel->registerItem(item);

#ifdef OMANIMATOR
			if(TOMExterns::Anim() && tomIsValidItem(item))
				TOMExterns::Anim()->notifyNewItem(item);
#endif
		delete relationName;
		return;
					   }
	case relationDisconnected: {
		// Get message information
		char * relationName = s->safeGetChar(p);
		TOMInstance * item = (TOMInstance *)s->safeGetPointer(p);
		// Deregister in relation
		TOMList *rel = getLinkByName(relationName);
		if (rel != NULL) {
			rel->deregisterItem(item);
		}
		// Notify my observers
		NOTIFY_OBSERVERS(OMRelationInterest,notifyRelationDisconnected(this,
													 relationName, 
													 item));
		delete relationName;
		return;
					   }
	case relationCleared: {
		// Get message info
		char * relationName = s->safeGetChar(p);
		// Clear the relation
		TOMList *rel = getLinkByName(relationName);
		if (rel != NULL) {
			rel->removeAll();
		}
		// Notify my observers
		NOTIFY_OBSERVERS(OMRelationInterest,
			notifyRelationCleared(this, relationName));
		delete relationName;
		return;
					   }
	case ::setName:	{
		char * theName = s->safeGetChar(p);
		int theMultiplicity = TOMNoMultiplicity;
		if (s->isNotEmpty(p))
			theMultiplicity = s->safeGetInt(p);

		// add myself to the system renamed instances
		TOMSystem::instance()->addRenamedInstance(this);

		// Actually set my name
		setName(theName, theMultiplicity, NULL);

		createObserver->notifyNewItem();	// Notify the create observer
		notifyCreatedForMSC();

#ifdef OMANIMATOR
		if(TOMExterns::Anim())
			TOMExterns::Anim()->notifyNewItem(this);
#endif
		return;
					}
	case updatedAttributeValues:
		if (attributes) {
			attributes->updateAttributeValues(s,p);
			NOTIFY_OBSERVERS(OMAttributesInterest,
						notifyAttributeValues(attributes->getChangeList(),
												this, FALSE));
			return;
		}
		// return; // Here we fall through on purpose !!!!
	case attributeValues:	// Make sure attributes exists before using it
		getAttributes()->newAttributeValues(s,p);
		NOTIFY_SHOW_OBSERVERS(notifyAttributeValues(attributes, this, TRUE));
		if (!myMask.isInteresting(OMAttributesInterest)) {
			delete attributes;
			attributes = NULL;
		}
		return;
	case instanceValue:	{
		OMInterestMask theMask(s->safeGetInt(p));
		if (theMask.isInteresting(OMRelationInterest)) {
			TOMSData * relationMessage = s->safeGetOMSData(p);
			handleMessage(relationsValues,relationMessage,
					relationMessage->getFirst());
			delete relationMessage;
		}
		if (theMask.isInteresting(OMAttributesInterest)) {
			TOMSData * attributeMessage = s->safeGetOMSData(p);
			handleMessage(attributeValues,attributeMessage,
				attributeMessage->getFirst());
			delete attributeMessage;
		} 
		if (theMask.isInteresting(OMStateInterest)) {
			//don't update the instance's states if the message is older then the last
			//message. This could happen will there is a thread race, that the application didn't 
			//send the 'instanceValue' message till after another thread progress the state machine.
			bool bNeedUpdate = true;
			if (s->isTimeUnit(p)) 
			{
				timeUnit time = s->safeGetTimeUnit(p);
				if(lastMsgTimeStamp >= time)
					bNeedUpdate = false;
			}

			TOMSData * stateMessage = s->safeGetOMSData(p);
			if(bNeedUpdate || myState == NULL)
			{
				handleMessage(stateConfiguration,stateMessage,stateMessage->getFirst());

				//extract the serialized flows if any (valid only for UML2Activities)
				handleFlowConfiguration(s, p);
			}
			delete stateMessage;
		}
		return;
				}
	case relationsValues:
		{
			// update the internal relations structure
			handleRelations(s, p);
			// Notify my observers
			NOTIFY_SHOW_OBSERVERS(notifyRelationsValues(this));
			return;
		}
	case createInstRelations:
		{
			TOMSData * itsRelationsMessage = s->safeGetOMSData(p);
			createRelationsFirstInstance(itsRelationsMessage);
			// No longer needed so free it
			delete itsRelationsMessage;

			//notify all observers on inner parts that they are created.
			_notifyCreatedForMSC();
			return;
		}
	case tokenReady:
		{
			if (myState)
			{
				myState->startedTransition(s,p);
				int tokenCount = s->safeGetInt(p);
#ifdef OMANIMATOR
				if(TOMExterns::Anim())
					TOMExterns::Anim()->OpenAnimatedViewIfNeeded(myState->getCurrent(), this);
#endif
				NOTIFY_OBSERVERS(OMStateInterest, notifyTokenReady(this, tokenCount) );
			}
			return;
		}
	case tokenConsumed:
		{
			if (myState)
			{
				myState->endedTransition(s,p);
				int tokenCount = s->safeGetInt(p);
#ifdef OMANIMATOR
				if(TOMExterns::Anim())
					TOMExterns::Anim()->OpenAnimatedViewIfNeeded(myState->getCurrent(), this);
#endif
				NOTIFY_OBSERVERS(OMStateInterest, notifyTokenConsumed(this, tokenCount) );
			}
			return;
		}
	case actionReady:
		{
			if (myState) 
			{
				myState->enteredState(s,p);
#ifdef OMANIMATOR
				if(TOMExterns::Anim())
					TOMExterns::Anim()->OpenAnimatedViewIfNeeded(myState->getCurrent(), this);
#endif
				NOTIFY_OBSERVERS(OMStateInterest, notifyActionReady(this) );
			}
			return;
		}
	case actionDone:
		{
			if (myState) 
			{
				myState->exitedState(s,p);
#ifdef OMANIMATOR
				if(TOMExterns::Anim())
					TOMExterns::Anim()->OpenAnimatedViewIfNeeded(myState->getCurrent(), this);
#endif
				NOTIFY_OBSERVERS(OMStateInterest, notifyActionDone(this) );
			}
			return;
		}
	case actionStepStarted:
		{
			NOTIFY_OBSERVERS(OMStateInterest, notifyActionStepStarted(this) );
			return;
		}
	case tokenValues:
		{
			char* elemId = s->getChar(p);

			if (TOMProxyConsole::instance()) 
			{
				OMString msg;
				TOMSData* tokensData = s->safeGetOMSData(p);
				if(!tokensData->isEmpty(tokensData->getFirst()))
				{
					OMString tokenValues, value;
					TOMAttributes tokens(NULL);
					tokens.newAttributeValues(tokensData, tokensData->getFirst());
					for(OMIterator<TOMAttributeItem *> iter(tokens); *iter; iter++) 
					{
						if(!tokenValues.IsEmpty())
							tokenValues += "\n";
						tokenValues += "\t";
						tokenValues += (*iter)->getName();
						tokenValues += "\t";
						value.Empty();
						(*iter)->getValue(value);
						tokenValues += value;
					}

					if(!tokenValues.IsEmpty())
					{
						OMString instName;
						outputFirstName(instName);

						msg += "Values in ";
						msg += elemId;
						msg += " of ";
						msg += instName + "\n";
						msg += tokenValues + "\n\n";
						
						TOMProxyConsole::instance()->notifyRawMessage(msg);
					}
				}	
				else
				{
					OMString instName;
					outputFirstName(instName);

					msg += "No values in ";
					msg += elemId;
					msg += " of ";
					msg += instName + "\n\n";
					TOMProxyConsole::instance()->notifyRawMessage(msg);
				}
				delete tokensData;
			}
			return;
		}
		// Messages which should never occuer
	case breakpointActive:
	default: notifyUnexpectedMessage(msgCode);
	}
}

void TOMInstance::handleMessage(AnimMessage* msg)
{
	int code = msg->getCode();
	if (code == allocateCore) {
		AnimAllocateCore *aMsg = (AnimAllocateCore *)(msg);
		myAffinity = (int)(rhp_long64_t)aMsg->getAffinity()->getValue();
		myPowerMode = (int)(rhp_long64_t)aMsg->getPowerMode()->getValue();
		NOTIFY_OBSERVERS(OMAllInterest, notifyCoreAllocation(this,myAffinity, myPowerMode));
	}
}

void TOMInstance::_notifyCreatedForMSC() {
	// Cascade the "created" information to all my components
	for(OMIterator<TOMList *> i(myLinks); *i; ++i) {
		TOMList * rel = (*i);
		if ((rel != NULL) && (rel->composite())) 
		{
			// Iterate on all wlements and make the notify
			for(OMIterator<TOMInstance *> j(rel); *j; ++j) {
				TOMInstance *item = (*j);
				// First I notify
				if (this==item->getContext())
				{
					item->notifyCreatedForMSC(FALSE);

#ifdef OMANIMATOR
					if(TOMExterns::Anim())
						TOMExterns::Anim()->notifyNewItem(item);
#endif
				}
			}
		}
	}
}

void TOMInstance::notifyCreatedForMSC(OMBoolean withComponents /*= TRUE*/) {
	// Notify my observers that I was "created"
	NOTIFY_OBSERVERS(OMExistInterest,
		notifyInverseCompositeRelationConnected(this,getContext()));

	// if processor core was allocated, notify observers
	if(myAffinity != 0)
	{
		NOTIFY_OBSERVERS(OMAllInterest, notifyCoreAllocation(this, myAffinity, myPowerMode));
	}

	// Cascade this information to all my components
	if (withComponents == TRUE) 
		_notifyCreatedForMSC();
}

void TOMInstance::notifyConstructionFinished(const TOMInstance * myCreator) {
	// safe programming - for a misbehaving application
	if (!tomIsValidItem(this)) return;

	// Notify my observers that I was created
	NOTIFY_OBSERVERS(OMExistInterest,
				 notifyInstanceCreated(this,myCreator));
	// Cascade this information to all my components
	_notifyCreatedForMSC();
}

void TOMInstance::notifyYouAreCreator(const TOMInstance * created) {
	NOTIFY_OBSERVERS(OMConstructorsInterest,
		 notifyInstanceCreated(created,this));
}

inline OMBoolean isBehavioral(OMMethodType type) {
	return (type==omBehaviourMethod || type==omTriggerMethod || type==omNullTransition);
}


void TOMInstance::notifyMethodCalled(TOMInstance* caller, 
									 TOMInstance* called,
									 OMString methodString,
									 OMMethodType type) {
	// check if notify from NULL transition
	OMBoolean aNullTransition = (type == omNullTransition);
	if (aNullTransition) type = omBehaviourMethod;

	// this is first to allow the part observers to make 
	// sure they are registered correctly
	TOMInstance *receiverOwner = NULL;
	if(called != NULL && called==this && tomIsValidItem(called))
		receiverOwner = called->getOwnerInstance();
	if ((receiverOwner != NULL) && tomIsValidItem(receiverOwner))
	{
		receiverOwner->notifyPartMethodCalled(caller, called, methodString, type, receiverOwner);
	}

	// notify my observers
	NOTIFY_OBSERVERS(method2Interest(type),
	 notifyMethodCalled(caller, called, methodString,type));

	if (called==this) {
		// if relevant Notify myState that a new behavior step starts
		// relevant = behaviourMethod && behaviour is interesting
		if (isBehavioral(type) && myState!=NULL) {

			// PATCH: an event cannot happen in a middle of a behavior
			// step - if it does, then something is wrong and 
			// we need to reset the counter of behavior step to zero
			if (type==omBehaviourMethod && !aNullTransition) {
				myState->resetInBehaviorStepCounter();
			}

			if (myState->notInBehaviorStep()) {
				myState->startBehaviourStep();
				// For blinking recurring transitions
				NOTIFY_OBSERVERS(OMStateInterest,
					notifyBehaviorStep(	myState->getCurrentStates(),
					myState->getOldStates(),
					myState->getCurrentTransitions(),
					myState->isTerminated(),
					this));
			}
			else if (aNullTransition) {
				NOTIFY_OBSERVERS(OMStateInterest,
					notifyBehaviorStep(	myState->getCurrentStates(),
					myState->getOldStates(),
					myState->getCurrentTransitions(),
					myState->isTerminated(),
					this));
				myState->startNullStep();
			}
			else {
				// redundent 'start'
				myState->startBehaviourStep();
			}
		}
		hasControl = TRUE;
		NOTIFY_OBSERVERS(OMControlInterest, notifyGotControl(this));
	} else {
		NOTIFY_OBSERVERS(OMControlInterest, notifyLostControl(this));
		hasControl = FALSE;
	}
}

void TOMInstance::notifyMethodReturned(TOMInstance* caller,
									   TOMInstance* called,
									   OMString methodString,
									   OMMethodType type) {
	// check if notify from NULL transition
	OMBoolean aNullTransition = (type == omNullTransition);
	if (aNullTransition) type = omBehaviourMethod;

	TOMInstance *owner = getOwnerInstance();
	if ((owner != NULL) && tomIsValidItem(owner)) {
		owner->notifyPartMethodReturned(caller, called, methodString, type, owner);
	}

	NOTIFY_OBSERVERS(method2Interest(type),
		 notifyMethodReturned(caller, called, methodString, type));

	if (called==this) {
		// if relevant Notify myObservers that a behavior step ended
		// relevant = behaviourMethod && behaviour is interesting
		if (isBehavioral(type) && myState!=NULL) {
			if (aNullTransition) {
				NOTIFY_OBSERVERS(OMStateInterest,
					notifyBehaviorStep(	myState->getCurrentStates(),
									myState->getOldStates(),
									myState->getCurrentTransitions(),
									myState->isTerminated(),
									this));
			}
			else {
			myState->endBehaviourStep();
			if (myState->notInBehaviorStep()) {
				NOTIFY_OBSERVERS(OMStateInterest,
					notifyBehaviorStep(	myState->getCurrentStates(),
									myState->getOldStates(),
									myState->getCurrentTransitions(),
									myState->isTerminated(),
									this));
			}
		}
	}
	}

	hasControl = (caller==this);
	if (caller==this) {
		NOTIFY_OBSERVERS(OMControlInterest, notifyGotControl(this));
	} else {
		NOTIFY_OBSERVERS(OMControlInterest, notifyLostControl(this));
	}
}

// to notify AnimOpReturn
void TOMInstance::notifyOpReturn(TOMInstance* caller,
								 TOMInstance* called,
								 OMString method,
								 OMMethodType methodType,
								 OMString& retValString, 
								 OMList<OMString>& nameValList) 
{ 
	NOTIFY_OBSERVERS(OMUserControl, notifyOpReturn(caller, called, method, methodType, retValString, nameValList));
}

// get the instance that contains me, NULL if I am not a part
TOMInstance* TOMInstance::getOwnerInstance() const
{
	TOMInstance *owner = NULL;
	const TOMProxyItem* proxyItem = getContext();
	if ((proxyItem != NULL) &&
		(proxyItem->getType() == omProxyInstance)) 
	{
		owner = (TOMInstance*)(proxyItem);
	}
	return owner;
}


void TOMInstance::notifyEventSent(TOMInstance * sender,
								  TOMInstance * receiver,
								  OMString eventString,
								  void* eventId) {

	// forward to the part listeners onlt via my owner
	TOMInstance* owner = getOwnerInstance();
	if (owner != NULL)
	{
		owner->notifyPartEventSent(sender, receiver, eventString, eventId, owner);
	}

	NOTIFY_OBSERVERS(OMReceiveEventInterest,
		 notifyEventSent(sender, receiver, eventString, eventId));
	
}
void TOMInstance::notifyEventReceived(TOMInstance * sender,
									  TOMInstance * receiver,
									  OMString eventString,
									  void* eventId) {
	// forward to the part listeners onlt via my owner
	TOMInstance* owner = getOwnerInstance();
	if (owner != NULL)
	{
		owner->notifyPartEventReceived(sender, receiver, eventString, eventId, owner);
	}

	NOTIFY_OBSERVERS(OMReceiveEventInterest,
		 notifyEventReceived(sender, receiver, eventString, eventId));
}

void TOMInstance::notifyTimeoutSet(OMString eventString,
								   void* eventId) {
	NOTIFY_OBSERVERS(OMTimeoutsInterest,
			 notifyTimeoutSet(this, eventString, eventId));
}
void TOMInstance::notifyEventCancelled(OMString eventString,
										 void* eventId) {
	NOTIFY_OBSERVERS(OMTimeoutsInterest,
			 notifyEventCancelled(this, eventString, eventId));
}

void TOMInstance::notifyYouAreDeleted(const TOMInstance * myDestroyer) {
	// Last chance to notify about "pending" transitions
	// This is here mainly so we "catch" the transition to terminate
	// which has no "end behaviour" trigger
	hasControl = TOMIsDead;
	if (myState /*myMask.isInteresting(OMStateInterest)*/ ) {
		NOTIFY_OBSERVERS(OMStateInterest,
			notifyBehaviorStep(	myState->getCurrentStates(),
							myState->getOldStates(),
							myState->getCurrentTransitions(),
							myState->isTerminated(),
							this));
	}
	// Notify all my observers about my deletion
#ifdef OMANIMATOR
	SAFE_NOTIFY_OBSERVERS(OMExistInterest,
		 notifyInstanceDeleted(this, myDestroyer));
#endif
#ifdef OMTRACER
	if ( myMask.toInt() & OMExistInterest)
		proxyConsole->notifyInstanceDeleted(this, myDestroyer);
#endif
}


void TOMInstance::notifyYouAreDestroyer(const TOMInstance * destroyed) {
	// Notify all my observers about the destruction
	NOTIFY_OBSERVERS(OMDestructorsInterest,
		notifyInstanceDeleted(destroyed, this));
}

void TOMInstance::_showYourself(TOMUniversalObserver* obs, 
							 int& theMask) {
	// A TOMInstance has exactly 3 "subjects" to show
	theMask = theMask & (OMRelationInterest	|
						 OMStateInterest	|
						 OMAttributesInterest);
	if (/* myMask.toInt() & */ theMask & OMRelationInterest) {
		// Observer is interested in Relation.
		// Relations are always "up to date" so - notify it about them
		obs->notifyRelationsValues(this);
		theMask = theMask & (~OMRelationInterest);
	}

	if ( (theMask & OMAttributesInterest) && 
			myMask.isInteresting(OMAttributesInterest) ) {
/* Changed by Yachin - always send the message
		// Observer is interested in Attributes.
		// and so is the instance - so no need to send messages
		if (attributes!=NULL) { // Instance already has the requested info.
			obs->notifyAttributeValues(attributes, this, TRUE);
		} else { // Instance is waiting to receive the requested info.
			// Create the observer which will "capture" the messsage
			// once it arrives
			MAKE_SHOW_OBSERVER(this, obs, OMAttributesInterest);
		}
		theMask = theMask & (~OMAttributesInterest);
*/
	}
	if ( (theMask & OMStateInterest) && 
			myMask.isInteresting(OMStateInterest) ) {
		// Observer is interested in States.
		// and so is the instance - so no need to send messages
		if (myState!=NULL) // Instance already has the requested info.
			obs->notifyStateConfiguration(this,
										myState->getCurrentStates(),
										myState->isTerminated());
		else { // Instance is waiting to receive the requested info.
			// Create the observer which will "capture" the messsage
			// once it arrives
			MAKE_SHOW_OBSERVER(this, obs, OMStateInterest);
		}
		theMask = theMask & (~OMStateInterest);
	}
}

void TOMInstance::notifyFlowDataReceive(TOMInstance* sender, TOMInstance* receiver, char* argName, char* argValue, TOMInstance* identifier)
{
//	if (receiver == this) {
		NOTIFY_OBSERVERS(OMAllInterest, notifyFlowDataReceive(sender, receiver, argName, argValue, identifier));
//	}
}

void TOMInstance::notifyFlowDataSend(TOMInstance* sender, char* argName, char* argValue, TOMInstance* identifier)
{
	NOTIFY_OBSERVERS(OMAllInterest, notifyFlowDataSend(sender, argName, argValue, identifier));
}

void TOMInstance::notifyMsgCallDuringCtor(TOMInstance* caller, TOMInstance* called, OMString method, OMMethodType type)
{
	if(caller == this)
	{
		NOTIFY_OBSERVERS(OMAllInterest, notifyMsgCallDuringCtor(caller, called, method, type));
	}
}

void TOMInstance::notifyCoreAllocation(TOMInstance* caller, int affinity, int powerMode)
{
	if(caller == this)
	{
		// for now only store the information. Notify observers when finish construction
		myAffinity = affinity;
		myPowerMode = powerMode;
	}
}

void TOMInstance::accept(TOMProxyVisitor1Arg & visitor) 
{
	// do for me
	/* OMBoolean result = */ (void) visitor.execute(*this);
}


// return TRUE if I am an aggregate of the possibleOwner
OMBoolean TOMInstance::isPartOf(const TOMInstance* possibleOwner) const
{
	OMBoolean res = FALSE;
	if ((possibleOwner != NULL) && (tomIsValidItem(possibleOwner))) {
		const TOMProxyItem* proxyItem = getContext();
		if ((proxyItem != NULL) &&
			(proxyItem->getType() == omProxyInstance)) 
		{
			TOMInstance *owner = (TOMInstance*)(proxyItem);
			if (owner == possibleOwner) {
				res = TRUE;
			}
			else {
				res = owner->isPartOf(possibleOwner);
			}
		}
	}
	return res;
}

// return TRUE if possible part is an aggregate of mine (by composition)
OMBoolean TOMInstance::isMyPart(const TOMInstance* possiblePart) const
{
	OMBoolean res = FALSE;
	if ((possiblePart != NULL) && (tomIsValidItem(possiblePart))) 
	{
		res = possiblePart->isPartOf(this);
	}
	return res;
}

void TOMInstance::addPartObserver(TOMPartObserver* partObserver)
{
	if (tomInstancePartObserver != NULL) {
		tomInstancePartObserver->addPartObserver(partObserver);
	}
}

void TOMInstance::TOMInstancePartObserver::addPartObserver(TOMPartObserver* partObserver)
{
	if (TOMSystem::animationIsActive())
	{
		if ((partObserver != NULL) && (myPartObservers.find(partObserver) == 0)
			&& (partObserver != this)) {
			myPartObservers.add(partObserver);
		}
	}
}

void TOMInstance::removePartObserver(TOMPartObserver* partObserver)
{
	if (tomInstancePartObserver != NULL) {
		tomInstancePartObserver->removePartObserver(partObserver);
	}
}

void TOMInstance::TOMInstancePartObserver::removePartObserver(TOMPartObserver* partObserver)
{
	if (partObserver != NULL) {
		myPartObservers.remove(partObserver);
	}
}

void TOMInstance::removePartObserverRecursive(TOMPartObserver* partObserver) 
{
	if (tomInstancePartObserver != NULL) {
		tomInstancePartObserver->removePartObserverRecursive(partObserver);
	}
}

void TOMInstance::TOMInstancePartObserver::removePartObserverRecursive(TOMPartObserver* partObserver)
{
	if (partObserver != NULL) 
	{
		// remove from myself
		myPartObservers.remove(partObserver);

		// remove from my parts
		if (tomInstance != NULL) {
			for(OMIterator<TOMList *> i(tomInstance->getLinks()); *i; ++i) {
				TOMList * rel = (*i);
				if (rel->composite()) {
					// Iterate on all elements and make the notify
					for(OMIterator<TOMInstance *> j(rel); *j; ++j) {
						TOMInstance *item = (*j);
						// First I notify - also if the partObserver is me then stop - 
						// avoid infinite loop
						if ((tomIsValidItem(item)) && (partObserver->getTOMInstance() != item))
						{
							item->removePartObserverRecursive(partObserver);
						}
					}
				}
			}
		}
	}
}




void TOMInstance::notifyPartConnected(TOMInstance* theOwner,
									  TOMInstance* thePart) {
	if (tomInstancePartObserver != NULL)
		tomInstancePartObserver->notifyPartConnected(theOwner, thePart);
}


void TOMInstance::TOMInstancePartObserver::notifyPartConnected(TOMInstance* theOwner,
		TOMInstance* thePart) 
{ 
	for(OMIterator<TOMPartObserver*> i(myPartObservers); *i; i++) 
	{
		TOMPartObserver* partObserver = (*i);
		if ((partObserver != NULL) && (partObserver != this)) // avoid infinite loop
			partObserver->notifyPartConnected(theOwner, thePart);
	}
}


void TOMInstance::notifyPartEnteredState(TOMInstance * instance ,
		char * state ,
		TOMInstance * theOwner )
{
	if (tomInstancePartObserver != NULL)
		tomInstancePartObserver->notifyPartEnteredState(instance, state, theOwner);
}

void TOMInstance::TOMInstancePartObserver::notifyPartEnteredState(TOMInstance * instance ,
		char * state ,
		TOMInstance * /*theOwner*/ )
{
	for(OMIterator<TOMPartObserver*> i(myPartObservers); *i; i++) 
	{
		(*i)->notifyPartEnteredState(instance, state, tomInstance);
	}
}


void TOMInstance::notifyPartEventReceived(TOMInstance * sender,
										  TOMInstance *receiver,
										  OMString event,
										  void* eventId,
										  TOMInstance* theOwner) {
	if (tomInstancePartObserver != NULL)
		tomInstancePartObserver->notifyPartEventReceived(sender, receiver, event, eventId, theOwner);
}

void TOMInstance::TOMInstancePartObserver::notifyPartEventReceived(TOMInstance * sender,
										  TOMInstance *receiver,
										  OMString event,
										  void* eventId,
										  TOMInstance* /*theOwner*/)
{
	
	for(OMIterator<TOMPartObserver*> i(myPartObservers); *i; i++) 
	{
		(*i)->notifyPartEventReceived(sender, receiver, event, eventId, tomInstance);
	}
}

void TOMInstance::notifyPartEventSent(TOMInstance * sender,
									  TOMInstance * receiver,
									  OMString event,
									  void* eventId,
									  TOMInstance* theOwner)
{
	if (tomInstancePartObserver != NULL)
		tomInstancePartObserver->notifyPartEventSent(sender, receiver, event, eventId, theOwner);
}
void TOMInstance::TOMInstancePartObserver::notifyPartEventSent(TOMInstance * sender,
									  TOMInstance * receiver,
									  OMString event,
									  void* eventId,
									  TOMInstance* /*theOwner*/)
{
	for(OMIterator<TOMPartObserver*> i(myPartObservers); *i; i++) 
	{
		(*i)->notifyPartEventSent(sender, receiver, event, eventId, tomInstance);
	}
}


void TOMInstance::notifyPartMethodCalled(TOMInstance* caller,
										 TOMInstance* called,
										 OMString method,
										 OMMethodType methodType,
										 TOMInstance* theOwner)
{
	if (tomInstancePartObserver != NULL)
		tomInstancePartObserver->notifyPartMethodCalled(caller, called, method, methodType, theOwner);
}
void TOMInstance::TOMInstancePartObserver::notifyPartMethodCalled(TOMInstance* caller,
										 TOMInstance* called,
										 OMString method,
										 OMMethodType methodType,
										 TOMInstance* /*theOwner*/)
{
	for(OMIterator<TOMPartObserver*> i(myPartObservers); *i; i++) 
	{
		(*i)->notifyPartMethodCalled(caller, called, method, methodType, tomInstance);
	}
}


void TOMInstance::notifyPartMethodReturned(TOMInstance* caller,
										   TOMInstance* called,
										   OMString method,
										   OMMethodType methodType,
										   TOMInstance* theOwner)
{
	if (tomInstancePartObserver != NULL)
		tomInstancePartObserver->notifyPartMethodReturned(caller, called, method, methodType, theOwner);
}

void TOMInstance::TOMInstancePartObserver::notifyPartMethodReturned(TOMInstance* caller,
										   TOMInstance* called,
										   OMString method,
										   OMMethodType methodType,
										   TOMInstance* /*theOwner*/)
{
	for(OMIterator<TOMPartObserver*> i(myPartObservers); *i; i++) 
	{
		(*i)->notifyPartMethodReturned(caller, called, method, methodType, tomInstance);
	}
}

void TOMInstance::resetState()
{
	if(myState)
	{
		delete myState;
		myState = NULL;
	}
}

void TOMInstance::handleFlowConfiguration(TOMSData* s, OMSPosition& p)
{
	if(s != NULL && !s->isEmpty(p))
	{
		TOMSData* flowMessage = s->safeGetOMSData(p);
		if(!flowMessage->isEmpty(flowMessage->getFirst()))
		{
			TOMAttributes flows(NULL);
			flows.newAttributeValues(flowMessage, flowMessage->getFirst());
			if(flows.getCount() > 0)
			{
				NOTIFY_OBSERVERS(OMStateInterest,notifyFlowConfiguration(this,	&flows));
			}
		}
		delete flowMessage;
	}
}
//
// $Log: tominst.cpp $
// Revision 1.125  2007/03/11 13:14:42  ilgiga
// Change copyright comment
// Revision 1.124  2007/03/04 15:07:31  ilgiga
// Telelogic instead of i-Logix
// Revision 1.123  2006/11/19 09:52:02  ccohen
// fixed regression when having multiple instances from the same application.
// Revision 1.122  2006/11/06 09:46:28  ccohen
// fixed compilation errors/warnings in vxworks/integrity.
// Revision 1.121  2006/10/31 08:58:52  ccohen
// support running multiple animation processes.
// Revision 1.120  2006/07/26 13:38:40  eldad
// To main branch
// Revision 1.119.1.2  2006/07/24 14:08:40  eldad
// Avoid infinite loop by bailing out when removing recursively the part observer
// if the instance itself is the partObserver (circular compisitions)
// Revision 1.119.1.1  2005/08/23 14:50:43  eldad
// Duplicate revision
// Revision 1.118.1.2  2005/08/22 10:05:39  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.118  2005/04/21 11:44:07  eldad
// Fixed animation failure when part is by value and owner is deleted
// from user code
// Revision 1.117  2005/01/19 12:53:29  eldad
// patch for 79582 fix.
// Revision 1.116  2004/12/06 07:15:42  eldad
// Removed dynamic_cast (RTTI disablled in the RTOSes)
// Revision 1.115  2004/12/05 08:51:54  eldad
// Fixed 77939
// Revision 1.114  2004/10/10 15:52:04  eldad
// Merge 1.113 + 1.111.2.2
// Revision 1.111.2.2  2004/10/10 15:51:14  eldad
// Avoid having a part observer observe itself.
// Revision 1.113  2004/07/12 07:52:45  eldad
// Merge 1.112 + 1.111.2.1
// Revision 1.111.2.1  2004/07/05 07:45:53  eldad
// Fixed bug 72670
// Revision 1.111  2004/01/12 10:31:03  eldad
// Allow dor (.) notation in C++\Java
// Revision 1.112  2004/06/27 15:30:15  amos
// move to model-based oxf in RiC++
// Revision 1.111.1.2  2004/02/09 09:32:28  amos
// changes due to OMBoolean type change
// Revision 1.111.1.1  2004/01/12 10:31:03  amos
// Duplicate revision
// Revision 1.110  2003/12/28 12:54:13  eldad
// Removed multiple inheritance
// Revision 1.109  2003/12/25 12:06:08  eldad
// Black Box Animation
// Revision 1.108  2003/12/24 14:34:25  eldad
// Black Box Animation Support - Compositional Hierarchy
// Revision 1.107.1.4  2003/12/23 16:19:18  eldad
// Revision 1.107.1.3  2003/12/22 16:03:37  eldad
// Revision 1.107.1.2  2003/12/22 15:31:18  eldad
// Revision 1.107.1.1  2003/06/16 05:45:01  eldad
// Duplicate revision
// Revision 1.106.2.1  2002/07/07 14:06:52  amos
// framework cleanup from RTOS specific code - back to r41 main branch
// Revision 1.106.1.2  2002/07/07 14:06:52  amos
// replace adaptor specific #ifdef with generic statements
// Revision 1.106.1.1  2002/05/15 14:55:25  amos
// Duplicate revision
// Revision 1.105.1.2  2002/05/13 08:55:09  Eldad
// myName leak.
// Revision 1.105.1.1  2001/05/10 08:26:27  Eldad
// Duplicate revision
// Revision 1.104  2000/12/25 10:39:50  amos
// move to warning level 4
// Revision 1.103.1.2  2001/05/10 08:17:09  amos
// fix memory leak
// Revision 1.103.1.1  2001/05/09 18:31:01  sasha
// If the state in the handleStateConfiguration() operation is defferent 
// from the existing then update the myState to the new one.
// Revision 1.103  2000/11/14 14:29:27  ofer
// teak the code so GNU compiler  for PPC ( VxWorks )  will work
// bugfix 30417
// Revision 1.102  2000/11/05 08:26:02  yachin
// Fix bug 32797 - show attributes now always asks AOM for data
// Revision 1.101  2000/10/12 12:56:58  amos
// back to main branch
// Revision 1.100.1.2  2000/10/12 12:56:58  amos
// in TOMInstance::createRelationsFirstInstance() - reset the list or links before adding the new links. This is done to prevent multiply apprences of the base classes links.
// in TOMInstance::handleMessage() - in case of 'relationConnected' message:
//     if the relation is not found in the relations list, ignore the error, assuming that the message arived too soon, while the instance is still registered as its base class.
// Revision 1.100.1.1  2000/07/19 13:24:44  amos
// Duplicate revision
// Revision 1.99  2000/07/12 06:54:24  amos
// changes related to modify char* to const char*.
// Revision 1.98  2000/04/10 12:56:16  yachin
// tomInstance2String instead of getFullName()  - due to deleted context
// Revision 1.97  2000/03/14 08:35:56  amos
// back to main branch
// Revision 1.96.1.2  2000/02/21 08:42:28  amos
// add safe programming to prevent crashes caused by misbehaving applications.
// Revision 1.96.1.1  2000/01/25 16:34:22  amos
// Duplicate revision
// Revision 1.95  2000/01/19 12:36:27  amos
// back to main branch
// Revision 1.94.1.3  2000/01/13 09:50:45  amos
// support animation of Null Transition
// Revision 1.94.1.2  2000/01/12 14:05:21  amos
// refine handle of null transition step messages
// Revision 1.94.1.1  2000/01/06 14:01:06  amos
// Revision 1.94.2.1  2000/01/19 12:21:33  amos
// Revision 1.94  1999/10/12 13:33:00  yachin
// Fix bugs
// Revision 1.93  1999/07/15 13:42:03  yachin
// change 'instanceCallString from '->' to '.'
// Revision 1.92  1999/07/12 08:21:45  yachin
// Treat global rename correctly
// Revision 1.91  1999/07/11 12:52:58  yachin
// Allow name2Item to recognize global names
// Revision 1.90  1999/07/11 09:28:21  amos
// add a table for renamed global instances
// Revision 1.89  1999/06/03 13:10:21  amos
// temporary safe programming
// Revision 1.88  1999/02/16 05:56:55  yachin
// Speed up of constructors
// Revision 1.87  1998/11/25 12:56:41  beery
// Revision 1.86  1998/11/23 17:40:52  beery
// Revision 1.85  1998/11/22 14:17:31  beery
// Revision 1.84  1998/11/19 17:54:14  beery
// Revision 1.83  1998/11/17 12:16:41  beery
// Revision 1.82  1998/08/02 15:07:41  beery
// Revision 1.81  1998/06/25 08:46:17  yachin
// Fix bug 6515 - rereference deleted instances on call stack to 'inDestruction"
// Revision 1.80  1998/06/23 12:29:33  yachin
// Fix itoa problems
// Revision 1.79  1998/06/22 14:42:36  yachin
// using itoa instead of _itoa
// Revision 1.78  1998/06/18 11:58:58  yachin
// fix on fix
// Revision 1.77  1998/06/17 12:38:53  yachin
// don't use x2String for displaying multiplicity
// Revision 1.76  1998/06/14 12:17:48  yachin
// Fix bug 6241 - startMask in animation is now 'larger'
// Revision 1.75  1998/05/21 11:24:04  yachin
// Fix bug 5603 (have getPackage return a TOMPackage and not a TOMProxyItem)
// Revision 1.74  1998/04/02 06:02:19  yachin
// Revision 1.73  1997/08/07 05:50:08  yachin
// Remove "impossibly expressions" from createObserver list
// Revision 1.72  1997/07/20 11:36:36  yachin
// Adding globals to animation
// Revision 1.71  1997/05/27 09:02:49  yachin
// Made tomstr == ystr
// Revision 1.70  1997/04/07 23:06:44  ofer
// Move file names and includes to lowercase
// so UNIX will work with lowercase versions
// Revision 1.69  1997/03/03 12:21:37  yachin
// Fix "destructor going the wrong way" bug
// Revision 1.68  1997/02/26 07:58:01  yachin
// modified x2String to take 2 parameters
// Revision 1.67  1997/02/24 13:40:48  yachin
// fix on state config. notify
// Revision 1.66  1997/02/20 10:04:32  yachin
// Dead objects no longer update their masks
// Revision 1.65  1997/02/19 11:19:55  yachin
// Add isAnimationActive mode to all observer operations
// Revision 1.64  1997/02/18 11:30:47  yachin
// Bug fixes
// Revision 1.63  1997/02/16 09:29:05  yachin
// remove theClass parameter from instanceCreated/delted notifies.
// make inverseRelationConnect cascade from relations and not the createObserver
// Revision 1.62  1997/02/13 09:57:40  yachin
// removed isComposite isSingleton from the connectRelation message
// Revision 1.61  1997/02/12 11:15:39  yachin
// Rewrite of TOMProxyItem(...)
// Revision 1.60  1997/02/11 12:54:34  yachin
// Adding Name spaces
// Revision 1.59  1997/02/05 07:01:34  yachin
// Fix unix port bug
// Revision 1.58  1997/01/22 11:54:09  yachin
// Inverse composite relation bug fix
// Revision 1.57  1997/01/21 11:08:45  yachin
// changed _int32 to int
// Revision 1.56  1997/01/20 06:48:43  yachin
// Revision 1.55  1997/01/19 11:19:49  yachin
// Revision 1.54  1997/01/13 11:38:57  yachin
// Make constructor/destructor mult=2 notifications
// Revision 1.53  1996/12/23 11:51:06  yachin
// Add ids to events
// Revision 1.52  1996/12/22 09:03:22  yachin
// Has composite notify componentes abou tits new name
// Revision 1.51  1996/12/19 13:15:12  yachin
// Revision 1.50  1996/12/11 13:25:06  yachin
// Revision 1.49  1996/12/08 13:36:45  yachin
// Revision 1.48  1996/12/08 12:32:27  yachin
// Revision 1.47  1996/12/08 10:15:40  yachin
// Revision 1.46  1996/12/03 07:12:34  yachin
// Fixed "triggered op/notify behavior step" bug
// Revision 1.45  1996/12/02 09:43:16  yachin
// Revision 1.44  1996/11/24 12:40:37  yachin
// Revision 1.43  1996/11/14 12:25:01  yachin
// Revision 1.42  1996/11/05 13:45:35  yachin
// Change getType to non virtual add myType attribute
// Revision 1.41  1996/10/14 13:26:19  yachin
// Handle sub classes and set/cancel timeout
// Revision 1.40  1996/10/10 10:09:31  yachin
// Revision 1.39  1996/10/10 08:01:24  yachin
// Revision 1.38  1996/10/10 06:15:11  yachin
// Revision 1.37  1996/10/09 07:37:06  yachin
// Revision 1.36  1996/10/02 08:40:53  yachin
// Hopefully fixed "early" relation registration bug
// Revision 1.35  1996/10/01 11:42:53  yachin
// Fix registraction bug in relations
// Revision 1.34  1996/10/01 07:48:56  yachin
// Revision 1.33  1996/10/01 06:56:22  yachin
// Fixing the "show class all" bug
// Revision 1.32  1996/09/30 10:05:28  yachin
// Revision 1.31  1996/09/26 11:39:40  ofer
// Revision 1.30  1996/09/26 11:33:34  ofer
// Revision 1.29  1996/09/26 10:57:39  yachin
// Revision 1.28  1996/09/26 09:01:47  yachin
// Fix bug wiht interest masks
// Change instance count to star tat 0
// Revision 1.27  1996/09/24 13:56:28  yachin
// Revision 1.26  1996/09/19 12:31:38  yachin
// add class info to TOMInstance
// Revision 1.25  1996/09/18 13:00:41  yachin
// Revision 1.24  1996/09/17 13:43:00  yachin
// Revision 1.23  1996/09/16 13:44:29  yachin
// Revision 1.22  1996/09/16 10:04:13  yachin
// Revision 1.21  1996/09/16 09:28:30  yachin
// Revision 1.20  1996/09/09 07:25:54  yachin
// Fix bug in name2item
// Revision 1.19  1996/09/08 13:28:55  yachin
// Registeration of items which do not yet exist
// Revision 1.18  1996/09/05 13:35:55  yachin
// Revision 1.17  1996/09/04 13:56:22  yachin
// probably handling Event Queues correctly
// (inserted by ofer)
// Revision 1.16  1996/09/04 13:16:09  yachin
// Connect with Israel
// Revision 1.15  1996/08/29 11:35:06  ofer
// Revision 1.14  1996/08/14 12:40:24  yachin
// Seperate TOM Masks from AOM Masks. Fix bugs with attr. and states
// Revision 1.13  1996/08/12 12:28:48  yachin
// Unified Interface for "file" and "stdin". seperated show from trace
// Revision 1.12  1996/08/08 08:23:28  yachin
// Revision 1.11  1996/08/06 12:52:05  yachin
// Version for Prototype 4
// Revision 1.10  1996/07/22 11:30:29  yachin
// Revision 1.9  1996/07/10 12:50:24  yachin
// Handle termination properly
// Revision 1.8  1996/07/10 05:50:08  yachin
// Reprecussion of reorganizatio nof AOM
// Revision 1.7  1996/07/03 12:45:49  yachin
// Fixing bugs for "const" and "static
// enhancements for attributes and indentation
// Revision 1.6  1996/07/02 10:17:23  yachin
// Componnet/Relation distinction
// Revision 1.5  1996/06/26 12:45:58  yachin
// Put header message and fix some bugs
// Revision 1.4  1996/06/25 11:53:36  yachin
// Revision 1.3  1996/06/25 08:21:05  yachin
// Revision 1.2  1996/06/19 10:21:27  yachin
// Revision 1.1  1996/06/17 05:40:43  yachin
// Initial revision
//
