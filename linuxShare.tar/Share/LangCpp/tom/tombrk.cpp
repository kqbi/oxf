#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tombrk.cpp 1.14 2007/03/11 13:14:41 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tombrk.cpp $
//	file version:	$Revision: 1.14 $
//
//	purpose: Methods of TOMBreakPoint and TOMBreakPointManager	 	
//
//	author(s):		Yachin Pnueli
//	date started:	16.10.96
//	date changed:	$Date: 2007/03/11 13:14:41 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "toxf.h"
#include "tombrk.h"
#include "tommsg.h"
#include "tomdisp.h"
#include "tomobs.h"
#include "tomsys.h"

void TOMBreakPoint::serialize(OMSData& msg) {
	msg.addItem(myType);
	msg.addItem(((TOMProxyItem *)myItem)->getReal());
	msg.addItem(myData);
}


TOMBreakPointManager * TOMBreakPointManager::_instance = NULL;

void TOMBreakPointManager::sendMessage(OMNotify theType, 
									   void * theItem, 
									   const char *theData,
									   OMNotify what) {
	OMSData * msg = new OMSData(myReal,what);
	msg->addItem(theType);
	msg->addItem(((TOMProxyItem *)theItem)->getReal());
	msg->addItem(theData);
	TOMDispatcher::instance()->sendMessage(msg);
}

OMBoolean TOMBreakPointManager::addBreakPoint(OMNotify theType, void * theItem, const char *theData) {
	OMIterator<TOMBreakPoint *> iter;
	// Look for the breakPoint in the activeList
	for(iter.reset(activeList);*iter;++iter) {
		TOMBreakPoint *bp = (*iter);
		if (bp->matchBreakPoint(theType,theItem,theData)) {
			return FALSE;
		}
	}
	// Look for the breakPoint in the frozenList
	for(iter.reset(frozenList);*iter;++iter) {
		TOMBreakPoint *bp = (*iter);
		if (bp->matchBreakPoint(theType,theItem,theData)) {
			// Notify. my real of the adition
			sendMessage(theType,theItem,theData,setBreakpoint);
			// Actually remove it
			frozenList.remove(bp);
			activeList.add(bp);
			return TRUE;
		}
	}
	// Breakpoint not found
	// Notify. my real of the adition
	sendMessage(theType,theItem,theData,setBreakpoint);
	// Actually add it
	TOMBreakPoint *bp = new TOMBreakPoint(theType,theItem,theData);
	activeList.add(bp);
	return TRUE;
}

inline void TOMBreakPointManager::_freezeBreakPoint(TOMBreakPoint *bp) {
	// Notify my real of the removal
	sendMessage(bp->getType(),bp->getItem(),bp->getData(),removeBreakpoint);
	// Actually remove it
	activeList.remove(bp);
	frozenList.add(bp);
}

OMBoolean TOMBreakPointManager::freezeBreakPoint(OMNotify theType, void * theItem, const char *theData) {
	OMBoolean found = FALSE;
	OMIterator<TOMBreakPoint *> iter;
	// Look for the breakPoint in the activeList
	OMBoolean localFound;
	do {
		localFound = FALSE;
		for(iter.reset(activeList);*iter;++iter) {
			TOMBreakPoint *bp = (*iter);
			if (bp->matchBreakPoint(theType,theItem,theData)) {
				// Actually freeze it
				_freezeBreakPoint(bp);
				localFound = found = TRUE;
				break;
			}
		}
	} while (localFound);
	if (found) return TRUE;
	// Look for the breakPoint in the frozenList
	for(iter.reset(frozenList);*iter;++iter) {
		if ((*iter)->matchBreakPoint(theType,theItem,theData))
			return TRUE;
	}
	// Breakpoint not found
	return FALSE;
}

inline void TOMBreakPointManager::_reviveBreakPoint(TOMBreakPoint *bp) {
	// Notify. my real of the adition
	sendMessage(bp->getType(),bp->getItem(),bp->getData(),setBreakpoint);
	// Actually revive it
	frozenList.remove(bp);
	activeList.add(bp);
}


OMBoolean TOMBreakPointManager::reviveBreakPoint(OMNotify theType, void * theItem, const char *theData) {
	OMBoolean found = FALSE;
	OMIterator<TOMBreakPoint *> iter;
	// Look for the breakPoint in the frozenList
	OMBoolean localFound;
	do {
		localFound = FALSE;
		for(iter.reset(frozenList);*iter;iter++) {
			TOMBreakPoint *bp = (*iter);
			if (bp->matchBreakPoint(theType,theItem,theData)) {
				// Actually revive it
				_reviveBreakPoint(bp);
				localFound = found = TRUE;
				break;
			}
		}
	} while (localFound);
	if (found) return TRUE;
	// Look for the breakPoint in the activeList
	for(iter.reset(activeList);*iter;iter++) {
		if ((*iter)->matchBreakPoint(theType,theItem,theData))
			return TRUE;
	}
	// Breakpoint not found
	return FALSE;
}

inline void TOMBreakPointManager::_removeBreakPoint(TOMBreakPoint *bp) {
	// Notify. my real of the removal
	sendMessage(bp->getType(),bp->getItem(),bp->getData(),removeBreakpoint);
	// Actually remove it
	activeList.remove(bp);
	delete bp;
}


OMBoolean TOMBreakPointManager::removeBreakPoint(OMNotify theType, void * theItem, const char *theData) {
	OMBoolean found = FALSE;
	OMIterator<TOMBreakPoint *> iter;
	// Look for the breakPoint in the activeList
	OMBoolean localFound;
	do {
		localFound = FALSE;
		for(iter.reset(activeList);*iter;iter++) {
			TOMBreakPoint *bp = (*iter);
			if (bp->matchBreakPoint(theType,theItem,theData)) {
				// Actually remove it
				_removeBreakPoint(bp);
				localFound = found = TRUE;
				break;
			}
		}
	} while (localFound);
	// Look for the breakPoint in the frozenList
	do {
		localFound = FALSE;
		for(iter.reset(frozenList);*iter;iter++) {
			TOMBreakPoint *bp = (*iter);
			if (bp->matchBreakPoint(theType,theItem,theData)) {
				// No need to Notify. my real contains only active bp's
				// Actually remove it
				frozenList.remove(bp);
				delete bp;
				localFound = found = TRUE;
				break;
			}
		}
	} while (localFound);
	return found;
}

void TOMBreakPointManager::_showYourself(TOMUniversalObserver*obs , int& theMask) {
	if (theMask) {
		obs->notifyBreakPointValues(this);
		theMask = OMNoInterest;
	}
}

void TOMBreakPointManager::handleMessage(OMNotify msgCode, 
								 TOMSData* s, 
								 OMSPosition p) {
	switch (msgCode) {
	case breakpointActive: {
		// Get the Break point data
		OMNotify theType = s->getOMNotify(p);
		void* theItem = s->getPointer(p);
		char* theData = s->getChar(p);
		// Notify my observers
		NOTIFY_OBSERVERS(OMExistInterest,
			notifyBreakPointActive(theType, (TOMProxyItem*)theItem, theData) );
		delete [] theData;
		break;
					   }
	case instanceDeleted: {
		// Get the deleted item
		/* void* theItem = */ (void) s->getPointer(p);
		// Currently we delete all break points on this item
//		removeBreakPoint(allValues, theItem, "");
		// Instead all such breakpoints should attempt to reregister
		// and only those recieving an OMGarbage response should 
		// delete themselves
		break;
					   }

	default: notifyUnexpectedMessage(msgCode);
	}
}
//
// $Log: tombrk.cpp $
// Revision 1.14  2007/03/11 13:14:41  ilgiga
// Change copyright comment
// Revision 1.13  2007/03/04 15:07:30  ilgiga
// Telelogic instead of i-Logix
// Revision 1.12  2005/08/23 14:50:42  amos
// bugfix 85444 to main branch
// Revision 1.11.1.2  2005/08/22 10:05:38  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.11  2000/12/25 10:39:50  amos
// move to warning level 4
// Revision 1.10  2000/07/11 09:20:07  amos
// changes related to modify char* to const char*.
// Revision 1.9  1999/02/16 05:56:52  yachin
// Speed up of constructors
// Revision 1.8  1998/08/02 15:07:40  beery
// Revision 1.7  1997/03/19 13:30:15  yachin
// bug fixes
// Revision 1.6  1997/03/19 09:45:24  yachin
// Delete breakpoints on deleted items 
// Revision 1.5  1997/01/21 11:08:44  yachin
// changed _int32 to int
// Revision 1.4  1996/11/24 12:40:35  yachin
// Revision 1.3  1996/11/07 07:47:19  yachin
// fix "show breakpoints" bug
// Revision 1.2  1996/10/28 09:49:56  yachin
// Revision 1.1  1996/10/21 11:39:50  yachin
// Initial revision
//
