#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomrefresh.cpp 1.5 2007/03/11 13:14:45 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomrefresh.cpp $
//	file version:	$Revision: 1.5 $
//
//	purpose: Methods of Class TOMAttr	 	
//
//	author(s):		Beery Holstein
//	date started:	10.98
//	date changed:	$Date: 2007/03/11 13:14:45 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//

#include "tommask.h"
#include "tomobs.h"
#include "tomrefresh.h"

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomrefresh_H;
#endif

OMBoolean TOMRefresh::execute(TOMProxyItem & proxy)
{
	proxy.refresh();
	return TRUE;
}

TOMRefresher::TOMRefresher()
: myProxy(NULL)
{}

TOMRefresher::TOMRefresher(TOMProxyItem * aProxy)
: myProxy(aProxy)
{}

// Propagate the notification to the console, which is the only observer.
#ifdef OMTRACER
#define REFRESH_OBSERVERS(THEMASK,THEACTION) {		\
	if (myProxy != NULL) {							\
		OMInterestMask mask = myProxy->getFullRealMask();	\
		if (mask.toInt() & (THEMASK)) {				\
			proxyConsole->THEACTION;				\
		}											\
	}												\
}
#endif

// Propagate the notification to all proxy's observers.
// For every observer, propagate only those notification 
// that the specific observer is interested about
#ifdef OMANIMATOR 
#define REFRESH_OBSERVERS(THEMASK,THEACTION) {	\
	if (myProxy != NULL) {							\
		const OMList<TOMMaskedObserver *> & observerList = myProxy->getObserverList(); \
		for(OMIterator<TOMMaskedObserver*> maskedObserver(observerList); *maskedObserver; ++maskedObserver)\
		{								\
			TOMUniversalObserver* uniObserver = (*maskedObserver)->getObserver();	\
			if (uniObserver != NULL) {	\
				OMInterestMask mask = (*maskedObserver)->getMask();	\
				if (mask.toInt() & (THEMASK)) {	\
					uniObserver->THEACTION;	\
				}	\
			}\
		}\
	}\
}
#endif

void TOMRefresher::notifyStateConfiguration(const TOMInstance * instance,
											OMList<OMHandle *>* states,
											OMBoolean isTerminated) 
{
	REFRESH_OBSERVERS(OMStateInterest,notifyStateConfiguration(instance,states,isTerminated))
}

void TOMRefresher::notifyAttributeValues(OMList<TOMAttributeItem *> *attr, 
											const TOMProxyItem * instance, 
											OMBoolean isFirstTime) 
{
	REFRESH_OBSERVERS(OMAttributesInterest,notifyAttributeValues(attr,instance,isFirstTime))
}

void TOMRefresher::notifyRelationsValues(TOMInstance* item) 
{
	REFRESH_OBSERVERS(OMRelationInterest,notifyRelationsValues(item))
}

void TOMRefresher::notifyCallStackValues(OMSData * values) 
{
	REFRESH_OBSERVERS(OMAllInterest,notifyCallStackValues(values))
}

void TOMRefresher::notifyEventQueueValues(OMSData * values) 
{
	REFRESH_OBSERVERS(OMAllInterest,notifyEventQueueValues(values))
}

//
// $Log: tomrefresh.cpp $
// Revision 1.5  2007/03/11 13:14:45  ilgiga
// Change copyright comment
// Revision 1.4  2007/03/04 15:07:36  ilgiga
// Telelogic instead of i-Logix
// Revision 1.3  2005/08/23 14:50:47  amos
// bugfix 85444 to main branch
// Revision 1.2.1.2  2005/08/22 10:05:42  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.2  2000/07/11 09:23:51  amos
// changes related to modify char* to const char*.
// Revision 1.1  1998/11/30 12:36:33  beery
// Initial revision
//
