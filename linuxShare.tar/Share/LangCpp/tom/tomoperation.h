#ifndef tomoper_H
#define tomoper_H "$Id: tomoperation.h 1.4 2007/03/11 13:14:44 ilgiga Exp $"

//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomoperation.h $
//	file version:	$Revision: 1.4 $
//
//	purpose: define the TOM Attribute handler class	
//
//	author(s):	Eldad Palachi
//	date started:	17.7.02
//	date changed:	$Date: 2007/03/11 13:14:44 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//

//	An operation proxy class
#include "tomproxy.h"

class TOMClass;
class AnimOperationData;

class RP_ANIM_DLL TOMOperation : public TOMProxyItem {
protected:
	OMString opName;
	OMBoolean isStatic;
	OMString signature;
	int numOfArgs;
	TOMClass *myClass;
	void removeBlanksFromSignature();
public:
	virtual ~TOMOperation()	{ }
	TOMOperation(AnimOperationData* operData, TOMClass *cls);
	void setMyClass(TOMClass *cls);
	OMBoolean match(const OMString& opName, const int numOfArgs, const OMString& signature);
	OMBoolean getIsStatic() {return isStatic;}
	const OMString& getSignature() {return signature;}
	const OMString& getName() {return opName;}
};


#endif
