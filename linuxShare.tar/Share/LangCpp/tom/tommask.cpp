#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tommask.cpp 1.91 2007/03/21 14:22:53 ilelpa Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tommask.cpp $
//	file version:	$Revision: 1.91 $
//
//	purpose: Methods of TOMProxyConsole	 	
//
//	author(s):		Yachin Pnueli
//	date started:	18.6.96
//	date changed:	$Date: 2007/03/21 14:22:53 $
//	last change by:	$Author: ilelpa $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "tommask.h"
#include "tominst.h"
#include "tomclass.h"
#include "tommsg.h"
#include "tomattr.h"
#include "tomsys.h"
#include "tomthrd.h"
#include "tompack.h"
#include "tombrk.h"
#include "toxf.h"
#include "tomstate.h"
#include <oxf/OXFNotifyMacros.h>

#include <omcom/AnimStringField.h>
#include <omcom/AnimIntField.h>
#include <omcom/AnimStringOrPointerField.h>
#include <omcom/AnimBooleanField.h>
#include <omcom/AnimOpCallReply.h>

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tommask_H;
#endif
// "macro"
inline void localInstance2String(const TOMProxyItem* item, OMString& msg) {
	if (item==NULL) {
//		msg += "EventLoop/main()";
		msg += "main()";
	} else
		tominstance2String(item, msg);
}

const OMString TOMProxyConsole::tomAniOut("omAnimateOutput");


TOMProxyConsole::TOMProxyConsole() { 
#ifdef OMTRACER
	// By default we output to "cout"
	addToOutputMap("cout");
#endif
	// Register myself according to defaults
	// For classes the default is OMAllInterest
#ifdef OMTRACER
	TOMSystem::instance()->registerObserver(this,OMAllInterest);
#else
	TOMSystem::instance()->registerObserver(this,OMAllInterest & (!OMUserControl));
#endif
	// For call stack and event queue the default is nothing
	//	TOMSystem::instance()->
	//	registerObserver(this,defaultCallStackMask,"#CallStack");
	//	TOMSystem::instance()->
	//	registerObserver(this,defaultEventQueueMask,"#EventQueue");

	// For break point manager the default is OMAllInterest
	TOMSystem::instance()->registerObserver(this,
												 OMAllInterest,
												 "#BreakPoints");
}

TOMProxyConsole::~TOMProxyConsole() { 
	// 1. Remove myself from being an observer on anyone
	// 1.1. From all classes and instance
	// reRegister "OMNoInterest" does this
	TOMSystem::instance()->reRegisterObserver(this,OMNoInterest);
	// 1.2. From callStack and eventQueue
	// Here we shall have problems with Multi-Threaded applications
	TOMSystem::instance()->deregisterObserver(this,"#CallStack");
	TOMSystem::instance()->deregisterObserver(this,"#EventQueue");

	// 2. Clean up the output list
	// 2.1 Remove the special animation ostream
	removeFromOutputMap(tomAniOut);
	removeFromOutputMap("cout");
	removeFromOutputMap("cerr");
	// 2.2 Remove and close the rest (cout,cerr will not be closed)
	outputMap.removeAll(); 

	// 3. Mark myself as deleted
	_instance=NULL ;
}

void TOMProxyConsole::addToOutputMap(const OMString s,
									 omostream* newOs) {
	omostream * os;
	if (!outputMap.lookUp(s,os) ) {
		outputMap.add(s,newOs);
		tracerOutput.registerItem(newOs);
	}
}

void TOMProxyConsole::addToOutputMap(OMString s) {
	omostream * os;
	if (! outputMap.lookUp(s,os) ) {
		// This is a new stream it should be added
		// First get the omostream
		if (s==(char*)"cout")
			os = &omcout;
		else {		
			//Some OS fail to open file when last character in its name is carriage return.
			tomTrimCarriageReturn(s);
			// attempt to open the file
			os = new omofstream(s.GetBuffer(0));
			if (!(*os))	{ // File open was unsuccessful
				OMString errMsg = "Could not open file ";
				errMsg += s;
				tomSendError(errMsg);
				return;
			}
		}
		// Now add the name, omostream * pair
		addToOutputMap(s,os);
	}
}

void TOMProxyConsole::removeFromOutputMap(const OMString s) {
	omostream * os;
	if (outputMap.lookUp(s,os) ) {
		outputMap.remove(s);

		//the 'tomAnimOut' could be destructed (for example is an 'exit' command was called), 
		//therefore use a local new OMString for the string comapare
		OMString tmpTomAniOut(tomAniOut);
		if (s!=tmpTomAniOut && s!="cout" && s!="cerr")
			tracerOutput.deregisterItem(os,TRUE);
		else
			tracerOutput.deregisterItem(os,FALSE);
	}
}

//
//	 Implementation of "singleton
//
// The "actual" entry for proxyConsole
TOMUniversalObserver * proxyConsole = NULL;

TOMProxyConsole * TOMProxyConsole::_instance = NULL;

TOMProxyConsole * TOMProxyConsole::createInstance() {
	if (_instance == NULL)
		proxyConsole = _instance = new TOMProxyConsole();
	return _instance;
}


//
//	 The notify methods
//
// The Check Double macro's protect against making the same notification 
// twice they assume that two or more identical mult2 notifications
// follow each other consequtively
#define CHECK_DOUBLE(currentNotify)										\
	if (!strcmp(lastNotify, (char *)(#currentNotify))) return;	\
	lastNotify = (char *)(#currentNotify);

void TOMProxyConsole::notifyInstanceCreated(const TOMInstance *theInstance,
											const TOMInstance *creator) {
	CHECK_DOUBLE(notifyInstanceCreated);

	// Actually Notify
	OMString msg = "New instance ";
	theInstance->outputFullName(msg);
	TOMClass* c = theInstance->getClass();
	if (c!=NULL && !c->isImplicit()) {
		msg += ":";
		c->outputFullName(msg);
	}
	msg += " created by ";
	localInstance2String(creator, msg);
	msg += "\n";
	tracerOutput.notify(msg);
}

void TOMProxyConsole::notifyInstanceDeleted(const TOMInstance *theInstance,
											const TOMInstance *destroyer) {
	CHECK_DOUBLE(notifyInstanceDeleted);
	// Actually Notify
	OMString msg = "Instance ";
	theInstance->outputFullName(msg);

#ifdef OMANIMATOR
	if (isLangC()) // Go by tool mode
		msg += " of object type ";
	else
		msg += " of class ";
#else
#ifdef RIC_APP	// C app
	msg += " of object type ";
#else
	msg += " of class ";
#endif
#endif
	TOMClass* c = theInstance->getClass();
	if (!c) return;
	c->outputFullName(msg);
	if (theInstance == destroyer)
		msg += " deleted itself\n";
	else {
		msg += " deleted by ";
		localInstance2String(destroyer, msg);
		msg += "\n";
	}
	tracerOutput.notify(msg);
}

void TOMProxyConsole::notifyClassValues(TOMClass * theClass) {
 	OMString msg;
#ifdef OMANIMATOR
	if (isLangC()) // Go by tool mode
		msg = "Object type ";
	else
		msg = "Class ";
#else
#ifdef RIC_APP	// C app
	msg = "Object type ";
#else
	msg = "Class ";
#endif
#endif
	if (TOMSystem::instance()->numberOfPackages()>1)
		theClass->outputFullFullName(msg);
	else
		theClass->outputFullName(msg);
	msg += " - Instance List";

	OMBoolean hasInstances = FALSE;
//	for(OMIterator<TOMInstance *> i(theClass); *i; i++) {
	for(TOMClassIterator i(theClass); *i; ++i) {
		if (!hasInstances) {
			hasInstances = TRUE;
			msg += "\n";
		}
		(*i)->outputFullName(msg);
		msg += "\n";
	}
	if (!hasInstances)
		msg += " Empty\n";
	else
		msg += "\n";
	tracerOutput.notify(msg,FALSE);
}


void TOMProxyConsole::notifyEventValues(TOMPackage* p) {
 	OMString msg = "Package ";
	p->outputFullName(msg);
	if (msg==(char*)"Package OMInternal")
		return;
	msg += " - Event List";

	OMBoolean hasEvents = FALSE;
	for(OMIterator<TOMEventClass*> i(p->getEventClasses()); *i; ++i) {
		if (!hasEvents) {
			hasEvents = TRUE;
			msg += "\n";
		}
		(*i)->outputFullName(msg);
		msg += "\n";
	}
	if (!hasEvents)
		msg += " Empty\n";
	else
		msg += "\n";
	tracerOutput.notify(msg,FALSE);
}


void TOMProxyConsole::notifyTerminationReached(const TOMInstance * theInstance) {
	tracerOutput.notify(theInstance, "Reached Termination State");
}

void TOMProxyConsole::notifyEnteredState(const TOMInstance * theInstance,
										 char * stateName) {
	OMString msg = "Entered State ";
	msg += stateName;
	tracerOutput.notify(theInstance, msg);
}

void TOMProxyConsole::notifyExitedState(const TOMInstance * theInstance,
										 char * stateName) {
	OMString msg = "Exited State ";
	msg += stateName;
	tracerOutput.notify(theInstance, msg);
}

void TOMProxyConsole::notifyStateConfiguration(const TOMInstance * instance,
								  OMList<OMHandle *>* states,
								  OMBoolean isTerminated) {
	OMString msg =" State Configuration\n";
	// Are we in any states or terminators ?
	if (states->isEmpty() && !isTerminated) {
		// If not we are before startBehaviour
		msg +="Uninitialized";
	} else {
		for(OMIterator<OMHandle *> i(*states); *i; i++) {
			msg +="\t";
			msg += (*i);
			msg +="\n";
		}
		if (isTerminated)
			msg += "\tTermination state\n";
	}
	tracerOutput.notify(instance, msg, FALSE);
}

// This is here only as a temporary test
void TOMProxyConsole::notifyBehaviorStep(
		OMList<OMHandle *>* /* currentStates */,
		OMList<OMHandle *>* /* previousStates */,
		OMList<OMHandle *>* /* currentTransitions */,
		OMBoolean /* isTerminated */,
		const TOMInstance* /* currentInstance */) {
#ifdef DEBUG_BEHAVIOR_STEP
	OMString msg =" notify Behavior Step\n";
	
	msg +=" Current States\n";
	for(OMIterator<OMHandle *> i(*currentStates); *i; i++) {
		msg +="\t";
		msg += (*i);
		msg +="\n";
	}
	
	msg +=" Previous States\n";
	for(i.reset(*previousStates); *i; i++) {
		msg +="\t";
		msg += (*i);
		msg +="\n";
	}
	
	msg +=" Current Transitions\n";
	for(i.reset(*currentTransitions); *i; i++) {
		msg +="\t";
		msg += (*i);
		msg +="\n";
	}

	if (isTerminated)
			msg += "\tTermination Reached\n";
	msg +="End notify Behavior Step\n";

	tracerOutput.notify(msg);
#endif // DEBUG_BEHAVIOR_STEP
}
// End of // This is here only as a temporary test


void TOMProxyConsole::notifyAttributeValues(OMList<TOMAttributeItem *> *attr, 
											const TOMProxyItem * instance, 
											OMBoolean isFirstTime) {
	if (attr->isEmpty()) {
		if (isFirstTime) {
			OMString msg = " has no attributes\n";
			tracerOutput.notify(instance, msg);
		}
		return;
	}
	OMString msg;
	if (isFirstTime)
		msg = " Attribute Values\n";
	else
		msg = " Modified Attribute Values\n";

	for(OMIterator<TOMAttributeItem *> i(*attr); *i; i++) {
		msg +="\t";
		msg += (*i)->getName();
		msg +="\t";
		(*i)->getValue(msg);
		msg +="\n";
	}
	tracerOutput.notify(instance, msg);
}




void TOMProxyConsole::notifyRelationConnected(const TOMInstance* owner,
											  OMHandle* relationName, 
											  const TOMInstance* item, 
											  OMBoolean isSingleton,
											  OMBoolean isComposite) {
	OMString msg;
	if (isSingleton) {
		if (isComposite)
			msg = "Component ";
		else
			msg = "Relation ";
		msg += relationName;
		msg += " set to ";
		tominstance2String(item, msg, owner);
	} else {
		msg = "Instance ";
		tominstance2String(item, msg, owner);
		msg += " added to ";
		if (isComposite)
			msg += "component ";
		else
			msg += "relation ";
		msg += relationName;
	}
	tracerOutput.notify(owner,msg);
}

void TOMProxyConsole::notifyRelationDisconnected(const TOMInstance* owner,
												 OMHandle* relationName,
												 const TOMInstance* item) {
	// Construct message
	OMString msg = "Instance ";
	tominstance2String(item, msg, owner);
	msg += " removed from relation ";
	msg += relationName;
	tracerOutput.notify(owner, msg);
}

void TOMProxyConsole::notifyRelationCleared(const TOMInstance* owner,
											OMHandle* relationName) {
	// Construct message
	OMString msg = " Relation ";
	msg += relationName;
	msg += " Cleared ";
	tracerOutput.notify(owner,msg);
}


void TOMProxyConsole::notifyRelationsValues(TOMInstance* item) {
	// Set the relations iterator
	OMIterator<TOMList *> i(item->getLinks());
	// Do we have relations
	if (*i==NULL) {
		tracerOutput.notify(item,"No Relations", FALSE);
	} else {
		// Write header for all relations:
		tracerOutput.notify(item,"Relation values", FALSE);
		// Write the relations one by one
		do {
			notifyRelationValues(*i,item);
			i++;
		} while (*i);
//		tracerOutput.notify("", FALSE);
	}
}

void TOMProxyConsole::notifyRelationValues(TOMList* relation,
											const TOMInstance* owner) {
	OMString msg = "Relation ";
	msg += relation->getName();
	if (relation->isEmpty())
		msg +=" Empty\n";
	else {
		msg += ":\n";
		for(OMIterator<TOMInstance *> i(*relation); *i; i++) {
			msg +="\t";
			tominstance2String((*i), msg, owner);
			msg +="\n";
		}
	}
	tracerOutput.notify(msg, FALSE);
}


void TOMProxyConsole::notifyNewName(TOMInstance* item, OMString* oldName) {
	if (oldName) {
		OMString msg = (*oldName) + " Renamed ";
		item->outputFullName(msg);
		tracerOutput.notify(msg);
	}
}

//
//	"call stack notifications"
//
void TOMProxyConsole::notifyMethodCalled(TOMInstance * caller,
										 TOMInstance * called,
										 OMString method,
										 OMMethodType type) {
	CHECK_DOUBLE(notifyMethodCalled);
	// Compose the trace message
	OMString msg;
	// Write header
	localInstance2String(caller, msg);
	msg += " Invoked ";
	if (called!=caller && called!=NULL && type!=omConstructorMethod) {
		tominstance2String(called, msg);
		msg += (char*)tominstance2CallString(called);	// Add either "->" or "::"
	}

	// Write method signature/parameters
	msg += method;

	// output the message
	tracerOutput.notify(msg);
}	



void TOMProxyConsole::notifyMethodReturned(TOMInstance * /* caller */,
										 TOMInstance * called,
										 OMString method,
										 OMMethodType type) {
	CHECK_DOUBLE(notifyMethodReturned);
	// Compose the trace message
	OMString msg;

	// Write header
	if (called!=NULL && type!=omConstructorMethod) {
		tominstance2String(called, msg);
		msg += (char*)tominstance2CallString(called);	// Add either "->" or "::"
	}

	// Write method signature/parameters
	msg += method;

	msg += " Returned";
	// output the message
	tracerOutput.notify(msg);
}
void TOMProxyConsole::notifyFlowDataSend(TOMInstance* sender, char* argName, char* argValue, TOMInstance* identifier)
{
	if(sender != NULL && sender == identifier){
		OMString msg;
		tominstance2String(sender, msg);
		msg += " sends ";
		msg += argValue;
		msg += " via flowport ";
		msg += argName;
		tracerOutput.notify(msg);
	}
}
void TOMProxyConsole::notifyFlowDataReceive(TOMInstance* /* sender */, TOMInstance* receiver, char* argName, char* argValue, TOMInstance* identifier)
{
	// Compose the callstack message
	if (receiver!=NULL && receiver == identifier){
		OMString msg;
		tominstance2String(receiver, msg);
		msg += " receives ";
		msg += argValue;
		msg += " via flowport ";
		msg += argName;
		tracerOutput.notify(msg);
	}
}

void TOMProxyConsole::notifyCallStackValues(OMSData * values) {
	OMString msg;
	TOMSCallStackValues t(values);
	t.method2string(msg);
	tracerOutput.notify(msg, FALSE);
}

void TOMProxyConsole::notifyEventQueueValues(OMSData * values) {
	OMString msg;
	TOMSEventQueueValues t(values);
	t.method2string(msg);
	tracerOutput.notify(msg, FALSE);
}

void TOMProxyConsole::notifyEventQueueNull() {
	OMString msg = "Focus Thread does not have an Event Queue";
	tracerOutput.notify(msg, FALSE);
}

void TOMProxyConsole::printEventEvent(	TOMInstance * i1,
										TOMInstance * i2,
										const char * what,
										OMString event) {
	// Compose the trace message
	OMString msg;

	tominstance2String(i1, msg);

	msg += (char*)what;

	if (i1==i2)
		msg +="itself";
	else
		tominstance2String(i2, msg);

	msg += " Event ";

	// Write method signature/parameters
	msg += event;

	// output the message
	tracerOutput.notify(msg);
}

void TOMProxyConsole::notifyEventSent(TOMInstance * sender,
						 TOMInstance * receiver,
						 OMString event, void*) {
	CHECK_DOUBLE(notifyEventSent);
	printEventEvent(sender, receiver, " Sent to ", event);
}
void TOMProxyConsole::notifyEventReceived(TOMInstance * sender,
							 TOMInstance * receiver,
							 OMString event, void*) {
	CHECK_DOUBLE(notifyEventReceived);
	printEventEvent(receiver, sender, " Received from ", event);
}


void TOMProxyConsole::printTimeoutEvent(TOMInstance * i,
										const char * what,
										OMString event) {
	// Compose the trace message
	OMString msg;

	tominstance2String(i, msg);

	msg += (char*)what;

	// Write method signature/parameters
	msg += event;

	// output the message
	tracerOutput.notify(msg);
}

void TOMProxyConsole::notifyTimeoutSet(TOMInstance * item,
									   OMString event, void*) {
	printTimeoutEvent(item," set ",event);
}
void TOMProxyConsole::notifyEventCancelled(TOMInstance * item,
											 OMString event, void*) {
	printTimeoutEvent(item," cancelled ",event);
}


inline void serializeBreakPoint(OMString& msg, OMNotify theType, TOMProxyItem * theItem, const char *theData) {
	// Make it into a message
	msg += '<';
	msg += (char*)omnotify2String(theType);
	msg += ' ';
	tominstance2String(theItem, msg);
	if (theType!=updatedAttributeValues) {
		msg += ' ';
		msg += (char*)theData;
	}
	msg += '>';
}

void TOMProxyConsole::notifyBreakPointActive(OMNotify theType, TOMProxyItem * theItem, const char *theData) {
	// Make it into a message
	OMString msg;
	msg += "*********************************************\n";
	serializeBreakPoint(msg, theType,theItem,theData);
	msg += " Break point Active";
	msg += "\n*********************************************";
	tracerOutput.notify(msg, FALSE);
}


void TOMProxyConsole::notifyBreakPointValues(TOMBreakPointManager* bpm) {
	OMString msg = "Active Breakpoints\n";
	OMIterator<TOMBreakPoint *> iter;
	// Look for the breakPoint in the activeList
	for(iter.reset(*(bpm->getActiveList()));*iter;iter++) {
		TOMBreakPoint *bp = (*iter);
		msg +="   ";
		serializeBreakPoint(msg, bp->getType(),
							(TOMProxyItem *)bp->getItem(),
							bp->getData());
		msg += '\n';
	}
	// Look for the breakPoint in the frozenList
	msg += "\nFrozen Breakpoints\n";
	for(iter.reset(*(bpm->getFrozenList()));*iter;iter++) {
		TOMBreakPoint *bp = (*iter);
		msg +="   ";
		serializeBreakPoint(msg, bp->getType(),
							(TOMProxyItem *)bp->getItem(),
							bp->getData());
		msg += '\n';
	}
	tracerOutput.notify(msg, FALSE);
}


void TOMProxyConsole::notifyThreadValues(OMList<TOMThread *>*l) {
	TOMThread* focusThread = 
		TOMSystem::threadManagerInstance()->getFocusThread();
	if (focusThread==NULL) {
		// Should never happen
		tracerOutput.notify("Application has no live threads", FALSE);
		return;
	}

	OMString msg = "Live Threads\n";
	for(OMIterator<TOMThread*> i(l); *i; ++i) {
		// Get the therad
		TOMThread* t = (*i);
		// Write if in focus 
		if (t==focusThread)
			msg += " * ";
		else
			msg += "   ";
		// Write the thread name
		t->outputFirstName(msg);
		// Write is active/suspended
		if (t->isSuspended())
			msg += " suspended\n";
		else
			msg += " active\n";
	}
	tracerOutput.notify(msg, FALSE);
}


void TOMProxyConsole::notifyOpCallReply(AnimOpCallReply *reply, OMString& cmdStr, OMString& retValStr, OMBoolean& exception)
{

	if (reply != NULL)
	{
		char* callStr = (char *)(rhp_long64_t)(reply->getCallStr()->getValue());

		AnimStringOrPointerField* retF = reply->getRetValue();

		if (retF->isString()) {
			char *tmp;
			tmp = (char *)(const char *)(retF->getStringValue());
			retValStr = tmp;
			delete[] tmp;
		}
		else {
			gen_ptr aomInstance = retF->getPointerValue();
			if (aomInstance) {
				TOMInstance *tomInstance = (TOMInstance *)TOMSystem::instance()->getInstanceByReal(aomInstance);
				localInstance2String(tomInstance, retValStr);
			}
		}

		exception = (reply->getExceptionRaised()->getValue() != 0);
		
		rhp_long64_t reqID = (rhp_long64_t)(reply->getRequestID()->getValue());
		cmdStr = TOMSystem::instance()->reqIDToCallStr((int)reqID);

		OMString userMsg;
		if (TOMUI::instance()) {
			(void)TOMUI::instance()->checkAndParseForStruct(cmdStr.GetBuffer(0));
		}
		if (!exception) 
		{
			userMsg = cmdStr;
			userMsg += " returned ";
			userMsg += retValStr;
			userMsg += ".";
		}
		else {
			userMsg = "APPLICATION ERROR: An Exception has occured in ";
			userMsg += cmdStr;
			userMsg += " !";
		}

		tracerOutput.notify(userMsg);

		delete[] callStr;
	}

}





void TOMProxyConsole::notifyRawMessage(const char *msg, OMBoolean withCout) {
	tracerOutput.rawOutput(msg,withCout);
}

void TOMProxyConsole::notifyMessage(const char *msg) {
	tracerOutput.notifyMessage(msg);
}


void TOMProxyConsole::notifyCoreAllocation(TOMInstance* caller, int affinity, int powerMode)
{
	OMString msg = "Allocation to core. Affinity: ";
	char affStr[20];
	OMitoa(affinity,affStr,10);
	char pwrStr[20];
	OMitoa(powerMode,pwrStr,10);
	msg += affStr;
	msg += ", Power mode: ";
	msg += pwrStr;
	tracerOutput.notify(caller, msg);
}

void TOMProxyConsole::notifyActionReady(TOMInstance* inst)
{
	if (inst != NULL && tomIsValidItem(inst))
	{
		TOMState* tomState = inst->getState();
		if (tomState != NULL)
		{
			OMString currAction = tomState->getCurrent();
			OMString msg = " Action Ready";
			msg = currAction + msg;
			tracerOutput.notify(inst, msg);
		}
	}
}

void TOMProxyConsole::notifyActionDone(TOMInstance* inst)
{
	if (inst != NULL && tomIsValidItem(inst))
	{
		TOMState* tomState = inst->getState();
		if (tomState != NULL)
		{
			OMString currAction = tomState->getCurrent();
			OMString msg = " Action Done";
			msg = currAction + msg;
			tracerOutput.notify(inst, msg);
		}
	}
}

#ifdef OMANIMATOR
#include "tomExtern.h"
#endif

void tomOutputString(const char * msg)
{
	if (TOMProxyConsole::instance())
		TOMProxyConsole::instance()->notifyMessage(msg);
#ifdef OMTRACER
	else {
		OM_NOTIFY_TO_OUTPUT((char*)msg);
		OM_NOTIFY_TO_OUTPUT((char*)"\n");
	}
#endif
}

void tomSendError(const char * msg) {
#ifdef OMTRACER
	// We send the error to proxyConsole if exists
	if (TOMProxyConsole::instance())
		TOMProxyConsole::instance()->notifyMessage(msg);
	else {
		OM_NOTIFY_TO_ERROR((char*)msg);
		OM_NOTIFY_TO_ERROR((char*)"\n");
	}
#endif
#ifdef OMANIMATOR
	// Send the error to proxyConsole if exists
	// We need this so the message is written in log files
	if (TOMProxyConsole::instance())
		TOMProxyConsole::instance()->notifyMessage(msg);
	// Display the message as a box
	//TOMExterns::Anim()->omErrorMessageBox(msg);
#endif
}

//
// $Log: tommask.cpp $
// Revision 1.91  2007/03/21 14:22:53  ilelpa
// Added a notification for operation call reply
// Revision 1.90  2007/03/11 13:14:43  ilgiga
// Change copyright comment
// Revision 1.89  2007/03/04 15:07:32  ilgiga
// Telelogic instead of i-Logix
// Revision 1.88  2006/04/06 14:23:42  yzharkovsky
// Fix for Linux compilation error.
// Revision 1.87  2006/04/04 13:55:19  yzharkovsky
// Multi language refactoring:
// isLang static calls were changed to context related calls.
// Revision 1.86  2005/08/23 14:50:44  amos
// bugfix 85444 to main branch
// Revision 1.85.1.2  2005/08/22 10:05:40  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.85  2005/04/21 10:34:33  amos
// Revision 1.84.1.2  2005/04/18 10:20:32  amos
// Replace include file in the oxf
// Revision 1.84.1.1  2004/06/27 15:30:17  amos
// Duplicate revision
// Revision 1.83.1.2  2004/02/09 09:00:37  amos
// changes due to OMBoolean type change
// Revision 1.83.1.1  2002/07/29 09:26:39  amos
// Duplicate revision
// Revision 1.82  2002/07/15 12:29:32  avrahams
// Back to main
// Revision 1.81.1.2  2002/07/04 11:13:35  avrahams
// Cleanup std namespace usage
// Revision 1.81.1.1  2001/11/12 10:49:19  avrahams
// Duplicate revision
// Revision 1.81.2.1  2002/07/29 09:24:02  Eldad
// Revision 1.81  2001/11/12 10:49:19  Eldad
// #ifdef OMTRACER for warning.
// Revision 1.80  2001/10/01 10:22:12  Eldad
// 1.79.1.2 to main branch.
// Revision 1.79.1.2  2001/09/26 00:48:43  Eldad
// Changed some of the erros to warnings that are not to be shown in popup 
// message box.
// Revision 1.79.1.1  2001/08/23 09:30:56  Eldad
// Duplicate revision
// Revision 1.78  2001/05/16 12:32:37  amos
// merge OSE 4.3.1 support into r40
// Revision 1.77  2001/01/25 13:58:26  avrahams
// OXF globals encapsulation
// Revision 1.76  2000/12/25 10:39:51  amos
// move to warning level 4
// Revision 1.75.1.4  2001/06/14 16:04:19  Eldad
// Avoiding the mask changes in Tracer.
// Revision 1.75.1.1  2001/05/02 12:46:47  amos
// comment statements aftert #endif
// Revision 1.75  2000/09/06 15:46:31  ofer
// using NOTIFY_TO_ERROR instead of cerr
// psos cadul compiler does not recognize cerr
// Revision 1.74  2000/08/06 07:44:11  amos
// merge 1.72.1.2 (36668,36667) into 1.73
// Revision 1.73  2000/05/26 06:51:31  yachin
// Remove DLL dependencies
// Revision 1.72.1.2  2000/07/19 13:24:43  beery
// Comply with Solaris strict checking of assign "" to char*
// Revision 1.72.1.1  2000/07/12 06:54:23  amos
// changes related to modify char* to const char*.
// Revision 1.72  1999/10/12 13:33:02  yachin
// Fix bugs
// Revision 1.71  1999/10/11 09:40:15  yachin
// Fix regression classses/object types
// Revision 1.70  1999/10/10 12:53:08  yachin
// class to object_Type in case of RiC
// Revision 1.69  1999/09/22 16:29:27  yachin
// Restore the removed revision
// Revision 1.69  1999/09/15 05:54:17  yachin
// Tracer starts with attribute 'on' (bug #32100)
// Revision 1.68  1999/09/08 10:58:32  yachin
// Fix bugs 31581,31662,31958
// Revision 1.67  1999/02/25 07:20:08  yachin
// Revision 1.66  1999/02/24 09:17:56  yachin
// Revision 1.65  1999/02/16 05:56:57  yachin
// Speed up of constructors
// Revision 1.64  1999/02/12 11:09:40  beery
// Revision 1.63  1999/02/09 06:19:52  amos
// safe programming
// --- Added comments ---  amos [1999/02/10 12:40:36 GMT]
// back to main branch
// Revision 1.62.1.2  1999/02/04 16:39:16  amos
// safe programming
// Revision 1.62  1998/08/02 15:07:43  beery
// Revision 1.61  1998/05/21 11:24:06  yachin
// Fix bug 5603 (have getPackage return a TOMPackage and not a TOMProxyItem)
// Revision 1.60  1997/08/13 10:08:18  yachin
// correct syntax error for vxworks
// Revision 1.59  1997/08/05 17:13:45  yachin
// When no exceptions the default mask is without attributes
// Revision 1.58  1997/07/20 11:36:36  yachin
// Adding globals to animation
// Revision 1.57  1997/04/30 10:57:21  yachin
// small bug fix
// Revision 1.56  1997/02/26 06:42:10  yachin
// Add mutex on TOMOutput
// Revision 1.55  1997/02/21 08:56:42  yachin
// Added show #all events
// Revision 1.54  1997/02/18 11:30:48  yachin
// Bug fixes
// Revision 1.53  1997/02/16 09:29:06  yachin
// remove theClass parameter from instanceCreated/delted notifies.
// make inverseRelationConnect cascade from relations and not the createObserver
// Revision 1.52  1997/02/11 12:54:36  yachin
// Adding Name spaces
// Revision 1.51  1997/02/05 13:38:52  yachin
// Bug fixes
// Revision 1.50  1997/01/27 09:41:54  yachin
// Enter foreign threads
// Revision 1.49  1997/01/21 10:52:48  yachin
// User Threads part I
// Revision 1.48  1997/01/19 07:37:48  yachin
// Multi-threading addenda
// Revision 1.47  1997/01/14 13:52:44  yachin
// Revision 1.46  1997/01/14 09:06:08  yachin
// Revision 1.45  1997/01/13 11:38:58  yachin
// Make constructor/destructor mult=2 notifications
// Revision 1.44  1997/01/01 13:40:47  yachin
// Revision 1.43  1996/12/30 09:56:46  yachin
// Multi Thread support part III
// Revision 1.42  1996/12/26 09:48:43  yachin
// Revision 1.41  1996/12/23 11:51:08  yachin
// Add ids to events
// Revision 1.40  1996/12/22 13:13:52  yachin
// Revision 1.38  1996/12/22 09:03:24  yachin
// Has composite notify componentes abou tits new name
// Revision 1.37  1996/12/09 12:13:17  yachin
// Revision 1.36  1996/12/03 07:12:34  yachin
// Fixed "triggered op/notify behavior step" bug
// Revision 1.35  1996/11/27 10:00:11  yachin
// Revision 1.34  1996/11/24 12:40:39  yachin
// Revision 1.33  1996/11/05 07:54:37  yachin
// Revision 1.32  1996/11/05 07:20:17  yachin
// Fixed crash in "end animation"
// Revision 1.31  1996/10/29 13:21:34  yachin
// Revision 1.30  1996/10/23 10:10:03  yachin
// Revision 1.29  1996/10/22 12:04:59  yachin
// Revision 1.28  1996/10/22 08:15:38  yachin
// tomConsole now registers on breakpoint manager by name
// Revision 1.27  1996/10/21 11:39:25  yachin
// Cleanup on state notifies + fixes on timeouts + support for breakpoints
// Revision 1.26  1996/10/14 13:26:19  yachin
// Handle sub classes and set/cancel timeout
// Revision 1.25  1996/10/10 08:01:25  yachin
// Revision 1.24  1996/10/09 07:37:07  yachin
// Revision 1.23  1996/10/02 13:55:48  yachin
// Fix the double event bug
// Revision 1.22  1996/10/01 13:07:18  yachin
// Fix bug in ~proxyConsole
// Revision 1.21  1996/09/26 10:57:56  yachin
// Revision 1.20  1996/09/26 09:01:48  yachin
// Fix bug wiht interest masks
// Change instance count to star tat 0
// Revision 1.19  1996/09/25 10:01:24  yachin
// notifyEventQueueValues added + assorted bug fixes
// Revision 1.18  1996/09/24 13:56:29  yachin
// Revision 1.17  1996/09/24 07:33:56  yachin
// Bug fixes + single thread AOM
// Revision 1.16  1996/09/18 13:00:48  yachin
// Revision 1.15  1996/09/17 13:43:00  yachin
// Revision 1.14  1996/09/16 12:44:42  ofer
// deregistration changed to allow non closed ostreams
// like we are using in o-mate (output window)(tommask.cpp/h)
// Revision 1.13  1996/09/16 09:28:32  yachin
// Revision 1.12  1996/09/08 13:28:57  yachin
// Registeration of items which do not yet exist
// Revision 1.11  1996/09/05 13:35:56  yachin
// Revision 1.10  1996/09/04 13:16:10  yachin
// Connect with Israel
// Revision 1.9  1996/09/03 12:01:15  yachin
// Alow show #callStack
// Revision 1.8  1996/08/28 10:13:58  ofer
// Revision 1.7  1996/08/14 12:40:24  yachin
// Seperate TOM Masks from AOM Masks. Fix bugs with attr. and states
// Revision 1.6  1996/08/12 12:28:48  yachin
// Unified Interface for "file" and "stdin". seperated show from trace
// Revision 1.5  1996/08/06 12:52:06  yachin
// Version for Prototype 4
// Revision 1.4  1996/07/22 11:30:30  yachin
// Revision 1.3  1996/07/10 05:50:09  yachin
// Reprecussion of reorganizatio nof AOM
// Revision 1.2  1996/06/20 10:23:09  yachin
// Revision 1.1  1996/06/19 10:20:44  yachin
// Initial revision
// Revision 1.1  1996/06/17 05:40:39  yachin
// Initial revision
//
