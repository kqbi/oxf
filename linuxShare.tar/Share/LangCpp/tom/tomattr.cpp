#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomattr.cpp 1.24 2007/03/11 13:14:41 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomattr.cpp $
//	file version:	$Revision: 1.24 $
//
//	purpose: Methods of Class TOMAttr	 	
//
//	author(s):		Yachin Pnueli
//	date started:	28.7.96
//	date changed:	$Date: 2007/03/11 13:14:41 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "tomattr.h"
#include "tommsg.h"

class TOMAttributeCItem: public TOMAttributeItem  {
public:
	virtual ~TOMAttributeCItem() { delete [] (char *)attrValue; }
	TOMAttributeCItem(char * name, char * value):
		TOMAttributeItem(name,value) { }
	virtual void getValue(OMString & s, 
			  const TOMProxyItem * /* context */ = OMSystemContext) const {
		s += (char *)attrValue;
	}
};

class TOMAttributePItem: public TOMAttributeItem {
public:
	TOMAttributePItem(char * name, void * value):
	  TOMAttributeItem(name,value) { }
	void getValue(OMString & s, 
			  const TOMProxyItem * context=OMSystemContext) const {
		tominstance2String((TOMProxyItem *)attrValue, s, context);
	}
};

// The factory
inline TOMAttributeItem *makeAttributeItem(TOMSData& s, OMSPosition& p)
{
	OMString errMsg;
	TOMAttributeItem *item = NULL;
	// Read Attribute name
	OMSPosition oldp = p;
	char *name = s.safeGetChar(p);

	// Check correctness
	if (oldp==p || name[0] == '\0') {
		missingError(errMsg, "Name", oldp);
	} else if (s.isStringOrPointer(errMsg,p)) {	// Read the value
		oldp = p;
		if (s.isString(p))
			item = new TOMAttributeCItem(name, s.getChar(p));
		else if (s.isPointer(p))
			item = new TOMAttributePItem(name, s.getPointer(p));
		// Check that we read successfully
		if (p==oldp) {
			missingError(errMsg, (char *)("Value"), oldp);
			delete item;
			item = NULL;
		}
	}
	if (item==NULL)
		tomSendError(errMsg);
	return item;
}


TOMAttributes::~TOMAttributes() {
	// Clear the change list - Note we do not delete entries as they
	// are referenced in "this" too
	changeList.removeAll();
	// Delete my entries
	for(OMIterator<TOMAttributeItem *> il(this); *il; ++il)
		delete (*il);

	// Empty myself - redundent as we inherite from OMList
	// removeAll();
}


void TOMAttributes::updateAttributeValues(TOMSData* s,
										  OMSPosition p) {
	// Clear the change list
	// Note we do not "delete" the entries since these are 
	// referenced in "this" too
	changeList.removeAll();

	if (attrs == *s) return;	// Nothing more to do

	// From here on we know we have changes
	// 1.Copy myself to oldList
	OMList<TOMAttributeItem *> oldList;
	for(OMIterator<TOMAttributeItem *> il(this); *il; ++il)
		oldList.add(*il);

	// 2. Empty myself
	removeAll();

	// 3. Make "my" new list
	newAttributeValues(s, p);

	// 4. Compare new list with old list to make change list
	OMString errMsg;
	OMIterator<TOMAttributeItem *> nl(this);
	OMIterator<TOMAttributeItem *> ol(oldList);
	for(; *ol && *nl;
			++nl, ++ol) {
		// Compare names
		if (strcmp((*ol)->getName(),(*nl)->getName())) {
			// items differ in name
			lostSyncError(errMsg,p);
			errMsg += "Attributes differ in Name ";
			errMsg += (*ol)->getName();
			errMsg += " verses ";
			errMsg += (*nl)->getName();
			tomSendError(myInstance,errMsg);
			return;
		}

		// Compare values
		OMString s1,s2;
		(*ol)->getValue(s1);
		(*nl)->getValue(s2);
		if (s1!=s2) changeList.add((*nl));
	}

	// Make sure we have the same number of entries
	if (*nl || *ol)	 {
		errMsg = "Bad Attribute message unequal number of elements";
		tomSendError(myInstance, errMsg);
	}

	// remove all entries from oldList and delete them as well
	for(ol.reset(oldList); *ol; ++ol)
		delete (*ol);
	oldList.removeAll();
}

void TOMAttributes::newAttributeValues(TOMSData* s, OMSPosition p) {
	// Clear the attribute list
	removeAll();
	// Update attr (the message)
	attrs = *s;
	// Analyze the message
	int count = attrs.safeGetInt(p);

	for(int i=0;i<count;i++) {
		// Read item
		TOMAttributeItem * item = makeAttributeItem(attrs,p);
		// If o.k. add to list else quit
		if (item)
			add(item);
		else
			return;
	}
}

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomattr_H;
#endif


//
// $Log: tomattr.cpp $
// Revision 1.24  2007/03/11 13:14:41  ilgiga
// Change copyright comment
// Revision 1.23  2007/03/04 15:07:29  ilgiga
// Telelogic instead of i-Logix
// Revision 1.22  2005/08/23 14:50:41  amos
// bugfix 85444 to main branch
// Revision 1.21.1.2  2005/08/22 10:05:38  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.21  2000/12/25 10:18:24  amos
// move to warning level 4
// Revision 1.20  2000/07/19 13:24:45  beery
// Comply with Solaris strict checking of assign "" to char*
// Revision 1.19  2000/07/12 06:54:23  amos
// changes related to modify char* to const char*.
// Revision 1.18  1999/02/22 09:15:31  nirit
// bug in MKS ???
// Revision 1.17  1999/02/16 05:56:51  yachin
// Speed up of constructors
// Revision 1.16  1997/06/09 09:14:53  nili
// define variables out of the for-loop block
// since it is used after the for-loop 
// tomattr.cpp tomobs.h tomstep.cpp
// Revision 1.15  1997/02/26 07:58:00  yachin
// modified x2String to take 2 parameters
// Revision 1.14  1996/11/24 12:40:34  yachin
// Revision 1.13  1996/10/10 08:01:23  yachin
// Revision 1.12  1996/10/10 06:15:10  yachin
// Revision 1.11  1996/10/09 07:37:04  yachin
// Revision 1.10  1996/10/02 13:55:46  yachin
// Fix the double event bug
// Revision 1.9  1996/09/30 10:05:27  yachin
// Revision 1.8  1996/09/26 13:46:29  yachin
// Currently states/attributes alway ask aom for show
// Revision 1.7  1996/09/16 09:31:33  yachin
// Revision 1.6  1996/09/16 09:28:28  yachin
// Revision 1.5  1996/09/08 13:28:54  yachin
// Registeration of items which do not yet exist
// Revision 1.4  1996/08/29 11:37:14  ofer
// Revision 1.3  1996/08/14 12:40:23  yachin
// Seperate TOM Masks from AOM Masks. Fix bugs with attr. and states
// Revision 1.2  1996/08/06 12:55:55  yachin
// Revision 1.1  1996/08/06 12:53:22  yachin
// Initial revision
//
