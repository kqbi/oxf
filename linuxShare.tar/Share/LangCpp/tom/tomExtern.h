#ifndef tomExtern_H
#define tomExtern_H "$Id: tomExtern.h 1.6 2007/03/11 13:14:40 ilgiga Exp $"

//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomExtern.h $
//	file version:	$Revision: 1.6 $
//
//	purpose:	Define external (gemdi) interfaces tom needs
//				Here solely to remove loops
//
//	author(s):	Yachin Pnueli
//	date started:	13.4.2000
//	date changed:	$Date: 2007/03/11 13:14:40 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2000, 2008. All Rights Reserved.
//
#ifdef OMANIMATOR
#include "toxf.h"

class TOMInstance;
class TOMProxyItem;

class RP_ANIM_DLL TOMExterns {
protected:
	static TOMExterns* _theExterns; // implemented in tomstep.cpp
public:
	static TOMExterns* Anim() { return  _theExterns; }
	virtual int omAnimSendMessage( const char* lpBuf, int nBufLen)=0;
	virtual void omErrorMessageBox(const char * msg)=0;
	virtual void omAnimationStart()=0;
	virtual void SetActualSocket(void* a_pActualSocket)=0;
	virtual OMString GetAppNameBySocket(void* a_pSocket)=0;
	virtual void* GetActiveSocket()=0;
	virtual OMString GetActiveAppName()=0;
	virtual BOOL IsInExtendedExecutionModel()=0;
	virtual BOOL ForceOpReturnOnPackage() = 0;
	virtual BOOL IsLangJava() = 0;
	virtual char* AddProjectDirIfNeeded(char*& file) = 0;
	virtual gen_ptr GetCoreClassByName(char* className, TOMProxyItem* item) = 0;
	virtual void OpenAnimatedViewIfNeeded(OMHandle* actionName, TOMInstance* pTomInst) = 0;
	virtual BOOL ShouldAutoOpenBehavioralDiagrams() = 0;
	virtual void notifyNewItem(TOMInstance* pTomInst) = 0;
};
#endif // OMANIMATOR
//
// $Log: tomExtern.h $
// Revision 1.6  2007/03/11 13:14:40  ilgiga
// Change copyright comment
// Revision 1.5  2007/03/04 15:07:29  ilgiga
// Telelogic instead of i-Logix
// Revision 1.4  2007/01/16 11:05:00  ilchco
// fixed potentional crash when getting name of application.
// Revision 1.3  2006/10/31 08:58:50  ccohen
// support running multiple animation processes.
// Revision 1.2  2001/05/02 12:46:46  amos
// comment statements aftert #endif
// Revision 1.1  2000/05/26 19:57:13  yachin
// Initial revision
//

#endif // tomExtern_H
