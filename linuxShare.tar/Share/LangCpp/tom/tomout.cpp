#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomout.cpp 1.41 2007/03/11 13:14:44 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomout.cpp $
//	file version:	$Revision: 1.41 $
//
//	purpose: Global Instance + Methods of Class TOMTracerOutput	 	
//
//	author(s):		Yachin Pnueli
//	date started:	22.5.96
//	date changed:	$Date: 2007/03/11 13:14:44 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include <tom/toxf.h>

#ifdef OM_STL
#include <fstream>
#include <cstdio>
#else
#include <fstream.h>
#include <stdio.h>
#endif

#include "tomout.h"
#include "tomother.h"
#include "tomdisp.h"

#ifdef OMTRACER
#include <oxf/os.h>
#ifdef RIC_APP
// *** force definition if need to (psosx86) ***
#ifndef TRUE 
#define TRUE 1
#endif
#ifndef FALSE 
#define FALSE 0
#endif
// ***********
#endif
#endif

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomout_H;
#endif

#ifdef OMTRACER
#define OMTRACER_HEADER		"OMTracer"
#define ALTERNATIVE_HEADER	"         "
#else
#define OMTRACER_HEADER		""
#define ALTERNATIVE_HEADER	""
#endif

OMBoolean TOMTracerOutput::mayOutput;
OMString TOMTracerOutput::buffer;

// Lock unlock
#ifdef OMTRACER
OMOSMutex* TOMTracerOutput::mutex=NULL;
#define LOCK_OUTPUT { \
	if (mutex==NULL) mutex = OMOSFactory::instance()->createOMOSMutex();	\
	mutex->lock();												\
}
#define FREE_OUTPUT mutex->unlock();

#else
#define LOCK_OUTPUT
#define FREE_OUTPUT

#endif

void TOMTracerOutput::deregisterItem(omostream *s,
									 OMBoolean toDelete /*=TRUE*/) { 
	if (toDelete) {
		((omofstream *)s)->close();
		delete s;
	} else
		(*s)<<omflush;
	outList.remove(s);
}

TOMTracerOutput::~TOMTracerOutput() {
	for(OMIterator<omostream *> i(outList); *i; i++)  {
		omofstream * s  = (omofstream *)(*i);
		s->close();
		delete s;
	}
	outList.removeAll();
}


void TOMTracerOutput::rawOutput(const char * msg, OMBoolean withCout) {
	for(OMIterator<omostream *> i(outList); *i; i++)
		if (withCout || ( *i != &omcout) )
			(*(*i))<<msg<<omflush;
}

inline void TOMTracerOutput::output(const char * msg) {
	if (mayOutput) {
		for(OMIterator<omostream *> i(outList); *i; i++)
			(*(*i))<<msg;
	} else {
		buffer += (char*)msg;
	}
}

void TOMTracerOutput::allowOutput() {
	// flush the buffer
	rawOutput(buffer.GetBuffer(0));
	buffer = "";
	// Free the "semaphore"
	mayOutput = TRUE;
}

void TOMTracerOutput::disallowOutput() {
	if (mayOutput) {
		mayOutput = FALSE;
	} else {
		tomSendError("Attempting to freeze output while line is busy");
	}
}

void TOMTracerOutput::output(const TOMProxyItem * item) {
	OMString s;
	item->outputFullName(s);
	s += " ";
	output(s.GetBuffer(0));
}

void TOMTracerOutput::endOutput() {
	if (mayOutput) {
		for(OMIterator<omostream *> i(outList); *i; i++) {
			(*(*i))<<'\n'<<omflush;
		}
	} else {
		buffer += '\n';
	}
}

inline void TOMTracerOutput::printHeader(OMBoolean withHeader,
										 OMBoolean withIndent) {
	// alternative has a space for each char of the real header
	if (withHeader)
		actuallyPrintHeader();
	else
		output(ALTERNATIVE_HEADER);
	if (withIndent)
		output(TOMCallStack::getIndentation());
}

void TOMTracerOutput::outputString(const char *msg, 
								   OMBoolean withIndent) {
	// Output a message with correct indentations after "\n";
	// *msg is decomposed into
	// prefix - the part until the first "\n"    and
	// suffix - the part after the first "\n"
	// Prefix is printed "as is"
	// if there is a suffix the "context" for it is created
	// and outputString is called for it again
	char * newLine = strchr((char *)(msg),'\n');
	if (newLine!=NULL) {
		newLine[0] = '\0';	// Replace the '\n' with '\0'
		output(msg);		// Now this outputs only the prefix
		newLine[0] = '\n';	// Return the '\n' instead of '\0'
		// Prepare the context of the suffix
		output("\n");
		printHeader(FALSE,withIndent);
		// Output the suffix - note that it starts one position after the \n
		outputString(newLine+1,withIndent);
	} else	// message is all prefix
		output(msg);
}

void TOMTracerOutput::notify(const char *msg,
							 OMBoolean withIndent) {
	LOCK_OUTPUT;
	printHeader(TRUE, withIndent);
	outputString(msg,withIndent);
	endOutput();
	FREE_OUTPUT;
}

void TOMTracerOutput::notifyMessage(const char *msg) {
	LOCK_OUTPUT;

	output(msg);
	endOutput();
	FREE_OUTPUT;
}

void TOMTracerOutput::notify(const TOMProxyItem *p,
							 const char *msg, 
							 OMBoolean withIndent) {
	LOCK_OUTPUT;
	printHeader(TRUE, withIndent);
	output(p);
	outputString(msg,withIndent);
	endOutput();
	FREE_OUTPUT;
 }



void TOMTracerOutput::actuallyPrintHeader() {
	output(OMTRACER_HEADER);
	if (mask.withNothing()) {
		output(" ");
		return;
	}

	output(" (");

	// get the message time
	timeUnit elapsed = TOMDispatcher::instance()->getMsgTime();

	// formated time format
	if (mask.withFormattedTime()) {
		static char buf[64];
		// Print elapsed time
		unsigned int ms = elapsed % 1000;
		elapsed /= 1000;
		unsigned int ss = elapsed % 60;
		elapsed /= 60;
		unsigned int mm = elapsed % 60;
		elapsed /= 60;
		unsigned int hh = elapsed;
		sprintf(buf,"%0d:%02d:%02d.%03d",hh,mm,ss,ms);
		output(buf);
	}
	// raw time format
	if (mask.withRawTime()) {
		static char buf[64];
		// Print elapsed time
		OMitoa(elapsed,buf,10);
		output(buf);
	}

	
	output(") ");
}

#ifdef tomout_Debug

void main() {
}
#endif


//
// $Log: tomout.cpp $
// Revision 1.41  2007/03/11 13:14:44  ilgiga
// Change copyright comment
// Revision 1.40  2007/03/04 15:07:35  ilgiga
// Telelogic instead of i-Logix
// Revision 1.39  2005/08/23 14:50:46  amos
// bugfix 85444 to main branch
// Revision 1.38.1.2  2005/08/22 10:05:41  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.38  2002/07/23 11:11:31  amos
// replace include to omiotypes with include to toxf.h in order to set the OMMATE define.
// Revision 1.37  2002/07/15 12:29:32  avrahams
// Back to main
// Revision 1.36.1.2  2002/07/04 11:16:44  avrahams
// Cleanup the std namespace usage
// Revision 1.36.1.1  2001/05/16 08:11:54  avrahams
// Duplicate revision
// Revision 1.36  2001/05/16 08:11:54  amos
// merge OSE 4.3.1 support into r40
// Revision 1.35  2001/01/25 13:58:27  avrahams
// OXF globals encapsulation
// Revision 1.34  2000/07/19 13:24:41  beery
// Comply with Solaris strict checking of assign "" to char*
// Revision 1.33  2000/07/12 06:54:24  amos
// changes related to modify char* to const char*.
// Revision 1.32  2000/01/31 09:51:49  amos
// back to main branch
// Revision 1.31.1.2  2000/01/27 09:38:07  amos
// remove the #ifdef OMTRACER in the time stamp printing (TOMTracerOutput::actuallyPrintHeader())
// get the time in TOMTracerOutput::actuallyPrintHeader() from TOMDispatcher::instance()->getMsgTime() instead of theSysTimer, that is not avalible in animation
// Revision 1.31.1.1  1999/09/22 09:33:44  amos
// Duplicate revision
// Revision 1.30.1.1  1999/09/16 17:00:58  amos
// changes to support link omtraceRiC in psosX86
// Revision 1.30  1999/08/16 06:14:34  beery
// access RiC's timer
// Revision 1.29  1999/08/11 17:03:14  beery
// adding timestamp in tracer mode
// Revision 1.28  1999/02/16 05:56:59  yachin
// Speed up of constructors
// Revision 1.27  1998/08/02 15:06:34  beery
// changing boolean->OMBoolean
// Revision 1.26  1998/04/13 07:40:59  ofer
// added "using namespace std;" after each include to stl files
// Revision 1.25  1998/04/12 12:17:45  ofer
// Change includes to Stl format ifdefed by OM_USE_STL
// Revision 1.24  1997/06/09 09:16:27  nili
// 1)define variables out of the for-loop block
//  cast const msg to (char *) ( usend by strstr)
//      fix msg to its original value (toomout.cpp
// 
//      
// Revision 1.23  1997/04/09 12:11:02  ofer
// vxworks env does not have the file sys/timeb.h
//  remove includes to time.h timeb.h and so on 
// tomout.cpp
// Revision 1.22  1997/02/26 06:42:12  yachin
// Add mutex on TOMOutput
// Revision 1.21  1997/02/12 06:11:21  yachin
// Fixes for Unix proting
// Revision 1.20  1997/02/05 13:38:53  yachin
// Bug fixes
// Revision 1.19  1997/02/05 07:09:29  yachin
// Fix Unix port bug
// Revision 1.18  1997/01/19 07:37:49  yachin
// Multi-threading addenda
// Revision 1.17  1996/11/24 12:40:43  yachin
// Revision 1.16  1996/11/05 07:20:18  yachin
// Fixed crash in "end animation"
// Revision 1.15  1996/10/10 08:01:27  yachin
// Revision 1.14  1996/10/01 13:07:19  yachin
// Fix bug in ~proxyConsole
// Revision 1.13  1996/09/25 10:01:26  yachin
// notifyEventQueueValues added + assorted bug fixes
// Revision 1.12  1996/09/17 13:43:01  yachin
// Revision 1.11  1996/09/16 12:50:28  ofer
// deregistration changed to allow non closed ostreams
// like we are using in o-mate (output window)(tomout.cpp/h)
// Revision 1.10  1996/09/04 13:16:12  yachin
// Connect with Israel
// Revision 1.9  1996/08/28 05:38:02  ofer
// Revision 1.8  1996/08/12 12:28:49  yachin
// Unified Interface for "file" and "stdin". seperated show from trace
// Revision 1.7  1996/08/07 05:29:27  yachin
// Link fix
// Revision 1.6  1996/08/06 12:52:08  yachin
// Version for Prototype 4
// Revision 1.5  1996/07/22 11:30:32  yachin
// Revision 1.4  1996/07/03 12:45:52  yachin
// Fixing bugs for "const" and "static
// enhancements for attributes and indentation
// Revision 1.3  1996/06/26 12:45:59  yachin
// Put header message and fix some bugs
// Revision 1.2  1996/06/19 10:21:31  yachin
// Revision 1.1  1996/06/17 05:40:49  yachin
// Initial revision
//
