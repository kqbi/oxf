#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomoperation.cpp 1.10 2007/03/11 13:14:44 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomoperation.cpp $
//	file version:	$Revision: 1.10 $
//
//	purpose: Methods of Class TOMAttr	 	
//
//	author(s):		Eldad Palachi
//	date started:	17.7.02
//	date changed:	$Date: 2007/03/11 13:14:44 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "tomoperation.h"
#include "tomclass.h"


#include <omcom/AnimStringField.h>
#include <omcom/AnimPointerField.h>
#include <omcom/AnimBooleanField.h>
#include <omcom/AnimIntField.h>
#include <omcom/AnimOperationData.h>



TOMOperation::TOMOperation(AnimOperationData *opData, TOMClass *cls) : 
TOMProxyItem((char *)"")
{
	if (opData != NULL)
	{
		myReal = opData->getDestOrSource()->getValue();
		char *tmp = NULL;
		
		tmp = (char *)(rhp_long64_t)(opData->getOpName()->getValue());
		opName = (OMString)((char*)tmp);
		delete[] tmp;

		isStatic = (opData->getIsStatic()->getValue() != 0);

		tmp = (char *)(rhp_long64_t)(opData->getSignature()->getValue());
		signature = (OMString)((char*)tmp);
		delete[] tmp;

		removeBlanksFromSignature();
		rhp_long64_t lNum = (rhp_long64_t)(opData->getNumOfArgs()->getValue());
		numOfArgs = (int)lNum;
	}
	else {
		OMString msg = "Illegal operation data received";
		tomSendWarning(msg);
	}
	setMyClass(cls);

}


void TOMOperation::removeBlanksFromSignature()
{
	
	if (signature.IsEmpty() == FALSE) 
	{
		OMString newSignature;
		char *c = signature.GetBuffer(0);
		size_t len = strlen(c);
		size_t i;
		for (i=0; i<len; ++i) {
			while ((*c)!='\0' && isspace(*c)) { c++; i++; }
			if ((*c) != '\0') {
				newSignature += *c;
				c++;
			}
		}
		signature = newSignature;
	}
}

void TOMOperation::setMyClass(TOMClass *cls)
{
	myClass = cls;
}

OMBoolean TOMOperation::match(const OMString& i_opName, const int i_numOfArgs, 
	const OMString& i_signature)
{

	OMBoolean res = FALSE;

	if (((i_signature.IsEmpty()) || (i_signature == this->signature)) && 
		(i_numOfArgs == this->numOfArgs) && (i_opName == this->opName))
	{

		res = TRUE;
	}
	return res;
}

