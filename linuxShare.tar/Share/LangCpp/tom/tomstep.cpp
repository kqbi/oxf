#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomstep.cpp 1.137 2007/05/29 12:01:53 ilelpa Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomstep.cpp $
//	file version:	$Revision: 1.137 $
//
//	purpose:	Implement the TOMStepper, TOMUI and TOMExterns classes
//
//	author(s):		Yachin Pnueli
//	date started:	30.7.96
//	date changed:	$Date: 2007/05/29 12:01:53 $
//	last change by:	$Author: ilelpa $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1996, 2008. All Rights Reserved.
//

#include <stdio.h> 
#include "tomstep.h"
#include <omcom/om2str.h>
#include "tomstr.h"
#include "tomsys.h"
#include "tomthrd.h"
#include "tommsg.h"
#include "tommask.h"
#include "tomdisp.h"
#include "tominst.h"
#include "tomclass.h"
#include "tomobs.h"
#include "tombrk.h"
#include "tomoperation.h"
#include "toxf.h"

#ifdef OM_STL
#include <fstream>
#else
#include <fstream.h>
#endif
#include <omcom/omexp.h>

#ifdef OM_NEED_GETENV
// to get the environment variable in notifySingleStep()
#include <stdlib.h>
#include <string.h>
#endif // OM_NEED_GETENV

#include <omcom/AnimListField.h>
#include <omcom/AnimOpCallRequest.h>
#include <omcom/AnimTimeRequest.h>

#ifdef OMANIMATOR
#include "tomExtern.h"
#endif // OMANIMATOR

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomstep_H;
#endif

const char * TOMUI::tomSearchPathEnvVarName = "TOMPATH";


#define OMNullPosition 0
//
//	 TOMStepper Methods
//

void TOMStepper::_showYourself(TOMUniversalObserver*,
								  int& theMask) {
	// Currently nothing to show
	theMask=OMNoInterest;
}

TOMStepper* TOMStepper::getCurrentStepper() {
	TOMThread* focusT =TOMSystem::threadManagerInstance()->getFocusThread();
	if (focusT)
	{
		return focusT->getStepper();
	}
	else
	{
		return 0;
	}
}

void TOMStepper::handleMessage(OMNotify msgCode,
								  TOMSData*,
								  OMSPosition) {
	// Perform the operation appropriate to this message code
	switch (msgCode) {
	case stoppedForStep:
//		if (TOMProxyConsole::instance())
//			TOMProxyConsole::instance()->notifyMessage(
//				" Executable step completed");
		break;
	case stoppedForEvent:
		if (TOMProxyConsole::instance())
			TOMProxyConsole::instance()->notifyMessage(
				" Executable about to poll the event queue");
		break;
	case stoppedForBreakpoint:
		// A stepper which stopped makes its thread the current thread
		TOMSystem::threadManagerInstance()->setFocusThread(this);
		if (TOMProxyConsole::instance())
			TOMProxyConsole::instance()->notifyMessage(
				" Executable reached breakpoint");
		break;
	case stoppedForIdle:
		if (TOMProxyConsole::instance())
			TOMProxyConsole::instance()->notifyMessage(
				" Executable is Idle");
		TOMSystem::instance()->notifyApplicationIdle();
		break;
	case stoppedForAction:
		break;
	default: notifyUnexpectedMessage(msgCode);
	}
}



//
//	 TOMUI Methods
//
static OMString errMsg;

TOMUI::TOMUI()
{ 
  myState = waitForStart; 
  _needRefresh = FALSE; 
  logCmdFilePtr = NULL;
  logCmdFileName[0] = '\0';
}



TOMUI::~TOMUI() {
	recordCommandsOff();
	clearAllInputs();
	_instance = NULL;
}

void TOMUI::clearAllInputs() {
	for(OMIterator<omistream *> i(inputs); *i; ++i) {
		omistream* s =(*i);
//		s->close();
		delete s;
	}
	while (inputs.top()!=NULL)
		inputs.pop();
}

#ifdef OM_STL
#ifndef OM_STD_IFSTREAM_CREATION
#define OM_STD_IFSTREAM_CREATION
#endif // OM_STD_IFSTREAM_CREATION
#endif // OM_STL

#ifdef OM_STD_IFSTREAM_CREATION
// unix || QNX || _INTEGRITY
#define IOS_NO_CREATE
#else
#define IOS_NO_CREATE ,ios::nocreate
#endif // OM_STD_IFSTREAM_CREATION

OMBoolean TOMUI::setInput(const char * filename, 
					 OMBoolean withMessage, 
					 OMBoolean replace,
					 const char* path)
{
	char fname[256];
	strcpy(fname, "");
	if ((path != NULL) && (*path != (char)NULL)) {
		strcpy(fname, path);
	}
	else {
		char* tmpFilename = (char*)filename;
		char* newFileName = NULL;
#ifdef OMANIMATOR
	if(TOMExterns::Anim())
		newFileName = TOMExterns::Anim()->AddProjectDirIfNeeded(tmpFilename);
#endif
		if (newFileName != NULL)
		{
			strcat(fname, newFileName);
			delete newFileName;
		}
		else
		{
			strcat(fname, tmpFilename);
		}
	}

	//Some OS fail to open file when last character in its name is carriage return.
	tomTrimCarriageReturn(fname);
	
	omifstream* file = new omifstream(fname IOS_NO_CREATE);

	if (!(*file)) {
		if (withMessage) {
			errMsg = (char*)filename;
			errMsg += " File not found or cannot be opened";
		}
		delete file; // Pointer should be freed despite failure
		return FALSE;
	}
	else {
		if (replace)
			clearAllInputs();
		inputs.push(file);
		return TRUE;
	}
}

void TOMUI::refresh() 
{
	_needRefresh = FALSE;
}

void TOMUI::passControlToUser() 
{ 
	while (myState==controlWithUser) { 
		myState=getAndDoUserRequest();
	}
	if (_needRefresh){
		refresh();
	}
}


inline omistream* TOMUI::getActiveInStream() {
	// Get the "current" input source and "pop it off" if at eof
   omistream* file;
	for (	file = inputs.top();
			inputs.top()!=NULL && inputs.top()->eof();
			file = inputs.top()) {
		inputs.pop();
		delete file;
	}
	return file;
}


inline OMBoolean TOMUI::actualyReadLine(omistream* file,
									char * line, 
									int size) {
#ifndef OM_STL
	int len = 0;										
	file->getline(line,size,'\n');
	len = file->gcount();
#else
	STD_NAMESPACE streamsize len = 0;
	line[0]='\0';
	// in VC 5.0's STL, the getline waited for another character after the '\n'
	// and when the line contained just '\n' the omistream failbit was set
	if (! (file->peek() == '\n')) {
		file->get(line,size,'\n');
		len = file->gcount();
	}
	file->ignore();
#endif
#ifndef OM_SKIP_EOL_CLEAN
	if (len <= size && line[len-1] == '\r')
		line[len-1] = '\0';
#endif // OM_SKIP_EOL_CLEAN
	return (line[0]!='\0');

}

void TOMUI::readLine(char * line, int size) {
	// The loop here is just to "pop" files at eof from stack
	omistream* file;
	do {
		file = getActiveInStream();
		if (file==NULL) file = &omcin;
	} while (!actualyReadLine(file, line, size));
}

inline void sendInValidNameError(char *name) {
	char * oldName = name;
	OMString token;
	eatOneToken(oldName,token,"@#[]->.");
	if (token.IsEmpty())
		errMsg = "Missing item name";
	else {
		errMsg ="Could not find objects corresponding to ";
		errMsg += token;
//		while (isspace(*name)) name++;	// skip pre token spaces
//		while (!isEndOfName(name)) {
//			errMsg += *name;
//			name++;
//		}
	}
}



inline OMBoolean isYes(char c) {
	// 'n', 'N', and '0' == No. Other chars == Yes
	return c!='n' && c!='N' && c!='0';
}

inline OMBoolean string2mask(char * s, int& mask) {
	// Converts a null terminated string to a int interest mask
	// returns FALSE if strin gis not in the appropriate format
	mask = OMNoInterest;

	// String must have exactly nine entries
	if (strlen(s)!=9)
		return FALSE;

	// Add entries one by one
	// Enforce that if Existance is not interesting - nothing is
	if (isYes(s[0])) {
		mask |= OMExistInterest;
		if (isYes(s[1]))	mask |= OMRelationInterest;
		if (isYes(s[2]))	mask |= OMAttributesInterest;
		if (isYes(s[3]))	mask |= OMStateInterest;
		if (isYes(s[4]))	mask |= OMParameterInterest;
		if (isYes(s[5]))	mask |= OMMethodsInterest;
		if (isYes(s[6]))	mask |= OMConstructorsInterest;
		if (isYes(s[7]))	mask |= OMDestructorsInterest;
		if (isYes(s[8]))	mask |= OMControlInterest;
	}

	return TRUE;
}




int token2Subject(NoCaseString token, OMBoolean& badToken) {
	badToken = FALSE;
	if (token == "all")
		return OMAllInterest;
	else if (token == "nothing")
		return OMNoInterest;
	else if (token == "existence")
		return OMExistInterest;
	else if (token == "relation" || token == "relations")
		return OMRelationInterest;
	else if (token == "attribute" || token == "attributes")
		return OMAttributesInterest;
	else if (token == "state" || token == "states")
		return OMStateInterest;
	else if (token == "control" || token == "controls")
		return OMControlInterest;
	else if (token == "method" || token == "methods")
		return OMMethodsInterest;
	else if (token == "event" || token == "events")
		return OMMethodsInterest;
	else if (token == "constructor" || token == "constructor")
		return OMConstructorsInterest;
	else if (token == "destructor" || token == "destructors")
		return OMDestructorsInterest;
	else if (token == "timeout" || token == "timeouts")
		return OMTimeoutsInterest;
	else if (token == "subClass" || token == "subClasses")
		return OMSubClassInterest;
	else if (token == "parameter" || token == "parameters")
		return OMParameterInterest;
	else if (token == "thread" || token == "threads")
		return OMThreadInterest;
	else {
		errMsg = " Incorrect interest mask value ";
		errMsg += token;
		badToken = TRUE;
		return OMNoInterest;
	}
}



OMBoolean updateShowMask(char*& c, int& showMask) {
	char * tmpC = c;
	NoCaseString token;
	// Check the yes no posibillity
	eatOneExplicitToken(c,token,"ynYN01");
	if (string2mask(token.GetBuffer(0), showMask)) return TRUE;

	c = tmpC;	// unread anything you might have read;
	// It should be a list of key words
	showMask = OMExistInterest;
	do {
		// Read the sign if any
		OMString sign;
		eatOneExplicitToken(c,sign,"+-");
		// Read the subject
		eatOneToken(c,token);
		if (token=="") { return TRUE; }
		// If subject invalid quit
		OMBoolean badToken;
		int subject = token2Subject(token,badToken);
		if (badToken) {	return FALSE; }
		if (sign.IsEmpty() ||
			  sign[OMNullPosition]=='+')
			showMask = showMask | subject;
		else
			showMask = showMask & ~subject;

		// Read a comma if we have any
		eatOneExplicitToken(c,token,",");
	} while (token!="");
	return TRUE;
}


TOMUIState TOMUI::showSomething(char *& c) {

	// Check if proxyConsole exists - otherwise no destination for output
	if (TOMProxyConsole::instance()==NULL) {
		errMsg = "Cannot do SHOW when output window is closed";
		return failedLastCommand;
	}

	char * oldC = c;
	// Get the item to be shown
	TOMProxyItem * item = TOMSystem::instance()->name2Item(c);

	if (isCodeItem(item)) {	// Item not found
		sendInValidNameError(oldC);
		return failedLastCommand;
	}

	// Eldad's patch: should eat everything until the next white space
	// in case of leftovers.
	while (!isspace(*c) && (*c != '\0')) c++;

	// Get the mask to show
	int showMask;
	if (updateShowMask(c,showMask)) { // mask is valid -- show 
//		if (item->showYourself(TOMProxyConsole::instance(), showMask))
//			return controlWithApplication;
//		else
//			return controlWithUser;
		item->showYourself(TOMProxyConsole::instance(), showMask);
		return controlWithUser;
	} else	// mask invalid
		return failedLastCommand;
}

TOMUIState TOMUI::doSomething(TOMProxyVisitor1Arg & todo, char *& c) 
{
	char * oldC = c;
	// Get the item to be shown
	TOMProxyItem * item = NULL;
	if ((c == NULL) || (strcmp(c,"") == 0)) {
		item = TOMSystem::instance();
	}
	else {
		item = TOMSystem::instance()->name2Item(c);
	}

	if (isCodeItem(item)) {	// Item not found
		sendInValidNameError(oldC);
		return failedLastCommand;
	}

	// Get the mask to show
	item->accept(todo);
	return controlWithUser;
}


enum MaskToDo { setOnly, addOnly, subtractOnly, addSubtract, doNothing };



inline void updateMask(OMString sign, int subject, MaskToDo& toDo,
				int& addMask, int& subtractMask, int& setMask) {
	if (sign.IsEmpty()) {
		// Update the toDo
		if (toDo != setOnly) {
			toDo = setOnly;
			// Update the setMask
			setMask = setMask | addMask;
			setMask = setMask & ~subtractMask;
		}
		// Update the mask by the current subject
		setMask = setMask | subject;
	} else if (sign[OMNullPosition]=='+') {
		// Update the toDo
		if (toDo == doNothing) toDo = addOnly;
		else if (toDo == subtractOnly) toDo = addSubtract;
		// Update the appropriate mask
		if (toDo == setOnly)
			setMask = setMask | subject;
		else {
			addMask = addMask | subject;
			subtractMask = subtractMask & ~subject;
		}
	} else { // must be a '-'
		// Update the toDo
		if (toDo == doNothing) toDo = subtractOnly;
		else if (toDo == addOnly) toDo = addSubtract;
		// Update the appropriate mask
		if (toDo == setOnly)
			setMask = setMask & ~subject;
		else {
			subtractMask = subtractMask | subject;
			addMask = addMask & ~subject;
		}
	}
}




void getMask(char*& c, MaskToDo& toDo, int& addMask,
									   int& subtractMask,
									   int& setMask) {
	char * tmpC = c;
	NoCaseString token;
	// Check the yes no posibillity
	eatOneExplicitToken(c,token,"ynYN01");
	if (string2mask(token.GetBuffer(0), setMask)) {
		toDo = setOnly;
		return;
	} else
		c = tmpC;	// unread anything you might have read;
	// It should be a list of key words
	addMask = subtractMask = setMask = OMNoInterest;
	toDo = doNothing;
	do {
		// Read the sign if any
		OMString sign;
		eatOneExplicitToken(c,sign,"+-");
		// Read the subject
		eatOneToken(c,token);
		// If subject invalid quit
		OMBoolean badToken;
		int subject = token2Subject(token,badToken);
		if (badToken) {	toDo = doNothing; return; }
		updateMask(sign,subject,toDo,addMask,subtractMask,setMask);

		// Read a comma if we have any
		eatOneExplicitToken(c,token,",");
	} while (token!="");
}


OMBoolean TOMUI::traceSomething(char *& c) {
	// Check if proxyConsole exists - otherwise no destination for output
	if (TOMProxyConsole::instance()==NULL) {
		errMsg = "Cannot do TRACE when output window is closed";
		return FALSE;
	}

	char * oldC = c;
	// Get the item to be traced
	TOMProxyItem * item = TOMSystem::instance()->name2Item(c);

	if (isCodeItem(item)) {	// Item not found
		sendInValidNameError(oldC);
		return FALSE;
	}

	// Get the mask(s) to trace
	int setMask, addMask, subtractMask;
	MaskToDo toDo;
	getMask(c,toDo,addMask,subtractMask,setMask);
	switch (toDo) {
	case setOnly:
		item->reRegisterObserver(TOMProxyConsole::instance(),setMask);
		return TRUE;
	case addOnly:
		item->addToObserver(TOMProxyConsole::instance(),addMask);
		return TRUE;
	case subtractOnly:
		item->subtractFromObserver(TOMProxyConsole::instance(),subtractMask);
		return TRUE;
	case addSubtract:
		item->addToObserver(TOMProxyConsole::instance(),addMask);
		item->subtractFromObserver(TOMProxyConsole::instance(),subtractMask);
		return TRUE;
	default: 
		return FALSE;
	}
}


OMBoolean TOMUI::maskSomething(char *& c) {
	// Check if proxyConsole exists - otherwise no destination for output
	if (TOMProxyConsole::instance()==NULL) {
		errMsg = "Cannot do MASK when output window is closed";
		return FALSE;
	}

	char * oldC = c;
	// Get the item to be traced
	TOMProxyItem * item = TOMSystem::instance()->name2Item(c);

	if (isCodeItem(item)) {	// Item not found
		sendInValidNameError(oldC);
		return FALSE;
	}

	OMList<TOMMaskedObserver *>* observerList;
	OMList<TOMShowObserver *>* showObserverList;
	OMInterestMask mask;
	item->showObservers(observerList, showObserverList, mask);
	OMString msg = "Interest Mask = ";
	x2String(mask.toInt(),msg);
	msg += "\n";
#ifdef OMANIMATOR
	msg += "Observer List";
	if (observerList->isEmpty()) msg +=" is Empty";
	msg += "\n";
	for(OMIterator<TOMMaskedObserver*> iter(observerList); *iter; ++iter) {
		x2String(((*iter)->getMask()).toInt(),msg);
		msg +='\t';
		x2String(((void *)(*iter)->getObserver()),msg);
		msg +='\n';
	}
#endif
	msg += "Show Observer List";
	if (showObserverList->isEmpty()) msg +=" is Empty";
	msg += "\n";
	for(OMIterator<TOMShowObserver*> jter(showObserverList); *jter; ++jter) {
		x2String(((void *)(*jter)->getObserver()),msg);
		msg +='\n';
	}

	TOMProxyConsole::instance()->notifyRawMessage(msg.GetBuffer(0));
	return TRUE;
}

enum BPCommand { addBP, removeBP, freezeBP, reviveBP };
BPCommand getBPCommand(char *& c) {
	char *oldC =c;
	NoCaseString token;
	eatOneExplicitToken(c,token,"+-*@");
	if (token == "+") return addBP;
	if (token == "-") return removeBP;
	if (token == "@") return freezeBP;
	if (token == "*") return reviveBP;

	eatOneToken(c,token);
	if (token == "add") return addBP;
	if (token == "remove") return removeBP;
	if (token == "freeze") return freezeBP;
	if (token == "revive") return reviveBP;

	// No BPCommand
	c = oldC;
	return addBP;
}

OMBoolean getBreakPointType(char *&c, OMNotify& theType) {
	// Get the breakpoint type token
	NoCaseString token;
	eatOneToken(c,token);
	// Convert token to OMNotify
	if (token==BrkOnInstanceCreated) {
		theType = instanceCreated;
	} else if (token==BrkOnInstanceDeleted) {
		theType = instanceDeleted;
	} else if (token==BrkOnTerminationReached) {
		theType = terminationReached;
	} else if (token==BrkOnEnteredState) {
		theType = enteredState;
	} else if (token==BrkOnExitedState) {
		theType = exitedState;
	} else if (token==BrkOnState) {
		theType = stateModified;
	} else if (token==BrkOnRelationConnected) {
		theType = relationConnected;
	} else if (token==BrkOnRelationDisconnected) {
		theType = relationDisconnected;
	} else if (token==BrkOnRelationCleared) {
		theType = relationCleared;
	} else if (token==BrkOnRelation) {
		theType = relationModified;
	} else if (token==BrkOnAttributeValues) {
		theType = updatedAttributeValues;
	} else if (token==BrkOnMethodCalled) {
		theType = methodCalled;
	} else if (token==BrkOnMethodReturned) {
		theType = methodReturned;
	} else if (token==BrkOnEventSent) {
		theType = eventSent;
	} else if (token==BrkOnEventReceived) {
		theType = eventTaken;
	} else if (token==BrkOnGotControl) {
		theType = becameActivated;
	} else if (token==BrkOnLostControl) {
		theType = becameDeactivated;
	} else if (token=="ALL") {
		theType = allValues;
	} else if (token==BrkOnActionReady) {
		theType = actionReady;
	} else if (token==BrkOnActionDone) {
		theType = actionDone;
	} else {
		errMsg = "Missing or Invalid break point directive";
		return FALSE;
	}
	return TRUE;
}

OMBoolean checkBreakPoint(TOMProxyItem* item,
						OMNotify theType,
						const OMString& data) {
	switch (theType) {
	case updatedAttributeValues:
		if (item->getType()!=omProxyInstance) {
			errMsg = 
				"Attribute breakpoint requires valid instance name";
			return FALSE;
		} else if (data!="") {
			errMsg = "Attribute breakpoint cannot have data";
			return FALSE;
		} else
			return TRUE;
	case instanceCreated:
		if (item!=TOMSystem::instance() &&
			item->getType()!=omProxyClass) {
			errMsg = 
				"Instance Created breakpoint requires valid class name";
			return FALSE;
		} else if (data!="") {
			errMsg = "Instance Created breakpoint cannot have data";
			return FALSE;
		} else
			return TRUE;
	// Check for data less items
	case becameActivated:
	case becameDeactivated:
	case controlModified:
	case instanceDeleted:
	case terminationReached:
		if (data!="") {
			errMsg = "This breakpoint cannot have data";
			return FALSE;
		} else
			return TRUE;
	default:
		return TRUE;
	}
}



OMBoolean TOMUI::breakSomething(char *& c) {
	char * oldC = c;
	// Get the item to be breakPointed
	TOMProxyItem * item = TOMSystem::instance()->name2Item(c);

	if (isCodeItem(item)) {	// Item not found
		sendInValidNameError(oldC);
		return FALSE;
	}

	// Get the break point command
	// + - * @
	BPCommand bpCommand = getBPCommand(c);
	// Get the break point type
	OMNotify theType;
	if (!getBreakPointType(c,theType))
		return FALSE;
	// Get the Data if present
	OMString token;
	eatOneToken(c,token,".->:(),*&[]");
	if (!checkBreakPoint(item,theType,token))
		return FALSE;

	// Prepare to build the breakpoint
	// Change #all to NULL
	if (item == TOMSystem::instance())
		item = NULL;
	const char * theData = token.GetBuffer(0);
	OMBoolean ok = FALSE;
//	const char * theData = c;
	switch (bpCommand) {
	case addBP:
		if (theType==allValues)
			return FALSE;
		if (item==NULL)
			return TOMSystem::instance()->addBreakPoint(theType,theData);
		else
			return TOMBreakPointManager::instance()->addBreakPoint(theType,item,theData);
	case removeBP:
		ok= TOMBreakPointManager::instance()->removeBreakPoint(theType,item,theData);
		break;
	case freezeBP:
		ok= TOMBreakPointManager::instance()->freezeBreakPoint(theType,item,theData);
		break;
	case reviveBP:
		ok= TOMBreakPointManager::instance()->reviveBreakPoint(theType,item,theData);
		break;
	}
	if (!ok)
		errMsg = "Break point not found";
	return (ok);
}


OMBoolean checkAndGo(OMInterestMask mask) {
	TOMThread * t = TOMSystem::threadManagerInstance()->getFocusThread();
	if (t) {
		if (t->isSuspended()) {
			errMsg = "Cannot advance - current thread is suspended\n";
			errMsg += "Either release current thread or set focus to another";
			return FALSE;
		} else {
			t->getStepper()->setInterestMask(mask);
			return TRUE;
		}
	}
	return FALSE;
}


OMBoolean TOMUI::goSomething(char *&c) {
	NoCaseString token;
	eatOneToken(c,token);
	if (token == "") {
		// Go forever (or until interupt)
		return checkAndGo(OMNoStop);
	} else 	if (token == "idle") {
		// Go until idle
		return checkAndGo(OMStopWhenIdle);
	} else 	if (token == "event") {
		// Go until next event
		return checkAndGo(OMStopWhenEvent);
	} else 	if (token == "step") {
		// Go a step
		unsigned int stepMask = OMStopWhenStep | OMStopWhenNext;
#ifdef OM_NEED_GETENV
		// check the environment variable to disable the notifySingleStep()
		NoCaseString s("true");
		char * shouldSingleStep = getenv("GoStepAsGoNext");
		if ((shouldSingleStep != NULL) && (s == shouldSingleStep)) stepMask = OMStopWhenNext;
#endif // OM_NEED_GETENV
		return checkAndGo(stepMask);
	} else 	if (token == "next") {
		// Go until next step
		return checkAndGo(OMStopWhenNext);
	} else 	if (token == "action") {
		// Go until next action
		return checkAndGo(OMStopWhenAction);
	} else if (token == "fromdbg") {
		// continue without modification of the interest masks.
		TOMDispatcher::instance()->sendMessage( new OMSData(NULL,becameActivated));
		return TRUE;
	} else if (token == "quit") {
		OMSData* data;
		if (TOMStepper::getCurrentStepper() != 0)
		{
			data = new OMSData(TOMStepper::getCurrentStepper()->getReal(),quitExecutable);
		}
		else
		{
			data = new OMSData(NULL,quitExecutable);
		}
		TOMDispatcher::instance()->sendMessage(data);
		return TRUE;
	} else {
		errMsg = " Go command must be one of\n";
		errMsg += "go  go step  go event  go idle  step\n";
		errMsg += "Instead found ";
		errMsg += token;
		return FALSE;
	}
}

#define PRINT(msg)	 TOMProxyConsole::instance()->notifyRawMessage(msg);

void /* TOMUI::*/helpSomething(char *& c){
	NoCaseString token;
	eatOneToken(c,token,"#");
	if (token=="") {
		PRINT("Possible Commands Are:\n");
		PRINT("Go          Commands:   step   go   go step   go next   go event   go idle\n");
		PRINT("Trace       Commands:   Trace <nameOfItem> <maskForItem>\n");
		PRINT("Show        Commands:   Show  <nameOfItem> <maskForItem>\n");
		PRINT("Showall\n");
		PRINT("BreakPoint  Commands:   Break <nameOfItem> <bpOp><BPName> <data>\n");
		PRINT("Generate Event      :   <nameOfInstance>->GEN(<nameOfEvent>)\n");
		PRINT("                    :   GEN(<nameOfInstance>,<nameOfEvent>)\n");
		PRINT("Display\n");
		PRINT("Watch\n");
		PRINT("Refresh\n");
		PRINT("Output [+ or -] [filename or cout]\n");
		PRINT("LogCmd [+ or -] [filename]\n");
		PRINT("Input [+] filename\n");
		PRINT("TimeStamp [+ or +raw or -]\n");
		PRINT("Quit\n");
		PRINT("Help ?\n");
		PRINT("Comments // the comment goes here\n");
	} else {
		PRINT("Please refer to Rhapsody's documentation for details on animation\\tracing commands\n");
	}
}


OMBoolean TOMUI::inputSomething(char*& c) {
	NoCaseString token;
	eatOneExplicitToken(c,token,"+");
	OMBoolean replace = (token!="");
	char path[256];
	path[0] = '\0';
	OM_SEARCH_ENV(c, tomSearchPathEnvVarName, path);
	return setInput(c, TRUE, replace, path);
}

OMBoolean TOMUI::suspendSomething(char*& c) {
	char * oldC = c;
	// make sure we go for the thread
	TOMThread * t = TOMSystem::threadManagerInstance()->name2Thread(c);
	if (isCodeItem(t)) {	// Item not found
		sendInValidNameError(oldC);
		return FALSE;
	} else {
		t->suspend();
		return TRUE;
	}
}

OMBoolean TOMUI::resumeSomething(char*& c) {
	char * oldC = c;
	// make sure we go for the thread
	TOMThread * t = TOMSystem::threadManagerInstance()->name2Thread(c);
	if (isCodeItem(t)) {	// Item not found
		sendInValidNameError(oldC);
		return FALSE;
	} else {
		t->resume();
		return TRUE;
	}
}

OMBoolean TOMUI::setSomething(char*& c) {
	char * oldC = c;
	// Set what
	NoCaseString token;
	// Eat the + or - directive
	eatOneToken(c,token);
	if (token == "focus") {
		oldC = c;
		// Get the thread
		TOMThread * t = TOMSystem::threadManagerInstance()->name2Thread(c);
		if (isCodeItem(t)) {	// Item not found
			sendInValidNameError(oldC);
			return FALSE;
		} else {
			TOMSystem::threadManagerInstance()->setFocusThread(t);
			return TRUE;
		}
	}
	errMsg = "Don't know how to set ";
	errMsg += token;
	return FALSE;
}


OMBoolean TOMUI::outputSomething(char*& c) {
	// Check if proxyConsole exists - otherwise cannot modify output dest.
	if (TOMProxyConsole::instance()==NULL) {
		errMsg = "Cannot do Output Command without ProxyConsole";
		return FALSE;
	}
	NoCaseString token;
	// Eat the + or - directive
	eatOneExplicitToken(c,token,"+-");
	// skip possible white spaces
	while (isspace(*c)) c++;

	char* file = c;
	char* newFileName = NULL;
#ifdef OMANIMATOR
	if(TOMExterns::Anim())
		newFileName = TOMExterns::Anim()->AddProjectDirIfNeeded(file);
#endif

	// Now do the operation
	if (token=="+" || token == "") {
		if (newFileName != NULL)
		{
			TOMProxyConsole::instance()->addToOutputMap(newFileName);
			delete newFileName;
		}
		else
		{
			TOMProxyConsole::instance()->addToOutputMap(file);
		}
		return TRUE;
	} else if (token=="-") {
		TOMProxyConsole::instance()->removeFromOutputMap(file);
		return TRUE;
	} else {
		errMsg = "Output modifier must be + or - Instead found ";
		errMsg += token;
		return FALSE;
	}
}


OMBoolean TOMUI::logcmdSomething(char*& c) {

	OMBoolean res = FALSE;
	NoCaseString token;
	// Eat the + or - directive
	eatOneExplicitToken(c,token,"+-");
	// skip possible white spaces
	while (isspace(*c)) c++;

	// Now do the operation
	if (token=="+" || token == "") {
		if (shouldRecordCommand() == FALSE) {
			res = recordCommandsOn(c);
		}
		else {
			errMsg = "Already logging commands to ";
			errMsg += getLogCmdFilename();
			errMsg += ". Do \"LogCmd -\" to turn off current logging.";
		}
	} else if (token=="-") {
		res = recordCommandsOff();
	} else {
		errMsg = "LogCmd modifier must be + or - Instead found ";
		errMsg += token;
		return FALSE;
	}
	return res;
}

OMBoolean TOMUI::recordCommandsOn(const char* filename)
{
	OMBoolean res = FALSE;
	if (filename != NULL) {
	
		char* tmpFilename = (char*)filename;
		char* newFileName = NULL;
#ifdef OMANIMATOR
	if(TOMExterns::Anim())
		newFileName = TOMExterns::Anim()->AddProjectDirIfNeeded(tmpFilename);
#endif

		if (newFileName != NULL)
		{
			logCmdFilePtr = fopen(newFileName, "w");
			delete newFileName;
		}
		else
		{
			logCmdFilePtr = fopen(tmpFilename, "w");
		}
		if (logCmdFilePtr == NULL) {
			errMsg = "Unable to open file ";
			errMsg += (char*)filename;
			errMsg += " for writing";
		}
		else {
			strcpy(logCmdFileName, filename);
			res = TRUE;
		}
	}
	else {
		errMsg = "Filename must be specified";
	}
	return res;
}


char* TOMUI::getLogCmdFilename() const
{
	return (char *)(&logCmdFileName[0]);
}

OMBoolean TOMUI::recordCommandsOff() 
{
	OMBoolean res = FALSE;
	if (logCmdFilePtr != NULL) {
		fclose(logCmdFilePtr);
		logCmdFilePtr = NULL;
		logCmdFileName[0] = '\0';
		res = TRUE;
	}
	return res;
}

OMBoolean TOMUI::shouldRecordCommand() const
{
	OMBoolean res = FALSE;
	if (logCmdFilePtr != NULL) 
		res = TRUE;
	return res;
}

OMBoolean TOMUI::recordCommand(const char* cmd) const
{
	OMBoolean res = FALSE;
	if (logCmdFilePtr != NULL) {
		if (fprintf(logCmdFilePtr, "%s\n", cmd) >= 0)
			res = TRUE;
	}
	return res;
}


OMBoolean TOMUI::timestampSomething(char *& c)
{
	NoCaseString token;
	// Eat the + or - directive
	eatOneExplicitToken(c,token,"+-");

	// trim leading white spaces
	while (isspace(*c)) c++;

	if (token == "-") {
		TOMProxyConsole::instance()->setOutputTraceTime(OMwithNoTime);
		// notify AOM
		TOMDispatcher::instance()->sendMessage(new OMSData(NULL, withoutTimeStamp));
	}
	else {	// token == "+"
		NoCaseString rawStr((char*)"raw");
		if (rawStr == c) {
			TOMProxyConsole::instance()->setOutputTraceTime(OMwithRawTime);
		}
		else {
			// this is the default
			TOMProxyConsole::instance()->setOutputTraceTime(OMwithFormattedTime);
		}
		// notify AOM
		TOMDispatcher::instance()->sendMessage(new OMSData(NULL, withTimeStamp));
	}
	return TRUE;
}

OMString getStartEndExp(char border, char*& c) {
	OMString s;
	// Skip border
	c++;
	while (c[0]!=border) {
		if (c[0]=='\\') {
			s += c[0];
			c++;
		}
		if (c[0]=='\0') {
			OMString errMsg = "mismatch in ";
			errMsg += border;
			errMsg += " symbols";
			tomSendError(errMsg);
			return "";
		}
		s+= c[0];
		c++;
	}
	return s;
}

OMString getStartEndExpB(char border, char*& c) {
	OMString s;
	s+= c[0]; // Get the first border
	s += getStartEndExp(border,c);
	if (s.GetLength()>1) {
		s+= c[0]; // Get the last border
		c++; // Skip the last border
		return s;
	} else
		return "";
}

OMString getComplextStartEndExp(char*& c) {
	OMString s;
	// Skip the '{' border
	c++;
	while (c[0]!= '}') {
		if (c[0]=='\0') {
			tomSendError("mismatch in '{' '}' symbols");
			return "";
		}
		if (c[0]=='\\') {
			s += c[0];
			c++;
			if (c[0]=='\0') {
				OMString errMsg = "uninterpreted ";
				errMsg += '\\';
				errMsg += " symbol";
				tomSendError(errMsg);
				return "";
			}
			s += c[0];
			c++;
		} else if (c[0]=='\'' || c[0]=='\"') {
			OMString tmp = getStartEndExpB(c[0],c);
			if (tmp.IsEmpty())
				return "";
			else
				s += tmp;
		} else {
			s+= c[0];
			c++;
		}
	}
	return s;
}

OMBoolean decodeParameter(char*& c,OMSData& paramList, AnimOpCallRequest *req=NULL) {
	char * oldC = c;
	// Look for a real item
	OMString name;
	eatOneToken(c,name);
	TOMClass *item = TOMSystem::instance()->name2Class(name);
	OMString instName;
	char *tmpBuf = oldC;
	eatOneToken(tmpBuf, instName, "~!@#$%^&*+-=[]:<>.?/|");
	TOMInstance *instItem = TOMSystem::instance()->name2Instance(instName);
	c = oldC;
	if (isRealItem(item) || isRealItem(instItem)) { // The name is a class name or an instance global name
		
		// now look for an instance
		TOMInstance * inst;
		if (isRealItem(instItem)) {
			inst = instItem;
			OMString exp;
			eatOneToken(c,exp,"~!@#$%^&*+-=[]:<>.?/|");
		}
		else {
			inst = TOMSystem::instance()->name2Instance(c);
		}

		if (isRealItem(inst)) { // The name is a class name
			paramList.addItem(inst->getReal());
			if (req != NULL) {
				req->addArgValue(inst->getReal());
			}
			return TRUE;
		} else {
			OMString errMsg = "Non existing instance in parameter list ";
			c = oldC;
			while (!isEndOfName(c)) { errMsg += *c; c++; }
			tomSendError(errMsg);
			return FALSE;
		}
	}
	c = oldC;
	// Look for some expression
	OMString exp;
	while ((*c)!='\0' && isspace(*c)) c++;
	if (c[0]=='\0') {
		tomSendError("Missing parameter in event Expression");
		return FALSE;
	} else if (c[0]=='\'' || c[0]=='\"') {
		exp = getStartEndExp(c[0],c);
		c++;
	} else if (c[0]=='{') {
//		exp = getComplextStartEndExp(c);
//		c++;
		// currently we do not support arrays - print an error message and return
		// format error message
		OMString token;
		eatOneToken(c,token,"{,; ~!@#$%^&*+-=[]:<>.?/|"); // looking for '}'
		token += '}';
		const char* errMsgFormat = "Injection of argument %s is not supported";
		size_t len = strlen(errMsgFormat) + token.GetLength() + 1;
		char* msg = (char*) new char[len];
		sprintf(msg, errMsgFormat, (const char*)token);
		// notify the user
		tomSendError(msg);
		delete [] msg;
		return FALSE;
	} else {
		eatOneToken(c,exp,"~!@#$%^&*+-=[]:<>.?/|");
	}
	// treat empty string ("") as legal argument
	if (!exp.IsEmpty() || (oldC[0] == '"' && oldC[1] == '"')) 
	{
		paramList.addItem(exp);
		if (req != NULL) {
			req->addArgValue(exp);
		}
		return TRUE;
	} 
	else
	{
		tomSendError("Bad or Missing parameter in event Expression");
		return FALSE;
	}
}

OMBoolean decodeParamList(char*& c,OMSData& paramList, AnimOpCallRequest* req=NULL) {
	while ((*c)!='\0' && isspace(*c)) c++;
	if (c[0]==')') { // No parameters
		return TRUE;
	} else if (c[0]!='(') {
		OMString errMsg = "Bad parameter list ";
		errMsg += c;
		tomSendError(errMsg);
		return FALSE;
	}
	// We have a proper parameterList
	c++; // Skip the '('
	while ((*c)!='\0' && isspace(*c)) c++;
	if (c[0]==')') { // No parameters
		c++; // Skip the ')' ending the paramList
		return TRUE;
	}

	for (;;) {
		// Here we should have a parameter
		OMBoolean paramOk = decodeParameter(c,paramList, req);
		if (!paramOk)
			return FALSE;
		// Eat next seperator
		while ((*c)!='\0' && isspace(*c)) c++;
		if (c[0]==')') { // No more parameters
			c++; // Skip the ')' ending the paramList
			return TRUE;
		} else if (c[0]!=',') {
			OMString errMsg = "Bad separator in parameter list ";
			errMsg += c;
			tomSendError(errMsg);
			return FALSE;
		} else // skip the ','
			c++;
	}
}

OMBoolean TOMUI::callOperation(char*& c, bool showInConsole /*=true*/, bool doImmediately /*=false*/)
{
	OMBoolean res = FALSE;
	char *s=NULL;

	static int reqID = 1;

	OMString cmdString = c; // just for confirmation

	// check is this is a CALL command
	s = strstr(c, "CALL(");
	if (s != NULL) {
		res = TRUE;	// we know it is a CALL command.
		if ( s[-2]!='-' || s[-1] !='>') {
			OMString errMsg = "Syntax error in CALL command\n";
			tomSendError(errMsg);
		}
		else {
			char *instanceOrClassName = c;
			s[-2] = '\0'; // instanceOrClassName should be null terminated
			s += 5;  // skip CALL(
			
			OMBoolean isInstance = FALSE;

			// locate class or object
			char* oldC = instanceOrClassName;
			TOMSystem * tomSys = TOMSystem::instance();
			TOMInstance * instItem = tomSys->name2Instance(instanceOrClassName);
			TOMClass * classItem = NULL;
			if (isCodeItem(instItem)) {
				instanceOrClassName = oldC;
				classItem = tomSys->name2Class(instanceOrClassName);
			}
			else {
				isInstance = TRUE;
			}
			
			if (isCodeItem(classItem) && (!isInstance)) {
				OMString errMsg = "Invalid or none existent instance\\class name ";
				while (isspace(*oldC)) oldC++;	// skip pre token spaces
				while (!isEndOfName(oldC)) {
					errMsg += *oldC;
					oldC++;
				}
				tomSendError(errMsg);
			}
			else { // we have a valid instance or class
				// find the class if needed
				if (isInstance)
					classItem = instItem->getClass();

				// extract the operation name
				c = s;
				OMString opName;
				eatOneToken(c,opName);
				//Handle operators.
				if ((strcmp(opName.GetBuffer(0), "operator") == 0) || 
					(strcmp(opName.GetBuffer(0), "new") == 0) ||
					(strcmp(opName.GetBuffer(0), "delete") == 0))
				{
					OMString operatorSymbols;
					eatOneToken(c,operatorSymbols, "+-*/%^&|~!=<>,[]");
					opName+= operatorSymbols;
					//This is operator()
					if ((strcmp(opName.GetBuffer(0), "operator") == 0) && (*c == '(') && (*(c+1) == ')'))
					{
						//Add "()" to the operation name
						eatOneToken(c,operatorSymbols,"()");
						opName+= operatorSymbols;
					}

				}

				AnimOpCallRequest* callReq = new AnimOpCallRequest();
				OMSData paramList; // although we don't really use it.

				// Generate a parameter list;
				OMBoolean paramListOk = decodeParamList(c,paramList, callReq);
				if (!paramListOk)
					return TRUE;

				OMString signature;

				// Skip the ')' of the CALL
				while ((*c)!='\0' && isspace(*c)) c++;
				if (c[0] == ',') { // signature specified
					c++;
					// copy until the last character with no spaces
					size_t len = strlen(c);
					size_t i;
					for (i=0; i<len-1; ++i) {
						while ((*c)!='\0' && isspace(*c)) { c++; i++; }
						if ((*c) != '\0') {
							signature += *c;
							c++;
						}
					}
				}
				
				if (c[0]!=')') {
					OMString errMsg = "Bad CALL expression missing \')\' ";
					errMsg += c;
					tomSendError(errMsg);
				}
				else {					
					int bLangJava = FALSE;
#ifdef OMANIMATOR
					bLangJava = TOMExterns::Anim()->IsLangJava();
#endif // OMANIMATOR
					// find the operation object
					OMList<TOMOperation *>* tomOperations = NULL;
					int numOfArgs = callReq->getArgValues()->getSize();
					tomOperations = classItem->findPossibleOperationsToCall(opName, numOfArgs, signature);
					int numOfOperFound = tomOperations->getCount();
					if ( numOfOperFound == 1 || bLangJava) { // single operation found
						if(bLangJava)
						{
							//in java application we can call any operation via reflection,
							//therefore we send the operation's signature instead of a TOMOperation.
							callReq->setOp(NULL);
							if(instItem && !isCodeItem(instItem))
							{
								callReq->setInstance(instItem->getReal());
								callReq->setClass(NULL);
							}
							else
							{
								//in case of static operation and no instance exist send the TOMClass
								//so we can invoke the operation on the class
								callReq->setInstance(NULL);
								callReq->setClass(classItem->getReal());
							}
						
							//if the user didn't supply a signature sent the opName as the signature
							if(signature.IsEmpty())
								callReq->setSignature(opName);	
							else
								callReq->setSignature(signature);
						}
						else
						{
							TOMOperation *theOp = tomOperations->getFirstConcept();
							callReq->setOp(theOp->getReal());
							if (theOp->getIsStatic())
								callReq->setInstance(NULL);
							else
							{
								if(instItem && !isCodeItem(instItem))
									callReq->setInstance(instItem->getReal());
								else
								{//there is no instance, and we are invoking a non-statis function, abort.
									OMString errMsg = "Invalid or none existent instance\\class name ";
									while (isspace(*oldC)) oldC++;	// skip pre token spaces
									while (!isEndOfName(oldC)) {
										errMsg += *oldC;
										oldC++;
									}
									tomSendError(errMsg);
									
									//cleanup allocated msg
									delete callReq;
									callReq = NULL;
									return res;
								}
							}
							//signature and class aren't used in C/C++
							OMString dummySignature;
							callReq->setSignature(dummySignature);
							callReq->setClass(NULL);
						}
						
						// find the active stepper
						TOMStepper* stepper = TOMStepper::getCurrentStepper();
						callReq->setDestOrSource(stepper->getReal());
						
						// set the show in console flag
						callReq->setShowInConsole(showInConsole);
						
						// set the do immediately flag
						callReq->setDoImmediately(doImmediately);
						
						// set the ID and store the request
						callReq->setRequestID(reqID);
						TOMSystem::instance()->logOpRequest(reqID, cmdString);
						
						reqID = (reqID+1)%32768;
						
						// send the message
						TOMDispatcher::instance()->encodeAndSendMessage(callReq);
						if (showInConsole == true)
						{
							checkAndParseForStruct(cmdString.GetBuffer(0));

							OMString notif = "Message: ";
							notif += cmdString;
							notif += " sent.";
							tomOutputString(notif);
						}							
					}
					else if (numOfOperFound == 0) {
						OMString errMsg;
						errMsg = "Unable to perform ";
						errMsg += cmdString;
						errMsg += ", no matching operation found.";
						tomSendError(errMsg);
					}
					else {
						OMString errMsg;
						errMsg = "Unable to perform ";
						errMsg += cmdString;
						errMsg += ", more than a single matching operation found";
						tomSendError(errMsg);
					}
					delete tomOperations;
					
				}
			}
		}		
	}

	return res;
}

void TOMUI::checkAndParseForStruct(char* cmd)
{
	if(needToParseCommand(cmd))
	{
		parseCommand(cmd);
	}
}

bool TOMUI::needToParseCommand(char* cmd)
{
	return ((strchr(cmd,'=') != NULL) && (strchr(cmd,'%') != NULL));
}
void TOMUI::parseCommand(char* cmd) {
	OMString copyStr = cmd;
	OMString cmdString = cmd;
	int pntr = 0, dest = 0;
	while (cmdString[pntr] != '\0')
	{
		if (cmdString[pntr] == '#')
		{
    		if(cmdString[pntr-1] == '/')
    			copyStr.SetAt(--dest,'#');
    		else
    			copyStr.SetAt(dest,'"');
		}
		else if(cmdString[pntr] == '^')
		{
    		if(cmdString[pntr-1] == '/')
    			copyStr.SetAt(--dest,'^');
    		else
    			copyStr.SetAt(dest,' ');
		}
		else if(cmdString[pntr] == '%')
		{
			if(cmdString[pntr-1] == '/')
    			copyStr.SetAt(--dest,'%');
    		else
    			copyStr.SetAt(dest,',');
		}
		else
    		copyStr.SetAt(dest,cmdString[pntr]);
		pntr++;
		dest++;
	}
	if(dest < copyStr.GetLength() && copyStr[dest] != '\0')
	{
		copyStr.SetAt(dest,'\0');
	}
	strcpy(cmd,copyStr.GetBuffer(0));
}

OMBoolean TOMUI::generateEvent(char*& c) {
	// Is this a 'GEN' command
	bool isRicGen=false;
	char *s=NULL;
	s = strstr(c,"RiCGEN(");
	if (s==NULL) {
		s = strstr(c,"GEN(");
		if (s==NULL) {
			// not a GEN command
			return FALSE;
		}
	} else
		isRicGen=true;

	// Is a GEN Command
	// Look for the 'target' instance
	char * instanceName;

	if (s==c) {
		// The GEN(i,e) Format
		if (isRicGen)
			instanceName = s+7;
		else
			instanceName = s+4;
		s = strstr(s,",");
		if (s==NULL) {
			OMString errMsg = "Syntax error in GEN command\n";
			tomSendError(errMsg);
			return TRUE;
		}
		s[0] = '\0'; // So instanceName is null terminated
		s++; // Now s points to start of event name
	} else {
		// The i->GEN(e) Format
		if ( s[-2]!='-' || s[-1] !='>') {
			OMString errMsg = "Syntax error in GEN command\n";
			tomSendError(errMsg);
			return TRUE;
		}
		instanceName = c;
		s[-2]='\0'; // So instanceName is null terminated
		if (isRicGen)
			s += 7;
		else
			s += 4;
		// Now s points to start of event name
	}

	// Get object from name
	char* oldC = instanceName;
	TOMInstance * item = TOMSystem::instance()->name2Instance(instanceName);
	if (isCodeItem(item)) {
		OMString errMsg = "Invalid instance name or non existing instance ";
		while (isspace(*oldC)) oldC++;	// skip pre token spaces
		while (!isEndOfName(oldC)) {
			errMsg += *oldC;
			oldC++;
		}
		tomSendError(errMsg);
		return TRUE;
	}

	// Get event class from name
	c = s;
	OMString event;
	eatOneToken(c,event);
	TOMProxyItem * eventClass = 
		TOMSystem::instance()->name2EventClass(event, item->getMySocket());
	if (isCodeItem(eventClass)) {
		OMString errMsg = "Invalid event name or non existing event class ";
		errMsg += event;
		tomSendError(errMsg);
		return TRUE;
	}
	// Generate a parameter list;
	OMSData paramList;
	OMBoolean paramListOk = decodeParamList(c,paramList);
	if (!paramListOk)
		return TRUE;
	// Skip the ')' of the GEN
	while ((*c)!='\0' && isspace(*c)) c++;
	if (c[0]!=')') {
		OMString errMsg = "Bad GEN expression missing \')\' ";
		errMsg += c;
		tomSendError(errMsg);
		return TRUE;
	}

	// Tell this item to generate an event for itself
	 // 1. Pack the event class into a message
	OMSData *msg = new OMSData(item->getReal(), 
								 addEventToQueue, 
								 eventClass->getReal());
	msg->addItem(paramList);
	// Send it to the object with instructions to generate
#ifdef OMANIMATOR
	TOMExterns::Anim()->SetActualSocket(item->getMySocket());
#endif // OMANIMATOR

	TOMDispatcher::instance()->sendMessage(msg);

#ifdef OMANIMATOR
	TOMExterns::Anim()->SetActualSocket(NULL);
#endif // OMANIMATOR

	c = s;
	return TRUE;
}

OMBoolean TOMUI::dbgStopSomething(char*& c) {
	// find the thread stopped by the debugger
		const char* scanfStr = "0x%I64x";
		NoCaseString token;
		// Eat the os handle token
		eatOneToken(c,token);
		gen_ptr osHnd = 0;
		if (1 != sscanf(token.GetBuffer(0), scanfStr,&osHnd)) {
//			OMString errMsg = "Missing osHandle in hex format ";
//			errMsg += c;
//			tomSendError(errMsg);
			return FALSE;
		}

		TOMThread* thr = TOMSystem::threadManagerInstance()->osHandle2Thread(osHnd);

		if (NULL == thr) {
			OMString errMsg = "Unable to get thread from osHandle ";
			errMsg += c;
			tomSendError(errMsg);
			return FALSE;
		}
		NoCaseString isRhpBreakpointToken;
		eatOneToken(c,isRhpBreakpointToken);
		if ( (char*)"true" != isRhpBreakpointToken ) {
			if (TOMProxyConsole::instance()) {
				OMString thrName;
				thr->outputFirstName(thrName);
				OMString msg;
				msg += "*********************************************\n";
				msg += "Debugger Breakpoint on thread " + thrName + " threadId=" + token + "\n";
				msg += "*********************************************\n";
				TOMProxyConsole::instance()->notifyRawMessage(msg);
			}
		}

		// If under Eclipse integration no need to send stoppedByDebugger message
		NoCaseString isStoppedByDebuggerToken;
		eatOneToken(c, isStoppedByDebuggerToken);
		if ( (char*)"false" != isStoppedByDebuggerToken) {
		
#ifdef OMANIMATOR
		TOMExterns::Anim()->SetActualSocket(thr->getMySocket());
#endif // OMANIMATOR

		TOMDispatcher::instance()->sendMessage( 
									new OMSData((gen_ptr)NULL, stoppedByDebugger,thr->getReal()));
#ifdef OMANIMATOR
		TOMExterns::Anim()->SetActualSocket(NULL);
#endif // OMANIMATOR

		}

		TOMSystem::threadManagerInstance()->setFocusThread(thr);
	return TRUE;
}


void TOMUI::recordCmdIfNeeded(char *c) const
{
	if (shouldRecordCommand())
		recordCommand(c);
}

TOMUIState TOMUI::doUserRequest(char * c) {
	_needRefresh = FALSE;
	errMsg.Empty();
	char * command = c;

	char orgCommand[1024];
	strcpy(orgCommand, c);

	NoCaseString token;
	// Analyze the command
	stripComments(c,"//");
	if (*c=='\0')
		return controlWithUser;
	
	if (generateEvent(c)) {
		checkAndParseForStruct(orgCommand);
		recordCmdIfNeeded(orgCommand);
		return controlWithUser;
	}
	if (callOperation(c))
	{
		TOMSystem::instance()->notifyOpCallRequestSent();
		checkAndParseForStruct(orgCommand);
		recordCmdIfNeeded(orgCommand);
		return controlWithUser;
	}
	
	// Parse the first token
	eatOneToken(c,token,"?");
	if (token == "help" || token == "?") {
		helpSomething(c);
		return controlWithUser;
	}


	OMBoolean foundToken = FALSE;

	if (token == "quit") {
		foundToken = TRUE;
		c = (char *)("quit");
		recordCmdIfNeeded(orgCommand);
		if (goSomething(c)) {
			return controlWithApplication;
		}
	} 
	if (token == "trace") {
		foundToken = TRUE;
		if (traceSomething(c)) {
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "show") {
		foundToken = TRUE;
		TOMUIState s = showSomething(c);
		if (s==controlWithApplication) {
			// Tell aom to notify when it is done with the "show"
			TOMDispatcher::instance()->sendMessage(
				new OMSData(NULL, sendBecameDeactivated) );

			recordCmdIfNeeded(orgCommand);
			return controlWithApplication;
		} 
		else if (s==controlWithUser) {
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "output") {
		foundToken = TRUE;
		if (outputSomething(c)) {
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "logcmd") {
		foundToken = TRUE;
		if (logcmdSomething(c))
			return controlWithUser;
	}
	if (token == "mask") {
		foundToken = TRUE;
		if (maskSomething(c)) {
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "break" || token == "stop") {
		foundToken = TRUE;
		if (breakSomething(c)) {
			_needRefresh = TRUE;
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "input") {
		foundToken = TRUE;
		if (inputSomething(c)) {
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "suspend") {
		foundToken = TRUE;
		if (suspendSomething(c)) {
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "resume") {
		foundToken = TRUE;
		if (resumeSomething(c)) {
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "set") {
		foundToken = TRUE;
		if (setSomething(c)) {
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "go") {
		foundToken = TRUE;
		if (goSomething(c)) {
			_needRefresh = TRUE;
			recordCmdIfNeeded(orgCommand);
			return controlWithApplication;
		}
	} 
	if (token == "step") {
		foundToken = TRUE;
		c = (char *)("step");
		if (goSomething(c)) {
			_needRefresh = TRUE;
			recordCmdIfNeeded(orgCommand);
			return controlWithApplication;
		}
	} 
	if (token == "aomstop") {
		foundToken = TRUE;
		TOMDispatcher::instance()->sendMessage( 
									new OMSData(NULL, stoppedByUser));
		_needRefresh = TRUE;
		clearAllInputs(); // Should be 'suspendAllInputs' so aomResume will continue in same place
		//recordCmdIfNeeded(orgCommand);
		return controlWithApplication;
	} 
	if (token == "aomdbgstop") {
		foundToken = TRUE;
		if (dbgStopSomething(c)) {
			_needRefresh = TRUE;
//			clearAllInputs(); // Should be 'suspendAllInputs' so aomResume will continue in same place
			//recordCmdIfNeeded(orgCommand);
//			return controlWithApplication;
		}
//		else
//			return controlWithUser;
		return controlWithApplication;
	} 
	if (token == "display") {
		foundToken = TRUE;
		TOMSilent silent;
		TOMUIState result = doSomething(silent,c);
		if (result == controlWithUser) {
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "refresh") {
		foundToken = TRUE;
		TOMRefresh refresh;
		TOMUIState result = doSomething(refresh,c);
		if (result == controlWithUser) {
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "watch") {
		foundToken = TRUE;
		TOMLoud loud;
		TOMUIState result = doSomething(loud,c);
		if (result == controlWithUser) {
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "timestamp") {
		foundToken = TRUE;
		if (timestampSomething(c)) {
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	} 
	if (token == "notifytime") 
	{
		foundToken = TRUE;
		if (timestampSomething(c)) {
			OMString timeStr;
			eatOneToken(c, timeStr);
			requestTimeNotification((OxfTimeUnit)(atoi(timeStr.GetBuffer(0))));
			recordCmdIfNeeded(orgCommand);
			return controlWithUser;
		}
	}
	if (token == "showTokens") 
	{
		foundToken = TRUE;
		if (doShowTokens(c)) {
			return controlWithUser;
		}
	}
	if (!foundToken)
	{
		errMsg = "Unrecognized command";
	}
	errMsg += "\nFailed to do ";
	errMsg += command;
	tomSendError(errMsg);
	return controlWithUser;
}

OMBoolean TOMUI::callImmediateHiddenOperation(char*& c)
{
	return callOperation(c, false, true);
}

// should be called only by test conductor
// to get a notification after a certain time
void TOMUI::requestTimeNotification(OxfTimeUnit time)
{
	AnimTimeRequest* timeRequest = new AnimTimeRequest();
	timeRequest->setTimeInterval((int)time);
	TOMDispatcher::instance()->encodeAndSendMessage(timeRequest);


}

OMBoolean TOMUI::doShowTokens(char *& c) 
{
	// Check if proxyConsole exists - otherwise no destination for output
	if (TOMProxyConsole::instance()==NULL) {
		errMsg = "Cannot do SHOW when output window is closed";
		return FALSE;
	}

	char * oldC = c;

	// Get the item
	TOMProxyItem * item = TOMSystem::instance()->name2Item(c);
	if (isCodeItem(item)) {	// Item not found
		sendInValidNameError(oldC);
		return FALSE;
	}

	// Get the Data if present
	OMString token;
	eatOneToken(c,token,".->:(),*&[]");

	OMSData* msg = new OMSData(item->getReal(), tokenValues);
	msg->addItem(token.GetBuffer(0));
	TOMDispatcher::instance()->sendMessage(msg);
	return TRUE; 
}

const int commandLineSize = 1024;

TOMUIState TOMUI::getAndDoUserRequest() {
	char line[commandLineSize];
	TOMUIState res;

	// Get a command
	// 1. Freeze output channels to avoid output clashes
	// This is necessary specifically to avoid the mess other thread cout
	// outputs messing up cin. 
	// But also makes for more readable output messages
	if (TOMProxyConsole::instance()) {
		TOMProxyConsole::instance()->disallowOutput();
	// 2. Write the prompt
		TOMProxyConsole::instance()->notifyRawMessage(
			"Please enter OMTracer Command>> ",TRUE);
	}
	// 3. Get the input
	readLine(line,commandLineSize);
	// 4. Echo the input
	if (TOMProxyConsole::instance()) {
		TOMProxyConsole::instance()->notifyRawMessage(line, readingFromFile());
		TOMProxyConsole::instance()->notifyRawMessage("\n", readingFromFile());
	// 5. Free the output channels
		TOMProxyConsole::instance()->allowOutput();
	}

	res = doUserRequest(line);
	return res;
}


void TOMUI::uiTakeStart()
{
	TOMProxyConsole::createInstance();
	setInput("OMTracer.cfg", FALSE, TRUE);
}


TOMUI * TOMUI::_instance = NULL;

void createUIGUI() {
	if (TOMUI::_instance==NULL) {
#ifdef OMTRACER
		TOMUI::_instance = new TOMUI();
#endif
#ifdef OMANIMATOR
		TOMUI::_instance = new TOMGUI();
#endif
	}
}

TOMUI * TOMUI::instance() 
{
	if (_instance == NULL)
		createUIGUI();
	return _instance; 
}


//
//	 TOMGUI Methods
//
#ifdef OMANIMATOR
#include "tomExtern.h"

OMMap<OMString, int> TOMGUI::m_AppName2HasControlMap;
OMMap<OMString, TOMUIState> TOMGUI::m_AppName2MyStateMap;

void TOMGUI::setOutput(omostream* os)
{
	if (TOMProxyConsole::instance())
		TOMProxyConsole::instance()->addAnimationOutput(os);
}

void TOMGUI::uiTakeStart() { 
	TOMExterns::Anim()->omAnimationStart();
	setInput("OMAnimator.cfg", FALSE, TRUE);
}

void TOMGUI::passControlToUser() {
	// First read commands from "file" if an input file is open
//	myState=controlWithUser;
	setMyStateOfCurrentApplication(controlWithUser);

	TOMSystem::instance()->notifyReadyForInput();

	while (/*myState*/getMyStateOfCurrentApplication()==controlWithUser && !inputs.isEmpty()) {
		// Get the "current input source"
		omistream*file = getActiveInStream();
		char line[commandLineSize];
		// If we have a "current input source" and
		// we actually read something from it - do what is needed
		if (file!=NULL && actualyReadLine(file,line,commandLineSize)) {
			// Note we do not block output as animation has only
			// one thread that can write to "outputs"
			// If we have a proxyConsole display the command on it
			if (TOMProxyConsole::instance()) {
				// Write the prompt
				OMString msg = "Command From File>> ";
				// Echo the input
				msg += line;
				msg += '\n';
				TOMProxyConsole::instance()->notifyRawMessage(msg);
			}
			// Analyze and execute the command
			//myState = doUserRequest(line);
			setMyStateOfCurrentApplication(doUserRequest(line));
		}
	}
	if (/*myState*/getMyStateOfCurrentApplication()==controlWithUser)
		setControlOfCurrentApplication(0);//m_HasControl = 0;
	// refresh observers
	if (_needRefresh){
		refresh();
	}
}

void TOMGUI::refresh() 
{
	if (TOMSystem::sysInSilentMode()) {
		// if in silent mode everyone should show himself,
		// if not in silent mode then everything is updated already
		TOMRefresh refresh;
		TOMSystem::instance()->accept(refresh);
		_needRefresh = FALSE;
	}
}

TOMGUI::TOMGUI()
{
	setControlOfCurrentApplication(1);
}

TOMGUI::~TOMGUI()
{
	m_AppName2HasControlMap.removeAll();
	m_AppName2MyStateMap.removeAll();
}

int TOMGUI::hasControl()
{
	int nHasControl = 1, nTmpHasControl;
	OMString compName(TOMExterns::Anim()->GetActiveAppName());
	if(m_AppName2HasControlMap.lookUp(compName, nTmpHasControl))
		nHasControl = nTmpHasControl;
	else
	{
		//no entry in the map for this current application, therefore, create an entry
		m_AppName2HasControlMap.add(compName, nHasControl);
	}
	return nHasControl;
}

void TOMGUI::getControl()
{
	setControlOfCurrentApplication(1);
}

void TOMGUI::setControlOfCurrentApplication(int a_nHasControl)
{
	int nTmpHasControl;
	OMString compName(TOMExterns::Anim()->GetActiveAppName());
	if(m_AppName2HasControlMap.lookUp(compName, nTmpHasControl))
	{
		//if entry exist for this application remove it first from the map.
		m_AppName2HasControlMap.remove(compName);
	}
	m_AppName2HasControlMap.add(compName, a_nHasControl);
}

TOMUIState TOMGUI::getMyStateOfCurrentApplication()
{
	TOMUIState state = waitForStart, tmpState;
	OMString compName(TOMExterns::Anim()->GetActiveAppName());
	if(m_AppName2MyStateMap.lookUp(compName, tmpState))
		state = tmpState;
	else
		m_AppName2MyStateMap.add(compName, state);
	
	return state;
}

void TOMGUI::setMyStateOfCurrentApplication(TOMUIState a_State)
{
	TOMUIState state;
	OMString compName(TOMExterns::Anim()->GetActiveAppName());
	if(m_AppName2MyStateMap.lookUp(compName, state))
	{
		//if entry exist for this application remove it first from the map.
		m_AppName2MyStateMap.remove(compName);
	}
	m_AppName2MyStateMap.add(compName, a_State);
}

void TOMGUI::notifyControl()
{
	TOMUIState state = getMyStateOfCurrentApplication();
	if (state==waitForStart) {
		uiTakeStart();
	}
	setMyStateOfCurrentApplication(controlWithUser);
	passControlToUser();
}

void TOMGUI::removeInfoOfSpecificSocket(void* pSocket)
{
	TOMUIState state;
	int nHasControl;
	OMString compName(TOMExterns::Anim()->GetAppNameBySocket(pSocket));
	if(m_AppName2MyStateMap.lookUp(compName, state))
		m_AppName2MyStateMap.remove(compName);
	if(m_AppName2HasControlMap.lookUp(compName, nHasControl))
		m_AppName2HasControlMap.remove(compName);
}

TOMExterns* TOMExterns::_theExterns=NULL; // To break TOM-->rhapsody loop

#endif

void TOMGUI::getDebugStopCommand(char* cmd, const gen_ptr taskId, const OMBoolean isRhpBreakpoint, const OMBoolean isStoppedByDebugger) const
{
	const char* sprintfStr = "aomdbgstop  0x%I64x %s %s";
	const char* isRhpBreakpointStr = (isRhpBreakpoint ? "true" : "false");
	const char* isStoppedByDebuggerStr = (isStoppedByDebugger ? "true" : "false");
	sprintf(cmd, sprintfStr, taskId, isRhpBreakpointStr, isStoppedByDebuggerStr);
}


//
// $Log: tomstep.cpp $
// Revision 1.137  2007/05/29 12:01:53  ilelpa
// Timer service for RTC
// Revision 1.136.1.1  2007/04/01 07:39:47  ilelpa
// Duplicate revision
// Revision 1.135  2007/03/11 13:14:46  ilgiga
// Change copyright comment
// Revision 1.134  2007/03/04 15:07:37  ilgiga
// Telelogic instead of i-Logix
// Revision 1.133  2007/01/30 15:01:41  ilyuzh
// In case when debugging with eclipse don't send unnessecary becameDeactivated
// Revision 1.132  2006/11/23 08:51:58  ilchco
// fixed regression when having a OMAnimator.cfg file, nothing happens.
// Revision 1.131  2006/10/31 08:58:54  ccohen
// support running multiple animation processes.
// Revision 1.130  2005/11/13 11:50:42  ovol
// compilation warning fix
// Revision 1.129  2005/11/10 13:42:58  ovol
// treat empty string ("") as legal parameter
// Revision 1.128  2005/08/23 14:50:48  amos
// bugfix 85444 to main branch
// Revision 1.127.1.2  2005/08/22 10:05:43  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.127  2005/07/12 15:19:16  vova
// Safe programming: merge with 1.125.1.1
// Revision 1.126  2005/06/23 07:01:07  vova
// VxWorks with IDE:setFocusThread added,when breakpoint is achieved
// Revision 1.125.1.1  2005/07/11 11:21:40  vova
// Safe programming added.
// Revision 1.125  2005/02/07 17:58:01  vova
// 80361: empty array initialization added to avoid wrong path passing.
// Revision 1.124  2004/09/27 08:35:15  eldad
// Fixed 72581 (logging the quit command)
// Revision 1.123  2004/06/07 12:02:32  eldad
// To main branch (notifyApplicationIdle())
// Revision 1.122.1.2  2004/06/07 07:44:52  eldad
// Revision 1.122  2004/05/27 13:06:24  eldad
// Support LogCmd tracing command
// Revision 1.121.1.1  2004/01/21 08:19:19  eldad
// Duplicate revision
// Revision 1.120  2004/01/19 14:06:15  eldad
// use OM_SEARCH_ENV(name,searchpath,path) 
// to avoid build errors for the RTOSes
// Revision 1.119  2004/01/18 10:18:33  eldad
// To main branch.
// Revision 1.118.1.2  2004/01/13 16:23:44  eldad
// Search path TOMPATH for the input command
// Revision 1.118  2002/12/03 13:31:43  amos
// remove the block on loading of "OMTracer.cfg" in Borlad 5.5
// Revision 1.117  2002/12/01 12:25:40  gio
// BCC55 does not support tracer files:
// added #ifdef OM_NO_TRACER_FILE
// at TOMUI::uiTakeStart() before setInput func call.
// Revision 1.116  2002/11/25 11:49:54  Eldad
// Added notification when an operation call is issued from TOM.
// Revision 1.115  2002/10/01 08:54:00  Eldad
// Replaced online help with documentation.
// Revision 1.114  2002/09/30 12:04:40  Eldad
// 1.113.1.2 to main branch.
// Revision 1.113.1.2  2002/09/29 14:07:58  Eldad
// Changed the "better help" to refer to the on line help.
// Revision 1.113.1.1  2002/07/31 12:32:01  Eldad
// Duplicate revision
// Revision 1.112  2002/07/29 16:51:05  builder
// fix build errors
// Revision 1.111  2002/07/29 09:48:28  Eldad
// Merge 1.110 + 1.107.3.1
// Revision 1.110  2002/07/25 14:47:56  vova
// Syntax error fixed in animation message
// Revision 1.109  2002/07/15 12:29:34  avrahams
// Back to main
// Revision 1.108  2002/07/07 15:23:06  amos
// framework cleanup from RTOS specific code - back to r41 main branch
// Revision 1.107.2.2  2002/07/07 15:23:06  amos
// replace adaptor specific #ifdef with generic statements
// Revision 1.107.2.1  2002/06/06 12:24:45  amos
// Revision 1.107.1.2  2002/07/04 11:22:56  avrahams
// Cleanup std namespace usage
// Revision 1.107.1.1  2002/06/06 12:24:45  avrahams
// Duplicate revision
// Revision 1.107.3.1  2002/07/29 09:42:42  Eldad
// Revision 1.107  2002/06/06 12:24:45  avrahams
// Add Nucleus and Integrity adaptors frame work changes
// Revision 1.106  2001/10/01 12:01:47  Eldad
// 1.105.1.2 to main branch.
// Revision 1.105.1.2  2001/09/16 09:34:06  Eldad
// 
// --- Added comments ---  Eldad [2001/09/16 09:34:49 GMT]
// Left overs of indeces were left which prevented the mask in the show command from being read correctly.
// Revision 1.105  2001/08/23 09:19:40  Eldad
// Merged with 3.0.1 (1.103) , 1.102 and 1.103 were skipped (by mistake).
// Revision 1.103  2001/07/08 12:02:29  Eldad
// Enabling compilation on psos GNU compiler.
// Revision 1.102  2001/05/21 11:48:28  Eldad
// 1.101.1.2 to main branch.
// Revision 1.101.1.2  2001/05/17 09:48:14  Eldad
// Notification when user has control.
// Revision 1.101.1.1  2001/04/23 14:56:32  Eldad
// Duplicate revision
// Revision 1.104  2001/08/01 14:01:41  yachin
// Fix bug 32115
// Revision 1.101  2001/04/23 14:56:32  amos
// add QNX support
// Revision 1.100  2000/12/25 11:36:52  amos
// move to warning level 4
// Revision 1.99  2000/11/08 14:36:25  amos
// back to main branch
// Revision 1.98.1.2  2000/11/08 14:36:25  amos
// (38578) in decodeParameter() function, add code that disable injection of events with array argument.
// This is a temporary block until we'll support this kind of injection.
// Revision 1.98.1.1  2000/09/06 15:54:01  amos
// Duplicate revision
// Revision 1.97  2000/08/06 07:38:44  amos
// merge 1.94.1.4 (36668,36667) into 1.96
// Revision 1.96  2000/06/07 14:27:38  amos
// merge 1.94.1.2 (fix 35444) into 1.95
// Revision 1.95  2000/05/26 06:51:31  yachin
// Remove DLL dependencies
// Revision 1.94.1.4  2000/07/19 13:24:40  beery
// Comply with Solaris strict checking of assign "" to char*
// Revision 1.94.1.3  2000/07/12 06:54:24  amos
// changes related to modify char* to const char*.
// Revision 1.94.1.2  2000/06/07 07:11:15  amos
// modify commandLineSize to 1024 (1023 user characters)
// Revision 1.94.1.1  2000/03/14 07:38:41  amos
// Duplicate revision
// Revision 1.94  2000/03/14 07:38:41  yachin
// update trace help (34587)
// Revision 1.93  2000/01/31 09:51:50  amos
// back to main branch
// Revision 1.92.1.2  2000/01/30 07:45:36  amos
// let the AOMDispatcher know if it should send the time stamp
// Revision 1.92  2000/01/19 12:35:24  amos
// back to main branch
// Revision 1.91.1.1  2000/01/12 14:06:20  amos
// null transition step - interested in regular step as well
// Revision 1.91  2000/01/04 15:03:50  amos
// support go next
// changle go step, to stop after each NULL transition
// Revision 1.90  2000/01/03 16:26:06  amos
// add support in single step mode
// Revision 1.89  1999/10/14 17:59:41  yachin
// Provide better error message on instance not found
// Revision 1.88  1999/09/05 23:12:41  yachin
// Merge with Beery
// Revision 1.87  1999/08/16 13:55:21  sasha
// Replace stricmp to compare with NoCaseString instance
// Revision 1.86  1999/08/15 15:48:10  beery
// Revision 1.84.1.1  1999/08/11 17:03:18  beery
// adding timestamp in tracer mode
// Revision 1.85  1999/07/15 11:49:42  yachin
// Allow GEN(x,y) notation
// Revision 1.84  1999/03/11 13:37:23  ofer
// bugfix 30014 and 29565 ( the same bug )
// passing 1 more parameter to dbgBreakpointNotify(taskid,isRhpBrk)
// send to the tom this value and  if isRhpBrk is not zero we
//  DO NOT inform the user about debugger breakpoint.
// FIRST PHASE of bugfixes 30014 and 29565
// mainfrm.cpp ideabs.h wtxinterface.cpp and tomstep.cpp
// Revision 1.83  1999/02/21 13:27:57  yachin
// Fix loop bug in 'input loop.cfg'
// Revision 1.82  1999/02/18 11:27:14  yachin
// Fix regression on initial call stack entry
// Revision 1.81  1999/02/16 05:57:01  yachin
// Speed up of constructors
// Revision 1.80  1999/01/07 12:07:39  ofer
// notifyiing stoppedByDebugger instead of StoppedByUser
// when we get aomdbgbrk [taskid] command
// Revision 1.79  1998/12/24 14:36:59  ofer
// added support of command "go fromdbg" which continue
// and preserve the interest masks
// Revision 1.78  1998/12/17 14:36:41  ofer
// handle aomdbgstop message which is breakpoint from debugger
// Revision 1.77  1998/11/30 11:44:46  beery
// Revision 1.76  1998/11/23 09:52:06  beery
// Revision 1.75  1998/11/22 15:53:41  beery
// Revision 1.74  1998/11/22 14:18:22  beery
// Revision 1.73  1998/11/19 17:58:45  beery
// Revision 1.72  1998/11/17 13:15:40  beery
// Revision 1.71  1998/11/17 13:02:42  beery
// Revision 1.70  1998/08/02 15:06:38  beery
// changing boolean->OMBoolean
// Revision 1.69  1998/06/18 13:10:02  beery
// 6435
// Revision 1.68  1998/06/16 08:21:53  beery
// using get instead of getline to overcome a STL problem
// Revision 1.67  1998/04/13 08:27:54  ofer
// remove the ios::nocreate fro class to ifstream ctor
// when using STL ( OM_USE_STL is defined)
// Revision 1.66  1998/04/13 07:40:59  ofer
// added "using namespace std;" after each include to stl files
// Revision 1.65  1998/04/12 12:17:46  ofer
// Change includes to Stl format ifdefed by OM_USE_STL
// Revision 1.64  1998/03/09 06:09:48  yachin
// fixed spelling mistake bug 5018
// Revision 1.63  1998/01/07 14:30:05  ofer
// cannot use ios::nocreate in unix iostreams 
// somhow is does not open/create the file correctrly for READING
// Revision 1.62  1997/10/29 13:43:44  yachin
// Revision 1.60  1997/09/16 11:21:59  yachin
// Fix bug #3426
// Revision 1.59  1997/08/07 12:18:06  yachin
// Notify user when "input" command fails
// Revision 1.58  1997/06/09 09:14:56  nili
// define variables out of the for-loop block
// since it is used after the for-loop 
// tomattr.cpp tomobs.h tomstep.cpp
// Revision 1.57  1997/05/27 09:02:50  yachin
// Made tomstr == ystr
// Revision 1.56  1997/04/07 23:06:32  ofer
// Move file names and includes to lowercase
// so UNIX will work with lowercase versions
// Revision 1.55  1997/02/26 07:58:02  yachin
// modified x2String to take 2 parameters
// Revision 1.54  1997/02/21 08:56:45  yachin
// Added show #all events
// Revision 1.53  1997/02/12 11:15:41  yachin
// Rewrite of TOMProxyItem(...)
// Revision 1.52  1997/02/12 06:11:22  yachin
// Fixes for Unix proting
// Revision 1.51  1997/02/05 13:38:54  yachin
// Bug fixes
// Revision 1.50  1997/02/03 09:26:58  yachin
// Events with parameters
// Revision 1.49  1997/01/29 13:05:50  yachin
// Revision 1.48  1997/01/21 11:08:50  yachin
// changed _int32 to int
// Revision 1.47  1997/01/21 10:52:50  yachin
// User Threads part I
// Revision 1.46  1997/01/13 11:38:59  yachin
// Make constructor/destructor mult=2 notifications
// Revision 1.45  1997/01/12 13:36:21  yachin
// Revision 1.44  1996/12/30 13:04:36  yachin
// Revision 1.43  1996/12/30 09:56:48  yachin
// Multi Thread support part III
// Revision 1.42  1996/12/26 09:48:44  yachin
// Revision 1.41  1996/12/25 13:38:32  yachin
// Multi-Threading first shot
// Revision 1.40  1996/12/22 06:46:20  yachin
// Fix '_' bug in eventNames
// Revision 1.39  1996/12/04 08:56:33  yachin
// Revision 1.38  1996/11/24 12:40:45  yachin
// Revision 1.37  1996/11/12 09:30:52  yachin
// Change semantics of go event
// Revision 1.36  1996/11/11 11:54:27  yachin
// Support multi-thread part I
// Revision 1.35  1996/11/10 11:27:30  yachin
// added checks for breakpoint entries
// Revision 1.34  1996/11/07 09:06:43  yachin
// Fix bug 1509
// Revision 1.33  1996/11/05 07:20:21  yachin
// Fixed crash in "end animation"
// Revision 1.32  1996/10/29 08:28:49  yachin
// Revision 1.31  1996/10/28 09:49:57  yachin
// Revision 1.30  1996/10/24 12:56:41  yachin
// Rewrite of observer registration mechanism + new instance iterators
// Revision 1.29  1996/10/23 10:10:03  yachin
// Revision 1.28  1996/10/22 12:27:43  yachin
// Revision 1.27  1996/10/22 12:05:00  yachin
// Revision 1.26  1996/10/21 11:39:26  yachin
// Cleanup on state notifies + fixes on timeouts + support for breakpoints
// Revision 1.25  1996/10/15 13:29:58  yachin
// add mask and break options to interface
// Revision 1.24  1996/10/14 13:26:21  yachin
// Handle sub classes and set/cancel timeout
// Revision 1.23  1996/10/10 13:56:13  yachin
// Revision 1.22  1996/10/09 07:37:12  yachin
// Revision 1.21  1996/10/02 08:40:54  yachin
// Hopefully fixed "early" relation registration bug
// Revision 1.20  1996/10/01 06:56:24  yachin
// Fixing the "show class all" bug
// Revision 1.19  1996/09/30 10:05:31  yachin
// Revision 1.18  1996/09/30 06:31:21  yachin
// Fix setInput to be public and not produce message on init
// Revision 1.17  1996/09/29 12:16:40  yachin
// Fix bug with commens
// Revision 1.16  1996/09/29 08:04:20  yachin
// In ANIMATION: Read from input file before "promting to user"
// Revision 1.15  1996/09/25 13:45:46  yachin
// Minor Bug fixes
// Revision 1.14  1996/09/18 06:55:42  ofer
// interface with tomanim is done via global functions
// added omAnimationStart and omSendMessage whih are called by
// tomanim (tomdisp.cpp tomstep.cpp)
// Revision 1.13  1996/09/16 12:44:44  ofer
// passControltoUser --> passControlToUser (tomstep.cpp/h)
// Revision 1.12  1996/09/16 09:46:28  ofer
// implement uiTakeStart
// cause garabage include of half of the word since i need mainfrm.h
// Revision 1.11  1996/09/16 09:28:38  yachin
// Revision 1.10  1996/09/08 13:29:00  yachin
// Registeration of items which do not yet exist
// Revision 1.9  1996/09/03 12:01:17  yachin
// Alow show #callStack
// Revision 1.8  1996/09/01 11:30:02  yachin
// Revision 1.7  1996/09/01 06:35:56  ofer
// Revision 1.6  1996/08/14 12:40:25  yachin
// Seperate TOM Masks from AOM Masks. Fix bugs with attr. and states
// Revision 1.5  1996/08/12 12:28:51  yachin
// Unified Interface for "file" and "stdin". seperated show from trace
// Revision 1.4  1996/08/08 08:23:31  yachin
// Revision 1.3  1996/08/07 05:29:28  yachin
// Link fix
// Revision 1.2  1996/08/06 12:55:57  yachin
// Revision 1.1  1996/08/06 12:53:25  yachin
// Initial revision
//
