#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomC.cpp 1.16 2007/03/11 13:14:40 ilgiga Exp $";
#endif

/*
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomC.cpp $
//	file version:	$Revision: 1.16 $
//
//	purpose:	Interface for C.
//
//	author(s):	  Amos Ortal
//
//	date started:	31.5.1999
//	date changed:	$Date: 2007/03/11 13:14:40 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1999, 2008. All Rights Reserved.
//
*/


#include "toxf.h"
#include "tomC.h"
#ifdef USE_IOSTREAM
#ifndef OM_FORCE_STDIO
#ifdef OM_STL
#include <iostream>
#else
#include <iostream.h>
#endif
#endif /* OM_FORCE_STDIO */
#endif /* USE_IOSTREAM */
#include "tomdisp.h"

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomC_H;
#endif

/** handle a message **/
void TOMDispatcher_handleMessage(char * msg)
{
	OMSData * s = OMSData::string2OMSData(msg);
	TOMDispatcher::instance()->handleMessage(s);
	delete s;
}

/** close the TOM **/
void TOMDispatcher_quitTOM()
{
	TOMDispatcher::instance()->quitTOM();
}

/** psos init iostream entry point **/
#ifdef USE_IOSTREAM
#ifdef OM_NEED_INIT_IOSTREAMS_RIC_TRACE
void TRiCInitIOStream(int b1,int b2,int b3,int f)
{
	InitIostream(b1, b2, b3, f);
}
#endif
#endif

/*
// $Log: tomC.cpp $
// Revision 1.16  2007/03/11 13:14:40  ilgiga
// Change copyright comment
// Revision 1.15  2007/03/04 15:07:28  ilgiga
// Telelogic instead of i-Logix
// Revision 1.14  2005/08/23 14:50:41  amos
// bugfix 85444 to main branch
// Revision 1.13.1.2  2005/08/22 10:05:37  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.13  2005/05/05 08:34:52  vova
// 82143: spelling fixed
// Revision 1.12  2004/05/11 14:15:21  vova
// Linux warnings
// Revision 1.10  2002/07/15 12:29:30  avrahams
// Back to main
// Revision 1.9  2002/07/07 15:06:48  amos
// framework cleanup from RTOS specific code - back to r41 main branch
// Revision 1.8.1.2  2002/07/07 15:06:48  amos
// replace adaptor specific #ifdef with generic statements
// Revision 1.8.1.1  2002/07/04 13:49:19  amos
// Duplicate revision
// Revision 1.7.1.2  2002/07/04 11:08:57  avrahams
// Cleanup std namespace usage
// Revision 1.7  2000/10/16 19:48:26  vova
// Psos 2.5 changes for RiC: compilation error for MS
// Revision 1.6  2000/10/12 01:07:25  vova
// Back to main branch
// Revision 1.5.1.2  2000/10/12 00:47:54  vova
// Psos 2.5 changes for RiC
// Revision 1.5.1.1  2000/09/06 15:58:25  vova
// Duplicate revision
// Revision 1.3  1999/10/17 14:53:04  amos
// add new method TRiCInitIOStream() which init the iostream for psos x86 in C.
// Revision 1.2  1999/08/24 13:32:23  sasha
// Delete recieved message on tracing
// Revision 1.1  1999/06/01 13:33:27  amos
// Initial revision

*/
