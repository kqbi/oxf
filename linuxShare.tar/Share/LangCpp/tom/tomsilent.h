#ifndef tomsilent_H
#define tomsilent_H "$Id: tomsilent.h 1.3 2007/03/11 13:14:46 ilgiga Exp $"

//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomsilent.h $
//	file version:	$Revision: 1.3 $
//
//	purpose:		run silent
//
//	author(s):		Beery Holstein
//	date started:	10.98
//	date changed:	$Date: 2007/03/11 13:14:46 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1998, 2008. All Rights Reserved.
//

#include "tomvisitor.h"
class TOMProxyItem;

class TOMSilent : public TOMProxyVisitor1Arg  {
public:
	virtual OMBoolean execute(TOMProxyItem & proxy);
};

class TOMLoud : public TOMProxyVisitor1Arg  {
public:
	virtual OMBoolean execute(TOMProxyItem & proxy);
};

//
// $Log: tomsilent.h $
// Revision 1.3  2007/03/11 13:14:46  ilgiga
// Change copyright comment
// Revision 1.2  2007/03/04 15:07:37  ilgiga
// Telelogic instead of i-Logix
// Revision 1.1  1998/11/30 12:36:34  beery
// Initial revision
//

#endif

