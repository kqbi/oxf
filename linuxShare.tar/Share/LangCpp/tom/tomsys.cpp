#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomsys.cpp 1.125 2007/06/10 07:49:39 ilelpa Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomsys.cpp $
//	file version:	$Revision: 1.125 $
//
//	purpose:	Implement the TOMSys class
//
//	author(s):		Yachin Pnueli
//	date started:	23.7.96
//	date changed:	$Date: 2007/06/10 07:49:39 $
//	last change by:	$Author: ilelpa $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1996, 2008. All Rights Reserved.
//


#include "tomsys.h"
#include <omcom/om2str.h>
#include "tompack.h"
#include "tomthrd.h"
#include "tombrk.h"
#include "tomclass.h"
#include "tominst.h"
#include "tomother.h"
#include "tomstep.h"
#include "tommsg.h"
#include "tommask.h"
#include "tomstr.h"
#include "tomobs.h"
#include "tomdisp.h"
#include "tomExtern.h"


#include <omcom/RiCppAnimMessages.h>
#include <omcom/AnimRhapTranslator.h>
#include <omcom/AnimIntField.h>
#include <omcom/AnimBooleanField.h>
#include <omcom/AnimListField.h>
#include <omcom/AnimMessageField.h>
#include <omcom/AnimStringField.h>
#include <omcom/AnimOpCallReply.h>
#include <omcom/AnimDebuggerBreakPoint.h>
#include <omcom/AnimForeignMessage.h>
#include <omcom/AnimNameValueData.h>
#include <omcom/AnimOpReturn.h>
#include <omcom/AnimTimeNotification.h>

#include <stdio.h>

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomsys_H;
#endif


#ifdef OMTRACER
class TOMTracer {
public:
	TOMTracer() { TOMSystem::createInstance(); }
	~TOMTracer() {
		// Tell the animation model we finish
		TOMSystem::setAnimationIsOver();
		// Remove all views
		delete TOMProxyConsole::instance();
		// Remove the model
		delete TOMSystem::instance();
	}
};
TOMTracer tomTracer;
#endif


OMBoolean TOMSystem::_animationIsActive = FALSE;
OMBoolean TOMSystem::_systemIsCreated = FALSE;
TOMSystem * TOMSystem::_instance=NULL;

TOMSystem::TOMSystem():
	TOMProxyItem((char *)("TomSystem"),omProxyOther)
	//mySilentMode(TOMLoud) 
{
	// Mark animation as active
	_animationIsActive = TRUE;
	// make TOMSystem "known" to the world
	_instance = this;
	// the singleton is known to be avialable
	_systemIsCreated = TRUE;
	// Initiate the "threadManager"
	threadManager = new TOMThreadManager();
	// Initiate the "createObserver"
	createObserver = new TOMCreateObserver();
	// Create the tomDispatcher
	TOMDispatcher::createInstance();
	// Create the UI/GUI
	createUIGUI();
	// Now we are ready to accept aplication specific items

#ifdef OMTRACER
	myMask = OMAllInterest - OMSubClassInterest;
#endif
}

TOMSystem::~TOMSystem() {
	// the singelton is not longer with us
	_systemIsCreated = FALSE;
	// Mark animation as inactive
	_animationIsActive = FALSE;
	// Remove all application specific items
	// First delete the items, them remove the entries from the list
	// Remove all items in "my" lists -- actually should delete them.

	// Packages
	{
		OMTRY {
			for(OMIterator<TOMPackage *> i(packages); (*i); ++i)
			{
				if (!tomIsValidItem(*i)) continue;	// safe programming
				delete (*i);
			}
		}
		OMCATCH_ALL {}
	}
	// Thread
	{
		OMTRY {
			delete threadManager;
		}
		OMCATCH_ALL {}
	}
	// Now remove the "application independents"
	{
		OMTRY {
			delete TOMUI::instance();
		}
		OMCATCH_ALL {}
	}
	// the tomDispatcher
	{
		OMTRY {
			delete TOMDispatcher::instance();
		}
		OMCATCH_ALL {}
	}
	// createObserver
	{
		OMTRY {
			delete createObserver;
		}
		OMCATCH_ALL {}
	}
	// the breakpoint manager
	{
		OMTRY {
			delete TOMBreakPointManager::instance();
		}
		OMCATCH_ALL {}
	}

	// map
	{
		OMTRY {
			real2Proxy.removeAll();
		}
		OMCATCH_ALL {}
	}

	// make my deletion "known" to the world
	_instance=NULL;
}


OMBoolean TOMSystem::sysInSilentMode() 
{ 
	if ( _systemIsCreated == FALSE) {
		// the system can not be in silent until the singelton is created
		return FALSE;
	}
	else {
		// if the singelton exists, then look for its status
		return (instance()->inSilentMode()); 
	}
}

TOMPackage* TOMSystem::name2Package(const OMString& name) const {
	for(OMIterator<TOMPackage *> i(packages); *i; ++i) {
		if ((*i)->getFirstName()==name)
			return *i;
	}
	// Patch for 2.5 Alpha
	OMBoolean shouldIncreaseLevel = TRUE;
	for (int level = 1; shouldIncreaseLevel; level++) {
		shouldIncreaseLevel = FALSE;
		for(OMIterator<TOMPackage *> i(packages); *i; ++i) {
			// Get a package
			OMString cName = (*i)->getFirstName();
			char* tmp = cName.GetBuffer(0);
			// remove from it's name 'level' prefixes
			for(int j=0; j<level && tmp[0]!='\0'; j++) {
				OMString dummy;
				eatOneToken(tmp,dummy);
				if (isPackageCallString(tmp))
					tmp = skipPackageCallString(tmp); // Skip "::"
			}
			// If something is left check fitness with name
			if (tmp[0]!='\0') {
				if (name==tmp) {
					return (*i); // Found
				}
				shouldIncreaseLevel = TRUE; // should try one more level
			}
		}
	}
	// end of patch for 2.5 Alpha

	// with lazy evaluation the package may be not there yet .....
	return (TOMPackage*)TOMPossibleButNonExistent;
}

TOMClass* TOMSystem::name2Class(const OMString& name) const {
	// Delegate the request to the packages
	for(OMIterator<TOMPackage *> i(packages); *i; ++i) {
		TOMClass * item = (*i)->name2Class(name);
		if (isRealItem(item))
			return item;
	}
	// with lazy evaluation the package may be not there yet .....
	return (TOMClass*)TOMPossibleButNonExistent;
}

TOMClass* TOMSystem::name2Class(const OMString& packageName,const OMString& className) const {
	TOMPackage* p = name2Package(packageName);
	if (isCodeItem(p))
		return (TOMClass*)p;
	else return p->name2Class(className);
}

TOMEventClass* TOMSystem::name2EventClass(const OMString& name, void* pSocket) const {
	// Delegate the request to the packages
	for(OMIterator<TOMPackage *> i(packages); *i; ++i) {
		TOMEventClass * item = (*i)->name2EventClass(name, pSocket);
		if (isRealItem(item))
			return item;
	}
	// with lazy evaluation the package may be not there yet .....
	return (TOMEventClass*)TOMPossibleButNonExistent;
}

TOMEventClass* TOMSystem::name2EventClass(const OMString& packageName,const OMString& eventName, void* pSocket) const {
	TOMPackage* p = name2Package(packageName);
	if (isCodeItem(p))
		return (TOMEventClass*)p;
	else return p->name2EventClass(eventName, pSocket);
}

TOMInstance* TOMSystem::name2Instance(char *& name) const {
	TOMProxyItem * item = name2Item(name);
	if (isCodeItem(item) || item->getType()==omProxyInstance)
		return (TOMInstance *) item;
	else if (item->getType()==omProxyClass) {
		TOMInstance * inst = ((TOMClass *)item)->getTomNameGiver()->getFirstConcept();
		if (NULL != inst)
			return inst;
		else
			return (TOMInstance *)TOMPossibleButNonExistent;
	}
	return (TOMInstance *)OMGarbage;
}


inline TOMProxyItem* TOMSystem::name2Internal(char *& itemName) const {
	OMString name;
	eatOneToken(itemName,name,"#");
	 // Loose the case sensitivity
	NoCaseString noCaseName(((OMString)name).GetBuffer(0));
	// Check if the name is one of the predetermined key words
	if (noCaseName =="#CallStack") {
		TOMThread* t = threadManager->getFocusThread();
		if (NULL==t)
			return OMGarbage;
		else
			return t->getCallStack();
	} else if (noCaseName =="#EventQueue") {
		TOMThread* t = threadManager->getFocusThread();
		if (NULL==t)
			return OMGarbage;
		else
			return t->getEventQueue();
	} else if (noCaseName =="#Stepper") {
		TOMThread* t = threadManager->getFocusThread();
		if (NULL==t)
			return OMGarbage;
		else
			return t->getStepper();
	} else if (noCaseName =="#BreakPoints")
		return TOMBreakPointManager::instance();
	else if (noCaseName =="#All")
		return (TOMSystem*)this;
	else if (noCaseName =="#Thread")
		return threadManager->name2ThreadObject(itemName);
	else if (noCaseName =="#Threads")
		return threadManager;
	else
		return OMGarbage;
}

TOMProxyItem* TOMSystem::name2Item(char *& itemName) const {
	// Take care of various 'null' cases
	if (itemName==NULL)
		return OMGarbage;
	eatWhiteSpaces(itemName);
	if (itemName[0]=='\0')
		return OMGarbage;
	// Take care of 'internal' object names
	if (itemName[0]=='#') {
		TOMProxyItem* item = name2Internal(itemName);
		if (item==NULL)
			return TOMPossibleButNonExistent;
		else
			return item;
	}
	
	// Take care of 'global' instance (global 'renamed' instances)
	for (OMIterator<const TOMInstance*> i(m_renamedInstances); *i; i++) {
		OMString s;
		(*i)->outputFullName(s);
		
		TOMClass* possibleClass = name2Class(s);

		char* origItemName = itemName;
		// does itemName contains 's' + space seperator?
		// Was:
		// if (advanceIfStartsWith(itemName,s)) {
		// Changed dueto sol2 ver. 5 compilation problem
		
		if ((possibleClass == NULL) || !isRealItem(possibleClass)) 
		{
			const char* cItemName = itemName;
			OMBoolean found = advanceIfStartsWith(cItemName,s);
			if(found && cItemName[0] == '=') //case of complex type - where instance name is equal to type parameter name
				found = false;
			itemName = (char *)(cItemName);
			if(found){
				if (isSeperator(*itemName) && *itemName != '@') {
					// this is a substring in format of <object name>:<class name> the instance was found
					if (isEndOfName(itemName))
						return const_cast<TOMInstance*>(*i);
					else
						return (*i)->name2Item(itemName);
				} else // Accidental match (kuku prefixes kukuriku)
					itemName = origItemName;
			}
		}
	}

	OMString name;
	eatOneToken(itemName,name,"#");
	if (name.IsEmpty())
		return OMGarbage;

	if (isPackageCallString(itemName)) {
		// Assume Leading Object is a package
		TOMPackage *item;
		char * savedItemName;
		// find all leading packages for the nested packages case
		do {
			item = name2Package(name);
			if (!isCodeItem(item)) { // Package found
				if (isPackageCallString(itemName)) {
					itemName = skipPackageCallString(itemName); // Skip "::"
					savedItemName = itemName;
					eatOneToken(itemName,name,"#");
				}
				else if (isClassCallString(itemName)) {
					itemName = skipClassCallString(itemName); // Skip "::"/"."
					savedItemName = itemName;
					eatOneToken(itemName,name,"#");
				}
			}
			else if(isPackageCallString(itemName)) {
				//concat the next package token, and look for the package. This is 
				//needed for when the CG doesn't generate code for a package that is 
				//emtpy
				OMString tmpName;
				name += (char*)packageCallString;
				itemName = skipPackageCallString(itemName); // Skip "::"
				eatOneToken(itemName,tmpName);
				name += tmpName;
			}
			else {
				break;
			}
		} while (isPackageCallString(itemName));

		if (!isCodeItem(item)) { 
			return item->name2Item(savedItemName);
			//return item->name2Item(itemName);
		}
		else {
			// Package not found - assume Leading Object is a nested class
			OMString tmpName;
			while (isPackageCallString(itemName)) {
				name += (char*)packageCallString;
				itemName = skipPackageCallString(itemName); // Skip "::"
				eatOneToken(itemName,tmpName);
				name += tmpName;
			}
		}
	}
		
	// Leading object starts with a class name
	TOMClass *item = name2Class(name);
	if (((item == OMGarbage) || ( item == TOMPossibleButNonExistent)) 
		&& (isEndOfName(itemName)))
		// It might still be a package
		return name2Package(name);
	else if (isEndOfName(itemName) || isCodeItem(item))
		return item;
	else
		return item->name2Item(itemName);
}



TOMProxyItem * TOMSystem::tryToRegisterObserver(TOMUniversalObserver* obs, 
											OMInterestMask theMask,
											const char * theName){
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return OMGarbage;

	char* tmpName = (char *)(theName);
	TOMProxyItem * theItem;
	if (tmpName[0]=='#')
		theItem = name2Item(tmpName);
	else
		theItem = name2Instance(tmpName);

	if ( isRealItem(theItem) ) // We found the item so register it
		theItem->registerObserver(obs,theMask);
	return theItem;
}

TOMProxyItem * TOMSystem::registerObserver(TOMUniversalObserver* obs, 
											OMInterestMask theMask,
											const char * theName){
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return OMGarbage;

	TOMProxyItem * theItem = tryToRegisterObserver(obs,theMask,theName);
	if (theItem == TOMPossibleButNonExistent)
		createObserver->addObserver(obs,theMask,(char *)(theName));
	return theItem;
}

void TOMSystem::deregisterObserver(TOMUniversalObserver * obs,
								   const char * name,
								   OMInterestMask theMask){
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	TOMProxyItem * theItem;
	char * theName = (char *)(name); // Needed as "theName" gets lost in the search
	if (name[0]=='#')
		theItem = name2Item(theName);
	else
		theItem = name2Instance(theName);

	if ( isRealItem(theItem) ) 
		// We found such an item so deregister it
		theItem->deregisterObserver(obs,theMask);
	else if (theItem == TOMPossibleButNonExistent)
		// It's in the "waiting to create list" - remove it from there
		createObserver->removeObserver(obs,(char *)(name));
}

// This should never be called - its here to avoid a "hide" warning
void TOMSystem::deregisterObserver(TOMUniversalObserver *,
								   OMInterestMask){
	OMString msg = "Warning - TOMSystem::deregisterObserver(obs,mask) called and ignored";
	tomSendWarning(msg);
}



OMBoolean TOMSystem::showYourself(TOMUniversalObserver* obs, 
								int theMask) {
	OMBoolean toWait = TOMProxyItem::showYourself(obs,theMask);
	// Iterate on all classes and "show" them
	for(OMIterator<TOMPackage *> i(packages); *i; ++i)
		if ((*i)->showYourself(obs,(theMask & (~OMThreadInterest))))
			toWait |= TRUE;
	if (theMask & OMThreadInterest) {
		threadManager->showYourself(obs,theMask);
	}
	return toWait;
}

void TOMSystem::_showYourself(TOMUniversalObserver*, int& theMask) {
	// Currently nothing to show
	theMask=OMNoInterest;
}

OMBoolean TOMSystem::addBreakPoint(OMNotify theType, const char *theData) {
	// Apply the break point "criteria" on all packages
	OMBoolean ok = FALSE;
	for(OMIterator<TOMPackage *> i(packages); *i; ++i) {
		if ((*i)->addBreakPoint(theType,theData))
			ok = TRUE;
	}
	return ok;
}

TOMProxyItem * TOMSystem::getInstanceByReal(gen_ptr real)
{
	TOMProxyItem* p = real2Proxy.getKey(real);
	if (p!=NULL)
		return p;
	/*
	for(OMIterator<TOMPackage *> i(packages); *i; ++i) {
		TOMProxyItem *n = (*i)->getInstanceByReal(real);
		if (isRealItem(n))
			return n;
	}
	*/
	return OMGarbage;
}




void TOMSystem::registerObserver(TOMUniversalObserver* obs, 
								 OMInterestMask theMask) {
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return ;

	// We go on all classes so no need for OMSubClassInterest
	theMask -= OMSubClassInterest;

	if (obs == TOMProxyConsole::instance() || theMask.isInteresting(OMUserControl)) {
		TOMProxyItem::registerObserver(obs,theMask);
	}

	// Iterate on all classes and "do it"
	for(OMIterator<TOMPackage *> i(packages); *i; ++i)
		(*i)->registerObserver(obs,theMask);

	myMask = theMask;
}

void TOMSystem::reRegisterObserver(TOMUniversalObserver* obs,
								   OMInterestMask newMask) {
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return ;

	// We go on all classes so no need for OMSubClassInterest
	newMask -= OMSubClassInterest;

	if (obs == TOMProxyConsole::instance()) {
		TOMProxyItem::reRegisterObserver(obs,newMask);
	}

	// Iterate on all classes and "do it"
	for(OMIterator<TOMPackage *> i(packages); *i; ++i)
		(*i)->reRegisterObserver(obs,newMask);

	myMask = newMask;
}

void TOMSystem::addToObserver(TOMUniversalObserver* obs,
							  OMInterestMask addMask) {
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return ;

	// We go on all classes so no need for OMSubClassInterest
	addMask -= OMSubClassInterest;

	if (obs == TOMProxyConsole::instance()) {
		TOMProxyItem::addToObserver(obs,addMask);
	}
	
	// Iterate on all classes and "do it"
	for(OMIterator<TOMPackage *> i(packages); *i; ++i)
		(*i)->addToObserver(obs,addMask);

	myMask += addMask;
}

void TOMSystem::subtractFromObserver(TOMUniversalObserver* obs, 
									 OMInterestMask subtractMask){
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return ;

	// We go on all classes so no need for OMSubClassInterest
	subtractMask -= OMSubClassInterest;

	if (obs == TOMProxyConsole::instance()) {
		TOMProxyItem::subtractFromObserver(obs,subtractMask);
	}

	// Iterate on all classes and "do it"
	for(OMIterator<TOMPackage *> i(packages); *i; ++i)
		(*i)->subtractFromObserver(obs,subtractMask);

	myMask -= subtractMask;
}

void TOMSystem::addPackage(TOMPackage * p)
{
#ifdef OMANIMATOR
	TOMMaskedObserver * obs = NULL;
	for(OMIterator<TOMMaskedObserver *> iter(observerList); *iter; iter++) {
		obs = *iter;
		p->registerObserver(obs->getObserver(), obs->getMask());
	}
#endif
	p->registerToTrace(TOMSystem::instance());
	packages.add(p);
}



TOMPackage * TOMSystem::findOrMakePackage(OMSData* s, OMSPosition& p) {
	char * packageName = s->safeGetChar(p);
	if (packageName[0]=='\0') // A special case for package-less items
		return NULL;
	// Look for the package
	TOMPackage * package = name2Package(packageName);
	if ((package==OMGarbage) || (package==TOMPossibleButNonExistent)){ 
		// Not found - create it
		package = new TOMPackage(packageName);
		addPackage(package);
	} else
		delete packageName; // Not needed as the package exists
	return package;
}
/*
OMBoolean TOMSystem::checkUnique(char * name) {
	// Look for a class
	TOMProxyItem* item = name2Class(name);
	if (item!=OMGarbage)
		return FALSE;
	// Look for an event class
	item = name2EventClass(name);
	if (item!=OMGarbage)
		return FALSE;
	// Look for a package
	item = name2EventClass(name);
	if (item!=OMGarbage)
		return FALSE;
	else
		return TRUE;
}
*/

int current = 0;
void  *proxy[1000];

#ifdef OMOMATE
DWORD64 areal[1000];
#else
void *areal[1000];
#endif

void TOMSystem::real2ProxyAdd(gen_ptr r, TOMProxyItem*p)
{
	real2Proxy.remove(r); // Needed so we don't get multiple entries
	real2Proxy.add(r,p);
	areal[current] = r;
	proxy[current] = p;
	current++;
	if (current>999) current = 0;
}

void TOMSystem::makeProxy(OMSData* s, OMSPosition p, void* pSocket)
{
	gen_ptr	realP = s->safeGetPointer(p);
	OMProxyType  t = (OMProxyType) s->safeGetCode(p);
	TOMProxyItem* theNewProxy = NULL;
	switch (t) {
	case omProxyInstance:
		theNewProxy = new TOMInstance(realP);
		break;
	case omProxyClass:
		theNewProxy = makeProxyClass(realP,s,p);
		break;
	case omProxyEventClass:
		theNewProxy = makeProxyEventClass(realP,s,p);
		break;
	case omProxyPackage:
		theNewProxy = makeProxyPackage(realP,s,p);
		break;
	case omThread:
		theNewProxy = makeProxyThread(realP,s,p);
		break;
	case omProxyBreakPointManager:
		TOMBreakPointManager::createInstance(realP);
		theNewProxy = TOMBreakPointManager::instance();
		break;
	default:
		{
			OMString errMsg = "Tracer/Animator cannot create unkonwn proxy type ";
			x2String(t,errMsg);
			tomSendError(errMsg);
		}
		break;
	}
	if (theNewProxy!=NULL)
	{
		real2ProxyAdd(realP,theNewProxy);
#ifdef OMANIMATOR
		theNewProxy->setMySocket(pSocket);
		OMString appName = TOMExterns::Anim()->GetAppNameBySocket(pSocket);
		theNewProxy->setMyAppName(appName.GetBuffer(0));
#else
		if(pSocket == NULL) {} //avoid compliation warning
#endif
	}
	createObserver->notifyNewItem();	// Notify the create observer

}

void TOMSystem::handleMessage(AnimMessage* msg) 
{
	int code = msg->getCode();
	if (code == callOpReply) 
	{
		// for now we do not use the Observers mechansim
		AnimOpCallReply *rep = (AnimOpCallReply *)msg;
		notifyOpCallReply(rep);
	}
	else if (code == foreignMsg) {
		AnimForeignMessage *fMsg = (AnimForeignMessage *)(msg);
		OMString payload = (char *)(rhp_long64_t)(fMsg->getPayload()->getValue());
		notifyForeignMessage(payload);
	}
	else if (code == timeNotification)
	{
		AnimTimeNotification* tmNotify = (AnimTimeNotification*)(msg);
		timeUnit tmDelay = (timeUnit)(tmNotify->getTimeInterval()->getValue());
		timeUnit actualDelay = (timeUnit)(tmNotify->getActualTimeInterval()->getValue());
		timeUnit elapsedTime = (timeUnit)(tmNotify->getElapsedTime()->getValue());
		notifyTimer(tmDelay, actualDelay, elapsedTime);
		notifyTimeChange(elapsedTime);
	}
	else if (code == debuggerBreak) {
		AnimDebuggerBreakPoint *dbgMsg = (AnimDebuggerBreakPoint *)msg;
		rhp_long64_t taskId = (rhp_long64_t)(dbgMsg->getTaskID()->getValue());
		OMBoolean isRhpBreakpoint = (dbgMsg->getIsRhapsodyBreak()->getValue() != 0);
		if (TOMUI::instance()) {
			if (taskId > 0) {
				const char* sprintfStr = "aomdbgstop  0x%I64x %s true";
				char cmd[DEBUG_STOP_CMD_LEN];
				sprintf(cmd, sprintfStr, (gen_ptr)taskId, (isRhpBreakpoint ? "true" : "false"));
//				TOMGUI::instance()->getDebugStopCommand(cmd, (gen_ptr)taskId, isRhpBreakpoint, TRUE); 
				(void)TOMUI::instance()->doUserRequest(cmd);
				if (isRhpBreakpoint) {
					TOMUI::instance()->passControlToUser();
				}
			}
		}
	}
}


void TOMSystem::handleMessage(OMNotify msgCode, 
							  TOMSData* s, 
							  OMSPosition p,
							  void* pSocket) {
	switch (msgCode) {
	case createProxy:
		makeProxy(s,p,pSocket);
		break;
	case classList:
		{
			int itemCount = s->safeGetInt(p);
			for(int i=0;i<itemCount;i++) {
				OMSData* itemMessage = s->safeGetOMSData(p);
				makeProxy(itemMessage, itemMessage->getFirst(),pSocket);
				delete itemMessage;
			}
			break;
		}
	case supperClassList:
		{
			// Build the super class lists from message
			while (!s->isEmpty(p))	{
				TOMNameSpaced* theClass =(TOMNameSpaced *)s->getPointer(p);
				theClass->getSuperClassList(s,p);
			}
			// Build the sub class lists from the super class lists
			for(OMIterator<TOMPackage *> i(packages); *i; ++i)
				for(OMIterator<TOMClass *> j((*i)->getClasses()); *j; ++j)
				(*j)->notifySuperClasses();
			break;
		}
	case instanceList:
		{
			int itemCount = s->safeGetInt(p);
			for(int i=0;i<itemCount;i++) {
				OMSData* itemMessage = s->safeGetOMSData(p);
				TOMDispatcher::instance()->handleMessage(itemMessage,pSocket);
			}
			break;
		}
	case instanceDeleted:
		{
			TOMThread *thread  = (TOMThread *)s->safeGetPointer(p);
			if (tomIsValidItem(thread) && threadManager)
			{
				unsigned int mask  = static_cast<unsigned int>(s->safeGetInt(p));
				OMBoolean passControlToUser = ( mask != OMNoStop && thread == threadManager->getFocusThread() );
				OMTRY {
					delete thread;
				}
				OMCATCH_ALL {
					OMString warning("Exception while deleting thread");
					tomSendWarning(warning);
				}
				TOMThread* threadInFoucus = threadManager->getFocusThread();
				if (passControlToUser) {
					// Notify the user why we stop
					TOMProxyConsole::instance()->notifyMessage(
						" Focus Thread Deleted");
					// Tell the application to stop
					OMTRY {
						TOMUI::instance()->doUserRequest((char *)("aomstop"));	
					}
					OMCATCH_ALL {
						OMString warning("failed to do user request - aomstop");
						tomSendWarning(warning);
					}
				} else if ((threadInFoucus != NULL) && (threadInFoucus->isSuspended())) {
					// Notify the user why we stop
					TOMProxyConsole::instance()->notifyMessage(" All live Threads Are suspended");
					// Tell the application to stop
					OMTRY {
						TOMUI::instance()->doUserRequest((char *)("aomstop"));	
					}
					OMCATCH_ALL {
						OMString warning("failed to do user request - aomstop");
						tomSendWarning(warning);
					}
				}
			}
			break;
		}
	case errorFound:
		tomSendError(s->safeGetChar(p));
		break;
	case becameDeactivated:
		TOMUI::instance()->notifyControl();	
			// In tracer this prompts the user to give commands
			// In animator this lights up the VCR buttons etc.
		break;
	// Messages which should never occuer
	default:
		{
		OMString errMsg = 
		"TOMSystem Received unexpected message of type ";
		errMsg += (char*)omnotify2String(msgCode);
		tomSendWarning(errMsg);
		}
	}
}

void TOMSystem::notifyTimeChange(timeUnit time)
{
	NOTIFY_OBSERVERS(OMAllInterest, notifyTimeChange(time));
}

void TOMSystem::notifyTimer(timeUnit delay, timeUnit actualDelay, timeUnit elapsedTime)
{
	NOTIFY_OBSERVERS(OMAllInterest, notifyTimer(delay, actualDelay, elapsedTime));
}


void TOMSystem::replaceItemByDestroyed(TOMInstance* destroyed) {
	threadManager->replaceItemByDestroyed(destroyed);
}

OMString TOMSystem::reqIDToCallStr(int reqID)
{
	OMString ret = reqID2CallStr[reqID];
	return ret;
}


void TOMSystem::logOpRequest(int reqID, OMString callStr)
{
	reqID2CallStr.add(reqID, callStr);
}


void TOMSystem::accept(TOMProxyVisitor1Arg & visitor) 
{
	// do for me
	/* OMBoolean result = */ (void) visitor.execute(*this);
	// do for the thread manager
	threadManager->accept(visitor);
	//do for all packages
	for(OMIterator<TOMPackage *> i(packages); *i; ++i) {
		(*i)->accept(visitor);
	}
}


TOMProxyItem* TOMSystem::makeProxyClass(gen_ptr realP,OMSData* s, OMSPosition& p)
{
	TOMProxyItem* theNewProxy = NULL;
	// Read the class Name
	char * className = s->safeGetChar(p);
	OMBoolean  isSingleton = (s->safeGetCode(p) != 0);
	TOMPackage * package = findOrMakePackage(s,p);
	// Before we create the class we check if it is unique
	//OMBoolean unique = checkUnique(className);
	
	//check if a class with the same name exists in other packages
	TOMClass* sameNameItem = name2Class(className);

	// Now create the class:
	OMBoolean  isImplicit = FALSE;
	if ( (s->getLength() < (int)p) && (s->isCode(p)) )
		isImplicit = (s->safeGetCode(p) != 0);
	// 1. Actually create it
	TOMClass * newClass = new TOMClass(realP, className,
								isSingleton, isImplicit, package);
	theNewProxy = newClass;
	// Add it to its package
	package->addClass(newClass);
	// Set the uniqueness of the class i.e. the class name is not unique
	// so a full path name is needed to idnetify each of the classes with the same name
	if ((sameNameItem != OMGarbage) && (sameNameItem != TOMPossibleButNonExistent)) {
		newClass->notifyNonUnique();
		sameNameItem->notifyNonUnique();
	}
	return theNewProxy;
}

TOMProxyItem* TOMSystem::makeProxyEventClass(gen_ptr realP,OMSData* s, OMSPosition& p)
{
	TOMProxyItem* theNewProxy = NULL;
	// Read the event class Name
	char * eventClassName = s->safeGetChar(p);
	TOMPackage * package = findOrMakePackage(s,p);
	if(package == NULL)
		return theNewProxy;
	// Before we create the class we check if it is unique
//		OMBoolean unique = checkUnique(eventClassName);
	TOMEventClass* sameNameItem= name2EventClass(eventClassName);
	// Now create the class:
	// 1. Actually create it
	TOMEventClass* newClass = new TOMEventClass(realP, 
										eventClassName, package);
	theNewProxy = newClass;
	// Add it to its package
	package->addEventClass(newClass);
	// Set the uniqueness of the class
	if ((sameNameItem != OMGarbage) && (sameNameItem != TOMPossibleButNonExistent)) {
		newClass->notifyNonUnique();
		sameNameItem->notifyNonUnique();
	}
	return theNewProxy;
}

TOMProxyItem* TOMSystem::makeProxyPackage(gen_ptr realP,OMSData* s, OMSPosition& p)
{
	TOMProxyItem* theNewProxy = NULL;
	// Find or Create the package
	TOMPackage * package = findOrMakePackage(s,p);
	theNewProxy = package;
	// Connect it to its real - done only now as hte package might
	// already exist from before when a aomclass caused its creation
	// but knew not its 'real'
	package->setReal(realP);
	return theNewProxy;
}

TOMProxyItem* TOMSystem::makeProxyThread(gen_ptr realP,OMSData* s, OMSPosition& p)
{
	TOMProxyItem* theNewProxy = NULL;
	TOMThread* newThread = threadManager->add(realP,s,p);
	theNewProxy = newThread;
	real2ProxyAdd(newThread->getCallStack()->getReal(),newThread->getCallStack());
	real2ProxyAdd(newThread->getStepper()->getReal(),newThread->getStepper());
	real2ProxyAdd(newThread->getEventQueue()->getReal(),newThread->getEventQueue());
	return theNewProxy;
}


void TOMSystem::notifyReadyForInput()
{
	NOTIFY_OBSERVERS(OMUserControl, notifyReadyForInput());
}

void TOMSystem::notifyOpCallRequestSent()
{
	NOTIFY_OBSERVERS(OMUserControl, notifyOpCallRequestSent());
}

void TOMSystem::notifyApplicationIdle()
{
	NOTIFY_OBSERVERS(OMUserControl, notifyApplicationIdle());
}

void TOMSystem::notifyForeignMessage(OMString& payload)
{
	// we use the OMUserControl as well - it is assumed that all
	// external tools would be interested in foreign messages
	// and in user control.
	NOTIFY_OBSERVERS(OMUserControl, notifyForeignMessage(payload));
}

void TOMSystem::notifyOpCallReply(AnimOpCallReply* reply)
{
	if (reply != NULL)
	{
		OMString cmdStr;
		OMString retValStr;
		OMBoolean exception = FALSE;

		OMBoolean showInConsole = (reply->getShowInConsole()->getValue()) ? true : false;
		
		if (showInConsole == true)
		{
			TOMProxyConsole::instance()->notifyOpCallReply(reply, cmdStr, retValStr, exception);
		}

		NOTIFY_OBSERVERS(OMUserControl, notifyOpCallReply(cmdStr, retValStr, exception));
	}
}

/* helper function to extract a string form a StringOrPointerField */
OMString TOMSystem::getStringOrPointerFieldValue(AnimStringOrPointerField *theField)
{
	OMString str;
	if (theField != NULL) 
	{
		if (theField->isString()) {
			char *tmp;
			tmp = (char *)(const char *)(theField->getStringValue());
			str = tmp;
			delete[] tmp;
		}
		else if (theField->isPointer()) {
			gen_ptr	aomInstance = theField->getPointerValue();
			if (aomInstance) {
				TOMInstance *tomInstance = (TOMInstance *)TOMSystem::instance()->getInstanceByReal(aomInstance);
				tominstance2String(tomInstance, str);
			}
		}
	}
	return str;
}

void TOMSystem::notifyOpReturn(TOMInstance* caller, 
							   TOMInstance* called, 
							   OMString method, 
							   OMMethodType type, 
							   OMString& retValString,  
							   OMList<OMString>& nameValList)
{
	NOTIFY_OBSERVERS(OMUserControl, notifyOpReturn(caller, called, method, type, retValString, nameValList));
}

TOMProxyItem* TOMSystem::registerPartObserver(TOMPartObserver *theObserver, 
											  TOMInstance *theInstance)
{
	TOMProxyItem *res = OMGarbage;
	if (TOMSystem::animationIsActive() && tomIsValidItem(theInstance) 
		&& (theObserver != NULL)) 
	{
		theInstance->addPartObserver(theObserver);
		res = theInstance;
	}
	return res;
}

#ifdef OMANIMATOR
void TOMSystem::DestroyAllItemsWithSpecificSocket(void* pSocket)
{
	if(!pSocket)
		return;

	unsigned int i = 0, j = 0, z = 0;
	TOMPackage* pTomPackage = NULL;
	TOMClass* pTomClass = NULL;
	TOMInstance* pTomInstance = NULL;
	OMList<TOMClass*>* pClasses = NULL;
	TOMClassNameGiver* pNameGiver = NULL;
	for(i = 0 ; i < packages.getCount() ; i++)
	{
		pTomPackage = packages.getAt(i);
		pClasses = pTomPackage->getClasses();
		if(pClasses)
		{
			for(j = 0 ; j < pClasses->getCount() ; j++)
			{
				pTomClass = pClasses->getAt(j);
				if(pTomClass && !isCodeItem(pTomClass) && pTomClass->getMySocket() == pSocket)
				{
					pNameGiver = pTomClass->getTomNameGiver();
					if(pNameGiver)
					{
						for(z = 0 ; z < pNameGiver->getCount() ; z)
						{
							pTomInstance = pNameGiver->getAt(z);
							if (!tomIsValidItem(pTomInstance)) // safe programming
								continue;	
							pTomClass->destroyInstance(pTomInstance, pTomInstance);
						}
					}
					//if there isn't another class with the same name in the current 
					//pkg (i.e. another application is running with the same class), 
					//then destroy the TOMClass too, 
					OMString className(pTomClass->getFirstName());
					OMList<TOMClass*> classes;
					pTomPackage->name2Classes(className, classes);
					if(classes.getCount() == 1)
					{
						OMList <TOMClass *>* pPkgClasses = pTomPackage->getClasses();
						if(pPkgClasses)
							pPkgClasses->remove(pTomClass);
						delete pTomClass;
					}
				}
			}
		}
	}

	//now destroy all threads created by the application that is identified by the 
	//given socket
	TOMThread* pThread = NULL;
	OMList<TOMThread *>* pThreadList = TOMSystem::threadManagerInstance()->getThreadList();
	OMList<TOMThread*> threadsToDelete;
	if(pThreadList)
	{
		for(i = 0 ; i < pThreadList->getCount() ; i++)
		{
			pThread = pThreadList->getAt(i);
			if(pThread->getMySocket() == pSocket)
				threadsToDelete.add(pThread);
		}
	}
	for(i = 0 ; i < threadsToDelete.getCount() ; i++)
	{
		pThread = threadsToDelete.getAt(i);
		delete pThread;
	}

	//now remove the state info in the TOMGUI associated with the given socket.
	TOMGUI::instance()->removeInfoOfSpecificSocket(pSocket);
}
#endif

//
// $Log: tomsys.cpp $
// Revision 1.125  2007/06/10 07:49:39  ilelpa
// Fixed timer service for OSC
// Revision 1.124  2007/05/29 12:01:56  ilelpa
// Timer service for RTC
// Revision 1.123.1.1  2007/03/21 14:22:55  ilelpa
// Duplicate revision
// Revision 1.122  2007/03/11 13:14:47  ilgiga
// Change copyright comment
// Revision 1.121  2007/03/04 15:07:38  ilgiga
// Telelogic instead of i-Logix
// Revision 1.120  2007/02/08 10:38:40  ilelpa
// Added the ability to get time notifications to observer. This is used for test conductor
// to get the time from Rhapsody instead of relying on the OS clock.
// Revision 1.119  2007/01/16 11:05:00  ilchco
// fixed potentional crash when getting name of application.
// Revision 1.117  2006/11/23 08:50:30  ilchco
// avoid compilation warning on vxworks.
// Revision 1.116  2006/11/06 09:46:29  ccohen
// fixed compilation errors/warnings in vxworks/integrity.
// Revision 1.115  2006/10/31 08:58:55  ccohen
// support running multiple animation processes.
// Revision 1.114  2005/08/23 14:50:49  amos
// bugfix 85444 to main branch
// Revision 1.113.2.2  2005/08/22 10:05:43  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.113  2004/07/26 12:14:27  vova
// Merge with 1.111.1.1
// 74072: Opening of animated statechart of initial instance in file's nested class
// Revision 1.112  2004/06/27 15:30:20  amos
// move to model-based oxf in RiC++
// Revision 1.109.1.2  2004/02/09 09:29:50  amos
// changes due to OMBoolean type change
// Revision 1.109.1.1  2003/12/24 14:34:27  amos
// Duplicate revision
// Revision 1.108.1.2  2003/12/23 16:19:03  eldad
// Revision 1.108.1.1  2003/07/24 07:12:31  eldad
// Duplicate revision
// Revision 1.107  2003/07/22 15:00:11  eldad
// Avoid crash when exiting animation
// Revision 1.106  2003/05/26 11:06:21  vova
// ESTL-Embedded C++ with Standard Templates Libraries
// Revision 1.105  2003/05/15 07:02:00  Eldad
// Serailization of output params and return value
// Revision 1.104.1.1  2003/05/08 10:07:44  Eldad
// Duplicate revision
// Revision 1.103  2002/11/25 11:49:58  Eldad
// Added notification when an operation call is issued from TOM.
// Revision 1.102.1.1  2002/11/12 07:35:37  Eldad
// Duplicate revision
// Revision 1.101  2002/10/21 16:08:50  Eldad
// Use TOMUI instead of TOMGUI - otherwise link error in VxWorks.
// Revision 1.100.1.1  2002/09/26 08:09:59  Eldad
// Duplicate revision
// Revision 1.99.1.2  2002/09/24 12:42:52  Eldad
// Revision 1.99  2002/07/29 09:34:48  Eldad
// Merge 1.97.2.1 + 1.98
// Revision 1.98  2002/07/07 14:06:52  amos
// framework cleanup from RTOS specific code - back to r41 main branch
// Revision 1.97.1.2  2002/07/07 14:06:52  amos
// replace adaptor specific #ifdef with generic statements
// Revision 1.97.1.1  2002/04/25 14:18:39  amos
// Duplicate revision
// Revision 1.97.2.1  2002/07/29 09:32:35  Eldad
// Revision 1.97  2002/04/25 14:18:39  Eldad
// Simplified "safe programming".
// Revision 1.95  2002/03/25 12:59:51  Eldad
// 1.94.1.2 to main branch.
// Revision 1.94.1.2  2002/03/19 11:02:29  Eldad
// Registering observers for lazy (C, Java)
// Revision 1.94  2001/11/12 10:49:46  Eldad
// CString -> OMString.
// Revision 1.93  2001/10/01 10:19:53  Eldad
// 1.92.1.2 to main branch 
// Revision 1.92.1.2  2001/09/26 00:48:47  Eldad
// Changed some of the erros to warnings that are not to be shown in popup 
// message box.
// Revision 1.92  2001/07/29 10:41:01  amos
// TOMSystem::handleMessage() : add safe programming in handling of instance deletion (assume possibility of no active thread while application terminating)
// Revision 1.91  2001/05/21 11:44:14  Eldad
// 1.90.1.3 to main branch
// Revision 1.90.1.3  2001/05/20 07:22:21  Eldad
// We needed to register in the TOMSystem 
// when the mask was set to include OMUserControl
// Revision 1.90.1.2  2001/05/17 09:48:15  Eldad
// Notification when user has control.
// Revision 1.90.1.1  2001/05/13 07:37:51  Eldad
// Duplicate revision
// Revision 1.89  2000/12/25 12:20:49  amos
// move to warning level 4
// Revision 1.88  2000/11/14 14:29:29  ofer
// teak the code so GNU compiler  for PPC ( VxWorks )  will work
// bugfix 30417
// Revision 1.87  2000/07/19 14:15:30  beery
// Revision 1.86  2000/07/19 13:24:39  beery
// Comply with Solaris strict checking of assign "" to char*
// Revision 1.85  2000/07/12 06:54:23  amos
// changes related to modify char* to const char*.
// Revision 1.84  2000/06/15 07:12:57  builder
// Fix for  Solaris SC5.0 compiler
// Revision 1.83  2000/01/20 07:08:02  yachin
// Fix spelling mistake
// Revision 1.82  1999/10/17 09:38:31  yachin
// Yet another fix to name2item (32560)
// Revision 1.81  1999/10/14 18:04:07  yachin
// Fix bug on mishmash of old code with new tom
// Revision 1.80.1.1  1999/10/14 15:53:31  sasha
// Check if after instanceName goes a separator character but not
// continue of the another name:
// Obj_Type[0] and Obj
// Revision 1.80  1999/10/12 13:33:02  yachin
// Fix bugs
// Revision 1.79  1999/09/27 11:18:23  israel
// 32343- Animate instance lines with the format  <name>:<class name>.
// Revision 1.78  1999/09/22 16:29:04  yachin
// Restore the removed revision
// Revision 1.78  1999/09/15 05:55:34  yachin
// Fix addToObserver/removeFromObserver (bug #32089)
// Revision 1.77  1999/09/07 23:19:01  yachin
// Remember 'global interstMask' in TOMSystem for lazy tom creations
// Revision 1.76  1999/09/06 22:56:55  yachin
// Fix name2item
// Revision 1.75  1999/08/10 14:59:49  sasha
// Find exact name of instance.
// The object with name "Composite.Server" should not be found
// Revision 1.74  1999/08/10 10:17:28  sasha
// find all leading packages for the nested packages case in 
// name2Item() function
// Revision 1.73  1999/08/03 11:19:09  yachin
// Some fixes related to name2Item
// Revision 1.72  1999/07/29 12:55:37  yachin
// Part I of fix names of nested objects
// Revision 1.71  1999/07/12 08:21:46  yachin
// Treat global rename correctly
// Revision 1.70  1999/07/11 12:52:59  yachin
// Allow name2Item to recognize global names
// Revision 1.69  1999/07/11 09:41:37  amos
// add a table for renamed global instances
// Revision 1.68  1999/06/18 09:07:49  beery
// due to lazy evaluation, make sure that new package/class/classevent are observed my the console 
// so when a new object or event are created they "inherite" their initial mask from their logical parent
// Revision 1.67  1999/06/15 15:54:19  sasha
// Show attributes values
// Revision 1.66  1999/06/10 08:41:22  beery
// support lazt evaluation by returning "not found but possible will be crearted later" instead of just "not found"
// when looking for packages, classes and events.
// Revision 1.65  1999/06/08 07:29:50  beery
// reregister the console in trace lazy mode
// Revision 1.64  1999/02/21 09:31:18  yachin
// Fix bugs on unique name and name2class
// Revision 1.63  1999/02/18 11:27:15  yachin
// Fix regression on initial call stack entry
// Revision 1.62  1999/02/16 05:57:02  yachin
// Speed up of constructors
// Revision 1.61  1999/01/14 08:19:42  yachin
// Fix the nested class bug
// Revision 1.60  1998/11/19 17:58:59  beery
// Revision 1.59  1998/11/17 13:04:11  beery
// Revision 1.58  1998/08/02 15:05:14  beery
// changing boolean->OMBoolean
// Revision 1.57  1998/06/25 08:46:18  yachin
// Fix bug 6515 - rereference deleted instances on call stack to 'inDestruction"
// Revision 1.56  1997/07/20 11:36:41  yachin
// Adding globals to animation
// Revision 1.55  1997/05/27 09:02:52  yachin
// Made tomstr == ystr
// Revision 1.54  1997/04/07 23:06:24  ofer
// Move file names and includes to lowercase
// so UNIX will work with lowercase versions
// Revision 1.53  1997/03/31 09:29:52  yachin
// Fix Unix Warnings
// Revision 1.52  1997/03/13 13:41:37  yachin
// Fix memory leaks
// Revision 1.51  1997/02/27 11:34:06  yachin
// Fix tryToRegisterObserver for instance by class name not existing
// Revision 1.50  1997/02/26 07:58:02  yachin
// modified x2String to take 2 parameters
// Revision 1.49  1997/02/21 07:22:07  yachin
// Fix event inheritance bug 2529
// Revision 1.48  1997/02/20 11:49:36  yachin
// Revision 1.47  1997/02/19 11:19:57  yachin
// Add isAnimationActive mode to all observer operations
// Revision 1.46  1997/02/19 07:51:47  yachin
// Revision 1.45  1997/02/19 07:46:55  yachin
// Revision 1.44  1997/02/16 08:23:54  yachin
// Revision 1.43  1997/02/13 09:08:31  yachin
// Bug fix on eventQueue name
// Revision 1.42  1997/02/12 11:15:43  yachin
// Rewrite of TOMProxyItem(...)
// Revision 1.41  1997/02/12 08:25:08  yachin
// Bug fix for no Current Thread case
// Revision 1.40  1997/02/11 12:54:38  yachin
// Adding Name spaces
// Revision 1.39  1997/01/29 13:05:51  yachin
// Revision 1.38  1997/01/22 11:54:10  yachin
// Inverse composite relation bug fix
// Revision 1.37  1997/01/21 11:08:51  yachin
// changed _int32 to int
// Revision 1.36  1997/01/21 10:52:51  yachin
// User Threads part I
// Revision 1.35  1997/01/19 07:37:50  yachin
// Multi-threading addenda
// Revision 1.34  1997/01/14 13:52:45  yachin
// Revision 1.33  1997/01/12 13:36:22  yachin
// Revision 1.32  1996/12/30 13:04:39  yachin
// Revision 1.31  1996/12/30 09:56:49  yachin
// Multi Thread support part III
// Revision 1.29  1996/12/22 13:13:53  yachin
// Revision 1.27  1996/11/24 12:40:46  yachin
// Revision 1.26  1996/11/18 07:37:52  yachin
// fixed bug in "current Thread"
// Revision 1.25  1996/11/14 08:10:32  yachin
// Revision 1.24  1996/11/13 12:48:42  yachin
// Revision 1.23  1996/11/11 13:16:15  yachin
// Revision 1.22  1996/11/11 11:54:29  yachin
// Support multi-thread part I
// Revision 1.21  1996/11/07 09:06:48  yachin
// Fix bug 1509
// Revision 1.20  1996/10/28 09:49:58  yachin
// Revision 1.19  1996/10/24 12:56:42  yachin
// Rewrite of observer registration mechanism + new instance iterators
// Revision 1.18  1996/10/22 08:15:39  yachin
// tomConsole now registers on breakpoint manager by name
// Revision 1.17  1996/10/21 11:39:26  yachin
// Cleanup on state notifies + fixes on timeouts + support for breakpoints
// Revision 1.16  1996/10/14 13:26:22  yachin
// Handle sub classes and set/cancel timeout
// Revision 1.15  1996/10/10 13:56:14  yachin
// Revision 1.14  1996/10/09 07:37:13  yachin
// Revision 1.13  1996/09/19 08:04:09  yachin
// Proper deletion when animation is terminated
// Revision 1.12  1996/09/17 13:43:02  yachin
// Revision 1.11  1996/09/16 09:28:39  yachin
// Revision 1.10  1996/09/09 07:25:55  yachin
// Fix bug in name2item
// Revision 1.9  1996/09/08 13:29:01  yachin
// Registeration of items which do not yet exist
// Revision 1.8  1996/09/05 13:35:57  yachin
// Revision 1.7  1996/09/03 12:01:17  yachin
// Alow show #callStack
// Revision 1.6  1996/08/29 15:01:32  ofer
// Revision 1.5  1996/08/14 12:40:26  yachin
// Seperate TOM Masks from AOM Masks. Fix bugs with attr. and states
// Revision 1.4  1996/08/12 12:28:52  yachin
// Unified Interface for "file" and "stdin". seperated show from trace
// Revision 1.3  1996/08/08 08:23:31  yachin
// Revision 1.2  1996/08/06 12:55:58  yachin
// Revision 1.1  1996/08/06 12:53:27  yachin
// Initial revision
//
