#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomlist.cpp 1.39 2007/03/11 13:14:42 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomlist.cpp $
//	file version:	$Revision: 1.39 $
//
//	purpose: Methods of Class TOMList and its derivatives	 	
//
//	author(s):		Yachin Pnueli
//	date started:	25.7.96
//	date changed:	$Date: 2007/03/11 13:14:42 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "tomlist.h"
#include "tomobs.h"
#include "tominst.h"
#ifdef OM_STL
#include <cstdio>
#else
#include <stdio.h>
#endif

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomlist_H;
#endif

//
//	TOMList methods
//

void TOMList::registerItem(TOMInstance *i) {
	if (singleton()) removeAll();	// Clear relation of old values
	add(i);							// Actually add the item
	createObserver->notifyNewItem();	// Notify the create observer
}

#define READ_ITEM(item, count,s,position)					\
	if (count) {											\
		item = (TOMInstance *)s->safeGetPointer(position);	\
		count--;											\
	} else item = NULL;


void TOMList::update(TOMSData *s, OMSPosition& p) {
	// 1. Get ready to update yourself
	// 1.1 Copy yourself to oldList
	OMList<TOMInstance *> oldList;
	for(OMIterator<TOMInstance *> i(this); *i; i++) {
		oldList.add(*i);
	}

	// 1.2 Empty myself
	removeAll();

	// 2. Get the "message" ready for comparison
	// 2.1 Get the number of instances in this class
	int count = s->safeGetInt(p);
	TOMInstance * item;

	//
	// 3. Iterate on both old and new lists
	// elements appearing in both should remain unchanged
	// elements appearing only in "old" should be deregistered
	// elements appearing only in "new" should be registered
	// WARNING: TO GET AN EFFICIENT ALGORITHM WE RELY ON THE
	// FACT THAT ITEMS ARE ORDERED IN THE LIST ACCORDING TO
	// TIME OF ENTERING THE LIST (always addTail() )
	// If this is not true - the following will do nonsense!!!!
	// As a side effect an item that left the list and returned to it
	// will be first deregistered and then (re)registered) this can happen 
	// only in TOMRelations. There it is both acceptable and efficient
	// deregister and reregister is faster than search
	//

	// 3.1 Create two iterators:
	OMIterator<TOMInstance *> old(oldList);
	// OMIterator<TOMInstance *> young(newList);
	READ_ITEM(item, count,s, p);

	// 3.2 Re-Enter all common "old" items
	for(; *old; old++) {
		if (*old == item) {
			// The current item appears in both lists so keep it.
			add(*old);
			// read next item in new list
			READ_ITEM(item, count,s,p);
		} // else // Instance no longer in relation - ignore it
	}

	// 3.3 Register all remaining "young" items
	while (item) {
		registerItem(item);
		READ_ITEM(item, count,s,p);
	}
}


inline
TOMInstance * TOMList::getInstanceByRelativeMultiplicity(int multiplicity) const {
	// Strictly speaking this is incorrect for TOMLists which are
	// not name givers - but it might be useful just the same
	int count=0;
	for(OMIterator<TOMInstance *> i(this); *i; i++) {
		if (count==multiplicity) {
			if (tomIsValidItem(*i))
				return *i;
			else
				break; 
		}
		count++;
	}
	return (TOMInstance *)TOMPossibleButNonExistent;
}


inline TOMProxyItem* TOMList::finishName2Item(char *& theName,
									   TOMInstance* item) const {
	if (isCodeItem(item)) // OMGarbage || TOMPossibleButNonExistent
		// Something was found that is not a valid address
		return item;

	// Check that the address points to a live TOMInstance
	if (!tomIsValidItem(item))
		return OMGarbage; // OMInDestruction ????

	if (isEndOfName(theName))
		return item; // No more referencing
	else // Continue down the navigation expression
		return item->name2Item(theName);
}

TOMInstance* TOMList::hashExpression2Item(char *& theName) const {
	// Routine assumes name starts with "[#"
	// use only if this was checked by the caller before calling

	// Look for the closing bracket
	char * endOfMult = strchr(theName,']');
	if (endOfMult==NULL) { // not found
		OMString errMsg = theName;
		errMsg += " - missing ']'";
		tomSendError(errMsg);
		return (TOMInstance *)OMGarbage;
	}

	// Try to read the multiplicity
	int multiplicity;
	if (sscanf(theName,"[#%d]",&multiplicity)) { // Found multiplicity
		theName = endOfMult+1;	// Advance theName beyond the "[xxx]"
		return getInstanceByRelativeMultiplicity(multiplicity);
	} else { // Missing multiplicity
		OMString errMsg = theName;
		errMsg += " - should include only digits after the # symbol";
		tomSendError(errMsg);
		return (TOMInstance *)OMGarbage;
	}
}

TOMProxyItem* TOMList::name2Item(char *& theName) const {
	TOMInstance* item;
	if (theName[0]=='[' && theName[1]=='#')
		item = hashExpression2Item(theName);
	else if (isInstanceOrObjectCallString(theName) || isEndOfName(theName))
		item = getInstanceByRelativeMultiplicity(0); // Get first element
	else {
		// Nothing was found - give bad format message
		OMString errMsg = theName;
		errMsg += " - bad name format";
		tomSendError(errMsg);
		return OMGarbage;
	}
	return finishName2Item(theName,item);
}


TOMInstance* TOMNameGiver::absExpression2Item(char *& theName) const {
	// Routine assumes name starts with "[digit"
	// use only if this was checked by the caller before calling

	// Look for the closing bracket
	char * endOfMult = strchr(theName,']');
	if (endOfMult==NULL) { // not found
		OMString errMsg = theName;
		errMsg += " - missing ']'";
		tomSendError(errMsg);
		return (TOMInstance *)OMGarbage;
	}

	// Try to read the multiplicity
	int multiplicity;
	if (sscanf(theName,"[%d]",&multiplicity)) { // Found multiplicity
		theName = endOfMult+1;	// Advance name beyond the "[xxx]"
		// Look for the item by this absolute multiplicity
		if (multiplicity >= nameCounter)
			return (TOMInstance *)TOMPossibleButNonExistent;
		// Do a search on existing items
		for(OMIterator<TOMInstance *> i(this); *i; i++) {
			if ((*i)->getMultiplicity()==multiplicity)
				return *i;
		}
		// Patch for the class-first/relations-first dichotomy
		if (multiplicity == nameCounter -1 )
			return (TOMInstance *)TOMPossibleButNonExistent;
		else // Its realy an old (deleted) element
			return (TOMInstance *)OMGarbage;
	} else { // Missing multiplicity
		OMString errMsg = theName;
		errMsg += " format error\n - may include only # and digits between [ ] symbol";
		tomSendError(errMsg);
		return (TOMInstance *)OMGarbage;
	}
}


TOMProxyItem* TOMNameGiver::name2Item(char *& theName) const {
	// 1. Place TOMGarbage to indicate name might be in bad format
	TOMInstance* item;
	if (theName[0]=='[') {
		if (theName[1]=='#')
			item = hashExpression2Item(theName);
		else if (isdigit(theName[1]))
			item = absExpression2Item(theName);
		else {
			OMString errMsg = theName;
			errMsg += " - bad name format";
			tomSendError(errMsg);
			return OMGarbage;
		}
	} else if (isInstanceOrObjectCallString(theName) || isEndOfName(theName))
		item = getInstanceByRelativeMultiplicity(0); // Get first element
	else {
		// Nothing was found - give bad format message
		OMString errMsg = theName;
		errMsg += " - bad name format";
		tomSendError(errMsg);
		return OMGarbage;
	}
	return finishName2Item(theName,item);
}


void TOMCompositeLink::registerItem(TOMInstance *i) {
	// Set the item's name
	if (!tomIsValidItem(i))
		tomSendError("Cannot register bad proxy item in relation");
	else  {
		i->setName(name, giveMultiplicity(), owner);
		// Actually register it
		TOMList::registerItem(i);
	}
}


//
// $Log: tomlist.cpp $
// Revision 1.39  2007/03/11 13:14:42  ilgiga
// Change copyright comment
// Revision 1.38  2007/03/04 15:07:32  ilgiga
// Telelogic instead of i-Logix
// Revision 1.37  2005/08/23 14:50:43  amos
// bugfix 85444 to main branch
// Revision 1.36.1.2  2005/08/22 10:05:39  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.36  2004/01/12 10:31:04  eldad
// Allow dor (.) notation in C++\Java
// Revision 1.35  2002/07/15 12:29:31  avrahams
// Back to main
// Revision 1.34.1.2  2002/07/04 11:11:30  avrahams
// Cleanup std namespace usage
// Revision 1.34  2000/07/11 09:23:50  amos
// changes related to modify char* to const char*.
// Revision 1.33  1999/10/12 13:33:01  yachin
// Fix bugs
// Revision 1.32  1999/02/16 05:56:56  yachin
// Speed up of constructors
// Revision 1.31  1998/06/15 12:39:33  yachin
// Fix bug 6231 - name2item for relations return only valid objects of 'possibleButNonExistant'
// Revision 1.30  1998/04/13 07:59:04  ofer
// keep "using namespace std;"
// only after include to <XXXstream>
// Revision 1.29  1998/04/13 07:40:58  ofer
// added "using namespace std;" after each include to stl files
// Revision 1.28  1998/04/12 12:17:45  ofer
// Change includes to Stl format ifdefed by OM_USE_STL
// Revision 1.27  1997/08/12 08:37:26  yachin
// fix dynphil name recognition bug
// Revision 1.26  1997/03/31 09:13:12  yachin
// Fix warnings on Unix
// Revision 1.25  1997/03/04 11:52:13  yachin
// added namegiver::name2item + consequences
// Revision 1.24  1997/02/27 11:34:06  yachin
// Fix tryToRegisterObserver for instance by class name not existing
// Revision 1.23  1997/02/20 06:32:32  yachin
// bug fix on name2item
// Revision 1.22  1997/02/19 12:35:31  yachin
// name2item bug fix
// Revision 1.21  1997/02/11 12:54:35  yachin
// Adding Name spaces
// Revision 1.20  1997/02/06 13:33:50  yachin
// Switched from try to tomIsValidItem
// Revision 1.19  1996/12/22 09:03:23  yachin
// Has composite notify componentes abou tits new name
// Revision 1.18  1996/11/24 12:40:39  yachin
// Revision 1.17  1996/10/23 10:10:02  yachin
// Revision 1.16  1996/10/13 11:40:26  yachin
// Bug fixes
// Revision 1.15  1996/10/10 08:01:25  yachin
// Revision 1.14  1996/10/09 07:37:07  yachin
// Revision 1.13  1996/10/02 08:40:53  yachin
// Hopefully fixed "early" relation registration bug
// Revision 1.12  1996/10/01 11:42:54  yachin
// Fix registraction bug in relations
// Revision 1.11  1996/10/01 07:48:57  yachin
// Revision 1.10  1996/09/17 13:43:00  yachin
// Revision 1.9  1996/09/16 13:44:31  yachin
// Revision 1.8  1996/09/16 09:28:31  yachin
// Revision 1.7  1996/09/09 07:25:54  yachin
// Fix bug in name2item
// Revision 1.6  1996/09/08 13:28:56  yachin
// Registeration of items which do not yet exist
// Revision 1.5  1996/09/05 13:35:55  yachin
// Revision 1.4  1996/08/28 05:38:02  ofer
// Revision 1.3  1996/08/08 08:23:28  yachin
// Revision 1.2  1996/08/06 12:55:55  yachin
// Revision 1.1  1996/08/06 12:53:23  yachin
// Initial revision
//
