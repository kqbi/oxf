#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tommsg.cpp 1.35 2007/03/11 13:14:43 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tommsg.cpp $
//	file version:	$Revision: 1.35 $
//
//	purpose: Methods of Class TOMParameterMessage 	
//
//	author(s):		Yachin Pnueli
//	date started:	22.5.96
//	date changed:	$Date: 2007/03/11 13:14:43 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "tommsg.h"
#include "tomsys.h"

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tommsg_H;
#endif

OMBoolean tomItemExists(const TOMProxyItem *i)
{
	rhp_long64_t intVal = (rhp_long64_t)i;
	switch (intVal) {
	case 0:
	case _OMInConstruction:
	case _OMInDestruction:
		return FALSE;
	case _OMNotInteresting:
	case _OMGui:
	case _OMTrace:
		return TRUE;
	default:
		// Hope that item is o.k.
		if (tomIsValidItem(i)) {
			OMString s;
			i->outputFullName(s);
			return TRUE;
		} else {	// If not mark as non-existent
			return FALSE;
		}
	}
}


void tominstance2String(const TOMProxyItem *i, 
						OMString& s, 
						const TOMProxyItem * context) {
	rhp_long64_t intVal = (rhp_long64_t)i;
	switch (intVal) {
	case 0:					s += "NULL";					break;
	case _OMInConstruction:	s += "<under construction>";	break;
	case _OMInDestruction:	s += "<under destruction>";		break;
	case _OMNotInteresting:	s += "<un-traced>";				break;
	case _OMGui:			s += "<user via GUI>";			break;
	case _OMTrace:			s += "<user via Tracer>";		break;
	default:
		// Hope that item is o.k.
		if (tomIsValidItem(i)) {
			i->outputFullName(s,context);
		} else {	// If not mark as non-existent
			s +="<non-existent>";
		}
	}
}


void* TOMSData::safeGetPointer(OMSPosition& position) {
	gen_ptr p = OMSData::safeGetPointer(position);
	if (p==(gen_ptr)(rhp_long64_t)OMInConstruction) {
		p = OMSData::safeGetPointer(position);
		return TOMSystem::instance()->getInstanceByReal(p);
	}
	return (void*)(rhp_long64_t)p;
}

void* TOMSData::getPointer(OMSPosition& position) {
	gen_ptr p = OMSData::getPointer(position);
	if (p==(gen_ptr)(rhp_long64_t)OMInConstruction) {
		p = OMSData::getPointer(position);
		return TOMSystem::instance()->getInstanceByReal(p);
	}
	return (void*)(rhp_long64_t)p;
}



void TOMSList::setValues(OMSData *theS, OMSPosition& position) {
	s = (TOMSData*)theS;
	count = s->safeGetInt(position);
	p = position;
}


OMBoolean TOMSList::getValue(OMString & value, 
						   OMString & errMsg,
						   const TOMProxyItem * context) {
	value = "";	// Empty the value
	if (s->isStringOrPointer(errMsg,p)) {
		OMSPosition oldp = p;
		if (s->isString(p))
			value = s->getString(p);
		else if (s->isPointer(p))
			tominstance2String( (TOMProxyItem *)s->getPointer(p),
								value,
								context);
		// Check that we read successfully
		if (p==oldp) {
			missingError(errMsg, "Value", oldp);
			return FALSE;
		} else
			return TRUE;
	}
	return FALSE;
}

OMBoolean TOMSList::getNameValuePair(OMString & name, 
								   OMString & value, 
								   OMString & errMsg,
								   const TOMProxyItem * context) {
	name = "";	// Empty the name
	// Read Attribute name
	OMSPosition oldp = p;
	name += s->safeGetString(p);
	if (oldp==p) {
		missingError(errMsg, "Name", oldp);
		return FALSE;
	}

	// Read Attribute value	
	return getValue(value,errMsg,context);
}


OMBoolean TOMSList::method2string( OMString& tmsg,
									const char * header, 
									const char * nameValueSeperator,
									const char * itemItemSeperator,
									const char * /* itemName */, 
									const char * tailer,
									const TOMProxyItem * context) {
	// Write header
	tmsg += (char*)header;

	// Loop on the parameters and extract name, value
	for(int i=0; i<count; i++) {
		// Add the end of line seperator
		if (i>0)
			tmsg+=(char*)itemItemSeperator;

		OMString name,value;
		// Read Attribute name and value - if error place error in tmsg
		if (!getNameValuePair(name,value,tmsg,context) )
			return FALSE;

		// Form the next "item" in the message
		tmsg += name;
		tmsg +=	(char*)nameValueSeperator;
		tmsg += value;
	}
	// Write the tailer
	tmsg+=(char*)tailer;
	return TRUE;
}

void TOMSCallStackValues::getNextItem(TOMProxyItem *& caller,
										TOMProxyItem *& called, 
										OMSData *& method,
										OMMethodType& methodType) {
	caller = (TOMProxyItem *)s->safeGetPointer(p);
	called = (TOMProxyItem *)s->safeGetPointer(p);
	method = s->safeGetOMSData(p);
	methodType = (OMMethodType)s->safeGetCode(p);
	count--;
}

void TOMSCallStackValues::getNextItem(TOMProxyItem *& caller,
										TOMProxyItem *& called, 
										OMString& method,
										OMMethodType& methodType) {
	OMSData * theMethod;
	getNextItem(caller,called,theMethod,methodType);
	TOMSMethod m(theMethod);
	m.method2string(method);
	delete theMethod;
}

OMBoolean TOMSCallStackValues::method2string(OMString& msg, const TOMProxyItem * context) {
	if (isLastItem()) 
		msg += "Call Stack Empty";
	else do {
		TOMProxyItem * caller;
		TOMProxyItem * called;
		OMSData * method;
		OMMethodType methodType;
		getNextItem(caller,called,method,methodType);
		// Compose the trace message
		// Write header
		if (caller==NULL)
			msg += "main()";
		else
			tominstance2String(caller, msg, context);
		msg += " Invoked ";
		if (called!=caller && called!=NULL && called!=OMInConstruction) {
			tominstance2String(called, msg, context);
			msg += (char*)tominstance2CallString(called);	// Add either "->" or "::"
		}

		// Write method signature/parameters
		TOMSMethod m(method);
		m.method2string(msg, context);
		msg +='\n';
	} while(!isLastItem());

	return TRUE;
}


OMBoolean TOMSEvent::method2string(OMString& eventString,void*& eventId,
					const TOMProxyItem * context) {
	OMBoolean isOk = TOMSMethod::method2string(eventString,context);
	// Event id should always be present
	eventId = s->safeGetPointer(p);
	// eventId == NULL indicates a synchronization error
	return isOk && eventId!=NULL;
}


void TOMSEventQueueValues::getNextItem(TOMProxyItem *& caller,
										TOMProxyItem *& called, 
										OMSData *& event) {
	caller = (TOMProxyItem *)s->safeGetPointer(p);
	called = (TOMProxyItem *)s->safeGetPointer(p);
	event = s->safeGetOMSData(p);
	count--;
}

void TOMSEventQueueValues::getNextItem(TOMProxyItem *& caller,
										TOMProxyItem *& called, 
										OMString& event,
										void*& eventId) {
	OMSData * theEvent;
	getNextItem(caller,called,theEvent);
	TOMSEvent m(theEvent);
	m.method2string(event,eventId);
	delete theEvent;
}

OMBoolean TOMSEventQueueValues::method2string(OMString& msg, 
									const TOMProxyItem * context) {
	if (isLastItem()) 
		msg += "Event Queue Empty";
	else do {
		TOMProxyItem * sender;
		TOMProxyItem * receiver;
		OMSData * event;
		getNextItem(sender,receiver,event);
		// Compose the trace message
		// Write event signature/parameters
		msg += "Event ";
		TOMSEvent m(event);
		void * id;	// Unused in this context
		m.method2string(msg, id, context);

		msg +=" from ";
		// Write sender
		if (sender==NULL)
			msg += "main()";
		else
			tominstance2String(sender, msg, context);

		msg += " to ";
		// Write receiver
		if (receiver==sender)
			msg +="itself";
		else
			tominstance2String(receiver, msg, context);

		msg +='\n';
	} while(!isLastItem());

	return TRUE;
}
//
// $Log: tommsg.cpp $
// Revision 1.35  2007/03/11 13:14:43  ilgiga
// Change copyright comment
// Revision 1.34  2007/03/04 15:07:33  ilgiga
// Telelogic instead of i-Logix
// Revision 1.33  2005/08/23 14:50:44  amos
// bugfix 85444 to main branch
// Revision 1.32.1.2  2005/08/22 10:05:40  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.32  2000/12/25 10:39:51  amos
// move to warning level 4
// Revision 1.31  2000/10/04 09:56:58  ofer
// GNU compiler require 0 ( and not NULL ) in case statement
// Revision 1.30  2000/07/24 09:36:16  amos
// modify TOMList::method2string() to get 'const char*' arguments instead of 'char*' arguments
// Revision 1.29  2000/07/11 09:23:50  amos
// changes related to modify char* to const char*.
// Revision 1.28  2000/06/27 09:33:51  ofer
// Fix bug for pdiab data compiler ( using non const value in case statement )
// Revision 1.27  2000/04/12 10:42:33  yachin
// Fix bug for powerPC compiler
// Revision 1.26  2000/03/14 09:26:45  yachin
// fix compile error for QNX (actually a bug)
// Revision 1.25  1999/02/16 05:56:58  yachin
// Speed up of constructors
// Revision 1.24  1998/08/02 15:07:44  beery
// Revision 1.23  1997/04/09 11:43:16  ofer
//  gnu compiler 2.51 
// switch ( (int)i) statemment
// change to int intVal = (int)i;
// switch(intVal) ....
// tommsg.cpp
// Revision 1.22  1997/02/06 13:33:51  yachin
// Switched from try to tomIsValidItem
// Revision 1.21  1996/12/23 11:51:10  yachin
// Add ids to events
// Revision 1.20  1996/11/24 12:40:40  yachin
// Revision 1.19  1996/11/06 08:19:10  ofer
// Added new function tomItemExist(TOMProxyItem)
// Added By yachin
// Revision 1.18  1996/10/23 07:48:16  yachin
// Fix interrface to getNextMethod
// Revision 1.17  1996/10/09 07:37:08  yachin
// Revision 1.16  1996/09/26 06:31:26  yachin
// getNextMethod/isLastMethod changed to getNextItem/isLastItem
// Revision 1.15  1996/09/25 10:01:25  yachin
// notifyEventQueueValues added + assorted bug fixes
// Revision 1.14  1996/09/05 13:35:56  yachin
// Revision 1.13  1996/09/05 08:34:06  ofer
// added new method getNextMethod(...)
// ( different interface used by CallStack observers)
// 
// 
// Revision 1.12  1996/09/04 13:16:10  yachin
// Connect with Israel
// Revision 1.11  1996/08/28 05:38:02  ofer
// Revision 1.10  1996/08/15 08:42:40  yachin
// Revision 1.9  1996/08/06 12:52:07  yachin
// Version for Prototype 4
// Revision 1.8  1996/07/22 11:30:31  yachin
// Revision 1.7  1996/07/04 12:38:50  yachin
// Bug fixes and handleing static methods
// Revision 1.6  1996/07/03 12:45:50  yachin
// Fixing bugs for "const" and "static
// enhancements for attributes and indentation
// Revision 1.5  1996/07/01 11:25:12  yachin
// Revision 1.4  1996/06/30 12:24:02  yachin
// Handle "deleted items" too in TOMInstance2String
// Revision 1.3  1996/06/27 12:25:03  yachin
// Revision 1.2  1996/06/19 10:21:28  yachin
// Revision 1.1  1996/06/17 05:40:45  yachin
// Initial revision
//
