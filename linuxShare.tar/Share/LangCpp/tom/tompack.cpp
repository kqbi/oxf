#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tompack.cpp 1.33 2007/03/11 13:14:45 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tompack.cpp $
//	file version:	$Revision: 1.33 $
//
//	purpose:	Implement the TOMPackage class
//
//	author(s):		Yachin Pnueli
//	date started:	9.2.97
//	date changed:	$Date: 2007/03/11 13:14:45 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1996, 2008. All Rights Reserved.
//

#include "tomsys.h"
#include "tompack.h"
#include "tombrk.h"
#include "tomclass.h"
#include "tominst.h"
#include "tomstr.h"
#include "tomobs.h"
#include "tomattr.h"
#include "tommask.h"

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tompack_H;
#endif

#define _DO_TO_CLASSES(function) {						\
	for(OMIterator<TOMClass *> i(theClasses); *i; i++)	\
		(*i)->function;									\
}						 							


void TOMPackage::setReal(gen_ptr theReal) {
	TOMProxyItem::setReal(myMask,theReal);
}

TOMPackage::~TOMPackage() {
	// delete all "my" items
	// Classes
	for(OMIterator<TOMClass *> ic(theClasses); (*ic); ++ic)
	{
		if (!tomIsValidItem(*ic)) continue;	// safe programming
		delete (*ic);
	}
	// Event Classes
	for(OMIterator<TOMEventClass *> ie(theEventClasses); *ie; ++ie)
	{
		if (!tomIsValidItem(*ie)) continue;	// safe programming
		delete (*ie);
	}
	//	Done automatically by OMList destructor
	//	theClasses.removeAll();
	//	theEventClasses.removeAll();

	// name
	delete[] myName;
}

void TOMPackage::addClass(TOMClass* c) { 
#ifdef OMANIMATOR
	TOMMaskedObserver * obs = NULL;
	for(OMIterator<TOMMaskedObserver *> iter(observerList); *iter; iter++) {
		obs = *iter;
		c->registerObserver(obs->getObserver(), obs->getMask());
	}
#endif

	c->registerToTrace(this);
	// finally add it the the container itself
	theClasses.add(c); 
}


void TOMPackage::addEventClass(TOMEventClass* c) { 
#ifdef OMANIMATOR
	TOMMaskedObserver * obs = NULL;
	for(OMIterator<TOMMaskedObserver *> iter(observerList); *iter; iter++) {
		obs = *iter;
		c->registerObserver(obs->getObserver(), obs->getMask());
	}
#endif
	c->registerToTrace(this);
	// finally add it the the container itself
	theEventClasses.add(c); 
}


TOMEventClass* TOMPackage::name2EventClass(const OMString& name, void* pSocket) const {
	for(OMIterator<TOMEventClass *> i(theEventClasses); *i; ++i) {
		if ((*i)->getFirstName()==name)
		{
			if(pSocket && (*i)->getMySocket() != pSocket)
				continue;
			else
				return *i;
		}
	}
	// with lazy evaluation the package may be not there yet .....
	return (TOMEventClass*)TOMPossibleButNonExistent;
}

TOMClass* TOMPackage::name2Class(const OMString& name) const{
	for(OMIterator<TOMClass *> i(theClasses); *i; ++i) {
		if ((*i)->getFirstName()==name)
			return *i;
	}
	// with lazy evaluation the package may be not there yet .....
	return (TOMClass*)TOMPossibleButNonExistent;
}


TOMProxyItem* TOMPackage::name2Item(char *& itemName) const{
	OMString name;
	TOMProxyItem* ret;
	eatOneToken(itemName,name);
	if (name.IsEmpty()) 
	{
		ret = OMGarbage;
	}
	else
	{// Assume the postfix is a class name
		TOMClass *item = name2Class(name);
		if ((item != OMGarbage) && (item != TOMPossibleButNonExistent)) 
		{ 
			// We found some class
			if (isEndOfName(itemName) || isCodeItem(item))
				ret = item;
			else
				ret = item->name2Item(itemName);
		} 
		else  
		{
			// it may be due to lazy evaluation
			ret = (TOMProxyItem*)TOMPossibleButNonExistent;
		}
	}
	return ret;
}


OMBoolean TOMPackage::showYourself(TOMUniversalObserver* obs, 
								int theMask) {
	if (!myReal)
		return FALSE;
	
	int sendMask = theMask;
	OMBoolean toWait = TOMProxyItem::showYourself(obs,sendMask);

	OMBoolean onlyAttributes = 
		(theMask == (int)(OMAttributesInterest | OMExistInterest)) || 
			(theMask == (int)OMAttributesInterest);
	if (onlyAttributes) return toWait; // Do not propagate only attrinutes

	if ( theMask & (OMMethodsInterest|OMExistInterest) ) {
		obs->notifyEventValues(this);
	}

	// Iterate on all classes and "show" them
	for(OMIterator<TOMClass *> i(theClasses); *i; ++i) {
		if ((*i)->showYourself(obs,theMask))
			toWait = TRUE;
	}
	return toWait;

}

void TOMPackage::_showYourself(TOMUniversalObserver*, int& theMask)
{
	if (myReal) {
		// Currently a package sends only for attribute info
		theMask = theMask & OMAttributesInterest ;
	}
	else {
		theMask = OMNoInterest;
	}
}

void TOMPackage::registerObserver(TOMUniversalObserver* obs, 
								 OMInterestMask theMask) {
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	TOMProxyItem::registerObserver(obs,theMask);
	// Iterate on all classes and "do it"
	_DO_TO_CLASSES(registerObserver(obs,theMask));
}

void TOMPackage::deregisterObserver(TOMUniversalObserver* obs, 
								 OMInterestMask theMask) {
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	TOMProxyItem::deregisterObserver(obs,theMask);
	// Iterate on all classes and "do it"
	_DO_TO_CLASSES(deregisterObserver(obs,theMask));
}

void TOMPackage::reRegisterObserver(TOMUniversalObserver* obs,
								   OMInterestMask newMask) {
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;


	TOMProxyItem::reRegisterObserver(obs,newMask);
	// Iterate on all classes and "do it"
	_DO_TO_CLASSES(reRegisterObserver(obs,newMask));
}

void TOMPackage::addToObserver(TOMUniversalObserver* obs,
							  OMInterestMask addMask) {
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	TOMProxyItem::addToObserver(obs,addMask);
	// Iterate on all classes and "do it"
	_DO_TO_CLASSES(addToObserver(obs,addMask));
}

void TOMPackage::subtractFromObserver(TOMUniversalObserver* obs, 
									 OMInterestMask subtractMask){
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	TOMProxyItem::subtractFromObserver(obs,subtractMask);
	// Iterate on all classes and "do it"
	_DO_TO_CLASSES(subtractFromObserver(obs,subtractMask));
}


OMBoolean TOMPackage::addBreakPoint(OMNotify theType, const char *theData) {
	// Apply the break point "criteria" on all classes
	OMBoolean ok = FALSE;
	for(OMIterator<TOMClass *> i(theClasses); *i; ++i) {
		if (TOMBreakPointManager::instance()->addBreakPoint(theType,*i,theData))
			ok = TRUE;
	}
	return ok;
}


TOMProxyItem * TOMPackage::getInstanceByReal(gen_ptr real) {
	for(OMIterator<TOMClass *> i(theClasses); *i; ++i) {
		TOMClass * c = (*i);
		for(OMIterator<TOMInstance *> j(c->getTomNameGiver()); *j; ++j) {
			TOMInstance *n = (*j);
			if (n->getReal()==real)
				return n;
		}
	}
	return OMGarbage;
}


void TOMPackage::handleMessage(OMNotify msgCode, 
								TOMSData * s, 
								OMSPosition p) {
	// Perform the operation appropriate to this message code
	switch (msgCode) {
	case attributeValues: {
		TOMAttributes attributes(this);
		attributes.newAttributeValues(s,p);
		NOTIFY_SHOW_OBSERVERS(notifyAttributeValues(&attributes, this, TRUE));
		return;
						  }
	case instanceValue:	{
		TOMSData * attributeMessage = s->safeGetOMSData(p);
		handleMessage(attributeValues,attributeMessage,
				attributeMessage->getFirst());
		delete attributeMessage;
		return;
						}
	default: notifyUnexpectedMessage(msgCode);
	}
}

void TOMPackage::accept(TOMProxyVisitor1Arg & visitor) 
{
	// do for me
	/* OMBoolean result = */ (void) visitor.execute(*this);
	// do for all user classes
	for(OMIterator<TOMClass *> ic(theClasses); (*ic); ++ic) {
		(*ic)->accept(visitor);
	}
	// do for all events' classes
	for(OMIterator<TOMEventClass *> ie(theEventClasses); *ie; ++ie) {
		(*ie)->accept(visitor);
	}
}



void TOMPackageIterator::advanceToNextNonEmptyClass() {
	while (!value()) {
		classIter.increment();
		if (!(*classIter))
			return;
		TOMClass * currentClass = (*classIter);
		OMIterator<TOMInstance *>::reset(*currentClass->getTomNameGiver()); 
	}
}

TOMPackageIterator& TOMPackageIterator::increment() { 
	// Advance my self as an Instance iterator
	OMIterator<TOMInstance *>::increment();
	// As long as I == NULL try the next class
	advanceToNextNonEmptyClass();
	return *this;
}

void TOMPackageIterator::reset(TOMPackage *p){
	classIter.reset(p->theClasses);
	OMIterator<TOMInstance *>::reset(*(*classIter)->getTomNameGiver());
	advanceToNextNonEmptyClass();
}

void TOMPackageIterator::reset(){
	classIter.reset();
	OMIterator<TOMInstance *>::reset(*(*classIter)->getTomNameGiver());
	advanceToNextNonEmptyClass();
}

void TOMPackage::name2Classes(const OMString& name, OMList<TOMClass*>& classes) const
{
	classes.removeAll();
	for(OMIterator<TOMClass *> i(theClasses); *i; ++i) {
		if ((*i)->getFirstName()==name)
			classes.add(*i);
	}
}

//
// $Log: tompack.cpp $
// Revision 1.33  2007/03/11 13:14:45  ilgiga
// Change copyright comment
// Revision 1.32  2007/03/04 15:07:35  ilgiga
// Telelogic instead of i-Logix
// Revision 1.31  2006/10/31 08:58:52  ccohen
// support running multiple animation processes.
// Revision 1.30  2005/08/23 14:50:46  amos
// bugfix 85444 to main branch
// Revision 1.29.1.2  2005/08/22 10:05:41  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.29  2004/05/11 08:07:19  vova
// Linux warnings: casting to (int)
// Revision 1.28  2003/05/26 11:06:21  vova
// ESTL-Embedded C++ with Standard Templates Libraries
// Revision 1.27  2002/05/15 14:55:26  Eldad
// To main branch.
// Revision 1.26.1.2  2002/05/13 08:56:41  Eldad
// myName leak.
// Revision 1.26.1.1  2002/03/25 12:59:07  Eldad
// Duplicate revision
// Revision 1.25.1.2  2002/03/19 11:02:57  Eldad
// Registering observers for lazy (C, Java)
// Revision 1.25  2000/12/25 10:39:51  amos
// move to warning level 4
// Revision 1.24  2000/07/11 09:23:51  amos
// changes related to modify char* to const char*.
// Revision 1.23  1999/10/12 13:33:02  yachin
// Fix bugs
// Revision 1.22  1999/06/18 09:07:42  beery
// due to lazy evaluation, make sure that new package/class/classevent are observed my the console 
// so when a new object or event are created they "inherite" their initial mask from their logical parent
// Revision 1.21  1999/06/14 13:58:52  beery
// consider lazy evaluation for instacnes
// Revision 1.20  1999/06/10 08:41:21  beery
// support lazt evaluation by returning "not found but possible will be crearted later" instead of just "not found"
// when looking for packages, classes and events.
// Revision 1.19  1999/02/24 09:00:26  yachin
// Fix on fix
// Revision 1.18  1999/02/24 07:21:05  yachin
// Fix bug 29712
// Revision 1.17  1999/02/21 09:31:17  yachin
// Fix bugs on unique name and name2class
// Revision 1.16  1999/02/18 11:27:12  yachin
// Fix regression on initial call stack entry
// Revision 1.15  1999/02/16 05:57:00  yachin
// Speed up of constructors
// Revision 1.14  1998/12/28 08:07:08  beery
// 28402: after filtering the mask for itsself, the package send the original mask to its classes
// Revision 1.13  1998/12/08 15:44:06  beery
// 28100
// Revision 1.12  1998/11/19 17:57:46  beery
// Revision 1.11  1998/11/17 12:39:16  beery
// Revision 1.10  1998/08/02 15:06:36  beery
// changing boolean->OMBoolean
// Revision 1.9  1997/07/24 07:23:55  yachin
// bug fix
// Revision 1.8  1997/07/23 08:38:12  yachin
// bug fix
// Revision 1.7  1997/07/21 06:33:01  yachin
// Added global items to animation part II
// Revision 1.6  1997/07/20 12:09:37  yachin
// Revision 1.5  1997/07/20 11:36:40  yachin
// Adding globals to animation
// Revision 1.4  1997/05/27 09:02:50  yachin
// Made tomstr == ystr
// Revision 1.3  1997/02/21 08:56:44  yachin
// Added show #all events
// Revision 1.2  1997/02/19 11:19:56  yachin
// Add isAnimationActive mode to all observer operations
// Revision 1.1  1997/02/11 13:05:40  yachin
// Initial revision
//
