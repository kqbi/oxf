#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomclass.cpp 1.93 2007/03/11 13:14:41 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomclass.cpp $
//	file version:	$Revision: 1.93 $
//
//	purpose: Methods of Class TOMClass	 	
//
//	author(s):		Yachin Pnueli
//	date started:	27.5.96
//	date changed:	$Date: 2007/03/11 13:14:41 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "tomclass.h"
#include "tominst.h"
#include "tomsys.h"
#include "tomobs.h"
#include "tomstr.h"
#include "tomsilent.h"
#include "tommsg.h"
#include "tomoperation.h"


#include <omcom/AnimStringField.h>
#include <omcom/AnimPointerField.h>
#include <omcom/AnimBooleanField.h>
#include <omcom/AnimMessageField.h>
#include <omcom/AnimListField.h>
#include <omcom/AnimRegisterOperations.h>
#include <omcom/AnimOperationData.h>


#ifdef OMANIMATOR
#include <string.h>
#include "tomExtern.h"
#endif

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomclass_H;
#endif

TOMClass::TOMClass(gen_ptr theReal, char * theName, OMBoolean isSingleton,
					OMBoolean isImplicit, TOMProxyItem *const theContext):
			TOMNameSpaced(theName, omProxyClass, theContext),
			tomNameGiver(theName, isSingleton)
{ 
	_isImplicit = isImplicit;
	// Must do setReal here to preserve the virtual myDefaultMask
	setReal(OMExistInterest, theReal);

#ifdef OMANIMATOR
	coreClass = NULL;
#endif
}

OMString& TOMNameSpaced::outputFullName(OMString& s, 
							const TOMProxyItem * theContext) const {
	if (!unique  &&  (theContext==NULL ||
					(void*)myContext != (void*)theContext->getPackage()) ) {
		// Add context name + context seperator
		tominstance2String(myContext, s, theContext);
		s += (char*)getClassCallString();
	}
	return outputFirstName(s);
}

OMString& TOMNameSpaced::outputFullFullName(OMString& s,
							const TOMProxyItem * theContext) const {
	// Add context name + context seperator
	myContext->outputFullName(s,theContext);
	s += (char*)getClassCallString();
	return outputFirstName(s);
}

//
//	TOMClass methods
//
TOMClass::~TOMClass() {
	// Delete all instances of the class
	{
		for(OMIterator<TOMInstance *> i(this->tomNameGiver); *i; ++i) {
			if (!tomIsValidItem(*i)) continue;	// safe programming
			delete (*i);
		}
	}
	// Delete all relation names of the class
	if (myRelations.isEmpty() == FALSE)
	{
		for(OMIterator<char *> i(myRelations); *i; ++i) {
			delete (*i);
		}
	}
	// Delete all operations of the class
	if (operationList.isEmpty() == FALSE)
	{
		for(OMIterator<TOMOperation *> i(operationList); *i; ++i) {
			if (!tomIsValidItem(*i)) continue;	// safe programming
			delete (*i);
		}
	}


	// Class currently owns its name
	delete[] myName;
}

void TOMNameSpaced::notifySuperClasses() {
	for(OMIterator<TOMNameSpaced *> i(mySuperClasses); *i; ++i)
		(*i)->notifySubClass(this);
}


// This should never be called - its here to avoid a "hide" warning
void TOMClass::registerItem(TOMInstance *) {
	OMString msg = "Warning - TOMClass::registerItem(instance) called and ignored";
	tomSendWarning(msg);
}

void TOMClass::registerItem(TOMInstance *instance,
							TOMSData* itsRelationsMessage) 
{
#ifdef OMANIMATOR
	if(coreClass == NULL && TOMExterns::Anim())
		coreClass = TOMExterns::Anim()->GetCoreClassByName(myName, this);
#endif

	// Check for a valid item to prevent errors
	if (!tomIsValidItem(instance)) return;

	// Fix for attribute is class bug
	// Due to this bug if 'instance' has attributes which are
	// themselves AOMInstances 'instance' may already be registered 
	// in a super class.
	// What we do is 'remove' it from the supper class
	TOMClass* oldC = instance->getClass();
	if ((oldC != NULL) && (tomIsValidItem(oldC)))
		oldC->tomNameGiver.deregisterItem(instance);
	// End of Fix for attribute is class bug
	//
	// Registering into a class implies proxy creation.
	// The instance "inherites" the mask from the class
	OMInterestMask itemMask;
	if (myMask.isInteresting(OMInstanceInterest))
		itemMask = myMask;
	if (inSilentMode()) {
		// in silent mode, the real class' intersting mask is the saved one
		itemMask = mySavedMask;
	}

	// Attention: since giveMultiplicity changes nameCounter this code section
	// must be before the call to giveMultiplicity.
	// The boolean value was added since in Java singleton class we always get
	// TOMNoMultiplicity so multiplicity == 0 is irrelevant.
	OMBoolean tmpIsFirstInstance = FALSE;
	if (tomNameGiver.getNameCounter() == 0) {
		tmpIsFirstInstance = TRUE;
	}

	// Set the class of proxy, this gives it the correct interest mask
	// However "my" observers are as yet not registered on it
	int multiplicity = tomNameGiver.giveMultiplicity();
	
	instance->setClass(myName,multiplicity,itemMask,this,myContext);
	if (inSilentMode()) {
		// if the class is in silent mode then its instance should go into silent mode too
		TOMSilent silent;
		instance->accept(silent);
	}

	// In Java the multiplicity of singleton returns 0xffffff so no idication 
	// if the instance is first or not is given by giveMultiplicity.
	// Instead, we rely on the boolean tmpIsFirstInstance defined before in this method

	// Handle the instance's relations
	// Notify the instance about its relations
	if ( multiplicity==0 || ((multiplicity==TOMNoMultiplicity) && (tmpIsFirstInstance)) )
		instance->createRelationsFirstInstance(itsRelationsMessage);
	else
		instance->createRelations(itsRelationsMessage);
	// Register it in class (this notifies the createObserver
	tomNameGiver.registerItem(instance);
	// Now register all my "more than existance" observers on it
#ifdef OMANIMATOR
	for(OMIterator<TOMMaskedObserver*> i(observerList); *i; i++) {
		OMInterestMask obsMask = (*i)->getMask();
		if (obsMask.isInteresting(OMInstanceInterest))
			instance->registerObserver((*i)->getObserver(), obsMask);
	}
#endif

#ifdef OMANIMATOR
	if(TOMExterns::Anim())
		TOMExterns::Anim()->notifyNewItem(instance);
#endif
}

#define DO_TO_SUBCLASSES(mask,function) {						\
	if (mask.isInteresting(OMSubClassInterest)) { 				\
		for(OMIterator<TOMNameSpaced *> i(mySubClasses); *i; i++)	\
			(*i)->function;										\
		mask -= OMSubClassInterest;								\
	}															\
}						 

#define _DO_TO_INSTANCES(function) {					\
	for(OMIterator<TOMInstance *> i(this->getTomNameGiver()); *i; i++)		\
		if(tomIsValidItem(*i))												\
			(*i)->function;									\
}						 							

#define DO_TO_INSTANCES(mask,function) {			\
	if (mask.isInteresting(OMInstanceInterest)) 	\
		_DO_TO_INSTANCES(function)					\
}						 


void TOMClass::registerObserver(TOMUniversalObserver* obs,
								OMInterestMask mask) {
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	// Register with my sub classes if necessary
	DO_TO_SUBCLASSES(mask,addToObserver(obs, mask));
	// Register with myself (without the OMDescendentsInterest)
	TOMProxyItem::registerObserver(obs,mask);
	// If interested in instances register with my instances
	DO_TO_INSTANCES(mask,addToObserver(obs, mask));
}


void TOMClass::deregisterObserver(TOMUniversalObserver* obs,
									OMInterestMask mask) {
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	// Deregister from my sub classes if necessary
	DO_TO_SUBCLASSES(mask,deregisterObserver(obs, mask));
	// deregister the observer from myself
	TOMProxyItem::deregisterObserver(obs);
	// If interested in instances deregister from my instances
	DO_TO_INSTANCES(mask,deregisterObserver(obs));
}

void TOMClass::reRegisterObserver(TOMUniversalObserver* obs,
									OMInterestMask newMask) {
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	// reRegister with my sub classes if necessary
	DO_TO_SUBCLASSES(newMask,reRegisterObserver(obs, newMask));
	// reRegister the observer for my self
	TOMProxyItem::reRegisterObserver(obs,newMask);
	// reRegister with my instances - always since this is also a dereg.
	_DO_TO_INSTANCES(reRegisterObserver(obs,newMask));
}

void TOMClass::addToObserver(TOMUniversalObserver* obs,
							 OMInterestMask newMask) {
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	// addTo with my sub classes if necessary
	DO_TO_SUBCLASSES(newMask,addToObserver(obs, newMask));
	// addTo the observer for my self
	TOMProxyItem::addToObserver(obs,newMask);
	// addTo the observer for my instances
	DO_TO_INSTANCES(newMask,addToObserver(obs,newMask));
}

void TOMClass::subtractFromObserver(TOMUniversalObserver* obs,
									 OMInterestMask newMask) {
	// Do something only if animation is active
	if (!TOMSystem::animationIsActive()) return;

	// subtructFrom with my sub classes if necessary
	DO_TO_SUBCLASSES(newMask,subtractFromObserver(obs, newMask));
	// subtructFrom the observer for my self
	TOMProxyItem::subtractFromObserver(obs,newMask);
	// subtructFrom the observer for my instances -  always!
	_DO_TO_INSTANCES(subtractFromObserver(obs,newMask));
}



void TOMClass::_showYourself(TOMUniversalObserver* obs, 
							 int& theMask) {
	int finalMask;
	// First notify what elements I have
	if ( (theMask & OMExistInterest) 
		/*	&& myMask.isInteresting(OMExistInterest)*/ ) {
		obs->notifyClassValues(this);
		finalMask = OMNoInterest;
	} else
		finalMask = OMExistInterest;
	if (theMask & OMInstanceInterest) { 
		int localMask = theMask;
		finalMask = finalMask | localMask;
	}
	theMask = finalMask;
}

OMBoolean TOMClass::showYourself(TOMUniversalObserver* obs,
								   int theMask) {
	// First show yourself
	OMBoolean toWait = TOMProxyItem::showYourself(obs,theMask);
	// Then show descendents if required
	if (theMask & OMSubClassInterest) { 
		for(OMIterator<TOMNameSpaced *> i(mySubClasses); *i; i++) {
			// A class has only "classes" as subClasses
			TOMClass * subClass = (TOMClass *)(*i);
			toWait = toWait || subClass->showYourself(obs,theMask);
		}
	}
	if (theMask & OMInstanceInterest) { 
		// Tell my descendents to "show" themselves too
		// Note they must work in all or nothing
		// Otherwise outputs will get shuffled
		for(OMIterator<TOMInstance*> i(this->getTomNameGiver()); *i; i++) {
			(*i)->showYourself(obs,theMask);
		}
	}
	return toWait;
}

void TOMNameSpaced::getSuperClassList(TOMSData* s, OMSPosition& p) {
	// Guess a single super class
	TOMSData* t = (TOMSData*)s;
	TOMNameSpaced * mySuper = (TOMNameSpaced *)t->safeGetPointer(p);
	if (isRealItem(mySuper))
		mySuperClasses.add(mySuper);
	else {
		long superCount = (long)mySuper;
		for(int i=0;i<superCount;i++) {
			mySuper = (TOMNameSpaced *)t->safeGetPointer(p);
			mySuperClasses.add(mySuper);
		}
	}
}

int TOMClass::getCount(int theMask) {
	// Get my real count
	int count = tomNameGiver.getCount();
	// If with descendents recursively add up from my descendents
	if (theMask & OMSubClassInterest)
		for(OMIterator<TOMNameSpaced *> i(mySubClasses); *i; i++) {
			// A class has only "classes" as subClasses
			TOMClass * subClass = (TOMClass *)(*i);
			count += subClass->getCount(theMask);
		}
	return count;
}


void TOMClass::setRelations(OMList<TOMList* > * relations) {
	for (OMIterator<TOMList *> i(*relations); *i; ++i)
		myRelations.add((*i)->getName());
}



TOMProxyItem* lastDeleted = NULL;


void TOMClass::handleMessage(AnimMessage *msg)
{
	int code = msg->getCode();
	if (code == opList && operationList.getCount() == 0) 
	{
		AnimRegisterOperations* regOp = (AnimRegisterOperations *)msg;
		AnimListField* opDataList = regOp->getOpDataList();
		if (opDataList != NULL) 
		{
			int numOfOp = opDataList->getSize();
			int i;
			for (i = 0; i < numOfOp; ++i) {
				AnimMessageField *opDataField = (AnimMessageField *)(opDataList->getNextField());
				if (opDataField != NULL) {
					rhp_long64_t tmp = (rhp_long64_t)opDataField->getValue();
					AnimOperationData *opData = (AnimOperationData *)tmp;
					operationList.add(new TOMOperation(opData, this));
				}
			}
		}
	}
}

// to notify AnimOpReturn
void TOMClass::notifyOpReturn(TOMInstance* caller,
								 TOMInstance* called,
								 OMString method,
								 OMMethodType methodType,
								 OMString& retValString, 
								 OMList<OMString>& nameValList) 
{ 
	NOTIFY_OBSERVERS(OMUserControl, notifyOpReturn(caller, called, method, methodType, retValString, nameValList));
}



OMList<TOMOperation *>* TOMClass::findPossibleOperationsToCall(const OMString& opName, const int numOfArgs, const OMString& signature)
{
	OMList<TOMOperation *>* theOpList = new OMList<TOMOperation *>;
	OMBoolean done = FALSE;

	for(OMIterator<TOMOperation *> i(operationList); 
		(*i) && (!done); 
		i++) {
		if ((*i)->match(opName, numOfArgs, signature)) {
			theOpList->add(*i);
			if (signature.IsEmpty() == FALSE) // match based on signature
				done = TRUE;
		}
	}


	// in case nothing was found try the super classes
	done = FALSE;
	while ((!done) && (theOpList->getCount() == 0)) {
		for (OMIterator<TOMNameSpaced *> supIter(mySuperClasses); (*supIter); supIter++) {
			TOMClass *theClass = (TOMClass *)(*supIter);  // TOMClass may only have TOMClass as super class
			OMList<TOMOperation *>* tmpList = theClass->findPossibleOperationsToCall(opName, numOfArgs, signature);
			for (OMIterator<TOMOperation *> opIter(*tmpList); *opIter; opIter++)
			{
				if (theOpList->find(*opIter) == 0)
					theOpList->add(*opIter);
			}
		}
		done = TRUE;
	}
	return theOpList;
}

OMBoolean TOMClass::hasStaticOperationToCall()
{
	OMBoolean res = FALSE;
	for(OMIterator<TOMOperation *> i(operationList); 
		(*i) && (!res); 
		i++) {
		res = (*i)->getIsStatic();
	}
	return res;
}

void TOMClass::handleMessage(OMNotify msgCode, TOMSData* s, OMSPosition p) {
	// Perform the operation appropriate to this message code
	switch (msgCode) {
		// messages that just inform
	case instanceCreated: {
		// Register the instance in class
		// Get the instance
		TOMInstance *instance = (TOMInstance *)s->safeGetPointer(p);
		if (!tomIsValidItem(instance)) {
			OMString msg = "An invalid reference to an instance of class ";
			msg += myName;
			msg += " was specified in an Instance Created Message.";
 			// OMString msg = "Received instance created message with a reference to an illegal instance";
			tomSendWarning(msg);
			return;
		}
		// Get its relation TOMSData
		TOMSData * itsRelationsMessage = s->safeGetOMSData(p);
		// Actually register it
		registerItem(instance,itsRelationsMessage);
		// No longer needed so free it
		delete itsRelationsMessage;

		// Get the Creator
		TOMInstance *creator = (TOMInstance *)s->safeGetPointer(p);

		// Notify the instance about its creation
		instance->notifyConstructionFinished(creator);

		// Notify the creator about the creation
		if (tomIsValidItem(creator))
			creator->notifyYouAreCreator(instance);

		// Notify my observers
		NOTIFY_OBSERVERS(OMExistInterest,
						notifyInstanceCreated(instance,creator) );
		break;
						  }
	case instanceDeleted: {
		// Get pointer to real instance and if it is a singleton in its class
		// Yachin 2.2.99 changed getPointer to safeGetPointer
		TOMInstance * destroyed = (TOMInstance *)s->safeGetPointer(p);
		lastDeleted = destroyed;

		// Notify my observers
		// Get the destroyer
		TOMInstance *destroyer = (TOMInstance *)s->safeGetPointer(p);

		destroyInstance(destroyed, destroyer);
		break;
						  }
		
	case classValues: {
		update(s,p);
		// Notify my observers
		NOTIFY_SHOW_OBSERVERS(notifyClassValues(this));
		break;
					  }
	// Messages which should be ignored
	case methodReturned:	// callStack does the notify
	case methodCalled:		// callStack does the notify
		break; // Tracer does not output these events.

		// Messages which should never occuer
	case becameActivated:
	case becameDeactivated:
	case breakpointActive:
	default: notifyUnexpectedMessage(msgCode);
	}
}

#define READ_ITEM(real,proxy,count,s,position)				\
	if (count) {											\
		real = s->safeGetPointer(position);					\
		proxy = (TOMInstance *)s->safeGetPointer(position);	\
		count--;											\
	} else { real = proxy = NULL; }


void TOMClass::update(TOMSData *s, OMSPosition& position) {
	// 1. Get ready to update yourself
	// 1.1 Copy yourself to oldList
	OMList<TOMInstance *> oldList;
	for(OMIterator<TOMInstance *> i(this->tomNameGiver); *i; i++) {
		oldList.add(*i);
	}

	// 1.2 Empty myself
	tomNameGiver.removeAll();

	// 2. Get the "message" ready for comparison
	// 2.1 Get the number of instances in this class
	int count = s->safeGetInt(position);
	void * real;;
	TOMInstance * proxy;

	//
	// 3. Iterate on both old and new lists
	// elements appearing in both should remain unchanged
	// elements appearing only in "old" should be deregistered
	// elements appearing only in "new" should be registered
	// WARNING: TO GET AN EFFICIENT ALGORITHM WE RELY ON THE
	// FACT THAT ITEMS ARE ORDERED IN THE LIST ACCORDING TO
	// TIME OF ENTERING THE LIST (always addTail() )
	// If this is not true - the following will do nonsense!!!!
	// As a side effect an item that left the list and returned to it
	// will be first deregistered and then (re)registered) this can happen 
	// only in TOMRelations. There it is both acceptable and efficient
	// deregister and reregister is faster than search
	//

	// 3.1 Create two iterators:
	OMIterator<TOMInstance *> old(oldList);
	// OMIterator<TOMInstance *> young(newList);
	READ_ITEM(real,proxy,count,s,position);

	// 3.2 Re-Enter all common "old" items
	for(; *old; old++) {
		if (*old == proxy) {
			// The current item appears in both lists so keep it.
			tomNameGiver.add(*old);
			// read next item
			READ_ITEM(real,proxy,count,s,position);
		} else // Real instance no longer exists - delete the proxy
			delete *old;
	}

	// 3.3 Register all remaining "young" items
	if (real) {
		OMString msg = "Unable to update the instance list of class ";
		msg += myName;
		tomSendWarning(msg);
		//tomSendError("Cannot update instances from class list");
		// This part should be fixed when we have a "fastMode"
		// make sure we send item's relations and read them properly
	}
}


TOMProxyItem* TOMClass::name2Item(char *& theName) const {
	if (	isInstanceOrObjectCallString(theName) || 
			theName[0]=='[' || theName[0]==':') {
		// This is an "item" whose name was already consumed 
		return tomNameGiver.name2Item(theName);
	} else if (isClassCallString(theName)) {
		// This is a class defined within THIS class
		// Look in the list of mySub classes
		// Currently we do not do this
		tomSendError("Class as name space not implemented 'x::y' not allowed");
		return OMGarbage;
	} else {	// consume the name
		OMString firstName;
		eatOneToken(theName,firstName);
		// theName must ==  this class name
		if (theName!=OMString(myName)) {
			OMString errMsg = theName;
			errMsg += "bad name for item in class";
			errMsg += myName;
			tomSendError(errMsg);
			return OMGarbage;
		} else 
			return tomNameGiver.name2Item(theName);
	}
}

void TOMClass::accept(TOMProxyVisitor1Arg & visitor) 
{
	// do for the class
	/* OMBoolean result = */ (void) visitor.execute(*this);
	// for all instances
	for(OMIterator<TOMInstance *> i(this->tomNameGiver); *i; ++i) {
		(*i)->accept(visitor);
	}
}


#ifdef OMANIMATOR
OMString TOMClass::getRhpFullPathStr(bool assumePart /*= false*/) const
{
	// Example String: P1::P2::P3::C1#C2#C3 (Class)
	
	OMString res;

	const TOMProxyItem *currentItem = this;

	OMBoolean wasClass = TRUE;
	OMBoolean innerClass = FALSE;
	
	char *copyOfMyName = new char[strlen(myName) + 1];
	copyOfMyName[0] = '\0';

	char colCol[] = "::";

	if (strrchr(myName, ':') != NULL) {
		char *copy2 = new char[strlen(myName) + 1];
		strcpy(copy2, myName);
		char *lastColCol = strrchr(copy2, ':');
		innerClass = TRUE;
		char *token = strtok(copy2, colCol);
		// replace "::" with "#"
		while (token != NULL) {
			strcat(copyOfMyName, token);
			if (token < lastColCol) { 
				strcat(copyOfMyName, "#");
			}
			token = strtok(NULL, colCol);
		}
		delete[] copy2;
		// replace last '#' with '.' if we assumePart
		char* lastHash = strrchr(copyOfMyName, '#');
		if (lastHash != NULL)
			*lastHash = '.';
	}
	else {
		strcpy(copyOfMyName, myName);
	}

	res = copyOfMyName;

	while (currentItem != NULL) {
		TOMProxyItem* context = (TOMProxyItem *)(currentItem->getContext());
		if (context != NULL) {
			OMProxyType pType = context->getType();
			OMString contextName = context->getFirstName();
			OMString tmp = res;
			OMString sep;
			if (pType == omProxyClass) {
				sep = "#";
			}
			else if (pType == omProxyPackage) {
				if (wasClass) {
					if (assumePart) { // in case of implicit we need the TopLevel
						if (innerClass) 
							sep = "::TopLevel#"; 
						else
							sep = "::TopLevel."; 
					}
					else
						sep = ".";
					wasClass = FALSE;
				}
				else {
					sep = "::";
				}
			}
			if (sep.IsEmpty() == FALSE) {
				res = contextName;
				res += sep;
				res += tmp;
			}
		}
		currentItem = context;
	}

	delete[] copyOfMyName;
	return res;
}
#endif

void TOMClass::destroyInstance(TOMInstance* destroyed, TOMInstance* destroyer)
{
	if(destroyed == NULL)
		return;
	
	// Deregister it - needed here so active
	// navigation expressions will not find it again
	tomNameGiver.deregisterItem(destroyed);
	
	// Check for valid items
	if (!tomIsValidItem(destroyed)) return;
	if (destroyer != NULL && !tomIsValidItem(destroyer)) {
		if (tomIsValidItem(destroyed)) delete destroyed;
		return;
	}
	
	// Notify the instance itself that it will be destroyed
	destroyed->notifyYouAreDeleted(destroyer);
	
	// Notify the destroyer about the destruction
	if ( isRealItem(destroyer) && destroyer!=destroyed )
		destroyer->notifyYouAreDestroyer(destroyed);
	
	// Notify other observers
	NOTIFY_OBSERVERS(OMExistInterest,
		notifyInstanceDeleted(destroyed,destroyer) );
	
	// Actually delete the instance
	delete destroyed;
}

TOMClass * TOMClassIteratorPair::getNextClass() {
	TOMNameSpaced *theClass = value();
	if (theClass) increment();
	return (TOMClass*)theClass;
}

void TOMClassIterator::clearMe(){
	while (classIter.top())
		delete classIter.pop();
}

TOMClass * TOMClassIterator::getNextClass() {
	while (classIter.top()) {
		TOMClass * currentClass = classIter.top()->getNextClass();
		if (currentClass) {
			classIter.push(new TOMClassIteratorPair(currentClass));
			return currentClass;
		}
		// else this class item and all its sub tree were scaned
		delete classIter.pop();
	}
	return NULL;
}

void TOMClassIterator::advanceToNextNonEmptyClass() {
	while (!value()) {
		TOMClass * currentClass = (TOMClass*)getNextClass();
		if (!currentClass)
			return;	// All nodes in tree where scaned
		OMIterator<TOMInstance *>::reset(*currentClass->getTomNameGiver()); 
	}
}

TOMClassIterator& TOMClassIterator::increment() { 
	// Advance my self as an Instance iterator
	OMIterator<TOMInstance *>::increment();
	// As long as I == NULL try the next class
	advanceToNextNonEmptyClass();
	return *this;
}


void TOMClassIterator::reset(TOMClass& theClass){
	// remember the class
	myClass = &theClass;
	// Clear any old stuff we may have
	clearMe();
	classIter.push(new TOMClassIteratorPair(myClass));
	OMIterator<TOMInstance *>::reset(*(theClass.getTomNameGiver())); 
	advanceToNextNonEmptyClass();
}




//
// $Log: tomclass.cpp $
// Revision 1.93  2007/03/11 13:14:41  ilgiga
// Change copyright comment
// Revision 1.92  2007/03/04 15:07:30  ilgiga
// Telelogic instead of i-Logix
// Revision 1.91  2006/10/31 08:58:50  ccohen
// support running multiple animation processes.
// Revision 1.90  2005/08/23 14:50:42  amos
// bugfix 85444 to main branch
// Revision 1.89.1.2  2005/08/22 10:05:38  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.89  2004/09/27 11:11:08  eldad
// Revision 1.88  2004/01/12 10:30:39  eldad
// Allow dot (.) notation in C++\Java
// Revision 1.87  2003/12/30 13:11:04  eldad
// Bug #68559 - a more specialized ID String to locate the class in the model
// Revision 1.86  2003/10/08 15:11:32  eldad
// Added special treatment for implicit object for finding classes.
// Revision 1.85  2003/10/02 09:37:50  eldad
// Added getRhpFullPathStr() in facour of Rhapsody GUI to locate 
// the proper IClass.
// Revision 1.84.1.1  2003/05/26 11:06:20  eldad
// Duplicate revision
// Revision 1.83  2002/08/05 11:47:44  Eldad
// If the very same TOMOperation instance found by class when looking 
// for an operation in the super classes - it does not count!
// Revision 1.82  2002/07/29 09:42:25  Eldad
// Anim Operation Calls.
// Revision 1.81  2002/05/15 14:55:24  Eldad
// To main branch.
// Revision 1.80.1.2  2002/05/13 08:56:41  Eldad
// myName leak.
// Revision 1.80.1.1  2001/11/12 10:48:52  Eldad
// Duplicate revision
// Revision 1.79  2001/10/01 10:22:33  Eldad
// 1.78.1.2 to main branch.
// Revision 1.78.1.2  2001/09/26 00:48:38  Eldad
// Changed some of the erros to warnings that are not to be shown in popup 
// message box.
// Revision 1.78.1.1  2001/08/23 11:17:30  Eldad
// Duplicate revision
// Revision 1.77  2001/08/23 09:36:05  Eldad
// Merge 1.73.1.2 + 1.76
// Revision 1.76  2001/05/16 08:32:43  amos
// merge OSE 4.3.1 support into r40
// Revision 1.75  2001/05/06 12:50:49  Eldad
// Changed an error message.
// Revision 1.74  2000/12/25 10:39:50  amos
// move to warning level 4
// Revision 1.73.1.2  2001/07/16 13:05:00  Eldad
// Bug #46420.
// In Java multiplicty == 0 does not indicate first instance in case of singleton.
// TOMNoMultiplicity is returned from giveMultiplicity().
// Revision 1.73.1.1  2001/05/06 12:49:28  Eldad
// Changed an error message
// Revision 1.73  2000/11/13 10:11:10  Eldad
// Avoid array overflow (red in purify)
// Revision 1.72  2000/11/08 17:22:51  amos
// back to main branch
// Revision 1.71.1.2  2000/11/08 17:22:51  amos
// remove declaration of a redundant local variable
// Revision 1.71.1.1  2000/08/06 07:48:35  amos
// Duplicate revision
// Revision 1.70  2000/04/12 10:42:32  yachin
// Fix bug for powerPC compiler
// Revision 1.69.1.1  2000/07/11 09:23:50  amos
// changes related to modify char* to const char*.
// Revision 1.69  2000/04/10 12:56:16  yachin
// tomInstance2String instead of getFullName()  - due to deleted context
// Revision 1.68  2000/03/14 08:35:55  amos
// back to main branch
// Revision 1.67.1.3  2000/03/08 14:09:43  amos
// add safe programming
// Revision 1.67.1.2  2000/02/21 08:42:27  amos
// add safe programming to prevent crashes caused by misbehaving applications.
// Revision 1.67.1.1  2000/02/17 07:06:32  amos
// Duplicate revision
// Revision 1.66  2000/02/07 14:55:48  amos
// back to main branch
// Revision 1.65.1.2  2000/02/06 07:55:55  amos
// add valid item check in TOMClass::handleMessage(), case instanceDeleted
// Revision 1.65.1.1  2000/01/20 07:07:58  amos
// Duplicate revision
// Revision 1.64  1999/10/12 13:33:00  yachin
// Fix bugs
// Revision 1.63  1999/08/03 11:19:08  yachin
// Some fixes related to name2Item
// Revision 1.62  1999/07/15 13:42:02  yachin
// change 'instanceCallString from '->' to '.'
// Revision 1.61  1999/06/13 19:44:58  yachin
// Deregister from base when register in derived
// Revision 1.60  1999/02/18 11:27:12  yachin
// Fix regression on initial call stack entry
// Revision 1.59  1999/02/16 05:56:53  yachin
// Speed up of constructors
// Revision 1.58  1998/11/23 17:39:18  beery
// Revision 1.57  1998/11/22 14:17:15  beery
// Revision 1.56  1998/11/19 17:53:35  beery
// Revision 1.55  1998/11/17 13:49:33  beery
// Revision 1.54  1998/11/17 12:14:05  beery
// Revision 1.53  1998/08/02 15:07:40  beery
// Revision 1.52  1998/05/21 11:24:03  yachin
// Fix bug 5603 (have getPackage return a TOMPackage and not a TOMProxyItem)
// Revision 1.51  1998/03/25 05:38:42  yachin
// Fix bug 3927 - now notifyDestructor sent only once if destroyer==destructor
// Revision 1.50  1997/05/27 09:02:48  yachin
// Made tomstr == ystr
// Revision 1.49  1997/04/09 12:13:08  ofer
// calling delete myNmae instead of TOMProxyItem::myName
// since the gnu 2.51 ( under VxWorks environment does not like it)
// tomclass.cpp/h
// Revision 1.48  1997/03/31 10:00:39  yachin
// Fix Unizx warnings
// Revision 1.47  1997/03/31 08:57:09  yachin
// Fix Warning for Unix
// Revision 1.46  1997/03/13 13:41:36  yachin
// Fix memory leaks
// Revision 1.45  1997/03/09 08:45:07  yachin
// bugfix on subtractFromObserver
// Revision 1.44  1997/03/04 11:52:12  yachin
// added namegiver::name2item + consequences
// Revision 1.43  1997/02/21 07:22:01  yachin
// Fix event inheritance bug 2529
// Revision 1.42  1997/02/19 12:35:30  yachin
// name2item bug fix
// Revision 1.41  1997/02/19 11:19:55  yachin
// Add isAnimationActive mode to all observer operations
// Revision 1.40  1997/02/17 12:32:38  yachin
// bug fixes
// Revision 1.39  1997/02/16 09:29:04  yachin
// remove theClass parameter from instanceCreated/delted notifies.
// make inverseRelationConnect cascade from relations and not the createObserver
// Revision 1.38  1997/02/12 06:11:21  yachin
// Fixes for Unix proting
// Revision 1.37  1997/02/11 12:54:32  yachin
// Adding Name spaces
// Revision 1.36  1997/01/22 11:54:07  yachin
// Inverse composite relation bug fix
// Revision 1.35  1997/01/21 11:08:45  yachin
// changed _int32 to int
// Revision 1.34  1997/01/19 11:19:48  yachin
// Revision 1.33  1997/01/14 13:52:43  yachin
// Revision 1.32  1997/01/13 11:38:56  yachin
// Make constructor/destructor mult=2 notifications
// Revision 1.31  1996/11/24 12:40:35  yachin
// Revision 1.30  1996/10/29 08:28:47  yachin
// Revision 1.29  1996/10/24 12:56:38  yachin
// Rewrite of observer registration mechanism + new instance iterators
// Revision 1.28  1996/10/23 12:06:29  yachin
// added getCount(omwithdescnedents)
// Revision 1.27  1996/10/23 10:10:01  yachin
// Revision 1.26  1996/10/22 12:04:58  yachin
// Revision 1.25  1996/10/14 13:26:18  yachin
// Handle sub classes and set/cancel timeout
// Revision 1.24  1996/10/10 08:01:24  yachin
// Revision 1.23  1996/10/10 06:15:10  yachin
// Revision 1.22  1996/10/09 07:37:05  yachin
// Revision 1.21  1996/10/01 06:56:21  yachin
// Fixing the "show class all" bug
// Revision 1.20  1996/09/30 10:05:27  yachin
// Revision 1.19  1996/09/29 12:42:38  yachin
// Get Relations together with "create proxy" message (fix relations bug
// Revision 1.18  1996/09/24 13:56:26  yachin
// Revision 1.17  1996/09/19 12:31:36  yachin
// add class info to TOMInstance
// Revision 1.16  1996/09/16 09:43:36  yachin
// Revision 1.15  1996/09/16 09:28:28  yachin
// Revision 1.14  1996/09/09 07:25:54  yachin
// Fix bug in name2item
// Revision 1.13  1996/09/08 13:28:55  yachin
// Registeration of items which do not yet exist
// Revision 1.12  1996/09/05 13:35:54  yachin
// Revision 1.11  1996/09/04 13:16:09  yachin
// Connect with Israel
// Revision 1.10  1996/08/28 05:38:02  ofer
// Revision 1.9  1996/08/15 08:42:40  yachin
// Revision 1.8  1996/08/14 12:40:23  yachin
// Seperate TOM Masks from AOM Masks. Fix bugs with attr. and states
// Revision 1.7  1996/08/12 12:28:47  yachin
// Unified Interface for "file" and "stdin". seperated show from trace
// Revision 1.6  1996/08/08 08:23:27  yachin
// Revision 1.5  1996/08/06 12:52:04  yachin
// Version for Prototype 4
// Revision 1.4  1996/07/03 12:45:49  yachin
// Fixing bugs for "const" and "static
// enhancements for attributes and indentation
// Revision 1.3  1996/06/26 12:45:58  yachin
// Put header message and fix some bugs
// Revision 1.2  1996/06/19 10:21:24  yachin
// Revision 1.1  1996/06/17 05:40:39  yachin
// Initial revision
//
