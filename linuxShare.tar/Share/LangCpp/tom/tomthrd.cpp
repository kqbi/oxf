#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomthrd.cpp 1.48 2007/03/11 13:14:47 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomthrd.cpp $
//	file version:	$Revision: 1.48 $
//
//	purpose:	Implement the TOMThread/TOMThreadManager classes
//
//	author(s):		Yachin Pnueli
//	date started:	25.12.96
//	date changed:	$Date: 2007/03/11 13:14:47 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1996, 2008. All Rights Reserved.
//

#include "tomthrd.h"
#include "tomother.h"
#include "tomstep.h"
#include "tomstr.h"
#include "tomobs.h"
#include "tomdisp.h"
#include "tomsys.h"
#include "tominst.h"
#include <omcom/omexp.h>
#include "tomExtern.h"

#include <omcom/RiCppAnimMessages.h>
#include <omcom/AnimAllocateCore.h>
#include <omcom/AnimIntField.h>

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomthrd_H;
#endif

//
// TOMThread methods
//
// Patch to remove _omCloseHandle from display
TOMThread* the_omCloseHandle = NULL;
// End of Patch to remove _omCloseHandle from display

TOMThread::TOMThread(gen_ptr theReal, OMInterestMask theStepperMask,
					 gen_ptr realCallStack,
					 gen_ptr realStepper,
					 gen_ptr realEventQueue,
					 gen_ptr realOsHandle):
			TOMProxyItem(theReal,NULL,omThread,OMNoInterest,NULL) {
				// Null name and null context until I get more info
	// Create the thread elements
	myCallStack = new TOMCallStack(realCallStack);
	myCallStack->setThread(this);
	myStepper	= new TOMStepper(realStepper, theStepperMask);
	myOwnCallStackAndStepper = TRUE;
	myEventQueue= new TOMEventQueue(realEventQueue);
	myEventQueue->setThread(this);

	// Create "myself"
	myContext = OMInConstruction;
	suspended = FALSE;
	myOsHandle = realOsHandle;
	if (TOMSystem::sysInSilentMode()) {
		TOMSilent silent;
		accept(silent);
	}
	myAffinity = 0;
	myPowerMode = 0;
}

#ifdef OMANIMATOR
TOMThread::TOMThread(gen_ptr theReal,
					 gen_ptr realEventQueue,
					 TOMThread *mainTask,
					 gen_ptr realOsHandle):
			TOMProxyItem(theReal,NULL,omThread,OMNoInterest,NULL) {
	
	if(mainTask != NULL) {
		// Do not create the thread callstack and stepper
		myCallStack = mainTask->getCallStack();
		myCallStack->setThread(this);
		myStepper	= mainTask->getStepper();
		myOwnCallStackAndStepper = FALSE;
		// Create the thread event queue
		myEventQueue= new TOMEventQueue(realEventQueue);
		myEventQueue->setThread(this);

		// Create "myself"
		myContext = OMInConstruction;
		suspended = FALSE;
		myOsHandle = realOsHandle;
		if (TOMSystem::sysInSilentMode()) {
			TOMSilent silent;
			accept(silent);
		}
	}
	myAffinity = 0;
	myPowerMode = 0;
}
#endif

TOMThread::~TOMThread() {
	// Notify TOMSystem that I'm finished 
	TOMSystem::threadManagerInstance()->remove(this);

	// Notify my observers - (currently non
	// TOMProxyItem::clearObserversNotify();

	// Tell AOMThread he may delete itself
	// These two lines are here as a synch. mechanism
	myLastSentMask = myMask = OMExistInterest;
	setInterestMask(OMNoInterest);

	// Eldad: The following makes the Go Idle actually stop.
	// The reason this was added is that in C++ AOM only sendYourself
	// stops all thres (enterThreadsShouldStop) - an optimization made
	// for version 3.0.
#ifdef OMANIMATOR
	TOMDispatcher::instance()->sendMessage(
			new OMSData(getReal(), sendYourself, (gen_ptr)(rhp_long64_t)&myMask) );
#endif

	// Delete my "parts"
	if (myOwnCallStackAndStepper)
	{
		delete myCallStack;
		delete myStepper;
	}
	delete myEventQueue;
	if (myName!=NULL) delete[] myName;
	if (the_omCloseHandle == this)
		the_omCloseHandle = NULL;
}

inline void TOMThread::setName(char * theName) { 
	if (myName!=NULL)
		delete[] myName;
	myName = theName;
}


OMString& TOMThread::outputFirstName(OMString& s) const {
	if (myName != NULL) // named thread case
		s += myName;
	else { // unNamed thread case
		s+="@";
		if (isRealItem(myContext) && // We have a proxy
			tomIsValidItem(myContext) /* safe programming */) {
			myContext->outputFullName(s);
		}
		else {
			s += "<unknown>";
		}
	}
	return s;
}

void TOMThread::suspend() {
	suspended = TRUE;
	// Notify my observers

	// Tell my Real "stepper" to suspend itself
	TOMDispatcher::instance()->sendMessage(
		new OMSData(myStepper->getReal(), suspendThread) );
}

void TOMThread::resume() {
	suspended = FALSE;
	// Notify my observers

	// Tell my Real "stepper" to resume itself
	TOMDispatcher::instance()->sendMessage(
		new OMSData(myStepper->getReal(), resumeThread) );
}

void TOMThread::notifyLostFocus() {
	// Notify my observers

	// Notify my "parts"
	OMTRY {
		myCallStack->notifyLostFocus();
		myStepper->notifyLostFocus();
		myEventQueue->notifyLostFocus();
	}
	OMCATCH_ALL {
		// ignore error
	}
}



void TOMThread::handleMessage(OMNotify msgCode, 
							  TOMSData* s, 
							  OMSPosition p) {
	switch (msgCode) {
	case ::setName:	{
		if (s->isPointer(p))
		{
			TOMProxyItem *context = (TOMProxyItem*)s->getPointer(p);
			setContext(context);
			// when the instance that created the thread attach itself
			// notify it about core allocation (if occured)
			TOMInstance* inst = (TOMInstance*) context;
			if(tomIsValidItem(inst) && inst->getType()==omProxyInstance && myAffinity != 0)
				inst->notifyCoreAllocation(inst,myAffinity,myPowerMode);
		}
		else if (s->isString(p))
			setName(s->getChar(p));
		// Patch to remove _omCloseHandle from display
		if (getFirstName()!=NULL && 
				strcmp(getFirstName(),"_omCloseHandle")==0) {
			the_omCloseHandle = this;
			TOMSystem::threadManagerInstance()->remove(this);
		}
		// End of Patch to remove _omCloseHandle from display
		break;
						}
	default:
		{
		OMString errMsg = 
		"TOMThread Received unexpected message of type ";
		errMsg += (char*)omnotify2String(msgCode);
		tomSendWarning(errMsg);
		}
	}
}

void TOMThread::handleMessage(AnimMessage* msg)
{
	int code = msg->getCode();
	if (code == allocateCore) {
		// for now, just store the allocation parameters
		AnimAllocateCore *aMsg = (AnimAllocateCore *)(msg);
		myAffinity = (int)(rhp_long64_t)aMsg->getAffinity()->getValue();
		myPowerMode = (int)(rhp_long64_t)aMsg->getPowerMode()->getValue();
//		NOTIFY_OBSERVERS(OMAllInterest, notifyCoreAllocation(affinity, powerMode));
	}
}

void TOMThread::accept(TOMProxyVisitor1Arg & visitor) 
{
	// do for me
	/* OMBoolean result = */ (void) visitor.execute(*this);
	// do for the call stack
	myCallStack->accept(visitor);
	// do for the event queue
	myEventQueue->accept(visitor);
}


//
//	TOMThreadManager methods
//

TOMThreadManager::TOMThreadManager():TOMProxyItem((char *)("ThreadManager")) {
	focusThread = NULL;
}


TOMThreadManager::~TOMThreadManager() {
	// Clear current thread (so it does not interfere with deletion
#ifdef OMANIMATOR
	setFocusThread((TOMThread*)NULL);
#else
	focusThread = NULL;
#endif
	// Delete all threads
	while(!threadList.isEmpty())
	{
		TOMThread* thread = threadList.getFirstConcept();
		if (thread && tomIsValidItem(thread))	// safe programming
			delete thread; 
	}
	// Patch to remove _omCloseHandle from display
	if (the_omCloseHandle) {
		delete the_omCloseHandle;
		the_omCloseHandle = NULL; // so we do not crash on next animation
		// End of Patch to remove _omCloseHandle from display
	}
	_socket2FocusThreadMap.removeAll();
}

void TOMThreadManager::remove(TOMThread* thread) {
	// First remove it from list
	threadList.remove(thread);
	
	// make sure it is no longer the current thread
	TOMThread* pFocusThread = focusThread;
#ifdef OMANIMATOR
	pFocusThread = getFocusThread();
#endif
	if (thread == pFocusThread) {
		// If it was focusThread replace it by the first thread
		// in list which is not suspended
		for(OMIterator<TOMThread *> i(&(this->threadList)); (*i); ++i) {
			TOMThread * thread = *i;
			if ( !thread->isSuspended()) {
				setFocusThread(thread);
				return;
			}
		}
		// All threads are suspended so set current to first
		setFocusThread(threadList.getFirstConcept());
	}
}

TOMThread* TOMThreadManager::add(gen_ptr real, OMSData* s, OMSPosition p){
	// Get the real "parts" of this thread
	gen_ptr stepper = s->safeGetPointer(p);
	gen_ptr callStack = s->safeGetPointer(p);
	gen_ptr eventQueue = s->safeGetPointer(p);
	gen_ptr osHandle = s->safeGetPointer(p);

	// Create the thread
	TOMThread* thread;
	
	// Set focus thread is necessary
	TOMThread* pFocusThread = focusThread;
#ifdef OMANIMATOR
	pFocusThread = getFocusThread();
#endif
	if (pFocusThread==NULL) {
		thread = new TOMThread(real, OMStopWhenNext | OMStopWhenStep,
								callStack, stepper, eventQueue,osHandle);
		setFocusThread(thread);
	} else {
#ifdef OMANIMATOR
		if(osHandle==NULL && TOMExterns::Anim()->IsInExtendedExecutionModel()) {
			TOMThread *mainTask = NULL;
			for(OMIterator<TOMThread *> i(&(this->threadList)); *i; i++) {
				if ((*i)->getOsHandle() != NULL) {
					mainTask = (*i);
					break;
				}
			}
			thread = new TOMThread(real, eventQueue, mainTask, osHandle);
		} else
#endif
		thread = new TOMThread(real, OMNoInterest,
								callStack, stepper, eventQueue,osHandle);
	}
	// Actually add it to the list
	threadList.add(thread);
	return thread;
}

TOMThread* TOMThreadManager::name2Thread(const OMString& name) {
	OMString s;
	for(OMIterator<TOMThread *> i(&(this->threadList)); *i; i++) {
		s.Empty();
		(*i)->outputFirstName(s);
		if (s==name)
			return *i;
	}
	return (TOMThread*)OMGarbage;
}

TOMThread* TOMThreadManager::osHandle2Thread(gen_ptr osHandle) {
	for(OMIterator<TOMThread *> i(&(this->threadList)); *i; i++) {
		if (osHandle == (*i)->getOsHandle())
			return *i;
	}
	return (TOMThread*)NULL;
}

TOMThread* TOMThreadManager::name2Thread(char *& name) {
	OMString threadName;

	// Skip the "#Thread" keyword if present
	char *c = name;
	eatOneToken(c,threadName,"#");
	if ( !threadName.CompareNoCase((char *)("#Thread")))
		name = c;

	// Build the threadName from its '->' parts
	eatOneToken(name,threadName,"@[]");
	while (	isInstanceOrObjectCallString(name)) {
		char* orgName = name;
		// Eat the "->"
		skipInstanceOrObjectCallString(name);
		if (name[0]=='#') {
			// roll back
			name = orgName;
			break;
		}
		threadName += (char*)getInstaceCallString();
		// Eat the next "part"
		OMString namePart;
		eatOneToken(name,namePart,"@[]");
		threadName += namePart;
	}

	// Empty name indicates the focusThread
	if (threadName.IsEmpty())
		return getFocusThread();
	else
		return name2Thread(threadName);
}


TOMProxyItem* TOMThreadManager::name2ThreadObject(char *& itemName) {
	TOMThread* thread = name2Thread(itemName);
	if (isRealItem(thread) && itemName[0]=='-' && itemName[1]=='>') {
		// The item name points to an object owned by thread
		itemName += 2; // Skip the "->"
		NoCaseString name;
		eatOneToken(itemName,name,"#");
		// Check if the name is one of the predetermined key words
		if (name =="#CallStack" || name =="CallStack")
			return thread->getCallStack();
		else if (name =="#EventQueue" || name =="EventQueue")
			return thread->getEventQueue();
		else if (name =="#Stepper" || name =="Stepper")
			return thread->getStepper();
		else
			return OMGarbage;
	} else if (isEndOfName(itemName))
		return thread;
	else
		return OMGarbage;
}

OMBoolean TOMThreadManager::showYourself(TOMUniversalObserver* obs,int theMask) 
{
	OMBoolean toWait = TOMProxyItem::showYourself(obs,theMask);
	if (theMask & OMThreadInterest) {
		for(OMIterator<TOMThread *> i(&(this->threadList)); (*i); ++i) {
			if ((*i)->showYourself(obs,theMask))
					toWait = TRUE;
		}
	}
	return toWait;
}

void TOMThreadManager::_showYourself(TOMUniversalObserver * obs,int& theMask) 
{	
	// First notify what elements I have
	obs->notifyThreadValues(&(this->threadList));
	// currently we do not show call stacks and event queues
	// en'block. to see them you must ask for them explicetly
	theMask = theMask & OMExistInterest;
}

void TOMThreadManager::setFocusThread(TOMThread* thread) {
#ifdef OMANIMATOR
	void* pNewSocket = NULL;
	if(thread && isRealItem(thread))
		pNewSocket = thread->getMySocket();
	void* pActiveSocket = TOMExterns::Anim()->GetActiveSocket();
	TOMThread* pOldFocusThread = _socket2FocusThreadMap.getKey(pActiveSocket);

	if(thread == pOldFocusThread)
		return;

	if(pOldFocusThread)
	{
		if(pNewSocket && pNewSocket != pActiveSocket && _socket2FocusThreadMap.getKey(pNewSocket))
			_socket2FocusThreadMap.remove(pNewSocket);
		else
			_socket2FocusThreadMap.remove(pActiveSocket);
	}

	if(pNewSocket)
		_socket2FocusThreadMap.add(pNewSocket, thread);
	else
		_socket2FocusThreadMap.add(pActiveSocket, thread);
		
	if (pOldFocusThread!=NULL && tomIsValidItem(pOldFocusThread))
		pOldFocusThread->notifyLostFocus();

#else
	if (thread==focusThread)
		return;

	TOMThread * oldFocusThread = focusThread;
	focusThread = thread;
	if (oldFocusThread!=NULL)
		oldFocusThread->notifyLostFocus();
#endif
}


void TOMThreadManager::setFocusThread(TOMStepper* s) {
	for(OMIterator<TOMThread *> i(&(this->threadList)); *i; i++) {
		if ((*i)->getStepper() == s) {
			setFocusThread(*i);
			return;
		}
	}
}

void TOMThreadManager::replaceItemByDestroyed(TOMInstance* destroyed) {
	for(OMIterator<TOMThread *> i(&(this->threadList)); *i; i++) {
		TOMCallStack* c = (*i)->getCallStack();
		if (c) {
			c->replaceItemByDestroyed(destroyed);
		}
	}
}

void TOMThreadManager::accept(TOMProxyVisitor1Arg & visitor) 
{
	// do for me
	/* OMBoolean result = */ (void) visitor.execute(*this);
	// do for all threads
	for(OMIterator<TOMThread *> i(&(this->threadList)); (*i); ++i) {
		(*i)->accept(visitor);
	}
}

TOMThread* TOMThreadManager::getFocusThread()
{
#ifdef OMANIMATOR
	//return the focus thread according to the active socket
	void* pSocket = TOMExterns::Anim()->GetActiveSocket();
	TOMThread* pTOMThread = _socket2FocusThreadMap.getKey(pSocket);
	return pTOMThread;
#else
	return focusThread;
#endif
}

//
// $Log: tomthrd.cpp $
// Revision 1.48  2007/03/11 13:14:47  ilgiga
// Change copyright comment
// Revision 1.47  2007/03/04 15:07:39  ilgiga
// Telelogic instead of i-Logix
// Revision 1.46  2006/10/31 08:58:56  ccohen
// support running multiple animation processes.
// Revision 1.45  2005/08/23 14:50:49  amos
// bugfix 85444 to main branch
// Revision 1.44.1.2  2005/08/22 10:05:44  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.44  2004/01/12 10:31:04  eldad
// Allow dor (.) notation in C++\Java
// Revision 1.43  2003/05/26 11:13:13  vova
// ESTL-Embedded C++ with Standard Templates Libraries + 1.42 bug fix
// Revision 1.41.1.2  2003/05/26 11:07:10  vova
// ESTL-Embedded C++ with Standard Templates Libraries
// Revision 1.41.1.1  2002/05/15 14:55:26  vova
// Duplicate revision
// Revision 1.40.1.2  2002/05/13 08:56:42  Eldad
// myName leak.
// Revision 1.40.1.1  2001/12/03 14:58:18  Eldad
// Duplicate revision
// Revision 1.39  2001/11/20 15:41:35  Eldad
// Bug #46223 fix.
// Revision 1.38  2001/10/01 10:19:08  Eldad
// 1.37.1.2 to main branch.
// Revision 1.37.1.2  2001/09/26 00:48:49  Eldad
// Changed some of the erros to warnings that are not to be shown in popup 
// message box.
// Revision 1.37.1.1  2001/08/23 10:25:22  Eldad
// Duplicate revision
// Revision 1.36  2001/03/22 08:21:39  amos
// add safe-programming in TOMThread::outputFirstName() to prvent crash in case of a bud context
// Revision 1.35.1.1  2000/12/25 10:39:51  amos
// Duplicate revision
// Revision 1.34  2000/07/19 13:24:38  beery
// Comply with Solaris strict checking of assign "" to char*
// Revision 1.33  2000/07/12 06:54:24  amos
// changes related to modify char* to const char*.
// Revision 1.32  2000/01/20 07:08:03  yachin
// Fix spelling mistake
// Revision 1.31  2000/01/04 15:03:51  amos
// support go next
// changle go step, to stop after each NULL transition
// Revision 1.30  2000/01/03 16:26:10  amos
// add support in single step mode
// Revision 1.29  1999/08/30 11:31:44  yachin
// Fix bug 'rhapsody gets stuck on show #Thread @@SubB[0]->#Eventqueue
// Revision 1.28  1999/07/15 13:42:05  yachin
// change 'instanceCallString from '->' to '.'
// Revision 1.27  1999/03/04 07:26:35  yachin
// Set theOMCLoseHandle to null after deletion
// Revision 1.26  1999/03/03 11:02:21  yachin
// Fix bug 29907 remove _omCloseHandle from ThreadManagerList
// Revision 1.25  1999/02/16 05:57:03  yachin
// Speed up of constructors
// Revision 1.24  1998/12/17 14:36:42  ofer
// handle aomdbgstop message which is breakpoint from debugger
// Revision 1.23  1998/12/08 15:10:37  beery
// 28099
// Revision 1.22  1998/12/08 15:04:15  beery
// 28099
// Revision 1.21  1998/11/19 17:59:16  beery
// Revision 1.20  1998/11/17 12:37:15  beery
// Revision 1.19  1998/11/17 12:34:35  beery
// Revision 1.18  1998/08/02 15:05:14  beery
// changing boolean->OMBoolean
// Revision 1.17  1998/06/25 08:46:19  yachin
// Fix bug 6515 - rereference deleted instances on call stack to 'inDestruction"
// Revision 1.16  1998/05/21 11:24:08  yachin
// Fix bug 5603 (have getPackage return a TOMPackage and not a TOMProxyItem)
// Revision 1.15  1997/07/20 11:36:42  yachin
// Adding globals to animation
// Revision 1.14  1997/05/27 09:02:52  yachin
// Made tomstr == ystr
// Revision 1.13  1997/03/09 08:11:40  yachin
// removed windu include
// Revision 1.12  1997/02/26 07:58:03  yachin
// modified x2String to take 2 parameters
// Revision 1.11  1997/02/12 11:15:43  yachin
// Rewrite of TOMProxyItem(...)
// Revision 1.10  1997/01/30 13:32:17  yachin
// Revision 1.9  1997/01/21 13:48:05  yachin
// bug fix in name2thread
// Revision 1.8  1997/01/21 11:08:52  yachin
// changed _int32 to int
// Revision 1.7  1997/01/21 10:52:52  yachin
// User Threads part I
// Revision 1.6  1997/01/19 07:37:50  yachin
// Multi-threading addenda
// Revision 1.5  1997/01/12 13:36:22  yachin
// Revision 1.4  1997/01/12 11:44:13  yachin
// Revision 1.3  1996/12/30 09:56:49  yachin
// Multi Thread support part III
// Revision 1.2  1996/12/26 09:48:45  yachin
// Revision 1.1  1996/12/25 13:49:39  yachin
// Initial revision
//
