#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: tomother.cpp 1.63 2007/03/11 13:14:44 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/tom/rcs/tomother.cpp $
//	file version:	$Revision: 1.63 $
//
//	purpose: Methods of other (non instance/class) "TOM"Classes
//
//	author(s):		Yachin Pnueli
//	date started:	28.5.96
//	date changed:	$Date: 2007/03/11 13:14:44 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "tomother.h"
#include "tomobs.h"
#include "tominst.h"
#include "tommsg.h"
#include "tomsys.h"
#include "tomthrd.h"
#include "tomExtern.h"

#include <omcom/AnimOpReturn.h>
#include <omcom/AnimOpCallReply.h>
#include <omcom/AnimListField.h>
#include <omcom/AnimMessageField.h>
#include <omcom/AnimStringField.h>
#include <omcom/AnimNameValueData.h>
#include <omcom/AnimBooleanField.h>

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = tomother_H;
#endif

TOMCallStack::TOMCallStack(gen_ptr theReal, OMInterestMask theMask)
		:TOMProxyItem(theReal,(char*)("Call Stack"),omProxyCallStack,theMask), myThread(NULL),indentCounter(0),
		 m_lastCalled(NULL), m_lastCaller(NULL), m_lastMethodString(""), m_lastType(omNullTransition), m_lastMethodWithOMReturn("")
{
	if (TOMSystem::sysInSilentMode()) {
		goSilent();
	}
}



TOMCallStack::~TOMCallStack() {
	// Delete any upPoped methods
	for(OMIterator<OMSData *> i(methodStack); (*i); i++)
		delete (*i);
	// The stack itself is cleared implecetely by OMStack destructor

	// Make sure current call stack is not null
	if (this==current) {
		TOMThread * t = TOMSystem::threadManagerInstance()->
												getFocusThread();
		if (t!=NULL)
			current = t->getCallStack();
		else
			current = NULL;
	}
}

int TOMCallStack::methodType2Interest(OMMethodType type) {
	switch (type) {
	case omConstructorMethod:	return OMConstructorsInterest;
	case omDestructorMethod:	return OMDestructorsInterest;
	case omMethodMethod:
	case omBehaviourMethod:
	case omNullTransition:
	case omTriggerMethod:		return OMMethodsInterest;
	default: return OMNoInterest; // These should never be here
	}
}

void TOMCallStack::_showYourself(TOMUniversalObserver*,
								  int& theMask) {
	// Currently we want any "show" to go to application side
	// Also we always show "all"
	theMask = /*theMask &*/ (	OMMethodsInterest |
							OMConstructorsInterest |
							OMDestructorsInterest |
							OMParameterInterest );
}

void TOMCallStack::replaceItemByDestroyed(TOMInstance* destroyed) {
	for(OMIterator<TOMProxyItem*> i(instanceStack); *i; i++) {
		if ((*i)==(TOMProxyItem*)destroyed) {
			(*i) = OMInDestruction;
		}
	}
}


void TOMCallStack::handleMessage(OMNotify msgCode,
								 TOMSData* s,
								 OMSPosition p) {
	// Set yourself to be the "Current" call stack
	if(msgCode != callStackValues)
		current = this;
	// Perform the operation appropriate to this message code
	switch (msgCode) {
	case methodCalled: {
		// Decode the message into components
		// 1. Get pointer to calling instance
		TOMProxyItem * caller = (TOMProxyItem *)s->safeGetPointer(p);
		// 2. Get pointer to called instance
		TOMProxyItem * called = (TOMProxyItem *)s->safeGetPointer(p);
		// 3. Get method signature (+/-parameter s)
		OMSData * method = s->safeGetOMSData(p);
		// 4. Get method type
		OMMethodType type = (OMMethodType)s->safeGetCode(p);

		// Convert Method to string and notify the observers
		OMString methodString;
		TOMSMethod m(method);
		m.method2string(methodString);

		// Ugly patch so as not to change the interface of
		//	notifyMethodCalled
		TOMInstance* iCaller = (TOMInstance*)caller;
		TOMInstance* iCalled = (TOMInstance*)called;
		// Notify my observers
		NOTIFY_OBSERVERS(methodType2Interest(type),
			 notifyMethodCalled(iCaller, iCalled, methodString,type));

		// Perform required actions

		// 2. Push method + called into stack
		instanceStack.push(called);
		methodStack.push(method);
		typeStack.push(type);

		// Notify items about their methods
		// Notfiy caller
		if (tomIsValidItem(caller) && caller->getType()==omProxyInstance)
			iCaller->notifyMethodCalled(iCaller,iCalled,methodString,type);
		// Notify called if different from caller
		if (caller!=called &&
			called && tomIsValidItem(called) &&
			called->getType()==omProxyInstance)
				iCalled->notifyMethodCalled(iCaller,iCalled,methodString,type);

		incIndentCount();

		m_lastMethodWithOMReturn = "";
		m_lastMethodString = "";

		return;
					   }
	case methodReturned: {
		// Get pointer to "poped" instance
		TOMProxyItem * poped = instanceStack.pop();
		decIndentCount();
		// Get pointer to caller -- note we cannot use instanceStack.top();
		// since not all items sit on the proxy stack.
		TOMProxyItem * toped = (TOMInstance *)s->safeGetPointer(p);
		// Get Signature/Parameter List
		OMSData * method = methodStack.pop();
		if (method==NULL) {
			OMString msg = "Popped method from empty callStack";
			tomSendWarning(msg);
			return;
		}
		// Get the method type
		OMMethodType type = typeStack.pop();

		// Convert Method to string
		OMString methodString;
		{
			TOMSMethod m(method);
			m.method2string(methodString);
			delete method;
		}

		// Ugly patch so as not to change the interface of
		//	notifyMethodCalled
		TOMInstance* iPoped = (TOMInstance*)poped;
		TOMInstance* iToped = (TOMInstance*)toped;


		// Initialize last poped attributes
		m_lastCalled = iPoped;
		m_lastCaller = iToped;
		m_lastMethodString = methodString;
		m_lastType = type;

		// Notify my observers
		NOTIFY_OBSERVERS(methodType2Interest(type),
			 notifyMethodReturned(iToped, iPoped, methodString, type));

		// Notify caller and called about the method return
		if (tomIsValidItem(toped) && toped->getType()==omProxyInstance)
			iToped->notifyMethodReturned(iToped,iPoped,methodString,type);
		// Notify called only if different from caller
		if (toped!=poped &&
			tomIsValidItem(poped) &&
			poped->getType()==omProxyInstance)
				iPoped->notifyMethodReturned(iToped,iPoped,methodString,type);
		return;
		}
		
	case callStackValues:	{
		OMSData * values  = s->safeGetOMSData(p);
		// Update myself - if I'm interesting
		if (myMask.isInteresting()) {
			// First clear all existing stacks:
			instanceStack.removeAll();
			indentCounter = 0;
			typeStack.removeAll();
			while (!methodStack.isEmpty())
				delete methodStack.pop();
			// Now decode the message and insert
			TOMSCallStackValues t(values);
			TOMProxyItem * caller;
			TOMProxyItem * called;
			OMSData* method;
			OMMethodType type;
			while (!t.isLastItem())  {
				t.getNextItem(caller,called,method,type);
				instanceStack.push(called);
				methodStack.push(method);
				typeStack.push(type);
				incIndentCount();
			}
		}
		// Notify Show observers
		NOTIFY_SHOW_OBSERVERS(notifyCallStackValues(values));
		delete values;
		return;
	}

	case flowDataSend:		{
		// Decode the message into components
		// 1. Get pointer to sender instance
		TOMProxyItem * sender = (TOMProxyItem *)s->safeGetPointer(p);
		// 2. Get string of argument name
		char* argName = s->getChar(p);
		// 3. Get string of argument value
		char* argValue = s->getChar(p);

		TOMInstance* iSender = (TOMInstance*)sender;

		// Notify my observers
		NOTIFY_OBSERVERS(OMAllInterest, notifyFlowDataSend(iSender, argName, argValue, NULL));

		// Perform required actions

		// 2. Push called into stack
		instanceStack.push(sender);

		// Notify items about their methods
		// Notfiy caller
		if (tomIsValidItem(sender) && sender->getType()==omProxyInstance)
			iSender->notifyFlowDataSend(iSender, argName, argValue, iSender);

		incIndentCount();

		return;
		}

	case flowDataRecv:	{
		// Get pointer to sender instance
		TOMProxyItem * sender = instanceStack.top();
		//decIndentCount();

		// Decode the message into components
		// 1. Get pointer to the receiver instance
		TOMProxyItem * receiver = (TOMInstance *)s->safeGetPointer(p);
		// 2. Get string of argument name
		char* argName = s->getChar(p);
		// 3. Get string of argument value
		char* argValue = s->getChar(p);


		//Push receiver into stack
		instanceStack.push(receiver);

		// Ugly patch so as not to change the interface of
		//	notifyMethodCalled
		TOMInstance* iSender = (TOMInstance*)sender;
		TOMInstance* iReceiver = (TOMInstance*)receiver;

		// Notify my observers
		NOTIFY_OBSERVERS(OMAllInterest, notifyFlowDataReceive(iSender, iReceiver, argName, argValue, NULL));

		// Notify caller and called about the method return
		if (tomIsValidItem(sender) && sender->getType()==omProxyInstance)
			iSender->notifyFlowDataReceive(iSender, iReceiver, argName, argValue, iSender);
		// Notify called only if different from caller
		if (sender != receiver &&
			tomIsValidItem(receiver) &&
			receiver->getType()==omProxyInstance)
				iReceiver->notifyFlowDataReceive(iSender, iReceiver, argName, argValue, iReceiver);
		return;
		}

	case flowDataEnd:	{
		// pop the sender & receiver instance from the call stack
		TOMProxyItem * sender = (TOMInstance *)s->safeGetPointer(p);
		TOMProxyItem * receiver = (TOMInstance *)s->safeGetPointer(p);
		if(receiver == instanceStack.top())
			instanceStack.pop();
		if(sender == instanceStack.top())
			instanceStack.pop();

		// Notify my observers
		TOMInstance* iSender = (TOMInstance*)sender;
		TOMInstance* iReceiver = (TOMInstance*)receiver;
		NOTIFY_OBSERVERS(OMAllInterest, notifyFlowDataEnd(iSender, iReceiver));
		decIndentCount();
		return;
		}

	case flowDataPopPartial:	{
		//pop the current receiver flowport from the call stack (happens when broadcasting data to 
		//more than 1 flowports
		TOMProxyItem * receiver = (TOMInstance *)s->safeGetPointer(p);
		if(receiver == instanceStack.top())
			instanceStack.pop();

		// Notify my observers
		TOMInstance* iReceiver = (TOMInstance*)receiver;
		NOTIFY_OBSERVERS(OMAllInterest, notifyFlowDataPartialPop(iReceiver));
		return;
		}

	case msgCallDuringCtor:		{
		// Decode the message into components
		// 1. Get pointer to calling instance
		TOMProxyItem * caller = (TOMProxyItem *)s->safeGetPointer(p);
		// 2. Get pointer to called instance
		TOMProxyItem * called = (TOMProxyItem *)s->safeGetPointer(p);
		// 3. Get method signature (+/-parameter s)
		OMSData * method = s->safeGetOMSData(p);
		// 4. Get method type
		OMMethodType type = (OMMethodType)s->safeGetCode(p);

		// Convert Method to string and notify the observers
		OMString methodString;
		TOMSMethod m(method);
		m.method2string(methodString);

		TOMInstance* iCaller = (TOMInstance*)caller;
		TOMInstance* iCalled = (TOMInstance*)called;
		
		// Notify my observers
		NOTIFY_OBSERVERS(OMAllInterest, notifyMsgCallDuringCtor(iCaller, iCalled, methodString,type));

		// Notfiy caller
		if (tomIsValidItem(iCaller))
			iCaller->notifyMsgCallDuringCtor(iCaller, iCalled, methodString,type);
		delete method;
		return;
		}
	// Messages which should never occuer
	case breakpointActive:
	default: notifyUnexpectedMessage(msgCode);
	}
}

void TOMCallStack::handleMessage(AnimMessage* msg)
{
	TOMProxyItem::handleMessage(msg);

	int code = msg->getCode();

	if (code == callOpReply)
	{
		AnimOpCallReply *rep = (AnimOpCallReply *)msg;
		notifyOpCallReply(rep);
	}
	else if (code == opReturn)
	{
		AnimOpReturn *retMsg = (AnimOpReturn *)msg;
		notifyOpReturn(retMsg);

	}
}

void TOMCallStack::notifyOpCallReply(AnimOpCallReply* reply)
{
	if (reply != NULL)
	{
		TOMSystem::instance()->notifyOpCallReply(reply);

		AnimStringOrPointerField* retF = reply->getRetValue();
		OMString retValStr;
		if (retF != NULL) {
			retValStr = TOMSystem::getStringOrPointerFieldValue(retF);
		}

		const OMList<OMString> nameValList; // dummy

		_notifyOpReturn(false, retValStr, nameValList);
	}
}

void TOMCallStack::notifyOpReturn(AnimOpReturn* retMsg)
{
	if (retMsg != NULL)
	{
		AnimStringOrPointerField* retF = retMsg->getRetValue();
		OMString retValStr;
		if (retF != NULL) {
			retValStr = TOMSystem::getStringOrPointerFieldValue(retF);
		}

		OMList<OMString> nameValList;
		AnimListField *nameValF = retMsg->getArgDataList();
		if (nameValF) {
			if (nameValF != NULL) {
				int numOfArgs = nameValF->getSize();
				AnimMessageField *aMsg = NULL;
				AnimNameValueData *aData = NULL;
				for (int i=0; i<numOfArgs; ++i) {
					aMsg = (AnimMessageField*)(nameValF->getNextField());
					if (aMsg != NULL) {
						aData = (AnimNameValueData *)(rhp_long64_t)(aMsg->getValue());
						if (aData != NULL) {
							OMString aName = (char *)(rhp_long64_t)(aData->getTheName()->getValue());

							AnimStringOrPointerField *vF = aData->getTheValue();
							OMString aVal = TOMSystem::getStringOrPointerFieldValue(vF);
							nameValList.add(aName);
							nameValList.add(aVal);
						}
					}
				}
			}
		}

		OMBoolean isOMReturnMacro = (retMsg->getIsOMReturnMacro()->getValue() != 0);

		_notifyOpReturn(isOMReturnMacro, retValStr, nameValList);
	}
}

void TOMCallStack::_notifyOpReturn(OMBoolean isOMReturnMacro, OMString retValString, const OMList<OMString>& nameValList)
{
	OMBoolean bNotify = TRUE;
	OMBoolean bUnderConstruction = FALSE;
	OMBoolean bUseOMReturnMacro = isOMReturnMacro;

	// In C always notify return value for CALL macro.
	if ((isLangC() || isLangAda()) && !isOMReturnMacro) {
		bNotify = TRUE;
	}

	// In C OM_RETURN message from triggered operation arrives after method is returned from statechart.
	if ((isLangC() || isLangAda()) && m_lastType == omTriggerMethod && m_lastCaller != NULL) {
		bNotify = TRUE;
		bUseOMReturnMacro = FALSE;
	}

	// Notify return value only for those CALL macro, which are used only for methods without OM_RETURN.
	if (m_lastMethodWithOMReturn == m_lastMethodString) {
		bNotify = FALSE;
	}

	
	// For complex types which are still not builded, don't show their returns value.
	if (retValString == (char*)"<under construction>") {
		bUnderConstruction = TRUE;
	}
	
	if ((isOMReturnMacro || bNotify) && !bUnderConstruction) {

		TOMInstance *called	= NULL;
		TOMInstance *caller = NULL;
		OMString methodString;
		OMMethodType type;
		if (bUseOMReturnMacro) { // from OM_RETURN macro

			TOMInstance *tmpCalled = (TOMInstance*)instanceStack.pop();
			called = tmpCalled;
			TOMInstance *tmpCaller = (TOMInstance*)instanceStack.top();
			caller = tmpCaller;

			instanceStack.push(called);

			OMSData * method = methodStack.top();
			if (method==NULL) {
				OMString msg = "Popped method from empty callStack";
				tomSendWarning(msg);
				return;
			}
			// Convert Method to string
			{
				TOMSMethod m(method);
				m.method2string(methodString);
			}

			// Get the method type
			type = typeStack.top();

			// Remember last methos which has OM_RETURN
			m_lastMethodWithOMReturn = methodString;
		}
		else { // from CALL macro
			called = m_lastCalled;
			caller = m_lastCaller;
			methodString = m_lastMethodString;
			type = m_lastType;
		}

		OMList<OMString> nameVList(nameValList);

		bool shouldNotifyObservers = true;

		if (called && tomIsValidItem(called) && called->getType() == omProxyPackage) 
			shouldNotifyObservers = false;
#ifdef OMANIMATOR
        if (TOMExterns::Anim()->ForceOpReturnOnPackage())
			shouldNotifyObservers = true;
#endif 
	
		if (shouldNotifyObservers)
		{

			NOTIFY_OBSERVERS(OMUserControl, notifyOpReturn(caller, called, methodString, type, retValString, nameVList));
	
			TOMSystem::instance()->notifyOpReturn(caller, called, methodString, type, retValString, nameVList);
	
			if (called && tomIsValidItem(called)) {
				called->notifyOpReturn(caller, called, methodString, type, retValString, nameVList);
			}
		}
	}
}

void TOMCallStack::accept(TOMProxyVisitor1Arg & visitor)
{
	/* OMBoolean result = */ (void) visitor.execute(*this);
}

//
//	stuff for printing indentation
//
TOMCallStack * TOMCallStack::current = NULL;


const int localBufferSize=200;
class LocalBuffer {
public:
	char theBuffer[localBufferSize];
	int oldCount;
	LocalBuffer() {
		oldCount=localBufferSize-1;
		theBuffer[oldCount] = '\0';
		for(int i=0; i<oldCount; i++)
			theBuffer[i]=' ';
	}
	void setBuffer(int count) {
		if (count>localBufferSize-1)
			count = localBufferSize-1;
		theBuffer[oldCount] = ' ';
		oldCount = count;
		theBuffer[oldCount] = '\0';
	}
};
static LocalBuffer localBuffer;
char * TOMCallStack::indentationBuffer = localBuffer.theBuffer;
#define spacesPerIndent 2

char *TOMCallStack:: _getIndentation() {
	// Find the size of the buffer we need
	int count = spacesPerIndent * indentCounter;

	// Reset the indentation Buffer
	localBuffer.setBuffer(count);
	return localBuffer.theBuffer;
}

OMSData* TOMCallStack::getTopMarker() {
	return methodStack.top();
}
OMSData* TOMCallStack::getCurrentCallstackMarker() {
	OMSData* res = NULL;
	if (current != NULL) res = current->getTopMarker();
	return res;
}


TOMEventQueue* TOMEventQueue::current = NULL;

TOMEventQueue::TOMEventQueue(gen_ptr theReal, OMInterestMask theMask)
	  :TOMProxyItem(theReal,(char*)("Event Queue"),omProxyEventQueue,theMask),myThread(NULL)
{
	if (TOMSystem::sysInSilentMode()) {
		goSilent();
	}
}


void TOMEventQueue::_showYourself(TOMUniversalObserver*,
								  int& theMask) {
	// We want any "show" always to display the events
	// and currently we remember nothing on the tom side
	theMask = /* theMask & */ (	OMEventInterest |
							OMParameterInterest );
	if (myReal==NULL && theMask!=(int)OMNoInterest) {
		// Notify Show observers of nonexisting eventQueue
		NOTIFY_SHOW_OBSERVERS(notifyEventQueueNull());
	}
}

inline void TOMEventQueue::message2Event(	TOMSData* s,
								OMSPosition& p,
								OMString& eventString,
								void*& eventId ) const {
	// Get Event Signature/Parameter List
	OMSData * event = s->safeGetOMSData(p);
	// Convert it to a string + id
	TOMSEvent m(event);
	m.method2string(eventString,eventId);
	delete event;
}


inline void TOMEventQueue::readEvent(	TOMSData* s,
								OMSPosition& p,
								TOMInstance *& sender,
								TOMInstance *& receiver,
								OMString& eventString,
								void*& eventId ) const {
	// Decode the message into components
	// 1. Get sender of event
	sender = (TOMInstance *)s->safeGetPointer(p);
	// 2. Get receiver of event
	receiver = (TOMInstance *)s->safeGetPointer(p);
	// 3. Get Event Signature/Parameter List
	message2Event(s,p,eventString,eventId);
}


inline void TOMEventQueue::readTimeoutEvent(TOMSData* s,
								OMSPosition& p,
								TOMInstance *& sender,
								OMString& eventString,
								void*& eventId ) const {
	// Decode the message into components
	// 1. Get sender of event
	sender = (TOMInstance *)s->safeGetPointer(p);
	// 2. Get Event Signature/Parameter List
	message2Event(s,p,eventString,eventId);
}


void TOMEventQueue::handleMessage(OMNotify msgCode,
								  TOMSData* s,
								  OMSPosition p) {
	// Set yourself to be the "Current" event queue
	current = this;

	TOMInstance *sender, *receiver;
	OMString eventString;
	void * eventId;
	// Perform the operation appropriate to this message code
	switch (msgCode) {
	case eventSent:
		readEvent(s, p, sender, receiver, eventString, eventId);

		// Notify my observers
		NOTIFY_OBSERVERS(OMReceiveEventInterest,
				 notifyEventSent(sender, receiver, eventString,eventId));

		// Perform required actions
		// Notify items about their events
		// Notfiy sender
		if (tomIsValidItem(sender))
			sender->notifyEventSent(sender, receiver, eventString, eventId);
		if (sender!=receiver) { // Notify receiver
			if (tomIsValidItem(receiver))
				receiver->notifyEventSent(sender, receiver, eventString,eventId);
		}
		break;
	case eventTaken:
		readEvent(s, p, sender, receiver, eventString, eventId);

		// Notify my observers
		NOTIFY_OBSERVERS(OMReceiveEventInterest,
				 notifyEventReceived(sender, receiver,
								eventString, eventId));

		// Perform required actions
		// Notify items about their events
		// Notfiy sender
		if (tomIsValidItem(sender))
			sender->notifyEventReceived(sender, receiver, eventString, eventId);
		if (sender!=receiver) { // Notify receiver
			if (tomIsValidItem(receiver))
				receiver->notifyEventReceived(sender, receiver,
												eventString, eventId);
		}
		break;
	case timeoutSet:
		readTimeoutEvent(s, p, sender, eventString, eventId);

		// Notify my observers
		NOTIFY_OBSERVERS(OMTimeoutsInterest,
						 notifyTimeoutSet(sender, eventString,eventId));

		// Perform required actions
		// Notify item about the event
		if (tomIsValidItem(sender))
			sender->notifyTimeoutSet(eventString,eventId);
		break;
	case eventCancelled:
		readTimeoutEvent(s, p, sender, eventString, eventId);

		// Notify my observers
		NOTIFY_OBSERVERS(OMTimeoutsInterest | OMReceiveEventInterest,
				 notifyEventCancelled(sender, eventString, eventId));

		// Perform required actions
		// Notify item about the event
		if (tomIsValidItem(sender))
			sender->notifyEventCancelled(eventString,eventId);
		break;
	case eventQueueValues:	{
		OMSData * values  = s->safeGetOMSData(p);
		// Notify Show observers
		NOTIFY_SHOW_OBSERVERS(notifyEventQueueValues(values));
		delete values;
		break;
							}
	case breakpointActive:
	default: notifyUnexpectedMessage(msgCode);
	}
}

void TOMEventQueue::accept(TOMProxyVisitor1Arg & visitor)
{
	/* OMBoolean result = */ (void) visitor.execute(*this);
}


#ifdef tomother_Debug


void main() {
}
#endif


//
// $Log: tomother.cpp $
// Revision 1.63  2007/03/11 13:14:44  ilgiga
// Change copyright comment
// Revision 1.62  2007/03/04 15:07:34  ilgiga
// Telelogic instead of i-Logix
// Revision 1.61  2005/08/23 14:50:45  amos
// bugfix 85444 to main branch
// Revision 1.60.1.2  2005/08/22 10:05:41  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.60  2004/05/11 08:04:54  vova
// Linux warnings: casting to (int) added
// Revision 1.59  2004/01/14 10:24:22  eldad
// Instead of using the instanceStack for indent - use a special counter
// Revision 1.58  2004/01/08 11:16:27  eldad
// First push the messages then notify - bug 68769
// Revision 1.57  2004/01/07 14:09:56  eldad
// Back to main branch.
// Revision 1.56.1.2  2004/01/04 15:37:41  eldad
// Added a service to get the current top callstack marker.
// Revision 1.56  2001/11/12 10:47:52  Eldad
// CString -> OMString
// Revision 1.55  2001/10/01 10:21:51  Eldad
// 1.54.1.2 to main branch.
// Revision 1.54.1.2  2001/09/26 00:48:44  Eldad
// Changed some of the erros to warnings that are not to be shown in popup
// message box.
// Revision 1.54.1.1  2000/12/25 10:39:51  Eldad
// Duplicate revision
// Revision 1.53  2000/07/19 13:24:42  beery
// Comply with Solaris strict checking of assign "" to char*
// Revision 1.52  2000/07/12 06:54:24  amos
// changes related to modify char* to const char*.
// Revision 1.51  2000/01/19 12:35:48  amos
// back to main branch
// Revision 1.50.1.1  2000/01/06 14:01:15  amos
// Revision 1.50  1999/11/03 06:16:13  yachin
// Fix spelling mistake
// Revision 1.49  1999/02/16 05:56:59  yachin
// Speed up of constructors
// Revision 1.48  1998/11/22 14:17:44  beery
// Revision 1.47  1998/11/17 12:37:37  beery
// Revision 1.46  1998/08/18 11:59:35  ofer
// set metod ommethodType2Interest to be static memeber
// function of TOMClass ( the cad-ul 2.2.6 compiler did not like
// global function) tomother.cpp/h
// Revision 1.45  1998/06/25 08:46:17  yachin
// Fix bug 6515 - rereference deleted instances on call stack to 'inDestruction"
// Revision 1.44  1998/05/21 12:34:27  yachin
// Notify Tom when events are canceled
// Revision 1.43  1998/05/21 11:24:07  yachin
// Fix bug 5603 (have getPackage return a TOMPackage and not a TOMProxyItem)
// Revision 1.42  1997/07/21 06:33:00  yachin
// Added global items to animation part II
// Revision 1.41  1997/02/06 13:33:52  yachin
// Switched from try to tomIsValidItem
// Revision 1.40  1997/02/04 12:17:58  yachin
// Revision 1.39  1997/01/29 13:05:49  yachin
// Revision 1.38  1997/01/27 09:41:56  yachin
// Enter foreign threads
// Revision 1.37  1997/01/21 11:08:47  yachin
// changed _int32 to int
// Revision 1.36  1997/01/21 10:52:50  yachin
// User Threads part I
// Revision 1.35  1997/01/19 07:37:48  yachin
// Multi-threading addenda
// Revision 1.34  1996/12/23 11:51:11  yachin
// Add ids to events
// Revision 1.33  1996/12/19 13:15:14  yachin
// Revision 1.32  1996/12/09 11:08:56  yachin
// send timeoutCanceled to "event watchers" too
// Revision 1.31  1996/12/01 09:20:52  yachin
// Revision 1.30  1996/11/24 12:40:42  yachin
// Revision 1.29  1996/11/11 13:16:14  yachin
// Revision 1.28  1996/11/11 11:54:25  yachin
// Support multi-thread part I
// Revision 1.27  1996/10/14 13:26:21  yachin
// Handle sub classes and set/cancel timeout
// Revision 1.26  1996/10/10 13:56:12  yachin
// Revision 1.25  1996/10/10 08:01:26  yachin
// Revision 1.24  1996/10/09 07:37:10  yachin
// Revision 1.23  1996/09/25 10:01:26  yachin
// notifyEventQueueValues added + assorted bug fixes
// Revision 1.22  1996/09/19 08:04:07  yachin
// Proper deletion when animation is terminated
// Revision 1.21  1996/09/16 09:28:34  yachin
// Revision 1.20  1996/09/08 13:28:59  yachin
// Registeration of items which do not yet exist
// Revision 1.19  1996/09/04 13:16:11  yachin
// Connect with Israel
// Revision 1.18  1996/09/03 13:41:14  ofer
// calling notifyMethodReturned ( and not notifyMethodCalled )
// when handleing methodReturned
// Revision 1.17  1996/09/03 12:01:16  yachin
// Alow show #callStack
// Revision 1.16  1996/08/29 11:35:06  ofer
// Revision 1.15  1996/08/08 08:23:29  yachin
// Revision 1.14  1996/08/06 12:52:08  yachin
// Version for Prototype 4
// Revision 1.13  1996/07/22 11:30:32  yachin
// Revision 1.12  1996/07/15 12:37:56  yachin
// Revision 1.11  1996/07/11 13:32:39  yachin
// Revision 1.10  1996/07/10 05:50:09  yachin
// Reprecussion of reorganizatio nof AOM
// Revision 1.9  1996/07/04 12:38:51  yachin
// Bug fixes and handleing static methods
// Revision 1.8  1996/07/03 12:45:51  yachin
// Fixing bugs for "const" and "static
// enhancements for attributes and indentation
// Revision 1.7  1996/06/30 07:57:39  yachin
// Bug fix for case of none interesting call stack items/event senders/receivers
// Revision 1.6  1996/06/26 12:45:59  yachin
// Put header message and fix some bugs
// Revision 1.5  1996/06/26 08:39:29  yachin
// Revision 1.4  1996/06/24 11:19:36  yachin
// Removed TOMTimer - currently not needed
// Revision 1.3  1996/06/20 10:23:10  yachin
// Revision 1.2  1996/06/19 10:21:30  yachin
// Revision 1.1  1996/06/17 05:40:47  yachin
//
