//	Component		: oxfFiles 
//	Configuration 	: generic
//	Model Element	: OMDefaultReactivePort
//!	File name		: $Source$
//!	File version	: $Revision$
//
//!	Date changed	: $Date$
//!	Last change by	: $Author$
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2004, 2008. All Rights Reserved.
//
//#[ ignore
//#if ((!defined lint) && (!defined OM_NO_RCS_ID))
//static const char* rcsid = "//! $Id$";
//#endif
//#]

//## auto_generated
#include "OMDefaultReactivePort.h"
//## package Design::oxf::Services::Ports

//## class OMDefaultReactivePort
OMDefaultReactivePort::OMDefaultReactivePort(void) {
    //#[ operation OMDefaultReactivePort()
    InBound.setPort(this);
    //#]
}

OMDefaultReactivePort::~OMDefaultReactivePort(void) {
}

OMDefaultInBound* OMDefaultReactivePort::getInBound(void) const {
    //#[ operation getInBound() const
    return const_cast<OMDefaultInBound*>(&InBound);
    //#]
}

IOxfReactive* OMDefaultReactivePort::getItsDefaultProvidedInterface(void) const {
    //#[ operation getItsDefaultProvidedInterface() const
    return getInBound();
    //#]
}

IOxfReactive* OMDefaultReactivePort::getItsDefaultRequiredInterface(void) const {
    //#[ operation getItsDefaultRequiredInterface() const
    return getOutBound();
    //#]
}

OMDefaultOutBound* OMDefaultReactivePort::getOutBound(void) const {
    //#[ operation getOutBound() const
    return const_cast<OMDefaultOutBound*>(&OutBound);
    //#]
}

void OMDefaultReactivePort::setItsDefaultProvidedInterface(IOxfReactive* reactive) {
    //#[ operation setItsDefaultProvidedInterface(IOxfReactive)
    InBound.setItsDefaultProvidedInterface(reactive);
    //#]
}

void OMDefaultReactivePort::setItsDefaultRequiredInterface(IOxfReactive* reactive) {
    //#[ operation setItsDefaultRequiredInterface(IOxfReactive)
    OutBound.setItsDefaultRequiredInterface(reactive);
    //#]
}

//
//! Log: $Log$
//


