//	Component		: oxfFiles 
//	Configuration 	: generic
//	Model Element	: AMemAloc
//!	File name		: $Source$
//!	File version	: $Revision$
//
//!	Date changed	: $Date$
//!	Last change by	: $Author$
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2004, 2008. All Rights Reserved.
//


#ifndef AMemAloc_H
#define AMemAloc_H

#include "IOxfMemoryAllocator.h"
#endif
//
//! Log: $Log$
//


