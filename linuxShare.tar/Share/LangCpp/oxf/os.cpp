//	Component		: oxfFiles 
//	Configuration 	: generic
//	Model Element	: OMOSThread
//!	File name		: $Source$
//!	File version	: $Revision$
//
//!	Date changed	: $Date$
//!	Last change by	: $Author$
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2004, 2008. All Rights Reserved.
//
//#[ ignore
//#if ((!defined lint) && (!defined OM_NO_RCS_ID))
//static const char* rcsid = "//! $Id$";
//#endif
//#]

//## auto_generated
#include "os.h"
//## package Design::oxf::Adapters::AbstractLayer

//## class OMOSThread
//#[ ignore
/*

//#]
const Rhp_int64_t OMOSThread::DefaultMessageQueueSize = 100;
//#[ ignore

*/
//#]

//#[ ignore
/*

//#]
const Rhp_int64_t OMOSThread::DefaultStackSize = 1000;
//#[ ignore

*/
//#]

//#[ ignore
/*

//#]
const Rhp_int64_t OMOSThread::DefaultThreadPriority = 0;
//#[ ignore

*/
//#]

bool OMOSThread::exeOnMyThread(void) {
    //#[ operation exeOnMyThread()
    // a handle to the thread that executes the delete
    void * executedOsHandle = OMOSFactory::instance()->getCurrentThreadHandle();
    // a handle to this' 'thread'
    void * myOsHandle = getOsHandle();
    
    bool res = ((executedOsHandle == myOsHandle) ? true : false);
    return res;
    //#]
}

//
//! Log: $Log$
//


