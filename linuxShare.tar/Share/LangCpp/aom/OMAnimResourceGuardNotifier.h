//	Component		: oxfFiles 
//	Configuration 	: generic
//	Model Element	: OMAnimResourceGuardNotifier
//!	File name		: $Source: R:/StmOO/Master/cg/LangCpp/aom/rcs/OMAnimResourceGuardNotifier.h $
//!	File version	: $Revision: 1.3 $
//
//!	Date changed	: $Date: 2007/03/11 11:57:49 $
//!	Last change by	: $Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2004, 2008. All Rights Reserved.
//



#ifndef OMAnimResourceGuardNotifier_H 

#define OMAnimResourceGuardNotifier_H 
//## package Design::oxf::Services::Instrumentation 

//----------------------------------------------------------------------------
// OMAnimResourceGuardNotifier.h                                                                  
//----------------------------------------------------------------------------
class AOMStepper;
class AOMThread;

// This class provides instrumentation services for the OMResourceGuard template class
//## class OMAnimResourceGuardNotifier 
class OMAnimResourceGuardNotifier  {


////    Constructors and destructors    ////
public :
    
    //## auto_generated 
    ~OMAnimResourceGuardNotifier();


////    Operations    ////
public :
    
    // notify the animation that a mutex is about to be locked (b == true) and after the mutex was locked (b == false)
    // Argument bool b : 
    // should be true before the lock and false after the lock is completed
    //## operation notifyLock(bool) 
    static void notifyLock(bool b);


};



#endif  
//
//! Log: $Log: OMAnimResourceGuardNotifier.h $
//! Log: Revision 1.3  2007/03/11 11:57:49  ilgiga
//! Log: Change copyright comment
//! Log: Revision 1.2  2007/03/01 16:31:21  ilgiga
//! Log: Telelogic instead of i-Logix
//! Log: Revision 1.1  2004/11/09 14:41:06  amos
//! Log: Initial revision
//! Log: Revision 1.5  2004/11/08 08:58:52  amos
//


