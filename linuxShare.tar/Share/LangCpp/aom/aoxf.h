#ifndef aoxf_H
#define aoxf_H "$Id: aoxf.h 1.24 2007/03/11 11:57:54 ilgiga Exp $"

//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/aom/rcs/aoxf.h $
//	file version:	$Revision: 1.24 $
//
//	purpose: define top level items to tracer/animation executable
//
//	author(s):	Yachin Pnueli
//	date started:	21.5.96
//	date changed:	$Date: 2007/03/11 11:57:54 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//

// Macro to set the type cast properly
#ifndef OMCAST_CLASS
#define OMCAST_CLASS AOMAnimationItem
#endif

#ifndef OMAPPLICATION
#define OMAPPLICATION
#endif

#include <oxf/rp_framework_dll_definition.h>
#include <omcom/om.h>
//
// $Log: aoxf.h $
// Revision 1.24  2007/03/11 11:57:54  ilgiga
// Change copyright comment
// Revision 1.23  2007/03/01 16:31:27  ilgiga
// Telelogic instead of i-Logix
// Revision 1.22  2000/12/27 16:38:48  amos
// Add support for framework as DLL - for support in Rhapsody C++ COM
// Revision 1.21  1997/04/07 23:00:54  ofer
// Move file names and includes to lowercase
// so UNIX will work with lowercase versions
// Revision 1.20  1997/01/13 09:35:10  yachin
// Added #ifndef OMAPPLICATION
// Revision 1.19  1996/11/24 12:55:30  yachin
// Revision 1.18  1996/11/11 11:47:03  yachin
// Support multi-thread part I
// Revision 1.17  1996/11/10 07:51:01  yachin
// fixed gotControl breakpoint + breakPoint to dead objects
// Revision 1.16  1996/10/21 11:38:31  yachin
// Cleanup on state notifies + fixes on timeouts + support for breakpoints
// Revision 1.15  1996/10/09 07:34:04  yachin
// Revision 1.14  1996/08/28 05:35:24  ofer
// Revision 1.13  1996/08/15 08:40:55  yachin
// Revision 1.12  1996/08/08 08:22:20  yachin
// Prototype 4 major revision
// Revision 1.11  1996/08/06 12:49:56  yachin
// Tracer for Prototype 4
// Revision 1.10  1996/07/18 10:48:58  yachin
// Post Prototype 3 rewrite: virtual destructors, remarks, type changes and safe programing on deleted items
// Revision 1.9  1996/07/14 07:30:18  yachin
// Revision 1.8  1996/07/10 09:12:09  yachin
// Revision 1.7  1996/07/10 05:47:01  yachin
// Reorganization + some stuff for OMANIMATOR
// Revision 1.6  1996/07/04 12:37:45  yachin
// Revision 1.5  1996/06/24 11:15:22  yachin
// OMANIMATOR version should work
// AOMTimer removed - as it is unused
// Revision 1.4  1996/06/23 11:18:51  yachin
// Changes for integration with oxf
// Revision 1.3  1996/06/20 10:21:57  yachin
// Revision 1.2  1996/06/19 10:18:56  yachin
// Revision 1.1  1996/06/17 05:33:27  yachin
// Initial revision
//

#endif
