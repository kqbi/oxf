#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: AOMMessageSender.cpp 1.16 2007/03/11 11:57:47 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/aom/rcs/AOMMessageSender.cpp $
//	file version:	$Revision: 1.16 $
//
//	purpose:	 	
//
//	author(s):		
//	date started:	
//	date changed:	$Date: 2007/03/11 11:57:47 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2000, 2008. All Rights Reserved.
//

#include "AOMMessageSender.h"

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = AOMMessageSender_H;
#endif

#ifdef OMANIMATOR

#include "aomdisp.h"

#include "aoxf.h"
#include <oxf/os.h>

// Number of messages that are allowed to be in queue.
// Once reached the AOMSchedDispatcher is requested to stop
// the applicative threads
#define MAX_NUM_OF_MSGS 2

const int AOMMessageSender::UNAVAILABLE = 128;
const int AOMMessageSender::READY = 129;


AOMMessageSender::AOMMessageSender(OMOSConnectionPort* port, OMAffinity_t affinity) : 
connPort(port), m_terminate(false), state(READY)
{
	OMOSFactory *fact = OMOSFactory::instance();
	thread = fact->createOMOSThread(doExecute, this,(char*)"msgSender");
	if (affinity != 0U)
	{
		thread->setAffinity(affinity);
	}
	msgQueue = new MsgSenderQueue();
	m_mutex = fact->createOMOSMutex();
	msgCounter = new MsgCounter();
}

AOMMessageSender::~AOMMessageSender()
{
	// to prevent deletion from starting
	// before we terminate.
	// (race on msgQueue)
	m_mutex->lock();
	delete msgQueue;
	m_mutex->unlock();
	delete thread;
	delete m_mutex;
	delete msgCounter;
}


// for stopping the sender thread - results in deletion
// of the AOMMessageSender instance.
void AOMMessageSender::terminate()
{
	// guarding block so deletion won't start
	// before we terminate
	m_mutex->lock();
	m_terminate = true;
	// just to wake up the pending queue
	msgQueue->put(0);
	m_mutex->unlock();
}


void AOMMessageSender::start()
{
	if (thread) {
		// thread->setPriority(1);
		thread->start();
	}
}

void AOMMessageSender::suspend()
{
	if (thread)
		thread->suspend();
}
void AOMMessageSender::resume()
{
	if (thread)
		thread->resume();
}

void AOMMessageSender::sendMessageFromQueue()
{
	OMSData *msg = (OMSData *)(msgQueue->get());
	
	msgCounter->dec();

	if (msg && connPort)
	{
		connPort->Send(msg);
		delete msg;
	}
}


void AOMMessageSender::sendMessage(OMSData* msg)
{
	const char* rawData = msg->getRawData();
	OMSData *clone = OMSData::string2OMSData(rawData);
	msgQueue->put(clone);
	msgCounter->inc();
}

void AOMMessageSender::doExecute(void *me)
{
	AOMMessageSender *theSender = (AOMMessageSender*)me;
	if (theSender)
		theSender->execute();
}

void AOMMessageSender::execute()
{
	state = READY;
	thread->InitCommunicationLayer();
	while (!m_terminate) {
		while (msgQueue->isEmpty()) {
			// once the event queue is empty we resume the callers.
			msgQueue->pend();
			if (m_terminate) 
				break;
		}
		sendMessageFromQueue();
	}
	state = UNAVAILABLE;
 	// it makes sense for Integrity target only
	thread->CleanupCommunicationLayer();
	delete this;
}

MsgCounter::MsgCounter():m_count(0)
{
	OMOSFactory *fact = OMOSFactory::instance();
	m_mutex = fact->createOMOSMutex();
}

MsgCounter::~MsgCounter()
{
	delete m_mutex; 
}

int MsgCounter::get()
{
	int rc;
	m_mutex->lock();
	rc = m_count;
	m_mutex->unlock();
	return rc;
}
void MsgCounter::set(int val)
{
	m_mutex->lock();
	m_count = val;
	m_mutex->unlock();
}
int MsgCounter::inc()
{
	int rc;
	m_mutex->lock();
	rc = m_count++;
	m_mutex->unlock();
	//cout << "m_count = " << m_count << endl;
	return rc;
}
int MsgCounter::dec()
{
	int rc;
	m_mutex->lock();
	rc = m_count--;
	//cout << "m_count = " << m_count << endl;
	m_mutex->unlock();
	return rc;
}



MsgSenderQueue::MsgSenderQueue(bool shouldGrow, int initSize): m_theQueue(shouldGrow, initSize), m_putCount(0) 
{
	OMOSFactory *fact = OMOSFactory::instance();
	m_QueueMutex = fact->createOMOSMutex();
	m_QueueEventFlag = fact->createOMOSEventFlag();
	m_putEventFlag = fact->createOMOSEventFlag();
}

MsgSenderQueue::~MsgSenderQueue()
{
	delete m_QueueMutex;
	delete m_QueueEventFlag;
	delete m_putEventFlag;
}


void *MsgSenderQueue::get() {
	void *m;
	m_QueueMutex->lock();
	if (!isEmpty()) {
		m = m_theQueue.get();
		if (m_putCount > 0) {
			--m_putCount;
			m_putEventFlag->signal();
		}
	} else {
		m =  0 ;
		m_QueueEventFlag->reset();
	}
	m_QueueMutex->unlock();
	return m ;
}


void MsgSenderQueue::pend() {
  if (isEmpty())  {
	m_QueueEventFlag->wait();
  }
}

bool MsgSenderQueue::put(void* m, bool /* fromISR */) {
	m_QueueMutex->lock();
	bool shouldWait = false;
	if (m_theQueue.getCount() > 10) {
		++m_putCount;
		shouldWait = true;
	}
	m_QueueMutex->unlock();
	if (shouldWait) {
		m_putEventFlag->wait();
	}

	m_QueueMutex->lock();
    int wasEmpty = isEmpty();

	bool res = m_theQueue.put(m);

	if (wasEmpty) m_QueueEventFlag->signal();
	m_QueueMutex->unlock();

	return res;
}

void MsgSenderQueue::getMessageList(OMList<void*>& c) {
	// Copy to it all the messages I have
	m_theQueue.getInverseQueue(c);
}



#else // !OMANIMATOR

// dummy to avoid linker warning
void AOMMessageSender_dummyOp() {}

#endif // OMANIMATOR

// $Log: AOMMessageSender.cpp $
// Revision 1.16  2007/03/11 11:57:47  ilgiga
// Change copyright comment
// Revision 1.15  2007/03/01 16:31:19  ilgiga
// Telelogic instead of i-Logix
// Revision 1.14  2005/08/23 14:56:24  amos
// bugfix 85444 to main branch
// Revision 1.13.1.2  2005/08/22 10:06:49  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.13  2005/07/03 15:44:14  vova
// 84508: unused variable deleted (warning avoided)
// Revision 1.12  2005/04/21 10:03:07  amos
// Revision 1.11.1.2  2005/03/16 14:02:24  amos
// Revision 1.11  2004/05/11 07:46:19  vova
// Linux warnings: order of initializers changed
// Revision 1.10  2002/12/17 14:52:07  amos
// Replace the usage of a general message queue with message sender specific queue that has blocking put()
// Block the entering tasks when the number of messages in the queue is greater than 10
// Revision 1.9.1.1  2002/12/15 14:23:40  vova
// Duplicate revision
// Revision 1.8  2002/11/24 16:21:56  vova
// 57700: leaks in INTEGRITY models
// Revision 1.7  2002/11/20 11:00:03  amos
// Set the message queue task context (required for OSE)
// Revision 1.5  2002/07/23 07:17:37  amos
// add dummy method AOMMessageSender_dummyOp() to avoid linker warnings in .NET

