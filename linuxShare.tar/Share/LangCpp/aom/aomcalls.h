#ifndef aomcalls_H
#define aomcalls_H "$Id: aomcalls.h 1.16 2007/03/11 11:57:50 ilgiga Exp $"

//
//	file name   :	Share/LangCpp/aom/aomcalls.h
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2014. All Rights Reserved.
//


#include "aomitem.h"
#include <oxf/omstack.h>

//
//	AOMCallStack	-	The "executable" call stack
//						Also responsible for registration/deregistration
//						of objects in classes
//						
class AOMInstance;
class AOMSMethod;
class AOMThread;
class OMOSMutex;
class AnimMessage;


class AOMCallStack : public AOMAnimationItem
{
public:
	RP_FRAMEWORK_DLL virtual ~AOMCallStack();

	RP_FRAMEWORK_DLL AOMCallStack(AOMThread* theThread);
	RP_FRAMEWORK_DLL AOMInstance* getRegistrationCandidate(){ return registrationCandidate; }

	RP_FRAMEWORK_DLL void setRegistrationCandidate(AOMInstance *);
	RP_FRAMEWORK_DLL void notify(const AOMAnimationItem * const instance,
					const OMMethodType type);
	RP_FRAMEWORK_DLL void push(const AOMAnimationItem * const instance, 
					 AOMSMethod * method,
					 OMMethodType type);
	RP_FRAMEWORK_DLL void pop();
	RP_FRAMEWORK_DLL AOMAnimationItem * top() { return instanceStack.top(); }

	RP_FRAMEWORK_DLL bool isEmpty() const { return instanceStack.isEmpty(); }

	RP_FRAMEWORK_DLL void makeTransient() { isTransient = true; }
	RP_FRAMEWORK_DLL bool getIsTransient() { return isTransient; }
	RP_FRAMEWORK_DLL void sendMyself(OMInterestMask theMask);
	RP_FRAMEWORK_DLL void restToMain(); // Used only from oxfInit() !!!
	RP_FRAMEWORK_DLL void setNextCallFromEnv(bool value) { nextCallIsFromEnv = value; }

	// Add the specified instance to the instancesForDeletion list
	RP_FRAMEWORK_DLL void registerInstanceForDeletion(const AOMInstance* inst);

	//push & pop for flow data via flowports
	RP_FRAMEWORK_DLL void flowDataPush(const AOMAnimationItem * const sender, 
															const char* const argName, 
															const char* const argValue);

	RP_FRAMEWORK_DLL void flowDataReceive(const AOMAnimationItem * const instance, 
															const char* const argName, 
															const char* const argValue);

	RP_FRAMEWORK_DLL void flowDataPop(const AOMAnimationItem * const sender);

	RP_FRAMEWORK_DLL bool shouldNotifyOpReturn();

	RP_FRAMEWORK_DLL void flowDataPartialPop();

	void sendDuringCtorMessages(AOMInstance* instance);
	void updateDuringCtorMessages(AOMInstance* oldInst, AOMInstance* newInst);

	AOMThread* getThread() { return myThread; }

	RP_FRAMEWORK_DLL static void cleanup();
private:
	void resetRegistrationCandidate();
	void registerCandidate();
	void deregisterItem(AOMInstance *, AOMAnimationItem *);
	bool shouldNotifyMethodCall(const AOMAnimationItem *const item, const OMMethodType type);
	bool shouldNotifyMethodReturn(const OMMethodType type);
	virtual int getDefaultMask() const { return OMAllInterest; }
	
	// executes stack tasks that should be done when the context thread is idle (empy stack)
	void checkAndDoEmptyStackActivities(OMMethodType type);
	
	// delete instances waiting for deletion
	void deleteInstancesForDeletion();

	void saveDuringCtorMsgData(OMNotify what, AOMAnimationItem* caller, AOMAnimationItem* called = NULL,
			AOMSMethod* method = NULL, OMMethodType type = omUnidentifiedMethod);
public:
	void saveDuringCtorMsgData(OMNotify what, AnimMessage* msg);
private:

	bool isTransient;
	AOMThread * myThread;
	OMStack<AOMAnimationItem *> instanceStack;
	OMStack<AOMSMethod *> methodStack;
	OMStack<OMMethodType> typeStack;

	// List of AOMInstances that should be deleted when the context thread becomes idle
	// We wait until the thread is idle in order to avoid destruction in the before a base class destructor is called
	OMList<const AOMInstance*> instancesForDeletion;

	// a static mutex to syncronize push() and pop() calls between callstacks
	// this is needed when passing an animated class (as an event parameter),
	// from one thread to the other, where the first thread create the class and the other -
	// destroy it.
	// DO NOT use this mutex for any other reason!!
	static OMOSMutex* callstackMutex;

	// this is a flag that indicates that the next push was made using
	// the CALL command.
	bool nextCallIsFromEnv; 


	AOMInstance * registrationCandidate;
	AOMAnimationItem * theCreator;
	AOMInstance * lastDeregistered;

	bool bDuringConstruction;

	//contains message data that were sent during construction of a class, and need to be resent, when 
	//the construction chain has finished.
	struct MsgData {
		OMNotify what;
		AOMAnimationItem* caller;
		AOMAnimationItem* called;
		AOMSMethod* method;
		OMMethodType type;
		AnimMessage* msg;

		MsgData(OMNotify a_what, AOMAnimationItem* a_caller, AOMAnimationItem* a_called,
			AOMSMethod* a_method, OMMethodType a_type, AnimMessage* a_msg) : what(a_what), 
			caller(a_caller), called(a_called), method(a_method), type(a_type), msg(a_msg) {}
	};
	OMList<MsgData*> duringCtorMsgDataList;
};

#endif
