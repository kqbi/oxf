#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: aomeque.cpp 1.53 2007/03/11 11:57:51 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/aom/rcs/aomeque.cpp $
//	file version:	$Revision: 1.53 $
//
//	purpose: Methods of AOMEventQueue class
//
//	author(s):		Yachin Pnueli
//	date started:	27.1.97 (split from aomother.cpp)
//	date changed:	$Date: 2007/03/11 11:57:51 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "aomeque.h"
#include "aomevent.h"
#include "aominst.h"
#include "aommsg.h"
#include "aomdisp.h"
#include "aombrk.h"
#include "aomthrd.h"

#include <oxf/os.h>
#include <oxf/IOxfEvent.h>
#include <oxf/IOxfAnimReactive.h>
#include <oxf/IOxfAnimHelper.h>

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = aomeque_H;
#endif


bool AOMEventQueue::isMaskInteresting(AOMAnimationItem* const item,
									  int mask) const 
{
	if (isInteresting(mask))
		return true;

	if (aomIsValidItem(item))
	{
		// Note - item may no longer exist
		return item->isInteresting(mask);
	}
	else
	{
		// If we are here que answered false and item is
		// either in valid or false
		return false;
	}
}


bool AOMEventQueue::isMaskInteresting(AOMAnimationItem *const i1,
										 AOMAnimationItem *const i2,
										 int mask) const
{
	if (aomIsValidItem(i1))
	{
		// Note - item may no longer exist
		if (i1->isInteresting(mask))
		{
			return true;
		}
	}
	return isMaskInteresting(i2,mask);
}

bool AOMEventQueue::isEventInteresting(AOMAnimationItem *const i1,
									   AOMAnimationItem *const i2) const
{
	return isMaskInteresting(i1,i2,OMEventInterest);
}

bool AOMEventQueue::isTimeoutInteresting(AOMAnimationItem *const item) const
{
	return isMaskInteresting(item,OMTimeoutsInterest);
}

bool AOMEventQueue::withParameters(AOMAnimationItem *const i1,
								   AOMAnimationItem *const i2) const
{
	return isMaskInteresting(i1,i2,OMParameterInterest);
}

bool AOMEventQueue::withParameters(AOMAnimationItem *const item) const
{
	return isMaskInteresting(item,OMParameterInterest);
}


void AOMEventQueue::notifyEventEvent(AOMEvent * event, 
									AOMAnimationItem *const  sender, 
									AOMInstance *const  receiver,
									OMNotify what)
{
	// Should check for timeouts too
	if (isEventInteresting(sender, receiver))
	{
		AOMSData msg(this, what);
		msg.addItem(sender);
		msg.addItem(receiver);
		OMSData * tmp = event->cserialize(withParameters(sender, receiver));
		if (tmp != 0)
		{
			msg.addItem(*tmp);
			delete tmp;
			AOMSchedDispatcher::instance()->sendMessage(msg);
		}
	}
}


void AOMEventQueue::notifyEventSent(AOMEvent * event,
									AOMAnimationItem * const sender, 
									AOMInstance * const receiver)
{
	// Make sure my proxy has arrived
	if (!myProxy && AOMSchedDispatcher::instance()->isActive())
	{
		waitForProxy();
	}
	// Actually do my thing
	notifyEventEvent(event, sender, receiver, eventSent);
}

void AOMEventQueue::notifyEventReceived(AOMEvent * event,
										AOMAnimationItem * const sender,
										AOMInstance * const receiver)
{
	notifyEventEvent(event, sender, receiver, eventTaken);
}


void AOMEventQueue::notifyTimeoutSet(AOMEvent * const event,
									 AOMAnimationItem * const item)
{
	if (isTimeoutInteresting(item))
	{
		AOMSData msg(this, timeoutSet);
		msg.addItem(item);
		OMSData * tmp = event->cserialize(true);
		if (tmp != 0)
		{
			msg.addItem(*tmp);
			delete tmp;
			AOMSchedDispatcher::instance()->sendMessage(msg);
		}
	}
}
void AOMEventQueue::notifyEventCancelled(AOMEvent * const event,
										 AOMAnimationItem * const item)
{
	// currently we are only interested in timeout cancelation
	notifyTimeoutCancelled(event, item);
}

void AOMEventQueue::notifyTimeoutCancelled(AOMEvent * const event,
										   AOMAnimationItem * const item)
{
	if (isTimeoutInteresting(item))
	{
		AOMSData msg(this, eventCancelled);
		msg.addItem(item);
		OMSData * tmp = event->cserialize(true);
		if (tmp != 0)
		{
			msg.addItem(*tmp);
			delete tmp;
			AOMSchedDispatcher::instance()->sendMessage(msg);
		}
	}
}


AOMEventQueue::AOMEventQueue(AOMThread* owner) : blockingPut(false), theOwner(owner) ,queueMutex(0)
{ 
	queueMutex = OMOSFactory::instance()->createOMOSMutex();
}

AOMEventQueue::~AOMEventQueue()
{
	delete queueMutex;
	queueMutex = 0;
}

// reset the queue state
// used by the owner AOMThread on change of the actual thread
void AOMEventQueue::reset()
{
	if (queueMutex != 0)
	{
		queueMutex->lock();
	}
	// reset
	while (!queue.isEmpty())
	{
		(void) queue.get();
	}
	if (queueMutex != 0)
	{
		queueMutex->unlock();
	}
}

void AOMEventQueue::onEventGetBegin(bool)
{
	if (!blockingPut)
	{
		// if the put is blocking, do not prevent the get
		// this is done to avoid deadlock that can occur 
		// if the put is waiting since the queue is full
		queueMutex->lock();
	}
}

void AOMEventQueue::onEventGetEnd(const IOxfEvent* ev, bool add2q)
{
	// queueMutex->lock() was called in onEventGetBegin()

	resetWakeupToken();
	
	OMString eventName;
	AOMEvent* aomEv = 0;
	AOMInstance* receiver = 0;
	bool report = false;
	setEventReceivedInfo(ev, aomEv, receiver, eventName, report);

	if (report && (aomEv != 0))
	{
		notifyEventReceived(aomEv, aomEv->getSender(), receiver);
	}

	// remove from the internal queue
	// since we add events to the queue without testing we need to remove them in this manar as well
	if (add2q)
	{
		(void) queue.get();
	}

	// The "unlock" must be before checkBreakPoint 
	// to prevent deadlock in trace multi-thread go idle
	
	// It is assumed that call to unlock() has no affect 
	// if the mutex was not locked in onEventGetBegin()
	queueMutex->unlock();
	
	if (!eventName.IsEmpty())
	{
		AOMBreakPointManager::instance()->checkBreakPoint(eventTaken, receiver, eventName.GetBuffer(0));
	}
}

void AOMEventQueue::onEventPutBegin(const IOxfEvent* ev, bool blocking, bool)
{
	// LOCK
	if (blocking)
	{
		blockingPut = true;
	}
	queueMutex->lock();
	
	// Report the event
	AOMEvent* theAOMEvent = AOMSchedDispatcher::instance()->getAOMEvent(ev);
	if (theAOMEvent)
	{
		AOMInstance* theInstance = AOMSchedDispatcher::instance()->getAOMInstance(ev->getDestination());
		AOMAnimationItem* sender = theAOMEvent->getSender();
		notifyEventSent(theAOMEvent, sender, theInstance);
	}
}

void AOMEventQueue::onEventPutEnd(const IOxfEvent* ev, bool add2q)
{
	// add to the internal queue
	// we add every event even non-animated in order to maintain a valid reflection of the real queue
	// however if the queue of the event failed then we should not add it
	if (add2q)
	{
		queue.put(ev);
	}

	const char * eventName = 0;
	AOMAnimationItem* sender = 0;
	AOMEvent* theAOMEvent = AOMSchedDispatcher::instance()->getAOMEvent(ev);
	if (theAOMEvent &&
		(theAOMEvent->getEventClass() != 0))
	{
		bool isTimeout = false;
		const IOxfAnimHelper* animHelper = AnimServices::getOxfAnimHelper();
		if (animHelper)
		{
			isTimeout = animHelper->isTimeoutEvent(ev);
		}
		sender = theAOMEvent->getSender();
		if (aomIsValidItem(sender) &&
			!isTimeout)
		{
			// theAOMEvent->getEventClass() is valid (checked above)
			eventName = theAOMEvent->getEventClass()->getEventName();
		}
	}
	// The "unlock" must be before checkBreakPoint 
	// to prevent deadlock in trace multi-thread go idle
	blockingPut = false; // since only one put is done at a time this is ok
	queueMutex->unlock();

	if (eventName != 0)
	{
		AOMBreakPointManager::instance()->checkBreakPoint(eventSent, sender, eventName);
	}
}

void AOMEventQueue::sendMyself(OMInterestMask theMask)
{
	// There is something to send only if events are interesting
	if (!theMask.isInteresting(OMEventInterest))
	{
		return;
	}
	// Create a message and place on it the methods one by one
	// 1. Create the message
	bool withParameters = theMask.isInteresting(OMParameterInterest);
	AOMSListOfMethods msg(countUnknown);

	// 2. Make a message list - needed as message queue itself might 
	// not be an OMAbstractContainer
	// Note we do not have to "clear" eventList in the end as ~OMList
	// takes care of that automaticly
	queueMutex->lock();
	//OMList<const IOxfEvent*> eventList;
	//queue.getInverseQueue(eventList);
	for(OMIterator<const IOxfEvent*> iter(queue); *iter; ++iter)
	{
		const IOxfEvent* e = (*iter);
		// Pack only "real" events
		bool canceledEvent = false;
		const IOxfAnimHelper* animHelper = AnimServices::getOxfAnimHelper();
		if (animHelper)
		{
			canceledEvent = animHelper->isCancelledEvent(e);
		}
		AOMEvent* theAOMEvent = AOMSchedDispatcher::instance()->getAOMEvent(e);
		if ((theAOMEvent != 0) && 
			(!canceledEvent))
		{
			OMSData* eventMsg = theAOMEvent->cserialize(withParameters);
			if (eventMsg != 0)
			{
				AOMInstance* theAOMInstance = AOMSchedDispatcher::instance()->getAOMInstance(e->getDestination());
				msg.addMethodCall(theAOMEvent->getSender(), theAOMInstance, eventMsg);
				delete eventMsg;
			}
		}
	}
	queueMutex->unlock();
	msg.end(); // Mark end of event list
	AOMSData omdata(this, eventQueueValues, msg);
	AOMSchedDispatcher::instance()->sendMessage(omdata);
}

// reset the owner thread wakeup token
void AOMEventQueue::resetWakeupToken() const
{
	if (theOwner)
	{
		theOwner->resetWakeupToken();
	}
}

// set information required for onEventGetEnd()
void AOMEventQueue::setEventReceivedInfo(const IOxfEvent* ev,
										 AOMEvent*& aomEv,
										 AOMInstance*& receiver,
										 OMString& eventName,
										 bool& report) const
{
	aomEv = 0;
	receiver = 0;
	eventName.Empty();
	report = false;
	
	if (ev != 0)
	{
		aomEv = AOMSchedDispatcher::instance()->getAOMEvent(ev);
		if (aomEv != 0)
		{
			if (aomEv->getEventClass() != 0)
			{
				eventName = (char*)aomEv->getEventClass()->getEventName();
				report = true;
			}
			receiver = AOMSchedDispatcher::instance()->getAOMInstance(ev->getDestination());
			if (aomIsValidItem(receiver))
			{
				if (!report)
				{
					const IOxfAnimHelper* animH = AnimServices::getOxfAnimHelper();
					if (animH != 0)
					{
						report = animH->getFrameworkEventClassName(ev, eventName);
					}
				}
			}
			else
			{
				receiver =  reinterpret_cast<AOMInstance*>(OMGarbage);
			}
		}
	}
}


//
// $Log: aomeque.cpp $
// Revision 1.53  2007/03/11 11:57:51  ilgiga
// Change copyright comment
// Revision 1.52  2007/03/01 16:31:23  ilgiga
// Telelogic instead of i-Logix
// Revision 1.51  2005/09/27 08:36:25  amos
// AOMEventQueue: move the actual put of the event to the reflection queue from onEventPutBegin() to onEventPutEnd() in order to be able to avoid adding events if the queue of the event in the OXF failed
// Revision 1.50  2005/09/15 07:29:24  vova
// AOM shadow queue will not be modified when timeouts expire (we need to simulate the enter to/exit from queue of the timeouts in order for the animation to display them properly).
// Revision 1.49  2005/08/23 14:56:26  amos
// bugfix 85444 to main branch
// Revision 1.48.1.2  2005/08/22 10:06:52  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.48  2005/06/06 15:34:26  amos
// Revision 1.47.1.2  2005/06/06 12:34:23  amos
// Use the IOxfAnimHelper services
// Revision 1.47  2005/05/19 09:22:24  amos
// fix compiler warnings
// Revision 1.46  2005/05/15 14:18:34  amos
// AOMEventQueue: add a new public operation - void reset()
//   The operation reset the queue state
//   It is used by the owner AOMThread on change of the actual thread
// Revision 1.45  2005/05/15 12:18:23  amos
// AOMEventQueue::setEventReceivedInfo() - fix the operation to handle animated events with non-animated destination
// Revision 1.44  2005/05/01 14:27:45  amos
// bugfix 82359
// Revision 1.43.1.2  2005/05/01 14:25:33  amos
// Add missing safe NULL check
// Revision 1.43.1.1  2005/04/21 10:03:18  amos
// Duplicate revision
// Revision 1.42.1.10  2005/04/18 12:08:59  amos
// Revision 1.42.1.9  2005/04/11 12:57:58  amos
// Revision 1.42.1.8  2005/04/11 11:51:51  amos
// Revision 1.42.1.7  2005/04/10 15:25:20  amos
// Revision 1.42.1.6  2005/04/10 10:49:29  amos
// Handle timeouts correctly
// Revision 1.42.1.5  2005/04/06 15:43:41  amos
// Revision 1.42.1.4  2005/04/04 13:48:45  amos
// Revision 1.42.1.3  2005/03/16 14:02:30  amos
// Revision 1.42.1.2  2005/03/03 14:06:21  amos
// Decouple the AOM event queue and the OXF thread event queue
// Revision 1.42.1.1  2004/09/08 13:02:37  amos
// Duplicate revision
// Revision 1.41.1.2  2004/09/07 14:17:41  amos
// Rename the framework interfaces and types to ensure unique names as well as updating all references.
// - IActive changed to IOxfActive
// - IReactive changed to IOxfReactive
// - IEvent changed to IOxfEvent
// - ITimeout changed to IOxfTimeout
// - IEventGenerationParams changed to IOxfEventGenerationParams
// - TimeUnit changed to OxfTimeUnit
// Revision 1.41.1.1  2004/06/27 15:43:01  amos
// Duplicate revision
// Revision 1.40.1.8  2004/04/25 09:46:58  amos
// Revision 1.40.1.7  2004/04/25 07:58:29  amos
// rename put to putMessage using the new API
// Revision 1.40.1.6  2004/03/04 11:37:28  amos
// AOMEventQueue::put() - prevent a race between the event deletion and the message after the event queuing by getting all the required event information prior to the queuing of the event.
// Revision 1.40.1.5  2004/02/09 11:43:18  amos
// frmaework interfaces vs concrete types
// Revision 1.40.1.4  2004/02/08 14:25:02  amos
// Revision 1.40.1.3  2004/02/04 13:52:08  amos
// Revision 1.40.1.2  2004/02/03 14:51:08  amos
// Revision 1.40.1.1  2003/10/29 09:22:25  amos
// Duplicate revision
// Revision 1.39.1.5  2003/10/28 16:47:49  eldad
// Revision 1.39.1.4  2003/10/28 15:15:37  eldad
// Revision 1.39.1.3  2003/10/28 14:47:32  eldad
// Revision 1.39.1.2  2003/10/19 14:14:08  eldad
// Revision 1.39.1.1  2003/05/26 10:52:57  eldad
// Duplicate revision
// Revision 1.38  2003/05/19 14:17:51  vova
// Revision 1.37  2001/10/24 10:19:26  vova
// 46507:Event is sent to non-animated class B, should arrive to border
// Revision 1.36  2001/05/16 08:11:52  amos
// merge OSE 4.3.1 support into r40
// Revision 1.35  2001/05/13 07:35:35  vova
// Redundant function checkEventBP() deleted (#44325)
// Revision 1.34  2001/03/20 11:17:02  vova
// Back to main from 1.33.1.2
// Revision 1.33.1.2  2001/02/20 09:45:16  vova
// Partial Animation friend using scheme
// Revision 1.34  2001/02/15 09:42:09  vova
// Partial Animation friend using scheme
// Revision 1.33  2001/01/25 13:58:07  avrahams
// OXF globals encapsulation
// Revision 1.32  2001/01/10 16:16:51  vova
// Merge with Partial Animation additions
// Revision 1.31.1.2  2000/12/17 14:20:43  vova
// Merge 1.31 with PartAnim
// Revision 1.28.1.3  2000/09/06 11:54:10  vova
// Bug fixes in Partial Animation
// Revision 1.28.1.2  2000/08/30 16:12:01  vova
// Partial Animation: Phases 1,2
// Revision 1.28.1.1  2000/07/11 09:23:50  vova
// Revision 1.31.1.1  2000/11/21 15:45:48  vova
// Duplicate revision
// Revision 1.30  2000/11/08 15:28:38  amos
// back to main branch
// Revision 1.29.1.2  2000/11/08 15:28:38  amos
// modify AOMEventQueue::put() to return a value
// Revision 1.29.1.1  2000/11/01 16:01:13  amos
// Duplicate revision
// Revision 1.28.2.2  2000/11/01 16:01:13  amos
// in AOMEventQueue::put() call theQueue->put() with the fromISR parameter
// Revision 1.28.2.1  2000/07/11 09:23:50  amos
// Duplicate revision
// Revision 1.27  2000/03/28 05:41:57  amos
// in AOMEventQueue::get(), the safe programming for OSE (handling 0 events) - unlock the event queue mutex before returning 0.
// Revision 1.26  2000/03/23 15:59:59  amos
// back to main branch
// Revision 1.25.1.2  2000/03/23 08:17:55  amos
// in AOMMessageQueue::get() - add safe programming that checks, that the event value is not 0. The check is needed for OSE
// Revision 1.25.1.1  1999/09/30 14:09:49  amos
// Duplicate revision
// Revision 1.24.1.2  1999/09/30 12:36:03  amos
// syntax fix
// Revision 1.24.1.1  1999/09/09 17:21:35  amos
// disable animation when generating an event from an ISR call
// Revision 1.24  1999/07/29 10:28:40  amos
// support generation of events from interupt handler (VxWorks)
// Revision 1.23  1999/02/16 06:07:59  yachin
// Speed up of construction during animation
// Revision 1.22  1999/02/09 14:57:12  amos
// change the getMessageList() back to OMList
// Revision 1.21  1999/02/03 15:55:46  amos
// back to main branch
// Revision 1.20.1.2  1999/02/03 14:12:51  amos
// change in getEventList()
// Revision 1.20.1.1  1999/01/26 08:29:06  amos
// Duplicate revision
// Revision 1.19.1.2  1999/01/24 14:50:31  amos
// Revision 1.19  1999/01/21 12:07:42  beery
// adjust to classes which were generated by Rhapsody but are part of the oxf itself and are not instrumented
// Revision 1.18.1.3  1999/01/19 15:27:55  beery
// Revision 1.18.1.2  1999/01/17 08:24:02  beery
// Revision 1.18  1998/11/30 10:29:15  amos
// sofe programming envolved with static oxf
// Revision 1.18.2.2  1999/01/19 12:18:21  amos
// support in setting the message queue size from OMTread constructor
// Revision 1.18.2.1  1998/11/30 10:29:15  amos
// Duplicate revision
// Revision 1.17  1998/08/02 15:04:02  beery
// changing boolean->bool
// Revision 1.16  1998/05/21 12:33:58  yachin
// Notify Tom when events are canceled
// Revision 1.15  1998/04/28 14:33:34  beery
// using the CancelledEvent_Id
// Revision 1.14  1997/08/11 11:15:47  yachin
// stop timer during "user's turn" in anim/trace
// Revision 1.14  1997/08/10 10:46:22  yachin
// timer suspended/resumed in user's turn in animation
// Revision 1.13  1997/08/05 15:26:16  yachin
// Yet again
// Revision 1.12  1997/08/05 13:50:04  yachin
// bug fix on bug fix
// Revision 1.11  1997/08/04 16:57:17  yachin
// eventQue/callStack make sure they have a proxy before send/push
// Revision 1.10  1997/07/20 11:41:04  yachin
// Adding globals to animation
// Revision 1.9  1997/04/15 03:40:04  yachin
// eventQueue no longer an OMAbstractContainer
// Revision 1.8  1997/04/09 13:30:28  ofer
// does not call sendMessage(OMSData(...)) since the sendMessage
// accept OMSData&.
// so we define variable OMSData xxx(...) and call sendMessage(xxx)
// the gnu compiler 2.51 complain about it and vc4.1 optimazier
// does not like it
// {aomcalls,aomdisp,aomequeue,aominst,aomstep}.cpp
// Revision 1.7  1997/03/05 07:04:51  yachin
// get eventName placed inside the mutex
// Revision 1.6  1997/03/02 13:27:31  yachin
// Fix deadlock bug when go idle and notifyBreakpoint ring together
// Revision 1.5  1997/02/16 12:37:23  yachin
// fixes related to  +OXFDelay -omthread::delay
// Revision 1.4  1997/02/06 13:31:02  yachin
// Switch from try to aomIsValidItem
// Revision 1.3  1997/02/03 06:31:27  yachin
// Revision 1.2  1997/01/28 10:54:41  yachin
// without low level signal
// Revision 1.1  1997/01/27 09:44:42  yachin
// Initial revision
// Revision 1.45  1997/01/26 13:50:02  yachin
// ReWrite for Foreign Threads
// Revision 1.44  1997/01/22 11:55:24  yachin
// Inverse composite relation bug fix
// Revision 1.43  1997/01/21 13:55:26  yachin
// not working properly
// Revision 1.42  1997/01/21 11:02:28  yachin
// changed _int32 to int
// Revision 1.41  1997/01/21 10:54:07  yachin
// User Threads part I
// Revision 1.40  1997/01/12 11:44:41  yachin
// Revision 1.39  1997/01/06 09:12:37  yachin
// Revision 1.38  1997/01/05 13:36:26  yachin
// Revision 1.37  1996/12/30 13:07:23  yachin
// Revision 1.36  1996/12/30 09:55:25  yachin
// Multi Thread support part III
// Revision 1.35  1996/12/25 13:42:45  yachin
// removed #ifdef from defintion of OMThread
// Revision 1.34  1996/12/19 13:14:11  yachin
// Fixed bug in breakpoinnt on event received
// Revision 1.33  1996/12/12 06:25:22  yachin
// fixed double notification on event b.p.
// Revision 1.32  1996/11/24 12:55:26  yachin
// Revision 1.31  1996/11/13 13:32:28  yachin
// Revision 1.30  1996/11/11 11:46:55  yachin
// Support multi-thread part I
// Revision 1.29  1996/11/10 07:51:00  yachin
// fixed gotControl breakpoint + breakPoint to dead objects
// Revision 1.28  1996/10/30 11:36:38  yachin
// Revision 1.27  1996/10/30 08:58:26  yachin
// Bug fix break methods
// Revision 1.26  1996/10/22 12:05:53  yachin
// Revision 1.25  1996/10/21 11:38:29  yachin
// Cleanup on state notifies + fixes on timeouts + support for breakpoints
// Revision 1.24  1996/10/15 13:30:54  yachin
// Fix Bug in notifySendEvent
// Revision 1.23  1996/10/14 11:35:49  yachin
// Enhancement for set/cancel timeouts
// Revision 1.21  1996/10/01 13:25:00  yachin
// Bug in eventQueue
// Revision 1.20  1996/09/24 12:20:09  yachin
// Fixes For single threaded AOM
// Revision 1.19  1996/09/08 11:25:07  yachin
// Fixed some prolem with cons tin const functions
// Revision 1.18  1996/09/03 11:58:53  yachin
// Fix bugs in show #callStack
// Revision 1.17  1996/09/02 13:40:44  yachin
// Preparations for connecting with call stack view and MSC
// Revision 1.16  1996/09/01 06:37:42  ofer
// Revision 1.15  1996/08/15 08:40:51  yachin
// Revision 1.14  1996/08/08 08:22:18  yachin
// Prototype 4 major revision
// Revision 1.13  1996/08/06 12:49:53  yachin
// Tracer for Prototype 4
// Revision 1.12  1996/07/18 10:48:56  yachin
// Post Prototype 3 rewrite: virtual destructors, remarks, type changes and safe programing on deleted items
// Revision 1.11  1996/07/14 07:30:17  yachin
// Revision 1.10  1996/07/11 13:32:04  yachin
// Revision 1.9  1996/07/10 12:48:35  yachin
// Revision 1.8  1996/07/10 05:47:00  yachin
// Reorganization + some stuff for OMANIMATOR
// Revision 1.7  1996/07/04 12:37:44  yachin
// Revision 1.6  1996/07/03 12:44:39  yachin
// Fixing bugs for "const" and "static" functions
// Revision 1.5  1996/06/25 11:51:57  yachin
// Revision 1.4  1996/06/24 11:15:20  yachin
// OMANIMATOR version should work
// AOMTimer removed - as it is unused
// Revision 1.3  1996/06/20 10:21:54  yachin
// Revision 1.2  1996/06/19 10:18:52  yachin
// Revision 1.1  1996/06/17 05:33:22  yachin
// Initial revision
//
