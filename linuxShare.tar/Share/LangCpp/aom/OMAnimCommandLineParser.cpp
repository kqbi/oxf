//	Component		: oxfFiles 
//	Configuration 	: generic
//	Model Element	: OMAnimCommandLineParser
//!	File name		: $Source: R:/StmOO/Master/cg/LangCpp/aom/rcs/OMAnimCommandLineParser.cpp $
//!	File version	: $Revision: 1.7 $
//
//!	Date changed	: $Date: 2007/03/11 11:57:48 $
//!	Last change by	: $Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2004, 2008. All Rights Reserved.
//
//#[ ignore
#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char* rcsid = "//! $Id: OMAnimCommandLineParser.cpp 1.7 2007/03/11 11:57:48 ilgiga Exp $";
#endif
//#]

#include "OMAnimCommandLineParser.h"
#include "AnimServices.h"
#include "oxf/omstring.h"

//## package Design::oxf::Services::Instrumentation 

//----------------------------------------------------------------------------
// OMAnimCommandLineParser.cpp                                                                  
//----------------------------------------------------------------------------
//## class OMAnimCommandLineParser 


OMAnimCommandLineParser::~OMAnimCommandLineParser() {
}

int OMAnimCommandLineParser::processHostArg(int numProgArgs, const char** progArgs, char*& host) {
    //#[ operation processHostArg(int,char*,char*) 
    host = 0;
    if (numProgArgs > 1) {
    	for (int i = 1; i < numProgArgs ; i++) {
    		if (!strncmp("-hostname", progArgs[i], strlen(progArgs[i]))) {
    			if (i < numProgArgs-1) {
    				host = const_cast<char*>(progArgs[i+1]);
    				return 1;
    			}
    			else {
    				usage(progArgs[0]);
    				return 0;
    			}
    		}
    	}
    }
    return 2;
    //#]
}

int OMAnimCommandLineParser::processPortArg(int numProgArgs, const char** progArgs, int& port) {
    //#[ operation processPortArg(int,char*,int) 
    port = 0;
    if (numProgArgs > 1) {
    	for (int i = 1; i < numProgArgs ; i++) {
    		if (!strncmp("-port",progArgs[i],strlen(progArgs[i]))) {
    			if (i < numProgArgs-1) {
    				port = atoi(progArgs[i+1]);
    				if (0 == port) {
    					usage(progArgs[0]);
    					return 0;
    				}
    				return 1;
    			}
    			else {
    				usage(progArgs[0]);
    				return 0;
    			}
    		}
    	}
    }
    return 2;
    //#]
}

bool OMAnimCommandLineParser::processNoAnimFlag(int numProgArgs, const char** progArgs)
{
    bool bWithNoAnim = false;
    if (numProgArgs > 1) {
    	for (int i = 1; i < numProgArgs ; i++) {
    		if (!strncmp("-noanim",progArgs[i],strlen(progArgs[i]))) {
    			bWithNoAnim = true;
			}
    	}
    }
    return bWithNoAnim;
}

void OMAnimCommandLineParser::usage(const char* programName) {
    // print an error msg if host not found
	OMString msg;
	msg += "Animation commandline usage: ";
	msg += const_cast<char*>(programName);
	msg += " [-h[ostname] hostname] [-p[ort] portNumber] [-noanim]";
	AnimServices::notifyError(msg.GetBuffer(0));
}



//
//! Log: $$(CMLog)$
//


