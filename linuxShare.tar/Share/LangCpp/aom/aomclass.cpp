#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: aomclass.cpp 1.29 2007/03/11 11:57:50 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/aom/rcs/aomclass.cpp $
//	file version:	$Revision: 1.29 $
//
//	purpose: Methods of Class AOMClass	 	
//
//	author(s):		Yachin Pnueli
//	date started:	11.8.96
//	date changed:	$Date: 2007/03/11 11:57:50 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "aomclass.h"
#include "aommsg.h"
#include "aomdisp.h"
#include "aominst.h"
#include "aomoperation.h"


#include <omcom/AnimClassData.h>
#include <omcom/AnimRegisterOperations.h>
#include <omcom/AnimRhapTranslator.h>


//
//	AOMClass methods
//
void AOMClass::simpleInit(char const* clsName, 
						  bool isSingleton, 
						  const char * context,
						  const int theSuperClassCount) {
	// Initialize attributes
	this->className = (char*)clsName;
	this->_isSingleton = isSingleton;
	this->_context = (char*)context;

	attributeCount = countUnknown;
	relationCount = countUnknown;
	superClassCount = theSuperClassCount;
	// InstanceList is created empty so we do not initialize it

	registerClass();
}

AOMClass::~AOMClass() { 
// This is done automatically
//	// Clear the instance list
//	instanceList.removeAll();
}

AOMClass *AOMClass::getSuperClass(int i)const {
	if (i<0 || i>=superClassCount) return 0;
	else if (superClassCount==1) return (AOMClass *) superClasses;
	else return superClasses[i];
}


void AOMClass::serializeSuperClasses(AOMSData& s) const {
	// When we support class contexted classes -
	// context!=0 should send context too

	// Should we serialize anything ?
	if (superClassCount==0) return;

	// Add my proxy
	s.addItem(this);

	// Now add the super Classes
	if (superClassCount==1)
		s.addItem((AOMClass *)superClasses);
	else {
		// This works provided we have less than OMMaxCode (199)
		// independent super classes
		s.addItem(superClassCount);
		for(int i=0;i<superClassCount;i++)
			s.addItem(superClasses[i]);
	}
}

void AOMClass::sendMyself(OMInterestMask theMask) {
	if (theMask.isInteresting(OMExistInterest)) {
		// Send the list of elements
		AOMSClass msg(this, instanceList.getCount());
		for(OMIterator<AOMInstance *>  iter(instanceList); *iter; iter++) {
			msg.addItem(*iter);
		}
		msg.end();
		AOMSchedDispatcher::instance()->sendMessage(msg);
	}
	// Make all my instances send them self as well
	//	for(OMIterator<AOMInstance *>  iter(instanceList); *iter; iter++)
	//		(*iter)->sendMyself(theMask);
}

void AOMClass::addItem(AOMInstance * item, AOMAnimationItem * creator) {
	// Create a proxy to the new item 
	// i.e. notify the TOMClass of this item's creation.
	if (isInteresting(OMExistInterest)) {
		// Create the message
		AOMSData msg(this, instanceCreated);
		// Add the item
		msg.addItem(item);
		// Add the list of relations for this item - this should be 
		// here as the item constructor does not use regular mutators
		AOMSRelations tmp;
		item->cserializeRelations(tmp);
		msg.addItem(tmp);
		// Add "my creator" - the "caller" of the constructor
		msg.addItem(creator);
		// Send the message and wait for proxy creation
		AOMSchedDispatcher::instance()->sendMessage(msg);
	}

	// Add item to my list
	instanceList.add(item);

	// Add to the item 'my' interestMask
	// Not very clean bu tI hope it works
	// Assumption the 'proxy Mask' from TOM will always come later
	// as I attach to class in TOM after I attach to class in AOM
//	// If item has not yet connected to proxy give it 'my' interestMask
//	if (item->getProxy()==OMInConstruction) {
		OMInterestMask oldMask = item->getInterestMask();
		OMInterestMask itemMask = oldMask + myMask;
		if (oldMask!=itemMask) {
			item->setInterestMask(itemMask);
			item->sendMyself(itemMask); // Patchy
		}
//	}

}

OMString AOMClass::getClassName()
{
	return className;
}

void AOMClass::addOperation(AOMOperation * op)
{
	operationList.add(op);
	op->setMyClass(this);
}

// register the operation in Rhapsody
void AOMClass::registerOperations()
{
	if (operationList.getCount() > 0)
	{
		AnimRegisterOperations *regMsg = new AnimRegisterOperations();
		regMsg->setOrigSource(this);
		regMsg->setDestOrSource(this->getProxy());
		for(OMIterator<AOMOperation *>  iter(operationList); *iter; iter++) {
			(*iter)->addRegisterData(regMsg);
		}
		AOMSchedDispatcher::instance()->encodeAndSendMessage(regMsg);
	}
}
void AOMClass::removeItem(AOMInstance * item, AOMAnimationItem * destroyer){
	// Notify my proxy
	if (isInteresting(OMExistInterest)) {
		AOMSData msg(this, instanceDeleted);
		msg.addItem(item);
		msg.addItem(destroyer);
		AOMSchedDispatcher::instance()->sendMessage(msg);
	}
	// Remove item from list
	instanceList.remove(item);
}

void AOMClass::registerClass()
{
	// message is currently supported by AOM only in animation
	// in tracing we should use the old mechanism for it.
#ifdef OMANIMATOR 

	AnimClassData *classData = new AnimClassData();
	classData->setDestOrSource(this);
	classData->setClassName(className.GetBuffer(0));
	classData->setIsSingleton(_isSingleton);
	classData->setPackageName(_context.GetBuffer(0));

	AOMSchedDispatcher::instance()->registerClass(this, *classData);

	delete classData;
#else
	// Create the proxy Message
	OMSData msg(this);
	msg.addCode(omProxyClass);
	msg.addItem(className.GetBuffer(0));
	msg.addCode(_isSingleton);
	msg.addItem(_context.GetBuffer(0));

	// Register in SchedDisp
	AOMSchedDispatcher::instance()->registerClass(this, msg);
#endif
}

void AOMClass::assureInitialization()
{
	if(!className.IsEmpty() && AOMSchedDispatcher::instance()->isClassRegistered(this) == false)
	{
		//in case AOMClass isn't registered in dispatcher, we need to re-registered it
		myProxy = NULL;
		registerClass();
	}
}

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = aomclass_H;
#endif

#ifdef aomclass_Debug


void main() {
}
#endif


//
// $Log: aomclass.cpp $
// Revision 1.29  2007/03/11 11:57:50  ilgiga
// Change copyright comment
// Revision 1.28  2007/03/01 16:31:22  ilgiga
// Telelogic instead of i-Logix
// Revision 1.27  2005/11/03 07:55:54  vova
// 85930: LINT error fixed
// Revision 1.26  2005/08/23 14:56:26  amos
// bugfix 85444 to main branch
// Revision 1.25.1.2  2005/08/22 10:06:51  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.25  2005/04/21 10:03:14  amos
// Revision 1.24.1.3  2005/04/10 15:25:20  amos
// Revision 1.24.1.2  2005/03/16 14:02:28  amos
// Revision 1.24  2002/08/20 15:59:19  vova
// 57137: The following warning message has been avoided:
// "Warning: className hides AOMClass::className"
// Revision 1.23  2002/07/31 08:54:01  Eldad
// In Tracer mode use old style messages to register the classes.
// Revision 1.22  2002/07/29 11:35:22  Eldad
// Anim Operation Calls.
// Revision 1.21.1.1  2001/04/02 07:33:20  Eldad
// Duplicate revision
// Revision 1.20  2000/07/11 09:23:50  amos
// fix compilation warnings under solaris
// Revision 1.19  1999/02/16 06:07:58  yachin
// Speed up of construction during animation
// Revision 1.18  1998/08/02 15:03:59  beery
// changing boolean->bool
// Revision 1.17  1997/04/06 11:36:51  yachin
// Assorted bug fixes
// Revision 1.16  1997/02/11 10:00:02  yachin
// Changes for name-spaces
// 
// Revision 1.15  1997/01/22 11:55:23  yachin
// Inverse composite relation bug fix
// Revision 1.14  1996/11/24 12:55:21  yachin
// Revision 1.13  1996/10/21 11:38:23  yachin
// Cleanup on state notifies + fixes on timeouts + support for breakpoints
// Revision 1.12  1996/10/09 07:33:55  yachin
// Revision 1.11  1996/10/01 13:21:30  yachin
// For Bug in show class all
// Revision 1.10  1996/09/30 10:04:43  yachin
// Fix something in "register new item"
// Revision 1.9  1996/09/29 12:41:47  yachin
// Send Relations together with "create proxy" message (fix relations bug
// Revision 1.8  1996/09/16 13:47:51  yachin
// Revision 1.6  1996/09/04 13:13:34  yachin
// Connect to Israel
// Revision 1.5  1996/09/02 13:40:41  yachin
// Preparations for connecting with call stack view and MSC
// Revision 1.4  1996/08/28 05:35:32  ofer
// Revision 1.3  1996/08/15 08:40:42  yachin
// Revision 1.2  1996/08/14 12:38:17  yachin
// Separate "updated" data from "show" data
// Revision 1.1  1996/08/12 12:32:59  yachin
// Initial revision
//
