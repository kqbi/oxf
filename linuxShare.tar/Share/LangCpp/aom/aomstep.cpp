#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: aomstep.cpp 1.52 2007/03/11 11:57:53 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/aom/rcs/aomstep.cpp $
//	file version:	$Revision: 1.52 $
//
//	purpose: Define the stepper
//
//	author(s):		Yachin Pnueli
//	date started:	9.7.96
//	date changed:	$Date: 2007/03/11 11:57:53 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "aomstep.h"
#include "aomdisp.h"
#include "aomcalls.h"
#include "aomthrd.h"
#include "aomeque.h"
#include "aommsg.h"
#include "aomee.h"
#include "aomoperation.h"

#include <oxf/os.h>
#include <oxf/IOxfAnimTimerManager.h>

#include <omcom/RiCppAnimMessages.h>
#include <omcom/AnimNewInterestMask.h>
#include <omcom/AnimQuitExecutable.h>

#include <omcom/AnimBooleanField.h>
#include <omcom/AnimIntField.h>
#include <omcom/AnimOpCallRequest.h>


#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = aomstep_H;
#endif


AOMStepper::~AOMStepper()
{ 
	// DeRegister with the scheduler
	if (AOMSchedDispatcher::getInstance())
		AOMSchedDispatcher::getInstance()->notify(instanceDeleted,  this);
	delete stopSignal;
}

AOMStepper::AOMStepper(AOMThread* theThread) {
	myThread = theThread;
	shouldStop = false;
	callInProcess = false;
	isLocked = suspended = false;
	stopSignal = OMOSFactory::instance()->createOMOSEventFlag();

	// register with the scheduller
	AOMSchedDispatcher::instance()->notify(instanceCreated, this);
	// Note - proxy creatio nis done by the owning AOMThread
}

void AOMStepper::stopMyself(OMNotify reason, int timeLimit) {
	//don't stop the current thread if the thread of this stepper isn't the current thread
	if (myThread != AOMThread::getThread((void*)NULL))
		return;	// Reset the signal
	
	// Must be here so if we "continue" between the message
	// and the wait - we respond properly
	stopSignal->reset();
	// Tell dispatcer that I'm stopping
	AOMSchedDispatcher::instance()->notify(reason, this);
	// Actually stop
	stopSignal->wait(timeLimit);
	handleOpCallRequests();
}

void AOMStepper::handleOpCallRequests()
{
	// the request must be removed from the container BEFORE
	// the operation is called. Otherwise we will keep 
	// calling it if we do "Go Step".
	OMIterator<AnimOpCallRequest *> request(opCallRequests);

	
	if (callInProcess == false) // do not allow more calls while another call is in process
	{
		callInProcess = true;
		while (*request) {

			AnimOpCallRequest *currentRequest = *request;

			// remove from container
			opCallRequests.remove(*request);

			// reset the iterator for next time;
			request.reset();

			doOpCallRequest(currentRequest);

			delete currentRequest;
		}
		callInProcess = false;

	}
}

void AOMStepper::doOpCallRequest(AnimOpCallRequest *currentRequest)
{
	AOMCallStack *cs = myThread->getCallStack();
	if (cs != 0) { 
		cs->setNextCallFromEnv(true); 
	}
	AOMOperation::doOpCallRequest(currentRequest, cs);
	if (cs != 0) { 
		cs->setNextCallFromEnv(false); // just to make sure
	}
}

inline void AOMStepper::notifyGoingToStop(OMNotify reason) {
	// Do what's necessary to stop
	shouldStop = true;
	// Notify my proxy that I'm the reason to stop
	AOMSData msg(this, reason);
	AOMSchedDispatcher::instance()->sendMessage(msg);
	// Notify sched that he should wait for user
	AOMSchedDispatcher::instance()->notify(waitForUser,this);
// In tracer, the resume point is here - the application is stopped
// by reading the command line
#ifdef OMTRACER 
	handleOpCallRequests();
#endif
}

void AOMStepper::doStep() {
	// A step has occered
	if (!AnimServices::isApplicationEnding())
	{
	if (shouldStop) // Tell dispatcer that I'm stopping and stop
		stopMyself(stoppedMyself);
	else if (suspended) { // Just stop
		stopSignal->reset();
		stopSignal->wait();
	}
}
}

void AOMStepper::notifyStep() {
	// A step is about to be taken

	////////////////////////////////////////////////////////////////////
	// myThread->getCallStack()->notify(0,omBehaviourMethod);
	// The above was commented out since the "end call" to notifyStep
	// from "pop" of aomcallStack cause undesired early registeration
	// of instances in their base classes
	// remove comment only with good reason !!
	////////////////////////////////////////////////////////////////////
	
	if (isInteresting(OMStopWhenNext))
		notifyGoingToStop(stoppedForStep);
	doStep();
}

void AOMStepper::notifyNullTransitionStep() {
	// A null transition step is about to be taken
	if (isInteresting(OMStopWhenStep)) 
		notifyGoingToStop(stoppedForStep);
	doStep();
}

void AOMStepper::notifyEvent() {
	// An event is about to be dispatched
	// Notify the call stack
	myThread->getCallStack()->notify(0,omBehaviourMethod);
	if (isInteresting(OMStopWhenEvent | OMStopWhenNext | OMStopWhenStep) &&
		!myThread->wasWakeupRequested()) 
	{
		notifyGoingToStop(stoppedForEvent);
	}
	doStep();
}

void AOMStepper::notifyIdle() {
	// The executable is about to become idle
	// Notify the call stack
	myThread->getCallStack()->notify(0,omBehaviourMethod);
	if (isInteresting(OMNotifyIdle)) {
		notifyGoingToStop(stoppedForIdle);
	}
	// Do a step - entering "idle" is considered a step
	// Needed because in idle we never do a "real" step
	doStep();
}

void AOMStepper::notifyBreakPoint() {
	notifyGoingToStop(stoppedForBreakpoint);
}


void AOMStepper::stopRequest() {
	// Remember that I should stop
	shouldStop = true;
	if (suspended ||
		isLocked ||
		(myThread && aomIsValidItem(myThread->getCallStack()) && myThread->getCallStack()->isEmpty()))
	{
		// Tell dispatcer that I stopped
		AOMSchedDispatcher::instance()->notify(stoppedMyself, this);
	}
}

void AOMStepper::continueRequest(AOMStepper* initiator) {
	// Thread different from initiating thread continue in "go"
	if (initiator!=this && initiator!=0)
		setInterestMask(OMNoStop);
	shouldStop = false;
	if (!suspended) {
		// Actually resume execution
		stopSignal->signal();
		if ((isInteresting() && myThread->getCallStack()->isEmpty()) 
			|| (opCallRequests.isEmpty() == false)) // if there is a pending call request wake thread as well
			
			myThread->wakeup();
	}
}

void AOMStepper::handleMessage(AnimMessage* animMessage)
{
	OMNotify code = (OMNotify)(animMessage->getCode());
	switch (code)
	{
		case newInterestMask:
		{
			AnimNewInterestMask *iM = (AnimNewInterestMask *)animMessage;
			// Get new intereset mask
			rhp_long64_t theMask = (rhp_long64_t)(iM->getInterestMask()->getValue());
			// Set interestMask appropriately
			setInterestMask((unsigned int)theMask);
			if (theMask == OMStopWhenIdle || theMask == OMStopWhenAction)
			{
				// Patch for go idle = go extended semantics
				// Before we continue we check if my thread is idle
				// and if so we do a "timer go next"
				AOMEventQueue * eque = myThread->getEventQueue();
				AOMCallStack* callstack = myThread->getCallStack();
				if (eque && eque->isEmpty() && callstack && callstack->isEmpty())
				{
					IOxfAnimTimerManager* tm = AnimServices::getTimerManager();
					if (tm && !tm->isExternalTimer())
					{
						tm->advanceTime();
					}
				}
			}
			// Tell dispatcer that I want to continue
			AOMSchedDispatcher::instance()->notify(becameActivated, this);
		}
		break;

		case callOpRequest:
		{
			AnimOpCallRequest *callRequest = (AnimOpCallRequest *)animMessage;
			if (callRequest->getDoImmediately()->getValue())
			{
				doOpCallRequest(callRequest);
			}
			else
			{
				opCallRequests.add(callRequest->fullClone()); // since animMessage is about to be deleted by the dispatcher
			}
		}
		break;

		case quitExecutable:
			// give chance for the other threads to finish
			OMOSFactory::instance()->delayCurrentThread(50);
			shouldStop = false;
			setInterestMask(OMNoStop); // needed so we do not get stuck
			// on the thread of the stepper (trace mode)
			OMOS::endApplication(0);
			break;
		default: 
			AOMAnimationItem::handleMessage(animMessage);
	}
}

void AOMStepper::handleMessage(OMNotify r, OMSData* s, OMSPosition& p) {
	// Perform the operation appropriate to this message code
	switch (r) {
	case newInterestMask:{ // This is the signal to continue
		// Set the intereset
		rhp_long64_t theMask = (rhp_long64_t)s->getPointer(p);
		// Set interestMask appropriately
		setInterestMask((unsigned int)theMask);
		if (theMask == OMStopWhenIdle || theMask == OMStopWhenAction) {
			// Patch for go idle = go extended semantics
			// Before we continue we check if my thread is idle
			// and if so we do a "timer go next"
			AOMEventQueue * eque = myThread->getEventQueue();
			AOMCallStack* callstack = myThread->getCallStack();
			if (eque && eque->isEmpty() && callstack && callstack->isEmpty())
			{
				IOxfAnimTimerManager* tm = AnimServices::getTimerManager();
				if (tm && !tm->isExternalTimer())
				{
					tm->advanceTime();
				}
			}
		}
		// Tell dispatcer that I want to continue
		AOMSchedDispatcher::instance()->notify(becameActivated, this);
		}
		break;
	case suspendThread:
		suspended = true;
		break;
	case resumeThread:
		if (suspended) {	// This condition is to prevent
							// two consequtive stopSignal->signal();
			suspended = false;
			// Resume execution if necessary
			if (!shouldStop)
				// Actually resume execution
				stopSignal->signal();
		}
		break;
	case quitExecutable: 
		shouldStop = false;
		setInterestMask(OMNoStop); // needed so we do not get stuck
		// on the thread of the stepper (trace mode)
		OMOS::endApplication(0);
		break;
	default: AOMAnimationItem::handleMessage(r,s,p);
	}
}


void AOMStepper::sendYourName() {
	myThread->sendYourName();
}

void AOMStepper::notifyAction() {
	// Notify the call stack
	myThread->getCallStack()->notify(0,omBehaviourMethod);
	if (isInteresting(OMStopWhenAction)) {
		notifyGoingToStop(stoppedForAction);
	}
	doStep();
}
//
// $Log: aomstep.cpp $
// Revision 1.52  2007/03/11 11:57:53  ilgiga
// Change copyright comment
// Revision 1.51  2007/03/01 16:31:26  ilgiga
// Telelogic instead of i-Logix
// Revision 1.50  2005/08/23 14:56:28  amos
// bugfix 85444 to main branch
// Revision 1.49.1.2  2005/08/22 10:06:54  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.49  2005/04/21 10:03:28  amos
// Revision 1.48.1.5  2005/04/18 09:16:28  amos
// Add missing include statements
// Revision 1.48.1.4  2005/04/10 15:25:22  amos
// Revision 1.48.1.3  2005/04/06 15:43:25  amos
// Revision 1.48.1.2  2005/04/05 08:41:32  amos
// Revision 1.48  2005/03/16 08:47:32  eldad
// Do not stop while quiting the application
// Revision 1.47.1.3  2005/03/16 14:02:36  amos
// Revision 1.47.1.2  2005/03/09 12:22:36  amos
// Initial support in decoupling of AOM from the OXF core implementation
// Revision 1.47.1.1  2005/01/30 11:27:35  amos
// Duplicate revision
// Revision 1.47  2005/01/30 11:27:35  amos
// AOMStepper::stopRequest() - add safe programming in the test of the thread call stack
// Revision 1.46  2004/05/11 07:27:31  vova
// TheMask should be defined as unsigned int in all appearances
// Revision 1.45  2002/11/25 09:32:33  Eldad
// b#59702 - Ensure caller of CALL operation is set to system border.
// Revision 1.44.1.1  2002/11/25 08:30:37  Eldad
// Duplicate revision
// Revision 1.43.1.2  2002/11/20 15:21:54  Eldad
// Revision 1.43.1.1  2002/08/05 11:21:34  Eldad
// Duplicate revision
// Revision 1.42.1.2  2002/08/01 10:21:11  Eldad
// call per thread.
// Revision 1.42.1.1  2002/07/30 14:33:12  Eldad
// Duplicate revision
// Revision 1.41  2002/07/30 11:18:04  Eldad
// Anim Op Calls
// Revision 1.40  2002/07/29 11:41:34  Eldad
// Anim Operation Calls.
// Revision 1.39.1.1  2002/01/03 15:19:50  Eldad
// Duplicate revision
// Revision 1.38.1.1  2001/07/02 17:08:26  Eldad
// Duplicate revision
// Revision 1.37  2001/04/17 15:21:19  Eldad
// Using new translation mechanism.
// Revision 1.36.1.2  2001/04/09 15:03:53  Eldad
// Refactoring of AnimMessages.
// Revision 1.36.1.1  2001/01/30 08:52:51  Eldad
// Duplicate revision
// Revision 1.35  2001/01/25 13:58:08  avrahams
// OXF globals encapsulation
// Revision 1.34  2000/07/11 09:23:50  amos
// fix compilation warnings under solaris
// Revision 1.33  2000/01/19 12:31:03  amos
// back to main branch
// Revision 1.32.2.6  2000/01/13 07:55:58  amos
// Revision 1.32.2.5  2000/01/12 14:02:08  amos
// add notifyNullTransitionStep() that handle the null transition steps.
// notifyStep() handle all other steps (i.e. regular steps).
// Revision 1.32.2.4  2000/01/06 13:59:59  amos
// Revision 1.32.2.3  2000/01/05 12:01:49  amos
// animation
// Revision 1.32.2.2  2000/01/04 15:07:37  amos
// remove notifySingleStep(), instead add parameter to notifyStep()
// Revision 1.32.2.1  2000/01/03 16:04:06  amos
// add single step
// Revision 1.32  1999/03/04 07:29:18  beery
// let know who is the initiator of the stop request
// Revision 1.31  1999/02/16 06:08:03  yachin
// Speed up of construction during animation
// Revision 1.30  1998/06/24 08:19:13  ofer
// will implement the OSEndApplication by itself
// the omthread dtor and aomdispatcher dtor use the endOfProcess
// the aomdispatcher does not inform delete of instance deletion
// vxos.cpp oxf.cpp/h omthread.cpp aomstep.cpp aomthrd.cpp
// Revision 1.29  1997/08/27 06:16:50  yachin
// Change go idle semantics to 'go extended'
// Revision 1.28  1997/07/20 11:41:07  yachin
// Adding globals to animation
// Revision 1.27  1997/06/05 07:42:42  ofer
// Using OSEndApplication instead of exit
// aomstep.cpp
// Revision 1.26  1997/04/09 13:23:08  ofer
// does not call sendMessage(OMSData(...)) since the sendMessage
// accept OMSData&.
// so we define variable OMSData xxx(...) and call sendMessage(xxx)
// the gnu compiler 2.51 complain about it and vc4.1 optimazier
// does not like it
// {aomcalls,aomdisp,aomequeue,aominst,aomstep}.cpp
// Revision 1.25  1997/02/03 06:31:29  yachin
// Revision 1.24  1997/01/29 13:05:15  yachin
// Revision 1.23  1997/01/29 06:16:28  yachin
// Bug fix
// Revision 1.22  1997/01/27 09:44:18  yachin
// Enter foreign threads
// Revision 1.21  1997/01/26 13:50:03  yachin
// ReWrite for Foreign Threads
// Revision 1.20  1997/01/21 11:02:29  yachin
// changed _int32 to int
// Revision 1.19  1997/01/19 07:39:05  yachin
// Rewrite of aomSchedDisp statechart
// Revision 1.18  1996/12/30 09:55:26  yachin
// Multi Thread support part III
// Revision 1.17  1996/12/26 13:48:43  yachin
// Revision 1.16  1996/12/25 13:42:48  yachin
// removed #ifdef from defintion of OMThread
// Revision 1.15  1996/11/24 12:55:29  yachin
// Revision 1.14  1996/11/12 09:31:29  yachin
// Change semantics of go event
// Revision 1.13  1996/11/11 11:46:59  yachin
// Support multi-thread part I
// Revision 1.12  1996/11/07 07:49:07  yachin
// fix step not idle bug
// Revision 1.11  1996/10/09 07:34:02  yachin
// Revision 1.10  1996/09/24 12:20:10  yachin
// Fixes For single threaded AOM
// Revision 1.9  1996/09/24 07:11:41  yachin
// Single threaded AOM
// Revision 1.8  1996/09/18 12:57:54  yachin
// Let idle/event notify end of construction
// Revision 1.7  1996/09/03 06:56:36  ofer
// Guard againt uninitialized event queue
// Revision 1.6  1996/08/28 05:35:32  ofer
// Revision 1.5  1996/08/12 12:34:41  yachin
// Seperated show from trace (possibly has bug if existence is canceled and then turned on).
// Revision 1.4  1996/08/08 08:22:19  yachin
// Prototype 4 major revision
// Revision 1.3  1996/08/06 12:49:55  yachin
// Tracer for Prototype 4
// Revision 1.2  1996/07/10 05:48:51  yachin
// Revision 1.1  1996/07/10 05:47:54  yachin
// Initial revision
//
