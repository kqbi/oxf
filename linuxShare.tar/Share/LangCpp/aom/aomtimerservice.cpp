#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: aomtimerservice.cpp 1.6 2007/06/19 08:04:59 ilelpa Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/aom/rcs/aomtimerservice.cpp $
//	file version:	$Revision: 1.6 $
//
//	purpose:
//
//	author(s):
//	date started:
//	date changed:	$Date: 2007/06/19 08:04:59 $
//	last change by:	$Author: ilelpa $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 2003, 2008. All Rights Reserved.
//

#include "aomtimerservice.h"
#include <oxf/IOxfAnimTimerManager.h>
#include <oxf/IOxfTimeout.h>
#include <omcom/AnimTimeNotification.h>

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = aomtimerservice_H;
#endif

// singleton instance
AOMTimerService* AOMTimerService::_instance = NULL;

// private constructor implementation
AOMTimerService::AOMTimerService()
{
}

// singletone implementation
AOMTimerService* AOMTimerService::instance()
{
	if (_instance == NULL)
	{
		_instance = new AOMTimerService();
	}
	return _instance;
	
}

// request to be notified after deltaT
void AOMTimerService::requestTimeNotification(const OxfTimeUnit deltaT)
{

	IOxfAnimTimerManager* tmManager = AnimServices::getTimerManager();

	if (tmManager != NULL)
	{
		OxfTimeUnit baseTime;
		IOxfTimeout* timeout = NULL;

		tmManager->requestTimeNotification(this, deltaT, timeout, baseTime);

		if (timeout != NULL)
		{
			timeout2Basetime.add(timeout, baseTime);
		}

	}
}

// overrides the OMReacitve send - simply notifies that the time has passed
bool AOMTimerService::send(IOxfEvent* ev, const IOxfEventGenerationParams& /* params */)
{
	IOxfTimeout* tm = (IOxfTimeout*)(ev);
	notifyTimeElapsed(tm);
	return true;
}

// overrides the OMReacitve send - simply notifies that the time has passed
bool AOMTimerService::send(IOxfEvent* ev)
{
	IOxfTimeout* tm = (IOxfTimeout*)(ev);
	notifyTimeElapsed(tm);
	return true;
}

// service operation to notify Rhapsody that the time has elapsed
void AOMTimerService::notifyTimeElapsed(IOxfTimeout* timeout)
{
	if (timeout != NULL)
	{
		OxfTimeUnit elapsedTime = 0;
		OxfTimeUnit baseTime = 0;
		OxfTimeUnit actualDiff = 0;
		IOxfAnimTimerManager* sysTimer = AnimServices::getTimerManager();
		if (sysTimer != NULL)
		{
			elapsedTime = sysTimer->getElapsedTime();
			baseTime = timeout2Basetime[timeout];
			actualDiff = elapsedTime - baseTime;

		}
		timeout2Basetime.remove(timeout);
		OxfTimeUnit delay = timeout->getDelayTime();
		AnimTimeNotification* tmNotify = new AnimTimeNotification();
		tmNotify->setTimeInterval((int)delay);
		tmNotify->setActualTimeInterval((int)actualDiff);
		tmNotify->setElapsedTime((int)elapsedTime);
		AOMSchedDispatcher::instance()->encodeAndSendMessage(tmNotify);
	}
}


//
// $Log: aomtimerservice.cpp $
// Revision 1.6  2007/06/19 08:04:59  ilelpa
// Fixed the include files
// Revision 1.5  2007/06/17 07:40:21  ilelpa
// Decoupling OXF-AOM
// Revision 1.4  2007/06/12 08:24:17  ilelpa
// Fixed AOM-OXF Decoupling - using only the interface IOxfReactive
// Revision 1.3  2007/06/11 14:43:29  ilelpa
// Fixed warning PPCDiab
// Revision 1.2  2007/06/10 07:48:43  ilelpa
// Fixed timer service for OSC
// Revision 1.1  2007/05/29 11:57:02  ilelpa
// Initial revision
//
