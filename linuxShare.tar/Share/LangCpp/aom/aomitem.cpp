#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: aomitem.cpp 1.32 2007/03/11 11:57:52 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/aom/rcs/aomitem.cpp $
//	file version:	$Revision: 1.32 $
//
//	purpose: Methods of Class AOMAnimationItem	 	
//
//	author(s):		Yachin Pnueli
//	date started:	30.5.96
//	date changed:	$Date: 2007/03/11 11:57:52 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "aomitem.h"
#include <omcom/omsdata.h>
#include "aomdisp.h"
#include "aomstep.h"
#include "aombrk.h"
#include "aomthrd.h"

#include <omcom/RiCppAnimMessages.h>
#include <omcom/AnimNewInterestMask.h>
#include <omcom/AnimPointerField.h>
#include <omcom/AnimIntField.h>
#include <omcom/AnimSendYourself.h>


#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = aomitem_H;
#endif

short AOMAnimationItem::MagicCookie = 0x3299;


AOMAnimationItem::~AOMAnimationItem()
{ 
	myCookie = 0;
	myProxy = OMInDestruction; // mark item as deleted
}
AOMAnimationItem::AOMAnimationItem()
{
	myCookie = AOMAnimationItem::MagicCookie;
	setProxy(0,OMNoInterest); // Could we shortCut to OMInConstruction ??
}

bool AOMAnimationItem::aomIsValid() const
{
	return myProxy!=OMInDestruction && (AOMAnimationItem::MagicCookie == myCookie);
}

void AOMAnimationItem::waitForProxy() {
	//don't wait for proxy when we are in no anim mode
	if(AOMSchedDispatcher::instance()->getWithNoAnim())
		return;
	/*
	// Wait for the proxy creation.
	// i.e. Stop this thread until my proxy is actually created
	AOMStepper* s = OMGetCurrentStepper();
	if (s) {
		while (!myProxy) {
			s->stopMyself(stoppedMyself);
		}
	}
	*/
	if (!myProxy)
		setProxyInConstruction();
}

void AOMAnimationItem::unexpectedCommand(OMNotify msgCode) {
	OMString msg = "Error AOMAnimationItem Received unexpected command ";
	msg += (char*)omnotify2String(msgCode);
	sendError(msg.GetBuffer(0));
}

void AOMAnimationItem::handleMessage(AnimMessage *msg)
{
	OMNotify code = (OMNotify)(msg->getCode());
	switch (code) 
	{
		case proxyCreated:
		{
			AnimProxyCreated *pC = (AnimProxyCreated *)msg;
			void *theProxy = pC->getProxy()->getValue();
			rhp_long64_t theMask = (rhp_long64_t)(pC->getInterestMask()->getValue());
			// Set proxy appropriately
			setProxy(theProxy,(unsigned int)theMask);
			break;
		}
		case newInterestMask:
		{
			AnimNewInterestMask *iM = (AnimNewInterestMask *)msg;
			// Get new intereset mask
			rhp_long64_t theMask = (rhp_long64_t)(iM->getInterestMask()->getValue());
			// Set interestMask appropriately
			setInterestMask((unsigned int)theMask);
			break;
		}
		case sendYourself:
		{
			AnimSendYourself *pC = (AnimSendYourself *)msg;
			AnimIntField* intField = pC->getInterestMask();
			if (intField) {
				rhp_long64_t whatToSend = (rhp_long64_t)intField->getValue();
				sendMyself((int)whatToSend);
			}
			break;			
		}
		default:
			unexpectedCommand(code);
			
	}
}

void AOMAnimationItem::handleMessage(OMNotify msgCode,
							 OMSData* s, 
							 OMSPosition& p) {
	// Perform the operation appropriate to this message code
	switch (msgCode) {
		// messages that just inform
	case proxyCreated: 
	{
		// Get pointer to proxy and new intereset mask
		void * theProxy = s->getPointer(p);
		rhp_long64_t theMask = (rhp_long64_t)s->getPointer(p);
		// Set proxy appropriately
		setProxy(theProxy,(unsigned int)theMask);
		break;
	}
	case newInterestMask:
	{
		// Get new intereset mask
		rhp_long64_t theMask = (rhp_long64_t)s->getPointer(p);
		// Set interestMask appropriately
		setInterestMask((unsigned int)theMask);
		break;
	}
	case sendYourself:
	{
		int whatToSend = (int)s->getInt(p);
		sendMyself(whatToSend);
		break;			
	}
	default: unexpectedCommand(msgCode);
	}
}

void AOMAnimationItem::notifyGotControl() const {
	AOMBreakPointManager::instance()->
		checkBreakPoint(becameActivated,this);
}
void AOMAnimationItem::notifyLostControl() const {
	AOMBreakPointManager::instance()->
		checkBreakPoint(becameDeactivated,this);
}

/*
bool aomIsValidItem(const void * const i) {
	OMTRY {
		// Check:	1. That we can "cast"
		//			2. That the virtual table is valid
		//			3. That the object is not marked deleted
		if (isCodeItem(i))
			return false;
		return ((AOMAnimationItem *)i)->aomIsValid();
	} OMCATCH_ALL { return false; }
}
*/

//
// $Log: aomitem.cpp $
// Revision 1.32  2007/03/11 11:57:52  ilgiga
// Change copyright comment
// Revision 1.31  2007/03/01 16:31:24  ilgiga
// Telelogic instead of i-Logix
// Revision 1.30  2005/08/23 14:56:27  amos
// bugfix 85444 to main branch
// Revision 1.29.1.2  2005/08/22 10:06:53  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.29  2005/04/21 10:03:23  amos
// Revision 1.28.1.2  2005/03/16 14:02:33  amos
// Revision 1.28  2001/12/30 16:09:29  amos
// AOMAnimationItem::handleMessage(AnimMessage*) - add missing case to handle sendYourself message,
// Revision 1.27  2001/04/17 15:21:18  Eldad
// Using new translation mechanism.
// Revision 1.26.1.2  2001/04/09 15:03:52  Eldad
// Refactoring of AnimMessages.
// Revision 1.26  2001/04/02 07:20:19  Eldad
// Handling AnimMessage (proxyCreated)
// Revision 1.25  2000/07/11 09:23:50  amos
// fix compilation warnings under solaris
// Revision 1.24  2000/01/20 07:08:22  yachin
// Fix spelling mistake
// Revision 1.23  1999/02/18 11:50:59  yachin
// Fix bug 29466
// Revision 1.22  1999/02/16 06:08:02  yachin
// Speed up of construction during animation
// Revision 1.21  1998/08/02 15:02:04  beery
// changing boolean->bool
// Revision 1.20  1998/06/29 12:24:43  ofer
// bugfix 4805 the problem was that the sender send the event and
//  then  kill itself and the notification relate to the sender,
// so we put magic cookie and aomIsValid use that cookie
// to check wether the proxy item is valid or not (aomitem.cpp/h)
// Revision 1.19  1998/06/23 12:33:43  yachin
// Fix borland bugs
// Revision 1.18  1997/11/19 08:43:06  yachin
// Fixed 'inline' problems for Borland compiler
// Revision 1.17  1997/07/20 11:41:05  yachin
// Adding globals to animation
// Revision 1.16  1997/04/07 23:02:04  ofer
// Move file names and includes to lowercase
// so UNIX will work with lowercase versions
// Revision 1.15  1997/02/03 06:31:29  yachin
// Revision 1.14  1997/01/26 13:49:54  yachin
// ReWrite for Foreign Threads
// Revision 1.13  1997/01/21 11:02:27  yachin
// changed _int32 to int
// Revision 1.12  1997/01/21 09:20:24  yachin
// removed AOMStatic
// Revision 1.11  1996/12/29 06:24:34  yachin
// Modified error message
// Revision 1.10  1996/11/24 12:55:25  yachin
// Revision 1.9  1996/11/11 11:46:51  yachin
// Support multi-thread part I
// Revision 1.8  1996/11/10 07:50:59  yachin
// fixed gotControl breakpoint + breakPoint to dead objects
// Revision 1.7  1996/10/09 07:33:58  yachin
// Revision 1.6  1996/08/28 05:35:32  ofer
// Revision 1.5  1996/08/15 08:40:47  yachin
// Revision 1.4  1996/07/18 10:48:54  yachin
// Post Prototype 3 rewrite: virtual destructors, remarks, type changes and safe programing on deleted items
// Revision 1.3  1996/07/10 05:46:58  yachin
// Reorganization + some stuff for OMANIMATOR
// Revision 1.2  1996/06/19 10:18:49  yachin
// Revision 1.1  1996/06/17 05:33:17  yachin
// Initial revision
//
