#ifndef aom_H
#define aom_H "$Id: aom.h 1.17 2007/03/11 11:57:49 ilgiga Exp $"

//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/aom/rcs/aom.h $
//	file version:	$Revision: 1.17 $
//
//	purpose:	AOM All include files
//
//	author(s):	  Yachin Pnueli
//	date started:	9.6.96
//	date changed:	$Date: 2007/03/11 11:57:49 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "aoxf.h"
#include <omcom/omcom.h>


#include "aombrk.h"
#include "aomcalls.h"
#include "aomclass.h"
#include "aomdisp.h"
#include "aomee.h"
#include "aomeque.h"
#include "aomevent.h"
#include "aominst.h"
#include "aomitem.h"
#include "aommacro.h"
#include "aommsg.h"
#include "aompack.h"
#include "aomstep.h"
#include "aomthrd.h"
#include "TargetMonitor.h"

//
// $Log: aom.h $
// Revision 1.17  2007/03/11 11:57:49  ilgiga
// Change copyright comment
// Revision 1.16  2007/03/01 16:31:21  ilgiga
// Telelogic instead of i-Logix
// Revision 1.15  1997/07/20 11:40:58  yachin
// Adding globals to animation
// Revision 1.14  1997/04/07 23:02:12  ofer
// Move file names and includes to lowercase
// so UNIX will work with lowercase versions
// Revision 1.13  1997/01/27 09:44:16  yachin
// Enter foreign threads
// Revision 1.12  1997/01/26 13:49:51  yachin
// ReWrite for Foreign Threads
// Revision 1.11  1997/01/21 11:46:18  yachin
// instrumentation macros moved to aommacro.h
// Revision 1.10  1996/11/24 12:55:17  yachin
// Revision 1.9  1996/10/21 11:38:22  yachin
// Cleanup on state notifies + fixes on timeouts + support for breakpoints
// Revision 1.8  1996/08/28 05:35:22  ofer
// Revision 1.7  1996/08/08 08:22:11  yachin
// Prototype 4 major revision
// Revision 1.6  1996/07/10 09:12:07  yachin
// Revision 1.5  1996/07/10 05:46:56  yachin
// Reorganization + some stuff for OMANIMATOR
// Revision 1.4  1996/06/24 12:25:32  yachin
// Revision 1.3  1996/06/24 11:15:18  yachin
// OMANIMATOR version should work
// Revision 1.2  1996/06/19 10:18:43  yachin
// Revision 1.1  1996/06/17 05:33:05  yachin
// Initial revision
//

#endif
