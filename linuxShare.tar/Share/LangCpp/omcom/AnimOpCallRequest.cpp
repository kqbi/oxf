/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimOpCallRequest
	File Path	: ../AnimOpCallRequest.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimOpCallRequest.h"
//## classInstance doImmediately
#include "AnimBooleanField.h"
//## auto_generated
#include "AnimField.h"
//## classInstance requestID
#include "AnimIntField.h"
//## classInstance argValues
#include "AnimListField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## classInstance signature
#include "AnimStringField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimOpCallRequest
AnimOpCallRequest AnimOpCallRequest::callRequestPrototype;

AnimOpCallRequest::AnimOpCallRequest() {
    //#[ operation AnimOpCallRequest()
    initRelations();
    code = callOpRequest;
    
    // set the names
    op->setName("AOMOperation");
    instance->setName("Instance");
    signature->setName("Operation Signature"); 
    opClass->setName("Operation AOMClass");
    
    // set list prototype
    AnimStringOrPointerField msgField;
    argValues->setFieldPrototype(&msgField);
    
    // add fields to container   
    addField(requestID);
    addField(op); 
    addField(instance);
    addField(showInConsole);
    addField(doImmediately);
    addField(argValues); 
    addField(signature); 
    addField(opClass);
    
    // set default values
    setShowInConsole(true);
    setDoImmediately(false);
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimOpCallRequest::~AnimOpCallRequest() {
    cleanUpRelations();
}

void AnimOpCallRequest::addArgValue(gen_ptr value) {
    //#[ operation addArgValue(gen_ptr)
    AnimStringOrPointerField *f = new AnimStringOrPointerField();   
    *f = value;  
    argValues->addField(f);
    
    
    //#]
}

void AnimOpCallRequest::addArgValue(OMString value) {
    //#[ operation addArgValue(OMString)
    AnimStringOrPointerField *f = new AnimStringOrPointerField();   
    *f = value;  
    argValues->addField(f);
    
    
    //#]
}

AnimMessage* AnimOpCallRequest::clone() {
    //#[ operation clone()
    AnimOpCallRequest *msg = new AnimOpCallRequest();   
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));   
    
    // operation
    msg->setOp(op->getValue());
    
    // instance
    msg->setInstance(instance->getValue());
    
    // request id
    rhp_long64_t id = (rhp_long64_t)(getRequestID()->getValue());
    msg->setRequestID((int)id);
    
    // show in console
    bool showInConsoleValue = showInConsole->getValue() ? true : false;
    msg->setShowInConsole(showInConsoleValue);
    
    // do immediately
    bool doImmediatelyValue = doImmediately->getValue() ? true : false;
    msg->setDoImmediately(doImmediatelyValue);
        
    // arg values
    // msg->argValues = (AnimListField *)(argValues->clone());
    
    return msg;
    //#]
}

AnimOpCallRequest* AnimOpCallRequest::fullClone() {
    //#[ operation fullClone()
    AnimOpCallRequest *msg = (AnimOpCallRequest *)clone();   
    
    msg->deleteArgValues();
    msg->argValues = (AnimListField *)(argValues->clone()); 
    
    return msg;
    //#]
}

void AnimOpCallRequest::setClass(gen_ptr value) {
    //#[ operation setClass(gen_ptr)
    *opClass = value;
    //#]
}

void AnimOpCallRequest::setDoImmediately(bool value) {
    //#[ operation setDoImmediately(bool)
    *doImmediately = value;
    //#]
}

void AnimOpCallRequest::setInstance(gen_ptr value) {
    //#[ operation setInstance(gen_ptr)
    *instance = value;
    //#]
}

void AnimOpCallRequest::setOp(gen_ptr value) {
    //#[ operation setOp(gen_ptr)
    *op = value;
    //#]
}

void AnimOpCallRequest::setRequestID(int id) {
    //#[ operation setRequestID(int)
    *requestID = id;
    //#]
}

void AnimOpCallRequest::setShowInConsole(bool value) {
    //#[ operation setShowInConsole(bool)
    *showInConsole = value;
    //#]
}

void AnimOpCallRequest::setSignature(OMString value) {
    //#[ operation setSignature(OMString)
    *signature = value;
    //#]
}

void AnimOpCallRequest::cleanUpRelations() {
    //#[ operation cleanUpRelations()
    {
        deleteShowInConsole();
    }
    {
        deleteRequestID();
    }
    {
        deleteOp();
    }
    {
        deleteInstance();
    }
    {
        deleteDoImmediately();
    }
    {
        deleteArgValues();
    }     
    {
        deleteSignature();
    }   
    {
    	deleteOpClass();
    }	
    //#]
}

void AnimOpCallRequest::initRelations() {
    //#[ operation initRelations()
    argValues = newArgValues();
    doImmediately = newDoImmediately();
    instance = newInstance();
    op = newOp();
    requestID = newRequestID();
    showInConsole = newShowInConsole();  
    signature = newSignature(); 
    opClass = newOpClass();
    //#]
}

void AnimOpCallRequest::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimListField* AnimOpCallRequest::getArgValues() const {
    return argValues;
}

AnimListField* AnimOpCallRequest::newArgValues() {
    argValues = new AnimListField;
    return argValues;
}

void AnimOpCallRequest::deleteArgValues() {
    delete argValues;
    argValues = NULL;
}

AnimBooleanField* AnimOpCallRequest::getDoImmediately() const {
    return doImmediately;
}

AnimBooleanField* AnimOpCallRequest::newDoImmediately() {
    doImmediately = new AnimBooleanField;
    return doImmediately;
}

void AnimOpCallRequest::deleteDoImmediately() {
    delete doImmediately;
    doImmediately = NULL;
}

AnimPointerField* AnimOpCallRequest::getInstance() const {
    return instance;
}

AnimPointerField* AnimOpCallRequest::newInstance() {
    instance = new AnimPointerField;
    return instance;
}

void AnimOpCallRequest::deleteInstance() {
    delete instance;
    instance = NULL;
}

AnimPointerField* AnimOpCallRequest::getOp() const {
    return op;
}

AnimPointerField* AnimOpCallRequest::newOp() {
    op = new AnimPointerField;
    return op;
}

void AnimOpCallRequest::deleteOp() {
    delete op;
    op = NULL;
}

AnimPointerField* AnimOpCallRequest::getOpClass() const {
    return opClass;
}

AnimPointerField* AnimOpCallRequest::newOpClass() {
    opClass = new AnimPointerField;
    return opClass;
}

void AnimOpCallRequest::deleteOpClass() {
    delete opClass;
    opClass = NULL;
}

AnimIntField* AnimOpCallRequest::getRequestID() const {
    return requestID;
}

AnimIntField* AnimOpCallRequest::newRequestID() {
    requestID = new AnimIntField;
    return requestID;
}

void AnimOpCallRequest::deleteRequestID() {
    delete requestID;
    requestID = NULL;
}

AnimBooleanField* AnimOpCallRequest::getShowInConsole() const {
    return showInConsole;
}

AnimBooleanField* AnimOpCallRequest::newShowInConsole() {
    showInConsole = new AnimBooleanField;
    return showInConsole;
}

void AnimOpCallRequest::deleteShowInConsole() {
    delete showInConsole;
    showInConsole = NULL;
}

AnimStringField* AnimOpCallRequest::getSignature() const {
    return signature;
}

AnimStringField* AnimOpCallRequest::newSignature() {
    signature = new AnimStringField;
    return signature;
}

void AnimOpCallRequest::deleteSignature() {
    delete signature;
    signature = NULL;
}

/*********************************************************************
	File Path	: ../AnimOpCallRequest.cpp
*********************************************************************/
