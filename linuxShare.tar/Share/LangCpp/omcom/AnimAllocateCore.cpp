/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimAllocateCore
	File Path	: ../AnimAllocateCore.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimAllocateCore.h"
//## auto_generated
#include "AnimField.h"
//## operation getAffinity() const
#include "AnimIntField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimAllocateCore
AnimAllocateCore AnimAllocateCore::msgPrototype;

AnimAllocateCore::AnimAllocateCore() {
    initRelations();
    //#[ operation AnimAllocateCore()
    code = allocateCore;
    
    // set the names      
    affinity->setName("Affinity");
    powerMode->setName("PowerMode");
    
    // add fields to container  
    addField(affinity);
    addField(powerMode);
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimAllocateCore::~AnimAllocateCore() {
    cleanUpRelations();
}

AnimMessage* AnimAllocateCore::clone() {
    //#[ operation clone()
    AnimAllocateCore *msg = new AnimAllocateCore();   
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));   
    
    // call str
    rhp_long64_t aff = (rhp_long64_t)(getAffinity()->getValue());
    msg->setAffinity((int)aff);         
    rhp_long64_t pwr = (rhp_long64_t)(getPowerMode()->getValue());
    msg->setAffinity((int)pwr);
    
    return msg;
    //#]
}

AnimIntField* AnimAllocateCore::getAffinity() const {
    //#[ operation getAffinity() const
    return affinity;
    //#]
}

AnimIntField* AnimAllocateCore::getPowerMode() const {
    //#[ operation getPowerMode() const
    return powerMode;
    //#]
}

bool AnimAllocateCore::isConstructionMessage() {
    //#[ operation isConstructionMessage()
    return true;
    //#]
}

AnimIntField* AnimAllocateCore::newAffinity() {
    //#[ operation newAffinity()
    affinity = new AnimIntField;
    return affinity;
    //#]
}

AnimIntField* AnimAllocateCore::newPowerMode() {
    //#[ operation newPowerMode()
    powerMode = new AnimIntField;
    return powerMode;
    //#]
}

void AnimAllocateCore::setAffinity(int value) {
    //#[ operation setAffinity(int)
    *affinity = value;
    //#]
}

void AnimAllocateCore::setPowerMode(int value) {
    //#[ operation setPowerMode(int)
    *powerMode = value;
    //#]
}

void AnimAllocateCore::cleanUpRelations() {
    //#[ operation cleanUpRelations()
    {
        deletePowerMode();
    }
    {
        deleteAffinity();
    }
    
    //#]
}

void AnimAllocateCore::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE || &msgPrototype == this)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

void AnimAllocateCore::deleteAffinity() {
    delete affinity;
    affinity = NULL;
}

void AnimAllocateCore::deletePowerMode() {
    delete powerMode;
    powerMode = NULL;
}

void AnimAllocateCore::initRelations() {
    affinity = newAffinity();
    powerMode = newPowerMode();
}

/*********************************************************************
	File Path	: ../AnimAllocateCore.cpp
*********************************************************************/
