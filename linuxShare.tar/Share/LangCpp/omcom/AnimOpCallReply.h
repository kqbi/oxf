/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimOpCallReply
	File Path	: ../AnimOpCallReply.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimOpCallReply_H
#define AnimOpCallReply_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimOpCallReply
#include "AnimAbstractMessage.h"
//## dependency AnimStringOrPointerField
#include "AnimStringOrPointerField.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## classInstance exceptionRaised
class AnimBooleanField;

//## auto_generated
class AnimField;

//## classInstance requestID
class AnimIntField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## classInstance callStr
class AnimStringField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimOpCallReply
// A reply to an operation call request (AnimOpCallRequest).
class AnimOpCallReply : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimOpCallReply()
    AnimOpCallReply();
    
    //## auto_generated
    virtual ~AnimOpCallReply();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    // Set the class name.
    //## operation setCallStr(OMString)
    void setCallStr(OMString value);
    
    //## operation setExceptionRaised(OMBoolean)
    void setExceptionRaised(OMBoolean value);
    
    //## operation setRequestID(int)
    void setRequestID(int id);
    
    //## operation setReturnValue(const AnimStringOrPointerField&)
    void setReturnValue(const AnimStringOrPointerField& value);
    
    //## operation setShowInConsole(bool)
    void setShowInConsole(bool value);

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimStringField* getCallStr() const;
    
    //## auto_generated
    AnimStringField* newCallStr();
    
    //## auto_generated
    void deleteCallStr();
    
    //## auto_generated
    AnimBooleanField* getExceptionRaised() const;
    
    //## auto_generated
    AnimBooleanField* newExceptionRaised();
    
    //## auto_generated
    void deleteExceptionRaised();
    
    //## auto_generated
    AnimIntField* getRequestID() const;
    
    //## auto_generated
    AnimIntField* newRequestID();
    
    //## auto_generated
    void deleteRequestID();
    
    //## auto_generated
    AnimStringOrPointerField* getRetValue() const;
    
    //## auto_generated
    AnimStringOrPointerField* newRetValue();
    
    //## auto_generated
    void deleteRetValue();
    
    //## auto_generated
    AnimBooleanField* getShowInConsole() const;
    
    //## auto_generated
    AnimBooleanField* newShowInConsole();
    
    //## auto_generated
    void deleteShowInConsole();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimOpCallReply callReplyPrototype;		//## attribute callReplyPrototype
    
    ////    Relations and components    ////

protected :

    // A convinience string that holds the call string.
    AnimStringField* callStr;		//## classInstance callStr
    
    // Indicates if an exception was raised.
    AnimBooleanField* exceptionRaised;		//## classInstance exceptionRaised
    
    AnimIntField* requestID;		//## classInstance requestID
    
    // The return value.
    AnimStringOrPointerField* retValue;		//## classInstance retValue
    
    AnimBooleanField* showInConsole;		//## classInstance showInConsole
};

#endif
/*********************************************************************
	File Path	: ../AnimOpCallReply.h
*********************************************************************/
