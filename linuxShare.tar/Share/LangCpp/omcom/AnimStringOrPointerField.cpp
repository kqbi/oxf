/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimStringOrPointerField
	File Path	: ../AnimStringOrPointerField.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimStringOrPointerField.h"
//## operation clone()
#include "AnimField.h"
//## operation decode(AnimMessageTranslator*)
#include "AnimMessageTranslator.h"
//## package RiCppAnimMessageTranslator

//## class AnimStringOrPointerField
AnimStringOrPointerField::AnimStringOrPointerField() : isPointerFlag(FALSE), isStringFlag(FALSE) {
}

AnimStringOrPointerField::~AnimStringOrPointerField() {
}

AnimField* AnimStringOrPointerField::clone() {
    //#[ operation clone()
    AnimStringOrPointerField *f = new AnimStringOrPointerField();
    f->name = name;
    f->pointerValue = pointerValue;
    f->stringValue = stringValue;
    f->isPointerFlag = isPointerFlag;
    f->isStringFlag = isStringFlag;
    return f;
    //#]
}

void AnimStringOrPointerField::decode(AnimMessageTranslator* translator) {
    //#[ operation decode(AnimMessageTranslator*)
    translator->decodeField(this);
    //#]
}

void AnimStringOrPointerField::encode(AnimMessageTranslator* translator) {
    //#[ operation encode(AnimMessageTranslator*)
    translator->encodeField(this);
    
    //#]
}

gen_ptr AnimStringOrPointerField::getPointerValue() const {
    //#[ operation getPointerValue() const
    return pointerValue;
    //#]
}

void * AnimStringOrPointerField::getStringValue(OMBoolean cloneStr) const {
    //#[ operation getStringValue(OMBoolean) const
    char *s = NULL;
    if (!cloneStr)
    {
      // casting is requires to avoid 
      // compilation error.
      s = ((OMString)stringValue).GetBuffer(0);
    }
    else 
    {    
      OMString cpy = stringValue;
      int len = cpy.GetLength();
      s = new char[len+1];
      strcpy(s, cpy.GetBuffer(0));
    }
    return (void *)(s);
    
    //#]
}

gen_ptr AnimStringOrPointerField::getValue() const {
    //#[ operation getValue() const
    return getValue(TRUE);
    
    //#]
}

gen_ptr AnimStringOrPointerField::getValue(OMBoolean cloneStr) const {
    //#[ operation getValue(OMBoolean) const
    gen_ptr res = NULL;
    if (isPointerFlag) {
      res = (gen_ptr)getPointerValue();
    }
    else if (isStringFlag) {
      res = (gen_ptr)(rhp_long64_t)getStringValue(cloneStr);
    }
    return res;
    
    //#]
}

OMBoolean AnimStringOrPointerField::isPointer() const {
    //#[ operation isPointer() const
    return isPointerFlag;
    //#]
}

OMBoolean AnimStringOrPointerField::isString() const {
    //#[ operation isString() const
    return isStringFlag;
    //#]
}

AnimStringOrPointerField& AnimStringOrPointerField::operator=(const AnimStringOrPointerField& field) {
    //#[ operation operator=(const AnimStringOrPointerField&)
    if (this != &field)   
    {         
        setName(field.getName());
        if (field.isString()) {
        	char *s = (char *)(field.getStringValue());
        	setStringValue((gen_ptr)(rhp_long64_t)s);
        	delete[] s;
        }
        else if (field.isPointer())
        	setPointerValue(field.getPointerValue());
    }
    return *this;
    //#]
}

AnimStringOrPointerField& AnimStringOrPointerField::operator=(OMString val) {
    //#[ operation operator=(OMString)
    const char * tmp = (const char *)val;
    setStringValue((gen_ptr)(rhp_long64_t)tmp);
    return *this;
    //#]
}

AnimStringOrPointerField& AnimStringOrPointerField::operator=(gen_ptr pointerVal) {
    //#[ operation operator=(gen_ptr)
    setPointerValue(pointerVal);
    return *this;
    //#]
}

void AnimStringOrPointerField::setAsPointer() {
    //#[ operation setAsPointer()
    isStringFlag = FALSE;
    isPointerFlag = TRUE; 
    stringValue = "";
    //#]
}

void AnimStringOrPointerField::setAsString() {
    //#[ operation setAsString()
    isStringFlag = TRUE;
    isPointerFlag = FALSE;     
    pointerValue = NULL;
    //#]
}

void AnimStringOrPointerField::setPointerValue(gen_ptr p_value) {
    //#[ operation setPointerValue(gen_ptr)
    setAsPointer();
    pointerValue = p_value;
    
    //#]
}

void AnimStringOrPointerField::setStringValue(gen_ptr p_value) {
    //#[ operation setStringValue(gen_ptr)
    setAsString();
    char * tmp = (char *)(rhp_long64_t)p_value;
    stringValue = (OMString)tmp;
    
    
    //#]
}

void AnimStringOrPointerField::setValue(gen_ptr p_value) {
    //#[ operation setValue(gen_ptr)
    if (isPointerFlag)
      setPointerValue(p_value);
    else if (isStringFlag)
      setStringValue(p_value);
    
    //#]
}

/*********************************************************************
	File Path	: ../AnimStringOrPointerField.cpp
*********************************************************************/
