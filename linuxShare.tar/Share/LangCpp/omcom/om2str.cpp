#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: om2str.cpp 1.31 2007/06/07 07:03:38 ilvler Exp $"
;
#endif
//
//      file name   :   $Source: R:/StmOO/Master/cg/LangCpp/omcom/rcs/om2str.cpp $
//      file version:   $Revision: 1.31 $
//
//      purpose: 
//
//      author(s):              Yachin Pnueli
//      date started:   22.5.96
//      date changed:   $Date: 2007/06/07 07:03:38 $
//      last change by: $Author: ilvler $
//
//      Licensed Materials - Property of IBM
//      (c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//


#include <oxf/rawtypes.h>
#include "om2str.h"
#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = om2str_H;
#endif



#ifdef NO_IOSTREAM_FOR_X2STRING_IMPLEMENTATION

#ifdef _OM_UNICODE_ONLY
#include <oxf/omunicode.h>
#endif // _OM_UNICODE_ONLY

char* x2String(const unsigned char f)
{
  char* cS = new char[30];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[30];
  swprintf(wS, L"%o", f);
  OMwtoc(cS, wS, 30);
#else
  sprintf(cS, "%o", f);
#endif 
  return(cS);
}


char* x2String(const char f)
{
  char* cS = new char[2];
  cS[0] = f;
  cS[1] = '\0';
  return(cS);
}

char* x2String(const bool f)
{
  char* cS = new char[6];
  char *res;
  if (f)
	  res = (char*)"true";
  else
	  res = (char*)"false";
  memcpy(cS, res, strlen(res)+1);
  return(cS);
}


char* x2String(const int f)
{
  char* cS = new char[30];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[30];
  swprintf(wS, L"%d", f);
  OMwtoc(cS, wS, 30);
#else
  sprintf(cS, "%d", f);
#endif 
  return(cS);
}

char* x2String(const unsigned int f)
{
  char* cS = new char[30];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[30];
  swprintf(wS, L"%u", f);
  OMwtoc(cS, wS, 30);
#else
  sprintf(cS, "%u", f);
#endif 
  return(cS);
}

char* x2String(const short f)
{
  char* cS = new char[30];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[30];
  swprintf(wS, L"%hd", f);
  OMwtoc(cS, wS, 30);
#else
  sprintf(cS, "%hd", f);
#endif 
  return(cS);
}

char* x2String(const unsigned short f)
{
  char* cS = new char[30];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[30];
  swprintf(wS, L"%hu", f);
  OMwtoc(cS, wS, 30);
#else
  sprintf(cS, "%hu", f);
#endif 
  return(cS);
}


char* x2String(const long f)
{
  char* cS = new char[30];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[30];
  swprintf(wS, L"%ld", f);
  OMwtoc(cS, wS, 30);
#else
  sprintf(cS, "%ld", f);
#endif 
  return(cS);
}

char* x2String(const unsigned long f)
{
  char* cS = new char[30];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[30];
  swprintf(wS, L"%lu", f);
  OMwtoc(cS, wS, 30);
#else
  sprintf(cS, "%lu", f);
#endif 
  return(cS);
}

#ifndef OM_NO_LONG_LONG_SUPPORT
char* x2String(const long long f)
{
  char* cS = new char[30];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[30];
  swprintf(wS, L"%lld", f);
  OMwtoc(cS, wS, 30);
#else
  sprintf(cS, "%lld", f);
#endif 
  return(cS);
}

char* x2String(const unsigned long long f)
{
  char* cS = new char[30];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[30];
  swprintf(wS, L"%llu", f);
  OMwtoc(cS, wS, 30);
#else
  sprintf(cS, "%llu", f);
#endif 
  return(cS);
}
#endif // OM_NO_LONG_LONG_SUPPORT

char* x2String(const double f)
{
  char* cS = new char[30];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[30];
  swprintf(wS, L"%f", f);
  OMwtoc(cS, wS, 30);
#else
  sprintf(cS, "%f", f);
#endif 
  return(cS);
}

char* x2String(const float f)
{
  char* cS = new char[20];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[20];
  swprintf(wS, L"%f", f);
  OMwtoc(cS, wS, 20);
#else
  sprintf(cS, "%f", f);
#endif 
  return(cS);
}

#ifndef OM_NO_SPECIAL_SERIALIZE_LONG_DOUBLE
char* x2String(const long double f)
{
	// simply use the same as for double
	return x2String((double)f);
}
#endif

char* x2String(const void* f)
{
  char* cS = new char[30];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[30];
  swprintf(wS, L"%p", f);
  OMwtoc(cS, wS, 30);
#else
  sprintf(cS, "%p", f);
#endif 
  return(cS);
}

char* x2String(const void* f,const char*unk)
{
  char* cS = new char[30];
#ifdef _OM_UNICODE_ONLY
  wchar_t wS[30];
  swprintf(wS, L"%p (%s)", f, unk);
  OMwtoc(cS, wS, 30);
#else
  sprintf(cS, "%p (%s)", f, unk);
#endif 
  return(cS);
}


char* x2String(const char* f)
{
  char* cS;

  if (f)
  {
        size_t len = strlen(f);
        cS = new char[len+1];
        memcpy(cS, f, len+1);
  }
  else
  {
        cS = new char[7];
        strcpy(cS, "(NULL)");
  }
  return(cS);
}

char* x2String(const OMString& s)
{
  char* cS = new char[s.GetLength()+1];
  memcpy(cS, s.GetBuffer(0), s.GetLength()+1);
  return(cS);
}


bool string2X(char* c, bool& t)
{
	t = (c[0] == 't');
	return t;
}

bool OMDestructiveString2X(char* c, bool& t)
{
	if (c[0] == 't')
		t = true;
	else
		t = false;
	delete [] c;
	return (t);
}


char OMDestructiveString2X(char* c, char& t)
{
	t = (char)atoi(c);
	delete [] c;
	return (t);
}

char OMDestructiveString2X(char* c, unsigned char& t)
{
	t = (unsigned char)atoi(c);
	delete [] c;
	return (t);
}

int string2X(char* c, int& t)
{
	t = atoi(c);
	return (t);
}

int OMDestructiveString2X(char* c, int& t)
{
	t = atoi(c);
	delete [] c;
	return (t);
}

unsigned int string2X(char* c, unsigned int& t)
{
	t = atoi(c);
	return (t);
}

unsigned int OMDestructiveString2X(char* c, unsigned int& t)
{
	t = atoi(c);
	delete [] c;
	return (t);
}

unsigned short string2X(char* c, unsigned short& t)
{	
	t = (unsigned short)atoi(c);
	return (t);
}

short string2X(char* c, short& t)
{	
	t = (short)atoi(c);
	return (t);
}


short OMDestructiveString2X(char* c, short & t)
{	
	t = (short )atoi(c);
	delete [] c;
	return (t);
}


unsigned short OMDestructiveString2X(char* c, unsigned short & t)
{
	t = (unsigned short )atoi(c);
	delete [] c;
	return (t);
}

long string2X(char* c, long& t)
{
	t = atol(c);
	return (t);
}

long OMDestructiveString2X(char* c, long& t)
{
	t = atol(c);
	delete [] c;
	return (t);
}

unsigned long string2X(char* c, unsigned long& t)
{
	t = atol(c);
	return (t);
}

unsigned long OMDestructiveString2X(char* c, unsigned long& t)
{
	t = atol(c);
	delete [] c;
	return (t);
}

#ifndef OM_NO_LONG_LONG_SUPPORT

long long string2X(char* c, long long& t)
{
	t = atoll(c);
	return (t);
}

long long OMDestructiveString2X(char* c, long long& t)
{
	t = atoll(c);
	delete [] c;
	return (t);
}

unsigned long long string2X(char* c, unsigned long long& t)
{
	t = atoll(c);
	return (t);
}

unsigned long long OMDestructiveString2X(char* c, unsigned long long& t)
{
	t = atoll(c);
	delete [] c;
	return (t);
}
#endif // OM_NO_LONG_LONG_SUPPORT

double string2X(char* c, double& t)
{
	t = atof(c);
	return (t);
}


float string2X(char* c, float& t)
{
	t = (float)atof(c);
	return (t);
}


double OMDestructiveString2X(char* c, double& t)
{
	t = atof(c);
	delete [] c;
	return (t);
}

float OMDestructiveString2X(char* c, float& t)
{
	t = (float)atof(c);
	delete [] c;
	return (t);
}

#ifndef OM_NO_SPECIAL_SERIALIZE_LONG_DOUBLE
long double string2X(char* c, long double& t)
{
	t = (long double)atof(c);
	return (t);
}

long double OMDestructiveString2X(char* c, long double& t)
{
	t = (long double)atof(c);
	delete [] c;
	return (t);
}
#endif

void* OMDestructiveString2X(char* c, void*& t)
{
	t = (void*)atol(c);
	delete [] c;
	return t;
}

#else // !NO_IOSTREAM_FOR_X2STRING_IMPLEMENTATION

// dummy to avoid linker warning
void om2str_dummyOp() {}

#endif // NO_IOSTREAM_FOR_X2STRING_IMPLEMENTATION

// new chriwa
char* out2String(bool b) { return x2String(b); }
char* out2String(bool* b) { return x2String(*b); }
char* out2String(int f) { return x2String(f); }
char* out2String(int* f) { return x2String(*f); }
char* out2String(unsigned int f) { return x2String(f); }
char* out2String(unsigned int* f) { return x2String(*f); }
char* out2String(long f) { return x2String(f); }
char* out2String(long* f) { return x2String(*f); }
char* out2String(unsigned long f) { return x2String(f); }
char* out2String(unsigned long* f) { return x2String(*f); }
char* out2String(double f) { return x2String(f); }
char* out2String(double* f) { return x2String(*f); }
char* out2String(float f) { return x2String(f); }
char* out2String(float* f) { return x2String(*f); }
#ifndef OM_NO_SPECIAL_SERIALIZE_LONG_DOUBLE
char* out2String(long double f) { return x2String(f); }
char* out2String(long double* f) { return x2String(*f); }
#endif
char* out2String(short f) { return x2String(f); }
char* out2String(short* f) { return x2String(*f); }
char* out2String(unsigned short f) { return x2String(f); }
char* out2String(unsigned short* f) { return x2String(*f); }
char* out2String(char f) { return x2String(f); }
char* out2String(char* f) { return x2String(f); }
char* out2String(unsigned char f) { return x2String(f); }
char* out2String(unsigned char* f) { return x2String(*f); }
char* out2String(OMString f) { return x2String(f); }
char* out2String(OMString* f) { return x2String(*f); }
// end new chriwa

char* struct2String(FieldDesc arr[],int numOfStructMembers){
	size_t sizeOfBuf = 0;
  int i = 0;
  char* buf;
	for(i=0;i<numOfStructMembers;++i){
		sizeOfBuf += strlen(arr[i].name);
		sizeOfBuf += strlen(arr[i].value);
		sizeOfBuf += 10;
	}
	buf = new char[sizeOfBuf];
	strcpy(buf,"{ ");
	for(i=0;i<numOfStructMembers;++i){
		strcat(buf,arr[i].name);
		strcat(buf," = ");
		strcat(buf,arr[i].value);
		delete[] arr[i].value;
		strcat(buf," , ");
	}
	buf[strlen(buf)-2] = '}';
	buf[strlen(buf)-1] = '\0';
	return buf;
}

char* parseString2Struct(char* str){
	int pntr=0, dest=1;
	char* copyStr = new char[strlen(str)+2];
    copyStr[0] = '%';
    while (str[pntr] != '\0'){
    	if (str[pntr] == '#'){
    		if(str[pntr-1] == '/')
    			copyStr[--dest] = '#';
    		else
    			copyStr[dest] = '"';
    	}
    	else if(str[pntr] == '^'){
    		if(str[pntr-1] == '/')
    			copyStr[--dest] = '^';
    		else
    			copyStr[dest] = ' ';
    	}
    	else
    		copyStr[dest] = str[pntr];
    	pntr++;
    	dest++;
    }
    copyStr[dest] = '\0';
	return copyStr;
}

//
// $Log: om2str.cpp $
// Revision 1.31  2007/06/07 07:03:38  ilvler
// 104455:WinCE adaptor:Framework compilation warnings
// Revision 1.30  2007/03/28 17:26:41  ilvler
// 102112: float type support in instrumentation
// Revision 1.29  2007/03/22 08:47:11  ilelpa
// Fixed out2str for char* to properly print char* strings
// Revision 1.28  2007/03/04 08:15:36  ilelpa
// Added out2String for bool
// Revision 1.27  2007/03/01 16:43:31  ilgiga
// Telelogic instead of i-Logix
// Revision 1.26  2006/09/25 14:32:48  vova
// Multi Linux warning solved
// Revision 1.25  2005/10/19 07:59:21  eldad
// #define OM_NO_SPECIAL_SERIALIZE_LONG_DOUBLE
// Revision 1.24  2005/10/02 12:42:06  eldad
// long double (for Linux)
// Revision 1.23  2005/08/23 14:55:25  amos
// bugfix 85444 to main branch
// Revision 1.22.1.2  2005/08/22 10:07:08  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.22  2004/07/21 09:37:57  eldad
// Revision 1.21  2004/07/20 13:53:04  eldad
// Fixed the format change of unknown pointers in Linux
// Revision 1.20  2004/03/31 08:35:38  vova
// 70593: crash in Linux (x2String with NULL char*)
// Revision 1.19  2004/03/30 16:04:49  vova
// Crash in Linux fixed
// Revision 1.18  2003/11/11 11:06:37  amos
// Fix compilation warings
// Revision 1.17  2003/10/27 14:57:55  vova
// 61884, 63658 - missing serialize/unserialize functions added for unsigned int,short and char types
// Revision 1.17  2003/10/27 14:50:56  vova
// Solaris 61884 bug
// Revision 1.16  2003/06/10 14:23:38  eldad
// Merge 1.15 + 1.14.1.3
// Revision 1.15  2003/04/07 16:01:58  vova
// x2string and string2x for bool type added.
// x2string of double bug fixed
// Revision 1.14.1.3  2003/06/08 15:08:35  vova
// Removed out2String functions with "long double" argument.
// Revision 1.14.1.2  2003/06/08 12:12:09  eldad
// out2String
// Revision 1.14  2003/01/09 12:21:04  vova
// 61074: OMDestructiveString2X(void*) added for Solaris implementation
// Revision 1.13  2002/11/29 08:42:47  Eldad
// 1.12.1.2 to main branch.
// Revision 1.12.1.2  2002/11/26 09:52:28  Eldad
// Avoid ^z in model by having x2String(unsigned char) that prints the hex number.
// Revision 1.12  2002/07/25 14:46:09  vova
// New x2string function added for void* attributes serialization
// Revision 1.11  2002/07/23 07:14:03  amos
// add dummy method om2str_dummyOp() to avoid linker warnings in .NET
// Revision 1.10  2001/05/16 12:32:33  amos
// merge OSE 4.3.1 support into r40
// Revision 1.9  2001/01/30 09:07:33  avrahams
// Add OM prefix to destructiveString2X
// Revision 1.8  2000/10/11 11:53:14  ofer
// since cadul compiler ( with psos 2.50 for x86 ) has bugs with iostream
// we had to implement x2String much alike we did in Windows CE
// Revision 1.7  2000/10/02 14:28:22  ofer
// include to oxf/rawtypes.h before om2str.h
// so the macro TMPL_INL will be defined
// Revision 1.6  2000/07/11 09:23:50  amos
// the main change related to modify char* to const char*.
// there are some other changes related to assignment of static member function as extern "C" functions.
// Revision 1.5  1999/05/27 14:32:13  ofer
// bugfix 30822 and 30839
// since the x2String is allocating memory we have to implement
// x2String for const char* as well 
// x2Item can work under WindowsCE
// Revision 1.4  1999/05/11 09:59:10  ofer
// Windows CE changes
// no iostream support and unicode ONLY ( no exceptions)
// ATTENTION revision 1.4 is the FIRST revision used with WINCE
// revisions 1.1-1.3 not used a long time ago ( not in r21 tree)
//

