/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimAbstractMessage
	File Path	: ../AnimAbstractMessage.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimAbstractMessage_H
#define AnimAbstractMessage_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## auto_generated
#include <oxf/omcollec.h>
//## class AnimAbstractMessage
#include "AnimMessage.h"
//## operation getOrigSource()
#include <oxf/rawtypes.h>
//## operation getNextField()
class AnimField;

//## operation setNextField(AnimMessageField*)
class AnimMessageField;

//## operation setDestOrSource(const AnimPointerField&)
class AnimPointerField;

//## operation getTimeStamp()
class AnimTimestampField;

//## package RiCppAnimMessageTranslator

//## class AnimAbstractMessage
class AnimAbstractMessage : public AnimMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimAbstractMessage()
    AnimAbstractMessage();
    
    //## operation ~AnimAbstractMessage()
    virtual ~AnimAbstractMessage();
    
    ////    Operations    ////
    
    // return the next field in the message.
    //## operation getNextField()
    virtual AnimField* getNextField();
    
    //## operation getOrigSource()
    virtual gen_ptr getOrigSource();
    
    //## operation getTimeStamp()
    AnimTimestampField* getTimeStamp();
    
    //## operation isConstructionMessage()
    virtual bool isConstructionMessage();
    
    //## operation resetFieldIterator()
    void resetFieldIterator();
    
    //## operation setConstructionMessage(bool)
    virtual void setConstructionMessage(bool bInConstruction);
    
    // Argument gen_ptr _destOrSource :
    // destOrSource value.
    //## operation setDestOrSource(gen_ptr)
    void setDestOrSource(gen_ptr _destOrSource);
    
    // Argument const AnimPointerField& _destOrSource :
    // destOrSource field.
    //## operation setDestOrSource(const AnimPointerField&)
    void setDestOrSource(const AnimPointerField& _destOrSource);
    
    // Set the next field value in the message.
    //## operation setNextField(AnimMessageField*)
    virtual void setNextField(AnimMessageField* _field);
    
    //## operation setOrigSource(gen_ptr)
    virtual void setOrigSource(gen_ptr pOrigSrc);
    
    //## operation setTimeStamp(timeUnit)
    virtual void setTimeStamp(timeUnit _timeStamp);
    
    //## operation setTimeStamp(const AnimTimestampField&)
    virtual void setTimeStamp(const AnimTimestampField& _timeStamp);
    
    ////    Additional operations    ////
    
    //## auto_generated
    bool getBInConstruction() const;
    
    //## auto_generated
    void setBInConstruction(bool p_bInConstruction);
    
    //## auto_generated
    int getCode() const;
    
    //## auto_generated
    void setCode(int p_code);
    
    //## auto_generated
    gen_ptr getPOrigSrc() const;
    
    //## auto_generated
    void setPOrigSrc(gen_ptr p_pOrigSrc);
    
    //## auto_generated
    AnimPointerField* getDestOrSource() const;
    
    //## auto_generated
    AnimPointerField* newDestOrSource();
    
    //## auto_generated
    void deleteDestOrSource();
    
    //## auto_generated
    OMIterator<AnimField*> getField() const;
    
    //## auto_generated
    void addField(AnimField* p_AnimField);
    
    //## auto_generated
    void removeField(AnimField* p_AnimField);
    
    //## auto_generated
    void clearField();
    
    //## auto_generated
    AnimTimestampField* getTimeStamp() const;
    
    //## auto_generated
    AnimTimestampField* newTimeStamp();
    
    //## auto_generated
    void deleteTimeStamp();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////
    
    bool bInConstruction;		//## attribute bInConstruction
    
    // Identifies message type.
    int code;		//## attribute code
    
    // A field iterator, used for successive getNextField() calls.
    OMIterator<AnimField*>* fieldIterator;		//## attribute fieldIterator
    
    gen_ptr pOrigSrc;		//## attribute pOrigSrc
    
    ////    Relations and components    ////
    
    OMCollection<AnimField*> field;		//## link field
    
    AnimPointerField* destOrSource;		//## classInstance destOrSource
    
    AnimTimestampField* timeStamp;		//## classInstance timeStamp
};

#endif
/*********************************************************************
	File Path	: ../AnimAbstractMessage.h
*********************************************************************/
