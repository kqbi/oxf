/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimClassData
	File Path	: ../AnimClassData.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimClassData.h"
//## classInstance isSingleton
#include "AnimBooleanField.h"
//## auto_generated
#include "AnimField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## classInstance className
#include "AnimStringField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimClassData
AnimClassData AnimClassData::classDataPrototype;

AnimClassData::AnimClassData() {
    initRelations();
    //#[ operation AnimClassData()
    code = omProxyClass;
    
    // set the names
    className->setName("className");
    isSingleton->setName("isSingleton");
    packageName->setName("packageName");
    
    // add fields to container
    addField(className); 
    addField(isSingleton);
    addField(packageName);
    
    // message is currently supported on by AOM
    // in tracing we should use the old mechanism for it.
    #ifdef OMANIMATOR 
    // register in translator
    registerInTranslator();
    #endif
    //#]
}

AnimClassData::~AnimClassData() {
    cleanUpRelations();
}

AnimMessage* AnimClassData::clone() {
    //#[ operation clone()
    AnimClassData *msg = new AnimClassData();   
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));   
    char* tmp = (char*)(rhp_long64_t)getClassName()->getValue();
    msg->setClassName((OMString)tmp);         
    delete[] tmp;
    msg->setIsSingleton((getIsSingleton()->getValue() != 0));
    tmp = (char*)(rhp_long64_t)getPackageName()->getValue();
    msg->setPackageName((OMString)tmp);
    delete[] tmp;
    return msg;
    //#]
}

void AnimClassData::setClassName(OMString value) {
    //#[ operation setClassName(OMString)
    *className = value;
    //#]
}

void AnimClassData::setIsSingleton(OMBoolean value) {
    //#[ operation setIsSingleton(OMBoolean)
    *isSingleton = value;
    //#]
}

void AnimClassData::setPackageName(OMString value) {
    //#[ operation setPackageName(OMString)
    *packageName = value;
    //#]
}

void AnimClassData::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimStringField* AnimClassData::getClassName() const {
    return className;
}

AnimStringField* AnimClassData::newClassName() {
    className = new AnimStringField;
    return className;
}

void AnimClassData::deleteClassName() {
    delete className;
    className = NULL;
}

AnimBooleanField* AnimClassData::getIsSingleton() const {
    return isSingleton;
}

AnimBooleanField* AnimClassData::newIsSingleton() {
    isSingleton = new AnimBooleanField;
    return isSingleton;
}

void AnimClassData::deleteIsSingleton() {
    delete isSingleton;
    isSingleton = NULL;
}

AnimStringField* AnimClassData::getPackageName() const {
    return packageName;
}

AnimStringField* AnimClassData::newPackageName() {
    packageName = new AnimStringField;
    return packageName;
}

void AnimClassData::deletePackageName() {
    delete packageName;
    packageName = NULL;
}

void AnimClassData::initRelations() {
    className = newClassName();
    isSingleton = newIsSingleton();
    packageName = newPackageName();
}

void AnimClassData::cleanUpRelations() {
    {
        deletePackageName();
    }
    {
        deleteIsSingleton();
    }
    {
        deleteClassName();
    }
}

/*********************************************************************
	File Path	: ../AnimClassData.cpp
*********************************************************************/
