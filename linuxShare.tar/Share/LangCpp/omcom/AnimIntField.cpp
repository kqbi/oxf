/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimIntField
	File Path	: ../AnimIntField.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimIntField.h"
//## operation clone()
#include "AnimField.h"
//## operation decode(AnimMessageTranslator*)
#include "AnimMessageTranslator.h"
//## package RiCppAnimMessageTranslator

//## class AnimIntField
AnimIntField::AnimIntField() : value(0) {
    //#[ operation AnimIntField()
    //#]
}

AnimIntField::~AnimIntField() {
}

AnimField* AnimIntField::clone() {
    //#[ operation clone()
    AnimIntField *f = new AnimIntField();
    f->name = name;
    f->value = value;
    return f;
    //#]
}

void AnimIntField::decode(AnimMessageTranslator* translator) {
    //#[ operation decode(AnimMessageTranslator*)
    translator->decodeField(this);
    //#]
}

void AnimIntField::encode(AnimMessageTranslator* translator) {
    //#[ operation encode(AnimMessageTranslator*)
    translator->encodeField(this);
    
    //#]
}

gen_ptr AnimIntField::getValue() const {
    //#[ operation getValue() const
    rhp_long64_t lVal = (rhp_long64_t)value; 
    return (gen_ptr)lVal;
    
    //#]
}

AnimIntField& AnimIntField::operator=(const AnimIntField& field) {
    //#[ operation operator=(const AnimIntField&)
    if (this != &field)   
    {   
        setName(field.getName());
        setValue(field.getValue());
    }
    return *this;
    //#]
}

AnimIntField& AnimIntField::operator=(int val) {
    //#[ operation operator=(int)
    rhp_long64_t lInt = (rhp_long64_t)val;
    setValue((gen_ptr)lInt);
    return *this;
    //#]
}

void AnimIntField::setValue(gen_ptr p_value) {
    //#[ operation setValue(gen_ptr)
    rhp_long64_t lVal = (rhp_long64_t)p_value;
    value = (int)lVal;
    
    //#]
}

/*********************************************************************
	File Path	: ../AnimIntField.cpp
*********************************************************************/
