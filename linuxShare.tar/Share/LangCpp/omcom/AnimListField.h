/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimListField
	File Path	: ../AnimListField.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimListField_H
#define AnimListField_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## auto_generated
#include <oxf/omcollec.h>
//## class AnimListField
#include "AnimField.h"
//## operation decode(AnimMessageTranslator*)
class AnimMessageTranslator;

//## operation AnimListField(AnimSimpleField* )
class AnimSimpleField;

//## package RiCppAnimMessageTranslator

//## class AnimListField
// A List containing AnimClassData messages.
class AnimListField : public AnimField {
    ////    Constructors and destructors    ////
    
public :

    // Argument AnimSimpleField* fieldP :
    // The type of fields this list contains.
    //## operation AnimListField(AnimSimpleField* )
    AnimListField(AnimSimpleField* fieldP);
    
    //## operation AnimListField()
    AnimListField();
    
    //## operation ~AnimListField()
    virtual ~AnimListField();
    
    ////    Operations    ////
    
    //## operation addField(AnimSimpleField*)
    void addField(AnimSimpleField* p_AnimSimpleField);
    
    //## operation clone()
    AnimField* clone();
    
    // Call translator to dencode field from its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to dencode field. 
    //## operation decode(AnimMessageTranslator*)
    virtual void decode(AnimMessageTranslator* translator);
    
    // Call translator to encode field to its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to encode field. 
    //## operation encode(AnimMessageTranslator*)
    virtual void encode(AnimMessageTranslator* translator);
    
    // Returns a clone of the field prototype.
    //## operation getFieldPrototypeClone() const
    AnimSimpleField* getFieldPrototypeClone() const;
    
    // return the next field in the message.
    //## operation getNextField() const
    virtual AnimSimpleField* getNextField() const;
    
    //## operation operator=(const AnimListField&)
    AnimListField& operator=(const AnimListField& _field);
    
    //## operation removeField(AnimSimpleField*)
    void removeField(AnimSimpleField* p_AnimSimpleField);
    
    //## operation resetFieldIterator()
    void resetFieldIterator();
    
    //## operation setFieldPrototype(AnimSimpleField*)
    void setFieldPrototype(AnimSimpleField* fieldP);

protected :

    //## operation cleanUpRelations()
    void cleanUpRelations();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    int getSize() const;
    
    //## auto_generated
    void setSize(int p_size);
    
    //## auto_generated
    OMIterator<AnimSimpleField*> getField() const;
    
    //## auto_generated
    void clearField();
    
    ////    Attributes    ////

protected :

    // A field iterator, used for successive getNextField() calls.
    OMIterator<AnimSimpleField*>* fieldIterator;		//## attribute fieldIterator
    
    // A prototype of the fields to be in the list.
    AnimSimpleField* fieldPrototype;		//## attribute fieldPrototype
    
    // Number of fields in list.
    int size;		//## attribute size
    
    ////    Relations and components    ////
    
    OMCollection<AnimSimpleField*> field;		//## link field
};

#endif
/*********************************************************************
	File Path	: ../AnimListField.h
*********************************************************************/
