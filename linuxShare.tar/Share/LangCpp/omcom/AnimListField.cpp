/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimListField
	File Path	: ../AnimListField.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimListField.h"
//## operation decode(AnimMessageTranslator*)
#include "AnimMessageTranslator.h"
//## operation AnimListField(AnimSimpleField* )
#include "AnimSimpleField.h"
//## package RiCppAnimMessageTranslator

//## class AnimListField
AnimListField::AnimListField(AnimSimpleField* fieldP) : size(0) {
    //#[ operation AnimListField(AnimSimpleField* )
    fieldIterator = new OMIterator<AnimSimpleField*>(field);
    fieldIterator->reset();
    fieldPrototype = (AnimSimpleField *)(fieldP->clone());
    //#]
}

AnimListField::AnimListField() : size(0) {
    //#[ operation AnimListField()
    fieldPrototype = NULL;
    fieldIterator = new OMIterator<AnimSimpleField*>(field);
    fieldIterator->reset();
    
    //#]
}

AnimListField::~AnimListField() {
    //#[ operation ~AnimListField()
    
    while (getSize() > 0)
    {
      fieldIterator->reset();
      AnimSimpleField *sF = *(*(fieldIterator));
      removeField(sF);
      delete sF;
    }
    
    delete fieldPrototype;
    delete fieldIterator;
    
    cleanUpRelations();
    
    //#]
    cleanUpRelations();
}

void AnimListField::addField(AnimSimpleField* p_AnimSimpleField) {
    //#[ operation addField(AnimSimpleField*)
    field.add(p_AnimSimpleField);
    ++size;
    //#]
}

AnimField* AnimListField::clone() {
    //#[ operation clone()
    // everything cloned, but the field iterator
    AnimListField *lF = new AnimListField();
    lF->name = name;
    lF->setSize(size);
    lF->setFieldPrototype(fieldPrototype);   
    
    OMIterator<AnimSimpleField* > iter(field);
    iter.reset();
    while (*iter)
    {  
      lF->addField((AnimSimpleField *)((*iter)->clone()));
      iter++;
    } 
    return lF;
    //#]
}

void AnimListField::decode(AnimMessageTranslator* translator) {
    //#[ operation decode(AnimMessageTranslator*)
    translator->decodeField(this);
    //#]
}

void AnimListField::encode(AnimMessageTranslator* translator) {
    //#[ operation encode(AnimMessageTranslator*)
    translator->encodeField(this);
    
    //#]
}

AnimSimpleField* AnimListField::getFieldPrototypeClone() const {
    //#[ operation getFieldPrototypeClone() const
    AnimSimpleField* f = NULL;
    if (fieldPrototype != NULL)
      f = (AnimSimpleField *)(fieldPrototype->clone());
    return f;
    //#]
}

AnimSimpleField* AnimListField::getNextField() const {
    //#[ operation getNextField() const
    AnimSimpleField *f = NULL;
    if (fieldIterator) 
    {
      f = *(*fieldIterator);
      (*fieldIterator)++;
    }
    return f;
    //#]
}

AnimListField& AnimListField::operator=(const AnimListField& _field) {
    //#[ operation operator=(const AnimListField&)
    if (this != &_field)   
    { 
        size = _field.getSize();
        fieldPrototype = (AnimSimpleField *)(_field.getFieldPrototypeClone());
        
        AnimSimpleField *sF = NULL;
        while ((sF = _field.getNextField()) != NULL)
        {
            addField(sF);
        }
    }      
    return *this;
    //#]
}

void AnimListField::removeField(AnimSimpleField* p_AnimSimpleField) {
    //#[ operation removeField(AnimSimpleField*)
    field.remove(p_AnimSimpleField);
    if (size > 0)
      --size;
    
    //#]
}

void AnimListField::resetFieldIterator() {
    //#[ operation resetFieldIterator()
    fieldIterator->reset();
    //#]
}

void AnimListField::setFieldPrototype(AnimSimpleField* fieldP) {
    //#[ operation setFieldPrototype(AnimSimpleField*)
    if (fieldPrototype != NULL)
      delete fieldPrototype;
    fieldPrototype = (AnimSimpleField *)(fieldP->clone());
    //#]
}

void AnimListField::cleanUpRelations() {
    //#[ operation cleanUpRelations()
    {
        field.removeAll();
    }
    
    //#]
}

int AnimListField::getSize() const {
    return size;
}

void AnimListField::setSize(int p_size) {
    size = p_size;
}

OMIterator<AnimSimpleField*> AnimListField::getField() const {
    OMIterator<AnimSimpleField*> iter(field);
    return iter;
}

void AnimListField::clearField() {
    field.removeAll();
}

/*********************************************************************
	File Path	: ../AnimListField.cpp
*********************************************************************/
