/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimAbstractMessage
	File Path	: ../AnimAbstractMessage.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimAbstractMessage.h"
//## operation getNextField()
#include "AnimField.h"
//## operation setNextField(AnimMessageField*)
#include "AnimMessageField.h"
//## operation setDestOrSource(const AnimPointerField&)
#include "AnimPointerField.h"
//## operation getTimeStamp()
#include "AnimTimestampField.h"
//## package RiCppAnimMessageTranslator

//## class AnimAbstractMessage
AnimAbstractMessage::AnimAbstractMessage() : bInConstruction(false), pOrigSrc(NULL) {
    initRelations();
    //#[ operation AnimAbstractMessage()
    fieldIterator = new OMIterator<AnimField*>(field);
    fieldIterator->reset();
    
    //#]
}

AnimAbstractMessage::~AnimAbstractMessage() {
    //#[ operation ~AnimAbstractMessage()
    delete fieldIterator;
    cleanUpRelations();
    
    //#]
    cleanUpRelations();
}

AnimField* AnimAbstractMessage::getNextField() {
    //#[ operation getNextField()
    AnimField *f = NULL;
    if (fieldIterator) 
    {
      f = *(*fieldIterator);
      (*fieldIterator)++;
    }
    return f;
    //#]
}

gen_ptr AnimAbstractMessage::getOrigSource() {
    //#[ operation getOrigSource()
    return pOrigSrc;
    //#]
}

AnimTimestampField* AnimAbstractMessage::getTimeStamp() {
    //#[ operation getTimeStamp()
    return timeStamp;
    
    //#]
}

bool AnimAbstractMessage::isConstructionMessage() {
    //#[ operation isConstructionMessage()
    return bInConstruction;
    //#]
}

void AnimAbstractMessage::resetFieldIterator() {
    //#[ operation resetFieldIterator()
    fieldIterator->reset();
    //#]
}

void AnimAbstractMessage::setConstructionMessage(bool bInConstruction) {
    //#[ operation setConstructionMessage(bool)
    this->bInConstruction = bInConstruction;
    //#]
}

void AnimAbstractMessage::setDestOrSource(gen_ptr _destOrSource) {
    //#[ operation setDestOrSource(gen_ptr)
    *(this->destOrSource) = _destOrSource;
    //#]
}

void AnimAbstractMessage::setDestOrSource(const AnimPointerField& _destOrSource) {
    //#[ operation setDestOrSource(const AnimPointerField&)
    *(this->destOrSource) = _destOrSource;
    //#]
}

void AnimAbstractMessage::setNextField(AnimMessageField* _field) {
    //#[ operation setNextField(AnimMessageField*)
    addField(_field);
    //#]
}

void AnimAbstractMessage::setOrigSource(gen_ptr pOrigSrc) {
    //#[ operation setOrigSource(gen_ptr)
    this->pOrigSrc = pOrigSrc;
    //#]
}

void AnimAbstractMessage::setTimeStamp(timeUnit _timeStamp) {
    //#[ operation setTimeStamp(timeUnit)
    *(this->timeStamp) = _timeStamp;
    
    //#]
}

void AnimAbstractMessage::setTimeStamp(const AnimTimestampField& _timeStamp) {
    //#[ operation setTimeStamp(const AnimTimestampField&)
    *(this->timeStamp) = _timeStamp;
    
    //#]
}

bool AnimAbstractMessage::getBInConstruction() const {
    return bInConstruction;
}

void AnimAbstractMessage::setBInConstruction(bool p_bInConstruction) {
    bInConstruction = p_bInConstruction;
}

int AnimAbstractMessage::getCode() const {
    return code;
}

void AnimAbstractMessage::setCode(int p_code) {
    code = p_code;
}

gen_ptr AnimAbstractMessage::getPOrigSrc() const {
    return pOrigSrc;
}

void AnimAbstractMessage::setPOrigSrc(gen_ptr p_pOrigSrc) {
    pOrigSrc = p_pOrigSrc;
}

AnimPointerField* AnimAbstractMessage::getDestOrSource() const {
    return destOrSource;
}

AnimPointerField* AnimAbstractMessage::newDestOrSource() {
    destOrSource = new AnimPointerField;
    return destOrSource;
}

void AnimAbstractMessage::deleteDestOrSource() {
    delete destOrSource;
    destOrSource = NULL;
}

OMIterator<AnimField*> AnimAbstractMessage::getField() const {
    OMIterator<AnimField*> iter(field);
    return iter;
}

void AnimAbstractMessage::addField(AnimField* p_AnimField) {
    field.add(p_AnimField);
}

void AnimAbstractMessage::removeField(AnimField* p_AnimField) {
    field.remove(p_AnimField);
}

void AnimAbstractMessage::clearField() {
    field.removeAll();
}

AnimTimestampField* AnimAbstractMessage::getTimeStamp() const {
    return timeStamp;
}

AnimTimestampField* AnimAbstractMessage::newTimeStamp() {
    timeStamp = new AnimTimestampField;
    return timeStamp;
}

void AnimAbstractMessage::deleteTimeStamp() {
    delete timeStamp;
    timeStamp = NULL;
}

void AnimAbstractMessage::initRelations() {
    destOrSource = newDestOrSource();
    timeStamp = newTimeStamp();
}

void AnimAbstractMessage::cleanUpRelations() {
    {
        deleteTimeStamp();
    }
    {
        deleteDestOrSource();
    }
    {
        field.removeAll();
    }
}

/*********************************************************************
	File Path	: ../AnimAbstractMessage.cpp
*********************************************************************/
