/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: RiCppAnimMessageTranslator
	File Path	: ../RiCppAnimMessageTranslator.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef RiCppAnimMessageTranslator_H
#define RiCppAnimMessageTranslator_H

//## dependency AnimMessageTranslator
#include "AnimMessageTranslator.h"
//## dependency AnimTranslatorFactory
#include "AnimTranslatorFactory.h"
//## auto_generated
class AnimAbstractMessage;

//## auto_generated
class AnimAbstractMessageTranslator;

//## auto_generated
class AnimBooleanField;

//## auto_generated
class AnimCodeField;

//## auto_generated
class AnimField;

//## auto_generated
class AnimIntField;

//## auto_generated
class AnimListField;

//## auto_generated
class AnimMessage;

//## auto_generated
class AnimMessageField;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimRhapTranslator;

//## auto_generated
class AnimSimpleField;

//## auto_generated
class AnimStringField;

//## auto_generated
class AnimStringOrPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessageTranslator



#endif
/*********************************************************************
	File Path	: ../RiCppAnimMessageTranslator.h
*********************************************************************/
