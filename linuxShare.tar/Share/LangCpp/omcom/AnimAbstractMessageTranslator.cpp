/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimAbstractMessageTranslator
	File Path	: ../AnimAbstractMessageTranslator.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimAbstractMessageTranslator.h"
//## link messagePrototypes
#include "AnimAbstractMessage.h"
//## operation getMessageClone(int)
#include "AnimMessage.h"
//## package RiCppAnimMessageTranslator

//## class AnimAbstractMessageTranslator
AnimAbstractMessageTranslator::AnimAbstractMessageTranslator() : messagePrototypes() {
    //#[ operation AnimAbstractMessageTranslator()
     
    //#]
}

AnimAbstractMessageTranslator::AnimAbstractMessageTranslator(const AnimAbstractMessageTranslator& /* _translator */) : messagePrototypes() {
    //#[ operation AnimAbstractMessageTranslator(const AnimAbstractMessageTranslator& /*  */)
    //#]
}

AnimAbstractMessageTranslator::~AnimAbstractMessageTranslator() {
    cleanUpRelations();
}

OMString AnimAbstractMessageTranslator::getLastErrorMessage() const {
    //#[ operation getLastErrorMessage() const
    return lastErrorMessage;
    
    //#]
}

AnimMessage* AnimAbstractMessageTranslator::getMessageClone(int code) {
    //#[ operation getMessageClone(int)
    AnimAbstractMessage* msg = getMessagePrototypes(code);
    AnimMessage* cloneMsg = NULL;
    if (msg != NULL)   
      cloneMsg = msg->clone();
    return cloneMsg;
    
    //#]
}

void AnimAbstractMessageTranslator::registerMessagePrototype(AnimMessage* animMessage) {
    //#[ operation registerMessagePrototype(AnimMessage*)
    addMessagePrototypes(animMessage->getCode(),
    (AnimAbstractMessage *)animMessage);
    //#]
}

void AnimAbstractMessageTranslator::operator=(const AnimAbstractMessageTranslator& /* _translator */) {
    //#[ operation operator=(const AnimAbstractMessageTranslator& /*  */)
    //#]
}

void AnimAbstractMessageTranslator::setLastErrorMessage(OMString p_lastErrorMessage) {
    lastErrorMessage = p_lastErrorMessage;
}

OMIterator<AnimAbstractMessage*> AnimAbstractMessageTranslator::getMessagePrototypes() const {
    OMIterator<AnimAbstractMessage*> iter(messagePrototypes);
    return iter;
}

void AnimAbstractMessageTranslator::clearMessagePrototypes() {
    messagePrototypes.removeAll();
}

void AnimAbstractMessageTranslator::removeMessagePrototypes(AnimAbstractMessage* p_AnimAbstractMessage) {
    messagePrototypes.remove(p_AnimAbstractMessage);
}

AnimAbstractMessage* AnimAbstractMessageTranslator::getMessagePrototypes(int key) const {
    return messagePrototypes.getKey(key);
}

void AnimAbstractMessageTranslator::addMessagePrototypes(int key, AnimAbstractMessage* p_AnimAbstractMessage) {
    messagePrototypes.add(key,p_AnimAbstractMessage);
}

void AnimAbstractMessageTranslator::cleanUpRelations() {
    {
        messagePrototypes.removeAll();
    }
}

/*********************************************************************
	File Path	: ../AnimAbstractMessageTranslator.cpp
*********************************************************************/
