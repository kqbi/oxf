/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimSetBreakpoint
	File Path	: ../AnimSetBreakpoint.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimSetBreakpoint.h"
//## classInstance breakpointCode
#include "AnimCodeField.h"
//## auto_generated
#include "AnimField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## classInstance breakpointData
#include "AnimStringField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimSetBreakpoint
AnimSetBreakpoint AnimSetBreakpoint::animSetBreakpoint;

AnimSetBreakpoint::AnimSetBreakpoint() {
    initRelations();
    //#[ operation AnimSetBreakpoint()
    code = setBreakpoint;
    
    // set the names
    breakpointCode->setName((OMString)"breakpointCode");
    animItem->setName("animItem");
    breakpointData->setName("breakpointData");
    
    // add fields to container
    addField(breakpointCode);
    addField(animItem);
    addField(breakpointData);
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimSetBreakpoint::~AnimSetBreakpoint() {
    cleanUpRelations();
}

AnimMessage* AnimSetBreakpoint::clone() {
    //#[ operation clone()
    AnimSetBreakpoint *msg = new AnimSetBreakpoint();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    msg->setBreakpointCode((unsigned char)(rhp_long64_t)(getBreakpointCode()->getValue()));
    msg->setAnimItem(getAnimItem()->getValue());   
    char *tmp = (char *)(rhp_long64_t)(getBreakpointData()->getValue());
    const OMString omStr(tmp);
    msg->setBreakpointData(omStr); 
    delete[] tmp;
    return msg;
    //#]
}

void AnimSetBreakpoint::setAnimItem(gen_ptr value) {
    //#[ operation setAnimItem(gen_ptr)
    *animItem = value;
    //#]
}

void AnimSetBreakpoint::setBreakpointCode(unsigned char value) {
    //#[ operation setBreakpointCode(unsigned char)
    *breakpointCode= value;
    //#]
}

void AnimSetBreakpoint::setBreakpointData(const OMString& value) {
    //#[ operation setBreakpointData(OMString)
    *breakpointData = value;
    //#]
}

void AnimSetBreakpoint::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimPointerField* AnimSetBreakpoint::getAnimItem() const {
    return animItem;
}

AnimPointerField* AnimSetBreakpoint::newAnimItem() {
    animItem = new AnimPointerField;
    return animItem;
}

void AnimSetBreakpoint::deleteAnimItem() {
    delete animItem;
    animItem = NULL;
}

AnimCodeField* AnimSetBreakpoint::getBreakpointCode() const {
    return breakpointCode;
}

AnimCodeField* AnimSetBreakpoint::newBreakpointCode() {
    breakpointCode = new AnimCodeField;
    return breakpointCode;
}

void AnimSetBreakpoint::deleteBreakpointCode() {
    delete breakpointCode;
    breakpointCode = NULL;
}

AnimStringField* AnimSetBreakpoint::getBreakpointData() const {
    return breakpointData;
}

AnimStringField* AnimSetBreakpoint::newBreakpointData() {
    breakpointData = new AnimStringField;
    return breakpointData;
}

void AnimSetBreakpoint::deleteBreakpointData() {
    delete breakpointData;
    breakpointData = NULL;
}

void AnimSetBreakpoint::initRelations() {
    animItem = newAnimItem();
    breakpointCode = newBreakpointCode();
    breakpointData = newBreakpointData();
}

void AnimSetBreakpoint::cleanUpRelations() {
    {
        deleteBreakpointData();
    }
    {
        deleteBreakpointCode();
    }
    {
        deleteAnimItem();
    }
}

/*********************************************************************
	File Path	: ../AnimSetBreakpoint.cpp
*********************************************************************/
