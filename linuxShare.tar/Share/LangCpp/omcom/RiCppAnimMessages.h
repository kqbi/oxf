/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: RiCppAnimMessages
	File Path	: ../RiCppAnimMessages.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef RiCppAnimMessages_H
#define RiCppAnimMessages_H

//## dependency AnimAbstractMessage
#include "AnimAbstractMessage.h"
//## dependency AnimMessage
#include "AnimMessage.h"
//## dependency AnimMessageTranslator
#include "AnimMessageTranslator.h"
//## dependency AnimProxyCreated
#include "AnimProxyCreated.h"
//## dependency AnimTranslatorFactory
#include "AnimTranslatorFactory.h"
//## auto_generated
#include "aom/aoxf.h"
//## auto_generated
class AnimAllocateCore;

//## auto_generated
class AnimClassData;

//## auto_generated
class AnimDebuggerBreakPoint;

//## auto_generated
class AnimForeignMessage;

//## auto_generated
class AnimNameValueData;

//## auto_generated
class AnimNewInterestMask;

//## auto_generated
class AnimOpCallReply;

//## auto_generated
class AnimOpCallRequest;

//## auto_generated
class AnimOpReturn;

//## auto_generated
class AnimOperationData;

//## auto_generated
class AnimQuitExecutable;

//## auto_generated
class AnimRegisterClasses;

//## auto_generated
class AnimRegisterOperations;

//## auto_generated
class AnimRemoveBreakpoint;

//## auto_generated
class AnimResumeThread;

//## auto_generated
class AnimSendYourself;

//## auto_generated
class AnimSetBreakpoint;

//## auto_generated
class AnimStoppedByUser;

//## auto_generated
class AnimSuspendThread;

//## auto_generated
class AnimTimeNotification;

//## auto_generated
class AnimTimeRequest;

//## package RiCppAnimMessages



#endif
/*********************************************************************
	File Path	: ../RiCppAnimMessages.h
*********************************************************************/
