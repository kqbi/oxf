/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimPointerField
	File Path	: ../AnimPointerField.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimPointerField.h"
//## operation clone()
#include "AnimField.h"
//## operation decode(AnimMessageTranslator*)
#include "AnimMessageTranslator.h"
//## package RiCppAnimMessageTranslator

//## class AnimPointerField
AnimPointerField::AnimPointerField() : value(NULL) {
    //#[ operation AnimPointerField()
    //#]
}

AnimPointerField::~AnimPointerField() {
}

AnimField* AnimPointerField::clone() {
    //#[ operation clone()
    AnimPointerField *f = new AnimPointerField();
    f->name = name;
    f->value = value;
    return f;
    //#]
}

void AnimPointerField::decode(AnimMessageTranslator* translator) {
    //#[ operation decode(AnimMessageTranslator*)
    translator->decodeField(this);
    //#]
}

void AnimPointerField::encode(AnimMessageTranslator* translator) {
    //#[ operation encode(AnimMessageTranslator*)
    translator->encodeField(this);
    
    //#]
}

gen_ptr AnimPointerField::getValue() const {
    //#[ operation getValue() const
    return value;
    
    //#]
}

AnimPointerField& AnimPointerField::operator=(gen_ptr pointerVal) {
    //#[ operation operator=(gen_ptr)
    setValue(pointerVal);
    return *this;
    //#]
}

AnimPointerField& AnimPointerField::operator=(const AnimPointerField& pointerField) {
    //#[ operation operator=(const AnimPointerField&)
    if (this != &pointerField)   
    {   
        setName(pointerField.getName());
        setValue(pointerField.getValue());
    }
    return *this;
    //#]
}

void AnimPointerField::setValue(gen_ptr p_value) {
    //#[ operation setValue(gen_ptr)
    value = p_value;
    
    //#]
}

/*********************************************************************
	File Path	: ../AnimPointerField.cpp
*********************************************************************/
