/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimTranslatorFactory
	File Path	: ../AnimTranslatorFactory.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimTranslatorFactory_H
#define AnimTranslatorFactory_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## operation getTranslatorInstance(OMString)
class AnimMessageTranslator;

//## dependency AnimRhapTranslator
class AnimRhapTranslator;

//## package RiCppAnimMessageTranslator

//## class AnimTranslatorFactory
class AnimTranslatorFactory {
    ////    Constructors and destructors    ////
    
private :

    //## operation AnimTranslatorFactory()
    AnimTranslatorFactory();

public :

    //## auto_generated
    ~AnimTranslatorFactory();
    
    ////    Operations    ////
    
    // Argument OMString protocolName :
    // Get the singleton instance of a translator by protocol name.
    // Currenlt the protocols are: "Rhapsody".
    //## operation getTranslatorInstance(OMString)
    AnimMessageTranslator* getTranslatorInstance(OMString protocolName);
    
    // Creates the singleton instance.
    //## operation instance()
    static AnimTranslatorFactory* instance();
    
    ////    Additional operations    ////
    
    //## auto_generated
    AnimMessageTranslator* getDefaultTranslator() const;
    
    //## auto_generated
    void setDefaultTranslator(AnimMessageTranslator* p_AnimMessageTranslator);

protected :

    //## auto_generated
    void cleanUpRelations();
    
    ////    Relations and components    ////
    
    AnimMessageTranslator* defaultTranslator;		//## link defaultTranslator
};

#endif
/*********************************************************************
	File Path	: ../AnimTranslatorFactory.h
*********************************************************************/
