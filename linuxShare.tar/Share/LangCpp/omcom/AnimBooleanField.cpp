/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimBooleanField
	File Path	: ../AnimBooleanField.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimBooleanField.h"
//## operation clone()
#include "AnimField.h"
//## operation decode(AnimMessageTranslator*)
#include "AnimMessageTranslator.h"
//## package RiCppAnimMessageTranslator

//## class AnimBooleanField
AnimBooleanField::AnimBooleanField() : value(TRUE) {
}

AnimBooleanField::~AnimBooleanField() {
}

AnimField* AnimBooleanField::clone() {
    //#[ operation clone()
    AnimBooleanField *bF = new AnimBooleanField();
    bF->value = value;
    return bF;
    //#]
}

void AnimBooleanField::decode(AnimMessageTranslator* translator) {
    //#[ operation decode(AnimMessageTranslator*)
    translator->decodeField(this);
    //#]
}

void AnimBooleanField::encode(AnimMessageTranslator* translator) {
    //#[ operation encode(AnimMessageTranslator*)
    translator->encodeField(this);
    
    //#]
}

gen_ptr AnimBooleanField::getValue() const {
    //#[ operation getValue() const
    return (gen_ptr)value;
    
    //#]
}

AnimBooleanField& AnimBooleanField::operator=(const AnimBooleanField& field) {
    //#[ operation operator=(const AnimBooleanField&)
    if (this != &field)   
    {   
        setName(field.getName());
        setValue(field.getValue());
    }
    return *this;
    //#]
}

AnimBooleanField& AnimBooleanField::operator=(OMBoolean val) {
    //#[ operation operator=(OMBoolean)
    setValue((gen_ptr)val);
    return *this;
    //#]
}

void AnimBooleanField::setValue(gen_ptr p_value) {
    //#[ operation setValue(gen_ptr)
    value = (p_value != 0);
    //#]
}

/*********************************************************************
	File Path	: ../AnimBooleanField.cpp
*********************************************************************/
