/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimPointerField
	File Path	: ../AnimPointerField.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimPointerField_H
#define AnimPointerField_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## class AnimPointerField
#include "AnimSimpleField.h"
//## operation getValue() const
#include <oxf/rawtypes.h>
//## operation clone()
class AnimField;

//## operation decode(AnimMessageTranslator*)
class AnimMessageTranslator;

//## package RiCppAnimMessageTranslator

//## class AnimPointerField
class AnimPointerField : public AnimSimpleField {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimPointerField()
    AnimPointerField();
    
    //## auto_generated
    virtual ~AnimPointerField();
    
    ////    Operations    ////
    
    //## operation clone()
    AnimField* clone();
    
    // Call translator to dencode field from its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to dencode field. 
    //## operation decode(AnimMessageTranslator*)
    virtual void decode(AnimMessageTranslator* translator);
    
    // Call translator to encode field to its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to encode field. 
    //## operation encode(AnimMessageTranslator*)
    virtual void encode(AnimMessageTranslator* translator);
    
    // Get the scalar value.
    //## operation getValue() const
    virtual gen_ptr getValue() const;
    
    // Argument gen_ptr pointerVal :
    // The pointer value of the field.
    //## operation operator=(gen_ptr)
    AnimPointerField& operator=(gen_ptr pointerVal);
    
    //## operation operator=(const AnimPointerField&)
    AnimPointerField& operator=(const AnimPointerField& pointerField);
    
    //## operation setValue(gen_ptr)
    void setValue(gen_ptr p_value);
    
    ////    Attributes    ////

protected :

    gen_ptr value;		//## attribute value
};

#endif
/*********************************************************************
	File Path	: ../AnimPointerField.h
*********************************************************************/
