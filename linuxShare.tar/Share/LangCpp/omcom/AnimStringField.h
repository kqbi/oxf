/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimStringField
	File Path	: ../AnimStringField.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimStringField_H
#define AnimStringField_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## class AnimStringField
#include "AnimSimpleField.h"
//## operation getValue() const
#include <oxf/rawtypes.h>
//## operation clone()
class AnimField;

//## operation decode(AnimMessageTranslator*)
class AnimMessageTranslator;

//## package RiCppAnimMessageTranslator

//## class AnimStringField
class AnimStringField : public AnimSimpleField {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    AnimStringField();
    
    //## auto_generated
    virtual ~AnimStringField();
    
    ////    Operations    ////
    
    //## operation clone()
    AnimField* clone();
    
    // Call translator to dencode field from its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to dencode field. 
    //## operation decode(AnimMessageTranslator*)
    virtual void decode(AnimMessageTranslator* translator);
    
    // Call translator to encode field to its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to encode field. 
    //## operation encode(AnimMessageTranslator*)
    virtual void encode(AnimMessageTranslator* translator);
    
    //## operation getValue() const
    virtual gen_ptr getValue() const;
    
    //## operation operator=(const AnimStringField&)
    AnimStringField& operator=(const AnimStringField& field);
    
    // Argument OMString val :
    // The value of the field.
    //## operation operator=(OMString)
    AnimStringField& operator=(OMString val);
    
    //## operation setValue(gen_ptr)
    void setValue(gen_ptr p_value);
    
    ////    Attributes    ////

protected :

    OMString value;		//## attribute value
};

#endif
/*********************************************************************
	File Path	: ../AnimStringField.h
*********************************************************************/
