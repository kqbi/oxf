/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimCodeField
	File Path	: ../AnimCodeField.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimCodeField_H
#define AnimCodeField_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## class AnimCodeField
#include "AnimSimpleField.h"
//## operation getValue() const
#include <oxf/rawtypes.h>
//## operation clone()
class AnimField;

//## operation decode(AnimMessageTranslator*)
class AnimMessageTranslator;

//## package RiCppAnimMessageTranslator

//## class AnimCodeField
// For handling code.
class AnimCodeField : public AnimSimpleField {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimCodeField()
    AnimCodeField();
    
    //## auto_generated
    virtual ~AnimCodeField();
    
    ////    Operations    ////
    
    //## operation clone()
    AnimField* clone();
    
    // Call translator to dencode field from its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to dencode field. 
    //## operation decode(AnimMessageTranslator*)
    virtual void decode(AnimMessageTranslator* translator);
    
    // Call translator to encode field to its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to encode field. 
    //## operation encode(AnimMessageTranslator*)
    virtual void encode(AnimMessageTranslator* translator);
    
    // Get the scalar value.
    //## operation getValue() const
    virtual gen_ptr getValue() const;
    
    //## operation operator=(const AnimCodeField&)
    AnimCodeField& operator=(const AnimCodeField& field);
    
    // Argument unsigned char val :
    // The value of the field.
    //## operation operator=(unsigned char)
    AnimCodeField& operator=(unsigned char val);
    
    //## operation setValue(gen_ptr)
    void setValue(gen_ptr p_value);
    
    ////    Attributes    ////

protected :

    unsigned char value;		//## attribute value
};

#endif
/*********************************************************************
	File Path	: ../AnimCodeField.h
*********************************************************************/
