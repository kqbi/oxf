/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimStoppedByUser
	File Path	: ../AnimStoppedByUser.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimStoppedByUser_H
#define AnimStoppedByUser_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimStoppedByUser
#include "AnimAbstractMessage.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## auto_generated
class AnimField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimStoppedByUser
// A stop command issued by the user.
class AnimStoppedByUser : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimStoppedByUser()
    AnimStoppedByUser();
    
    //## auto_generated
    virtual ~AnimStoppedByUser();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimStoppedByUser animStoppedByUser;		//## attribute animStoppedByUser
};

#endif
/*********************************************************************
	File Path	: ../AnimStoppedByUser.h
*********************************************************************/
