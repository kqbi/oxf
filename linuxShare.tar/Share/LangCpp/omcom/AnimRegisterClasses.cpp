/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimRegisterClasses
	File Path	: ../AnimRegisterClasses.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimRegisterClasses.h"
//## operation addClassData(AnimClassData*)
#include "AnimClassData.h"
//## auto_generated
#include "AnimField.h"
//## operation clone()
#include "AnimMessage.h"
//## dependency AnimMessageField
#include "AnimMessageField.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimRegisterClasses
AnimListField AnimRegisterClasses::classDataListPrototype;

AnimRegisterClasses::AnimRegisterClasses() {
    initRelations();
    //#[ operation AnimRegisterClasses()
    code = classList;
    
    // set the names      
    classDataList->setName("classDataList");
    
    
    // set list prototype
    AnimMessageField msgField;
    classDataList->setFieldPrototype(&msgField);
    
    
    // add fields to container
    addField(classDataList); 
    
    // message is currently supported on by AOM
    // in tracing we should use the old mechanism for it.
    #ifdef OMANIMATOR 
    // register in translator
    registerInTranslator();
    #endif
    //#]
}

AnimRegisterClasses::~AnimRegisterClasses() {
    cleanUpRelations();
}

void AnimRegisterClasses::addClassData(AnimClassData* classData) {
    //#[ operation addClassData(AnimClassData*)
    AnimMessageField *msgField = new AnimMessageField(); 
    msgField->setValue((gen_ptr)(rhp_long64_t)classData);
    classDataList->addField(msgField);
    //#]
}

AnimMessage* AnimRegisterClasses::clone() {
    //#[ operation clone()
    AnimRegisterClasses *msg = new AnimRegisterClasses();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    msg->classDataList = classDataList;
    return msg;
    //#]
}

void AnimRegisterClasses::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimListField* AnimRegisterClasses::getClassDataList() const {
    return classDataList;
}

AnimListField* AnimRegisterClasses::newClassDataList() {
    classDataList = new AnimListField;
    return classDataList;
}

void AnimRegisterClasses::deleteClassDataList() {
    delete classDataList;
    classDataList = NULL;
}

void AnimRegisterClasses::initRelations() {
    classDataList = newClassDataList();
}

void AnimRegisterClasses::cleanUpRelations() {
    {
        deleteClassDataList();
    }
}

/*********************************************************************
	File Path	: ../AnimRegisterClasses.cpp
*********************************************************************/
