/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimTimeNotification
	File Path	: ../AnimTimeNotification.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimTimeNotification.h"
//## auto_generated
#include "AnimField.h"
//## classInstance actualTimeInterval
#include "AnimIntField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimTimeNotification
AnimTimeNotification AnimTimeNotification::_timeNotification;

AnimTimeNotification::AnimTimeNotification() {
    initRelations();
    //#[ operation AnimTimeNotification()
    code = timeNotification;
    
    // set the names
    timeInterval->setName("timeInterval");
    
    // add fields to container
    addField(timeInterval);   
    addField(actualTimeInterval);
    addField(elapsedTime);
    
    registerInTranslator();
    
    //#]
}

AnimTimeNotification::~AnimTimeNotification() {
    cleanUpRelations();
}

AnimMessage* AnimTimeNotification::clone() {
    //#[ operation clone()
    AnimTimeNotification *msg = new AnimTimeNotification();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    rhp_long64_t lInt = (rhp_long64_t)(getTimeInterval()->getValue());
    msg->setTimeInterval((int)lInt);
    lInt = (rhp_long64_t)(getActualTimeInterval()->getValue());
    msg->setActualTimeInterval((int)lInt);
    lInt = (rhp_long64_t)(getElapsedTime()->getValue());
    msg->setElapsedTime((int)lInt);
    return msg;
    //#]
}

void AnimTimeNotification::setActualTimeInterval(int value) {
    //#[ operation setActualTimeInterval(int)
    *actualTimeInterval = value;
    //#]
}

void AnimTimeNotification::setElapsedTime(int value) {
    //#[ operation setElapsedTime(int)
    *elapsedTime = value;
    //#]
}

void AnimTimeNotification::setTimeInterval(int value) {
    //#[ operation setTimeInterval(int)
    *timeInterval = value;
    //#]
}

void AnimTimeNotification::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimIntField* AnimTimeNotification::getActualTimeInterval() const {
    return actualTimeInterval;
}

AnimIntField* AnimTimeNotification::createNewActualTimeInterval() {
    actualTimeInterval = new AnimIntField;
    return actualTimeInterval;
}

void AnimTimeNotification::deleteActualTimeInterval() {
    delete actualTimeInterval;
    actualTimeInterval = NULL;
}

AnimIntField* AnimTimeNotification::getElapsedTime() const {
    return elapsedTime;
}

AnimIntField* AnimTimeNotification::createNewElapsedTime() {
    elapsedTime = new AnimIntField;
    return elapsedTime;
}

void AnimTimeNotification::deleteElapsedTime() {
    delete elapsedTime;
    elapsedTime = NULL;
}

AnimIntField* AnimTimeNotification::getTimeInterval() const {
    return timeInterval;
}

AnimIntField* AnimTimeNotification::createNewTimeInterval() {
    timeInterval = new AnimIntField;
    return timeInterval;
}

void AnimTimeNotification::deleteTimeInterval() {
    delete timeInterval;
    timeInterval = NULL;
}

void AnimTimeNotification::initRelations() {
    actualTimeInterval = createNewActualTimeInterval();
    elapsedTime = createNewElapsedTime();
    timeInterval = createNewTimeInterval();
}

void AnimTimeNotification::cleanUpRelations() {
    {
        deleteTimeInterval();
    }
    {
        deleteElapsedTime();
    }
    {
        deleteActualTimeInterval();
    }
}

/*********************************************************************
	File Path	: ../AnimTimeNotification.cpp
*********************************************************************/
