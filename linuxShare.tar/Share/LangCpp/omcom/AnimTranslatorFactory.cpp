/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimTranslatorFactory
	File Path	: ../AnimTranslatorFactory.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimTranslatorFactory.h"
//## operation getTranslatorInstance(OMString)
#include "AnimMessageTranslator.h"
//## dependency AnimRhapTranslator
#include "AnimRhapTranslator.h"
//## package RiCppAnimMessageTranslator

//## class AnimTranslatorFactory
AnimTranslatorFactory::AnimTranslatorFactory() {
    defaultTranslator = NULL;
    //#[ operation AnimTranslatorFactory()
    setDefaultTranslator(getTranslatorInstance("Rhapsody"));
    //#]
}

AnimTranslatorFactory::~AnimTranslatorFactory() {
    cleanUpRelations();
}

AnimMessageTranslator* AnimTranslatorFactory::getTranslatorInstance(OMString protocolName) {
    //#[ operation getTranslatorInstance(OMString)
    AnimMessageTranslator *trans = NULL;
    if (protocolName == (char*)"Rhapsody")
    {
      trans = AnimRhapTranslator::instance();
    }
    
    return trans;
    //#]
}

AnimTranslatorFactory* AnimTranslatorFactory::instance() {
    //#[ operation instance()
    static AnimTranslatorFactory theFactoryInstance;
    return &theFactoryInstance;
    //#]
}

AnimMessageTranslator* AnimTranslatorFactory::getDefaultTranslator() const {
    return defaultTranslator;
}

void AnimTranslatorFactory::setDefaultTranslator(AnimMessageTranslator* p_AnimMessageTranslator) {
    defaultTranslator = p_AnimMessageTranslator;
}

void AnimTranslatorFactory::cleanUpRelations() {
    if(defaultTranslator != NULL)
        {
            defaultTranslator = NULL;
        }
}

/*********************************************************************
	File Path	: ../AnimTranslatorFactory.cpp
*********************************************************************/
