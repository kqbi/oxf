/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimRegisterOperations
	File Path	: ../AnimRegisterOperations.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimRegisterOperations_H
#define AnimRegisterOperations_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimRegisterOperations
#include "AnimAbstractMessage.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## auto_generated
class AnimField;

//## classInstance opDataList
class AnimListField;

//## operation clone()
class AnimMessage;

//## dependency AnimMessageField
class AnimMessageField;

//## operation addOpData(AnimOperationData*)
class AnimOperationData;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimRegisterOperations
// Used for registering operations in the animation browser.
class AnimRegisterOperations : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimRegisterOperations()
    AnimRegisterOperations();
    
    //## auto_generated
    virtual ~AnimRegisterOperations();
    
    ////    Operations    ////
    
    // Add an operation data to list.
    //## operation addOpData(AnimOperationData*)
    void addOpData(AnimOperationData* opData);
    
    // Clones the message object.
    // Attention: operations data are not cloned!!!
    //## operation clone()
    virtual AnimMessage* clone();

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimListField* getOpDataList() const;
    
    //## auto_generated
    AnimListField* newOpDataList();
    
    //## auto_generated
    void deleteOpDataList();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimRegisterOperations opDataListPrototype;		//## attribute opDataListPrototype
    
    ////    Relations and components    ////

protected :

    AnimListField* opDataList;		//## classInstance opDataList
};

#endif
/*********************************************************************
	File Path	: ../AnimRegisterOperations.h
*********************************************************************/
