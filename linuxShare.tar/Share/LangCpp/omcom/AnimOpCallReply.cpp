/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimOpCallReply
	File Path	: ../AnimOpCallReply.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimOpCallReply.h"
//## classInstance exceptionRaised
#include "AnimBooleanField.h"
//## auto_generated
#include "AnimField.h"
//## classInstance requestID
#include "AnimIntField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## classInstance callStr
#include "AnimStringField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimOpCallReply
AnimOpCallReply AnimOpCallReply::callReplyPrototype;

AnimOpCallReply::AnimOpCallReply() {
    initRelations();
    //#[ operation AnimOpCallReply()
    code = callOpReply;
    
    // set the names      
    exceptionRaised->setName("ExceptionFlag");
    retValue->setName("Return Value");
    callStr->setName("Call String");
    
    
    // initialize the exception field
    *exceptionRaised = FALSE;
    
    // add fields to container  
    addField(requestID);
    addField(exceptionRaised); 
    addField(retValue);
    addField(callStr);
    addField(showInConsole);
    
    //Set default values
    setShowInConsole(true);
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimOpCallReply::~AnimOpCallReply() {
    cleanUpRelations();
}

AnimMessage* AnimOpCallReply::clone() {
    //#[ operation clone()
    AnimOpCallReply *msg = new AnimOpCallReply();   
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));   
    
    
    // exception raised
    msg->setExceptionRaised((exceptionRaised->getValue() != 0));
    
    // ret value
    msg->setReturnValue(*retValue);
    
    // call str
    char *tmp = (char *)(rhp_long64_t)(getCallStr()->getValue());
    msg->setCallStr((OMString)(tmp));         
    delete[] tmp;
    
    // request id
    rhp_long64_t id = (rhp_long64_t)(getRequestID()->getValue());
    msg->setRequestID((int)id);
    
    // show in console
    bool showInConsoleValue = showInConsole->getValue() ? true : false;
    msg->setShowInConsole(showInConsoleValue);
    
    return msg;
    //#]
}

void AnimOpCallReply::setCallStr(OMString value) {
    //#[ operation setCallStr(OMString)
    *callStr = value;
    //#]
}

void AnimOpCallReply::setExceptionRaised(OMBoolean value) {
    //#[ operation setExceptionRaised(OMBoolean)
    (*exceptionRaised) = value;
    //#]
}

void AnimOpCallReply::setRequestID(int id) {
    //#[ operation setRequestID(int)
    *requestID = id;
    //#]
}

void AnimOpCallReply::setReturnValue(const AnimStringOrPointerField& value) {
    //#[ operation setReturnValue(const AnimStringOrPointerField&)
    
    (*retValue) = value;
    //#]
}

void AnimOpCallReply::setShowInConsole(bool value) {
    //#[ operation setShowInConsole(bool)
    *showInConsole = value;
    //#]
}

void AnimOpCallReply::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimStringField* AnimOpCallReply::getCallStr() const {
    return callStr;
}

AnimStringField* AnimOpCallReply::newCallStr() {
    callStr = new AnimStringField;
    return callStr;
}

void AnimOpCallReply::deleteCallStr() {
    delete callStr;
    callStr = NULL;
}

AnimBooleanField* AnimOpCallReply::getExceptionRaised() const {
    return exceptionRaised;
}

AnimBooleanField* AnimOpCallReply::newExceptionRaised() {
    exceptionRaised = new AnimBooleanField;
    return exceptionRaised;
}

void AnimOpCallReply::deleteExceptionRaised() {
    delete exceptionRaised;
    exceptionRaised = NULL;
}

AnimIntField* AnimOpCallReply::getRequestID() const {
    return requestID;
}

AnimIntField* AnimOpCallReply::newRequestID() {
    requestID = new AnimIntField;
    return requestID;
}

void AnimOpCallReply::deleteRequestID() {
    delete requestID;
    requestID = NULL;
}

AnimStringOrPointerField* AnimOpCallReply::getRetValue() const {
    return retValue;
}

AnimStringOrPointerField* AnimOpCallReply::newRetValue() {
    retValue = new AnimStringOrPointerField;
    return retValue;
}

void AnimOpCallReply::deleteRetValue() {
    delete retValue;
    retValue = NULL;
}

AnimBooleanField* AnimOpCallReply::getShowInConsole() const {
    return showInConsole;
}

AnimBooleanField* AnimOpCallReply::newShowInConsole() {
    showInConsole = new AnimBooleanField;
    return showInConsole;
}

void AnimOpCallReply::deleteShowInConsole() {
    delete showInConsole;
    showInConsole = NULL;
}

void AnimOpCallReply::initRelations() {
    callStr = newCallStr();
    exceptionRaised = newExceptionRaised();
    requestID = newRequestID();
    retValue = newRetValue();
    showInConsole = newShowInConsole();
}

void AnimOpCallReply::cleanUpRelations() {
    {
        deleteShowInConsole();
    }
    {
        deleteRetValue();
    }
    {
        deleteRequestID();
    }
    {
        deleteExceptionRaised();
    }
    {
        deleteCallStr();
    }
}

/*********************************************************************
	File Path	: ../AnimOpCallReply.cpp
*********************************************************************/
