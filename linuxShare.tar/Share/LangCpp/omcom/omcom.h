#ifndef omCom_H
#define omCom_H "$Id: omcom.h 1.5 2007/03/11 12:34:36 ilgiga Exp $"

//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/omcom/rcs/omcom.h $
//	file version:	$Revision: 1.5 $
//
//	purpose: all include files of omCom
//
//	author(s):	Yachin Pnueli
//	date started:	21.5.96
//	date changed:	$Date: 2007/03/11 12:34:36 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//

#include <omcom/om.h>
#include <omcom/om2str.h>
#include <omcom/ombrk.h>
#include <omcom/ommask.h>
#include <omcom/omnote.h>
#include <omcom/omsdata.h>
//
// $Log: omcom.h $
// Revision 1.5  2007/03/11 12:34:36  ilgiga
// Change copyright comment
// Revision 1.4  2007/03/01 16:43:32  ilgiga
// Telelogic instead of i-Logix
// Revision 1.3  2001/05/02 12:46:36  amos
// comment statements aftert #endif
// Revision 1.2  1997/04/07 22:56:24  ofer
// Move file names and includes to lowercase
// so UNIX will work with lowercase versions
// Revision 1.1  1996/11/24 12:37:18  yachin
// Initial revision
//

#endif // omCom_H
