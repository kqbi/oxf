/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimClassData
	File Path	: ../AnimClassData.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimClassData_H
#define AnimClassData_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimClassData
#include "AnimAbstractMessage.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## classInstance isSingleton
class AnimBooleanField;

//## auto_generated
class AnimField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## classInstance className
class AnimStringField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimClassData
// Holds class data for registering classes in browser.
class AnimClassData : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimClassData()
    AnimClassData();
    
    //## auto_generated
    virtual ~AnimClassData();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    // Set the class name.
    //## operation setClassName(OMString)
    void setClassName(OMString value);
    
    //## operation setIsSingleton(OMBoolean)
    void setIsSingleton(OMBoolean value);
    
    //## operation setPackageName(OMString)
    void setPackageName(OMString value);

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimStringField* getClassName() const;
    
    //## auto_generated
    AnimStringField* newClassName();
    
    //## auto_generated
    void deleteClassName();
    
    //## auto_generated
    AnimBooleanField* getIsSingleton() const;
    
    //## auto_generated
    AnimBooleanField* newIsSingleton();
    
    //## auto_generated
    void deleteIsSingleton();
    
    //## auto_generated
    AnimStringField* getPackageName() const;
    
    //## auto_generated
    AnimStringField* newPackageName();
    
    //## auto_generated
    void deletePackageName();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimClassData classDataPrototype;		//## attribute classDataPrototype
    
    ////    Relations and components    ////

protected :

    AnimStringField* className;		//## classInstance className
    
    AnimBooleanField* isSingleton;		//## classInstance isSingleton
    
    AnimStringField* packageName;		//## classInstance packageName
};

#endif
/*********************************************************************
	File Path	: ../AnimClassData.h
*********************************************************************/
