/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimStringOrPointerField
	File Path	: ../AnimStringOrPointerField.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimStringOrPointerField_H
#define AnimStringOrPointerField_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## class AnimStringOrPointerField
#include "AnimSimpleField.h"
//## operation getPointerValue() const
#include <oxf/rawtypes.h>
//## operation clone()
class AnimField;

//## operation decode(AnimMessageTranslator*)
class AnimMessageTranslator;

//## package RiCppAnimMessageTranslator

//## class AnimStringOrPointerField
// The field contains either a string value or a pointer value. It may be used for storing serilaized values of arguments or attributes.
class AnimStringOrPointerField : public AnimSimpleField {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    AnimStringOrPointerField();
    
    //## auto_generated
    virtual ~AnimStringOrPointerField();
    
    ////    Operations    ////
    
    //## operation clone()
    AnimField* clone();
    
    // Call translator to dencode field from its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to dencode field. 
    //## operation decode(AnimMessageTranslator*)
    virtual void decode(AnimMessageTranslator* translator);
    
    // Call translator to encode field to its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to encode field. 
    //## operation encode(AnimMessageTranslator*)
    virtual void encode(AnimMessageTranslator* translator);
    
    // Returns the pointer value.
    //## operation getPointerValue() const
    virtual gen_ptr getPointerValue() const;
    
    // Return the string value as void*.
    //## operation getStringValue(OMBoolean) const
    virtual void * getStringValue(OMBoolean cloneStr = TRUE) const;
    
    //## operation getValue() const
    virtual gen_ptr getValue() const;
    
    //## operation getValue(OMBoolean) const
    virtual gen_ptr getValue(OMBoolean cloneStr) const;
    
    //## operation isPointer() const
    OMBoolean isPointer() const;
    
    //## operation isString() const
    OMBoolean isString() const;
    
    //## operation operator=(const AnimStringOrPointerField&)
    AnimStringOrPointerField& operator=(const AnimStringOrPointerField& field);
    
    // Argument OMString val :
    // The value of the field.
    //## operation operator=(OMString)
    AnimStringOrPointerField& operator=(OMString val);
    
    // Argument gen_ptr pointerVal :
    // The pointer value of the field.
    //## operation operator=(gen_ptr)
    AnimStringOrPointerField& operator=(gen_ptr pointerVal);
    
    // Marks the field as containing a pointer value.
    //## operation setAsPointer()
    void setAsPointer();
    
    // Marks the field as containing a string value.
    //## operation setAsString()
    void setAsString();
    
    //## operation setPointerValue(gen_ptr)
    void setPointerValue(gen_ptr p_value);
    
    //## operation setStringValue(gen_ptr)
    void setStringValue(gen_ptr p_value);
    
    //## operation setValue(gen_ptr)
    void setValue(gen_ptr p_value);
    
    ////    Attributes    ////

protected :

    // FALSE means pointer value unspecified.
    // TRUE means the field contains pointer value.
    OMBoolean isPointerFlag;		//## attribute isPointerFlag
    
    // FALSE means string value unspecified.
    // TRUE means the field contains string value.
    OMBoolean isStringFlag;		//## attribute isStringFlag
    
    // Stores the pointer value.
    gen_ptr pointerValue;		//## attribute pointerValue
    
    // Stores the sting value.
    OMString stringValue;		//## attribute stringValue
};

#endif
/*********************************************************************
	File Path	: ../AnimStringOrPointerField.h
*********************************************************************/
