/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimForeignMessage
	File Path	: ../AnimForeignMessage.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimForeignMessage_H
#define AnimForeignMessage_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimForeignMessage
#include "AnimAbstractMessage.h"
//## dependency AnimStringOrPointerField
#include "AnimStringOrPointerField.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## auto_generated
class AnimField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimForeignMessage
// A message intended to be used by external plug ins. It has a single string payload which is used to store the information required to be sent from the application side to the plug-in.
class AnimForeignMessage : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimForeignMessage()
    AnimForeignMessage();
    
    //## auto_generated
    virtual ~AnimForeignMessage();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    // Set the payload
    //## operation setPayload(OMString)
    void setPayload(OMString value);

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimStringOrPointerField* getPayload() const;
    
    //## auto_generated
    AnimStringOrPointerField* newPayload();
    
    //## auto_generated
    void deletePayload();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimForeignMessage msgPrototype;		//## attribute msgPrototype
    
    ////    Relations and components    ////

protected :

    // The payload of the foreign message.
    AnimStringOrPointerField* payload;		//## classInstance payload
};

#endif
/*********************************************************************
	File Path	: ../AnimForeignMessage.h
*********************************************************************/
