/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimField
	File Path	: ../AnimField.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimField.h"
//## operation decode(AnimMessageTranslator*)
#include "AnimMessageTranslator.h"
//## package RiCppAnimMessageTranslator

//## class AnimField
AnimField::AnimField() {
}

AnimField::~AnimField() {
}

OMString AnimField::getName() const {
    return name;
}

void AnimField::setName(OMString p_name) {
    name = p_name;
}

/*********************************************************************
	File Path	: ../AnimField.cpp
*********************************************************************/
