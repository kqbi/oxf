/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimQuitExecutable
	File Path	: ../AnimQuitExecutable.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimQuitExecutable_H
#define AnimQuitExecutable_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimQuitExecutable
#include "AnimAbstractMessage.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## auto_generated
class AnimField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimQuitExecutable
// A command for quiting the executable.
class AnimQuitExecutable : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimQuitExecutable()
    AnimQuitExecutable();
    
    //## auto_generated
    virtual ~AnimQuitExecutable();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimQuitExecutable quitExecutablePrototype;		//## attribute quitExecutablePrototype
};

#endif
/*********************************************************************
	File Path	: ../AnimQuitExecutable.h
*********************************************************************/
