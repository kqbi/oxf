/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimTimeRequest
	File Path	: ../AnimTimeRequest.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimTimeRequest_H
#define AnimTimeRequest_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimTimeRequest
#include "AnimAbstractMessage.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## auto_generated
class AnimField;

//## classInstance timeInterval
class AnimIntField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimTimeRequest
// Requests to be notified after time interval has elapsed.
// The notification should be AnimTimeNotification
class AnimTimeRequest : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimTimeRequest()
    AnimTimeRequest();
    
    //## auto_generated
    virtual ~AnimTimeRequest();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    //## operation setTimeInterval(int)
    void setTimeInterval(int value);

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimIntField* getTimeInterval() const;
    
    //## auto_generated
    AnimIntField* createNewTimeInterval();
    
    //## auto_generated
    void deleteTimeInterval();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimTimeRequest _timeRequest;		//## attribute _timeRequest
    
    ////    Relations and components    ////

protected :

    AnimIntField* timeInterval;		//## classInstance timeInterval
};

#endif
/*********************************************************************
	File Path	: ../AnimTimeRequest.h
*********************************************************************/
