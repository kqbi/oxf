#ifndef ombrk_H
#define ombrk_H "$Id: ombrk.h 1.6 2007/03/11 12:34:36 ilgiga Exp $"

//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/omcom/rcs/ombrk.h $
//	file version:	$Revision: 1.6 $
//
//	purpose:	The Breakpoint reasons
//
//	author(s):	  Yachin Pnueli
//	date started:	16.10.96
//	date changed:	$Date: 2007/03/11 12:34:36 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#include "omnote.h"

class RP_ANIM_DLL OMBreakPoint {
protected:
	OMNotify myType;
	void * myItem;
	OMString myData;
public:
	OMBreakPoint(OMNotify theType,
				 void * theItem,
				 const char *theData="") {
		myType = theType;
		myItem = theItem;
		myData = (char*)theData;
	}
	OMBoolean matchBreakPoint(OMNotify theType,
				 void * theItem,
				 const char *theData) {
		return myType == theType &&
			myItem == theItem &&
			myData == theData;
	}
	OMNotify getType() const { return myType; }
	void * getItem() const { return myItem; }
};

//
// $Log: ombrk.h $
// Revision 1.6  2007/03/11 12:34:36  ilgiga
// Change copyright comment
// Revision 1.5  2007/03/01 16:43:31  ilgiga
// Telelogic instead of i-Logix
// Revision 1.4  1999/11/08 14:01:50  zvika
// Add DLLs.
// Revision 1.3  1998/08/02 15:08:57  beery
// changing boolean->OMBoolean
// Revision 1.2  1996/12/02 12:06:42  yachin
// Revision 1.1  1996/11/24 12:37:17  yachin
// Initial revision
//
#endif
