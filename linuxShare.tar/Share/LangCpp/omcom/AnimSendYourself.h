/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimSendYourself
	File Path	: ../AnimSendYourself.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimSendYourself_H
#define AnimSendYourself_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimSendYourself
#include "AnimAbstractMessage.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## auto_generated
class AnimField;

//## classInstance interestMask
class AnimIntField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimSendYourself
// A request for serializing an anim item.
class AnimSendYourself : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimSendYourself()
    AnimSendYourself();
    
    //## auto_generated
    virtual ~AnimSendYourself();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    //## operation setInterestMask(int)
    void setInterestMask(int value);

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimIntField* getInterestMask() const;
    
    //## auto_generated
    AnimIntField* newInterestMask();
    
    //## auto_generated
    void deleteInterestMask();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimSendYourself animSendYourself;		//## attribute animSendYourself
    
    ////    Relations and components    ////

protected :

    AnimIntField* interestMask;		//## classInstance interestMask
};

#endif
/*********************************************************************
	File Path	: ../AnimSendYourself.h
*********************************************************************/
