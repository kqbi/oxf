/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimIntField
	File Path	: ../AnimIntField.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimIntField_H
#define AnimIntField_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## class AnimIntField
#include "AnimSimpleField.h"
//## operation getValue() const
#include <oxf/rawtypes.h>
//## operation clone()
class AnimField;

//## operation decode(AnimMessageTranslator*)
class AnimMessageTranslator;

//## package RiCppAnimMessageTranslator

//## class AnimIntField
class AnimIntField : public AnimSimpleField {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimIntField()
    AnimIntField();
    
    //## auto_generated
    virtual ~AnimIntField();
    
    ////    Operations    ////
    
    //## operation clone()
    AnimField* clone();
    
    // Call translator to dencode field from its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to dencode field. 
    //## operation decode(AnimMessageTranslator*)
    virtual void decode(AnimMessageTranslator* translator);
    
    // Call translator to encode field to its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to encode field. 
    //## operation encode(AnimMessageTranslator*)
    virtual void encode(AnimMessageTranslator* translator);
    
    // Get the scalar value.
    //## operation getValue() const
    virtual gen_ptr getValue() const;
    
    //## operation operator=(const AnimIntField&)
    AnimIntField& operator=(const AnimIntField& field);
    
    // Argument int val :
    // The value of the field.
    //## operation operator=(int)
    AnimIntField& operator=(int val);
    
    //## operation setValue(gen_ptr)
    void setValue(gen_ptr p_value);
    
    ////    Attributes    ////

protected :

    int value;		//## attribute value
};

#endif
/*********************************************************************
	File Path	: ../AnimIntField.h
*********************************************************************/
