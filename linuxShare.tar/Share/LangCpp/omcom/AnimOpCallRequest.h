/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimOpCallRequest
	File Path	: ../AnimOpCallRequest.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimOpCallRequest_H
#define AnimOpCallRequest_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimOpCallRequest
#include "AnimAbstractMessage.h"
//## dependency AnimStringOrPointerField
#include "AnimStringOrPointerField.h"
//## operation addArgValue(gen_ptr)
#include "oxf/rawtypes.h"
//## classInstance doImmediately
class AnimBooleanField;

//## auto_generated
class AnimField;

//## classInstance requestID
class AnimIntField;

//## classInstance argValues
class AnimListField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## classInstance signature
class AnimStringField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimOpCallRequest
// A request to call an operation.
class AnimOpCallRequest : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimOpCallRequest()
    AnimOpCallRequest();
    
    //## auto_generated
    virtual ~AnimOpCallRequest();
    
    ////    Operations    ////
    
    // Adds a value to argument values list.
    //## operation addArgValue(gen_ptr)
    void addArgValue(gen_ptr value);
    
    // Adds a value to argument values list.
    //## operation addArgValue(OMString)
    void addArgValue(OMString value);
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    // Fully clones all fields including the AnimListField.
    //## operation fullClone()
    virtual AnimOpCallRequest* fullClone();
    
    //## operation setClass(gen_ptr)
    void setClass(gen_ptr value);
    
    //## operation setDoImmediately(bool)
    void setDoImmediately(bool value);
    
    //## operation setInstance(gen_ptr)
    void setInstance(gen_ptr value);
    
    // Set the class name.
    //## operation setOp(gen_ptr)
    void setOp(gen_ptr value);
    
    //## operation setRequestID(int)
    void setRequestID(int id);
    
    //## operation setShowInConsole(bool)
    void setShowInConsole(bool value);
    
    //## operation setSignature(OMString)
    void setSignature(OMString value);

protected :

    //## operation cleanUpRelations()
    void cleanUpRelations();
    
    //## operation initRelations()
    void initRelations();
    
    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimListField* getArgValues() const;
    
    //## auto_generated
    AnimListField* newArgValues();
    
    //## auto_generated
    void deleteArgValues();
    
    //## auto_generated
    AnimBooleanField* getDoImmediately() const;
    
    //## auto_generated
    AnimBooleanField* newDoImmediately();
    
    //## auto_generated
    void deleteDoImmediately();
    
    //## auto_generated
    AnimPointerField* getInstance() const;
    
    //## auto_generated
    AnimPointerField* newInstance();
    
    //## auto_generated
    void deleteInstance();
    
    //## auto_generated
    AnimPointerField* getOp() const;
    
    //## auto_generated
    AnimPointerField* newOp();
    
    //## auto_generated
    void deleteOp();
    
    //## auto_generated
    AnimPointerField* getOpClass() const;
    
    //## auto_generated
    AnimPointerField* newOpClass();
    
    //## auto_generated
    void deleteOpClass();
    
    //## auto_generated
    AnimIntField* getRequestID() const;
    
    //## auto_generated
    AnimIntField* newRequestID();
    
    //## auto_generated
    void deleteRequestID();
    
    //## auto_generated
    AnimBooleanField* getShowInConsole() const;
    
    //## auto_generated
    AnimBooleanField* newShowInConsole();
    
    //## auto_generated
    void deleteShowInConsole();
    
    //## auto_generated
    AnimStringField* getSignature() const;
    
    //## auto_generated
    AnimStringField* newSignature();
    
    //## auto_generated
    void deleteSignature();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimOpCallRequest callRequestPrototype;		//## attribute callRequestPrototype
    
    ////    Relations and components    ////

protected :

    // A list of AnimStringOrPointerField that hold the values of the arguments.
    AnimListField* argValues;		//## classInstance argValues
    
    // This flag indicates that the operation should be queued but performed immediately.
    AnimBooleanField* doImmediately;		//## classInstance doImmediately
    
    // The intsance on which the operation is to be invoked.
    AnimPointerField* instance;		//## classInstance instance
    
    // A pointer to the operation to invoke.
    AnimPointerField* op;		//## classInstance op
    
    AnimPointerField* opClass;		//## classInstance opClass
    
    AnimIntField* requestID;		//## classInstance requestID
    
    // Whether to print a message in the console regarding this operation call
    AnimBooleanField* showInConsole;		//## classInstance showInConsole
    
    // The signature of the operation. For example: "f(int, char*)"
    AnimStringField* signature;		//## classInstance signature
};

#endif
/*********************************************************************
	File Path	: ../AnimOpCallRequest.h
*********************************************************************/
