/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimMessage
	File Path	: ../AnimMessage.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimMessage.h"
//## operation getNextField()
#include "AnimField.h"
//## operation setNextField(AnimMessageField*)
#include "AnimMessageField.h"
//## operation getDestOrSource() const
#include "AnimPointerField.h"
//## operation getTimeStamp()
#include "AnimTimestampField.h"
//## package RiCppAnimMessageTranslator

//## class AnimMessage
AnimMessage::AnimMessage() {
}

AnimMessage::~AnimMessage() {
}

/*********************************************************************
	File Path	: ../AnimMessage.cpp
*********************************************************************/
