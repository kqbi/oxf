/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimSuspendThread
	File Path	: ../AnimSuspendThread.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimSuspendThread_H
#define AnimSuspendThread_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimSuspendThread
#include "AnimAbstractMessage.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## auto_generated
class AnimField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimSuspendThread
// A command for suspending a thread.
class AnimSuspendThread : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimSuspendThread()
    AnimSuspendThread();
    
    //## auto_generated
    virtual ~AnimSuspendThread();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimSuspendThread animSuspendThread;		//## attribute animSuspendThread
};

#endif
/*********************************************************************
	File Path	: ../AnimSuspendThread.h
*********************************************************************/
