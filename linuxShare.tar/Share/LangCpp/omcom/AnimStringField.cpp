/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimStringField
	File Path	: ../AnimStringField.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimStringField.h"
//## operation clone()
#include "AnimField.h"
//## operation decode(AnimMessageTranslator*)
#include "AnimMessageTranslator.h"
//## package RiCppAnimMessageTranslator

//## class AnimStringField
AnimStringField::AnimStringField() {
}

AnimStringField::~AnimStringField() {
}

AnimField* AnimStringField::clone() {
    //#[ operation clone()
    AnimStringField *f = new AnimStringField();
    f->name = name;
    f->value = value;
    return f;
    //#]
}

void AnimStringField::decode(AnimMessageTranslator* translator) {
    //#[ operation decode(AnimMessageTranslator*)
    translator->decodeField(this);
    //#]
}

void AnimStringField::encode(AnimMessageTranslator* translator) {
    //#[ operation encode(AnimMessageTranslator*)
    translator->encodeField(this);
    
    //#]
}

gen_ptr AnimStringField::getValue() const {
    //#[ operation getValue() const
    OMString cpy = value;
    int len = cpy.GetLength();
    char* s = new char[len+1];
    strcpy(s, cpy.GetBuffer(0));
    
    return (gen_ptr)(rhp_long64_t)s;
    
    //#]
}

AnimStringField& AnimStringField::operator=(const AnimStringField& field) {
    //#[ operation operator=(const AnimStringField&)
    if (this != &field)   
    {   
        setName(field.getName());
        setValue(field.getValue());
    }
    return *this;
    //#]
}

AnimStringField& AnimStringField::operator=(OMString val) {
    //#[ operation operator=(OMString)
    const char * tmp = (const char *)val;
    setValue((gen_ptr)(rhp_long64_t)tmp);
    return *this;
    //#]
}

void AnimStringField::setValue(gen_ptr p_value) {
    //#[ operation setValue(gen_ptr)
    
    value = (OMString)((char *)(rhp_long64_t)p_value);
    
    //#]
}

/*********************************************************************
	File Path	: ../AnimStringField.cpp
*********************************************************************/
