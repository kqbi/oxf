/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimSendYourself
	File Path	: ../AnimSendYourself.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimSendYourself.h"
//## auto_generated
#include "AnimField.h"
//## classInstance interestMask
#include "AnimIntField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimSendYourself
AnimSendYourself AnimSendYourself::animSendYourself;

AnimSendYourself::AnimSendYourself() {
    initRelations();
    //#[ operation AnimSendYourself()
    code = sendYourself;
    
    // set the names
    interestMask->setName("interestMask");
    
    // add fields to container
    addField(interestMask);
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimSendYourself::~AnimSendYourself() {
    cleanUpRelations();
}

AnimMessage* AnimSendYourself::clone() {
    //#[ operation clone()
    AnimSendYourself *msg = new AnimSendYourself();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    rhp_long64_t lVal = (rhp_long64_t)(getInterestMask()->getValue());
    msg->setInterestMask((int)lVal);
    return msg;
    //#]
}

void AnimSendYourself::setInterestMask(int value) {
    //#[ operation setInterestMask(int)
    *interestMask = value;
    //#]
}

void AnimSendYourself::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimIntField* AnimSendYourself::getInterestMask() const {
    return interestMask;
}

AnimIntField* AnimSendYourself::newInterestMask() {
    interestMask = new AnimIntField;
    return interestMask;
}

void AnimSendYourself::deleteInterestMask() {
    delete interestMask;
    interestMask = NULL;
}

void AnimSendYourself::initRelations() {
    interestMask = newInterestMask();
}

void AnimSendYourself::cleanUpRelations() {
    {
        deleteInterestMask();
    }
}

/*********************************************************************
	File Path	: ../AnimSendYourself.cpp
*********************************************************************/
