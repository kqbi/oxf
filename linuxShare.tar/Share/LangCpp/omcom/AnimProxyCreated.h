/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimProxyCreated
	File Path	: ../AnimProxyCreated.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimProxyCreated_H
#define AnimProxyCreated_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimProxyCreated
#include "AnimAbstractMessage.h"
//## operation setProxy(gen_ptr)
#include "oxf/rawtypes.h"
//## auto_generated
class AnimField;

//## classInstance interestMask
class AnimIntField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimProxyCreated
// A message that informs the application that a proxy on the orher side was created. It contains the id\address of that proxy.
class AnimProxyCreated : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimProxyCreated()
    AnimProxyCreated();
    
    //## auto_generated
    virtual ~AnimProxyCreated();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    //## operation setInterestMask(int)
    void setInterestMask(int value);
    
    //## operation setProxy(gen_ptr)
    void setProxy(gen_ptr value);

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimIntField* getInterestMask() const;
    
    //## auto_generated
    AnimIntField* newInterestMask();
    
    //## auto_generated
    void deleteInterestMask();
    
    //## auto_generated
    AnimPointerField* getProxy() const;
    
    //## auto_generated
    AnimPointerField* newProxy();
    
    //## auto_generated
    void deleteProxy();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimProxyCreated proxyCreatedPrototype;		//## attribute proxyCreatedPrototype
    
    ////    Relations and components    ////

protected :

    AnimIntField* interestMask;		//## classInstance interestMask
    
    AnimPointerField* proxy;		//## classInstance proxy
};

#endif
/*********************************************************************
	File Path	: ../AnimProxyCreated.h
*********************************************************************/
