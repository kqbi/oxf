/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimTimestampField
	File Path	: ../AnimTimestampField.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimTimestampField_H
#define AnimTimestampField_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## class AnimTimestampField
#include "AnimSimpleField.h"
//## operation getValue() const
#include <oxf/rawtypes.h>
//## operation clone()
class AnimField;

//## operation decode(AnimMessageTranslator*)
class AnimMessageTranslator;

//## package RiCppAnimMessageTranslator

//## class AnimTimestampField
class AnimTimestampField : public AnimSimpleField {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimTimestampField()
    AnimTimestampField();
    
    //## auto_generated
    virtual ~AnimTimestampField();
    
    ////    Operations    ////
    
    //## operation clone()
    AnimField* clone();
    
    // Call translator to dencode field from its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to dencode field. 
    //## operation decode(AnimMessageTranslator*)
    virtual void decode(AnimMessageTranslator* translator);
    
    // Call translator to encode field to its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to encode field. 
    //## operation encode(AnimMessageTranslator*)
    virtual void encode(AnimMessageTranslator* translator);
    
    // Get the scalar value.
    //## operation getValue() const
    virtual gen_ptr getValue() const;
    
    //## operation operator=(const AnimTimestampField&)
    AnimTimestampField& operator=(const AnimTimestampField& timestampField);
    
    // Argument timeUnit val :
    // The timestamp value of the field.
    //## operation operator=(timeUnit)
    AnimTimestampField& operator=(timeUnit val);
    
    //## operation setValue(gen_ptr)
    void setValue(gen_ptr p_value);
    
    ////    Additional operations    ////
    
    //## auto_generated
    OMBoolean isValueSet() const;
    
    ////    Attributes    ////
    
    // Indicates if value is set or not.
    OMBoolean valueSet;		//## attribute valueSet

protected :

    timeUnit value;		//## attribute value
};

#endif
/*********************************************************************
	File Path	: ../AnimTimestampField.h
*********************************************************************/
