/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimAllocateCore
	File Path	: ../AnimAllocateCore.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimAllocateCore_H
#define AnimAllocateCore_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimAllocateCore
#include "AnimAbstractMessage.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## auto_generated
class AnimField;

//## operation getAffinity() const
class AnimIntField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimAllocateCore
// A message sent when an active class is allocated to a core. Currently it contains two fields - affinity and power mode.
class AnimAllocateCore : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimAllocateCore()
    AnimAllocateCore();
    
    //## auto_generated
    virtual ~AnimAllocateCore();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    //## operation getAffinity() const
    AnimIntField* getAffinity() const;
    
    //## operation getPowerMode() const
    AnimIntField* getPowerMode() const;
    
    //## operation isConstructionMessage()
    bool isConstructionMessage();
    
    //## operation newAffinity()
    AnimIntField* newAffinity();
    
    //## operation newPowerMode()
    AnimIntField* newPowerMode();
    
    // Set the payload
    //## operation setAffinity(int)
    void setAffinity(int value);
    
    // Set the payload
    //## operation setPowerMode(int)
    void setPowerMode(int value);

protected :

    //## operation cleanUpRelations()
    void cleanUpRelations();
    
    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    void deleteAffinity();
    
    //## auto_generated
    void deletePowerMode();

protected :

    //## auto_generated
    void initRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimAllocateCore msgPrototype;		//## attribute msgPrototype
    
    ////    Relations and components    ////

protected :

    // The affinity to cores
    AnimIntField* affinity;		//## classInstance affinity
    
    // The affinity to cores
    AnimIntField* powerMode;		//## classInstance powerMode
};

#endif
/*********************************************************************
	File Path	: ../AnimAllocateCore.h
*********************************************************************/
