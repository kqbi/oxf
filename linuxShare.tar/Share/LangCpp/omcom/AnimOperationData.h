/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimOperationData
	File Path	: ../AnimOperationData.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimOperationData_H
#define AnimOperationData_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimOperationData
#include "AnimAbstractMessage.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## classInstance isStatic
class AnimBooleanField;

//## auto_generated
class AnimField;

//## classInstance numOfArgs
class AnimIntField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## classInstance opName
class AnimStringField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimOperationData
// Holds operation data for registering registering in browser.
// 
// The destOrSource field holds the AOM address.
class AnimOperationData : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimOperationData()
    AnimOperationData();
    
    //## auto_generated
    virtual ~AnimOperationData();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    //## operation setIsStatic(OMBoolean)
    void setIsStatic(OMBoolean value);
    
    //## operation setNumOfArgs(int)
    void setNumOfArgs(int value);
    
    // Set the class name.
    //## operation setOpName(OMString)
    void setOpName(OMString value);
    
    //## operation setSignature(OMString)
    void setSignature(OMString value);

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimBooleanField* getIsStatic() const;
    
    //## auto_generated
    AnimBooleanField* newIsStatic();
    
    //## auto_generated
    void deleteIsStatic();
    
    //## auto_generated
    AnimIntField* getNumOfArgs() const;
    
    //## auto_generated
    AnimIntField* newNumOfArgs();
    
    //## auto_generated
    void deleteNumOfArgs();
    
    //## auto_generated
    AnimStringField* getOpName() const;
    
    //## auto_generated
    AnimStringField* newOpName();
    
    //## auto_generated
    void deleteOpName();
    
    //## auto_generated
    AnimStringField* getSignature() const;
    
    //## auto_generated
    AnimStringField* newSignature();
    
    //## auto_generated
    void deleteSignature();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimOperationData opDataPrototype;		//## attribute opDataPrototype
    
    ////    Relations and components    ////

protected :

    AnimBooleanField* isStatic;		//## classInstance isStatic
    
    // Number of arguments.
    AnimIntField* numOfArgs;		//## classInstance numOfArgs
    
    AnimStringField* opName;		//## classInstance opName
    
    // The signature of the operation. For example: "f(int, char*)"
    AnimStringField* signature;		//## classInstance signature
};

#endif
/*********************************************************************
	File Path	: ../AnimOperationData.h
*********************************************************************/
