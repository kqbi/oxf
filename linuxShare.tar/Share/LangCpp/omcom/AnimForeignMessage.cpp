/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimForeignMessage
	File Path	: ../AnimForeignMessage.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimForeignMessage.h"
//## auto_generated
#include "AnimField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimForeignMessage
AnimForeignMessage AnimForeignMessage::msgPrototype;

AnimForeignMessage::AnimForeignMessage() {
    initRelations();
    //#[ operation AnimForeignMessage()
    code = foreignMsg;
    
    // set the names      
    payload->setName("Payload");
    
    // add fields to container  
    addField(payload);
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimForeignMessage::~AnimForeignMessage() {
    cleanUpRelations();
}

AnimMessage* AnimForeignMessage::clone() {
    //#[ operation clone()
    AnimForeignMessage *msg = new AnimForeignMessage();   
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));   
    
    // call str
    char* tmp = (char*)(rhp_long64_t)getPayload()->getValue();
    msg->setPayload((OMString)tmp);         
    delete[] tmp;
    
    return msg;
    //#]
}

void AnimForeignMessage::setPayload(OMString value) {
    //#[ operation setPayload(OMString)
    *payload = value;
    //#]
}

void AnimForeignMessage::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimStringOrPointerField* AnimForeignMessage::getPayload() const {
    return payload;
}

AnimStringOrPointerField* AnimForeignMessage::newPayload() {
    payload = new AnimStringOrPointerField;
    return payload;
}

void AnimForeignMessage::deletePayload() {
    delete payload;
    payload = NULL;
}

void AnimForeignMessage::initRelations() {
    payload = newPayload();
}

void AnimForeignMessage::cleanUpRelations() {
    {
        deletePayload();
    }
}

/*********************************************************************
	File Path	: ../AnimForeignMessage.cpp
*********************************************************************/
