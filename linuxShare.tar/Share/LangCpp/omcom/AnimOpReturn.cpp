/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimOpReturn
	File Path	: ../AnimOpReturn.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimOpReturn.h"
//## classInstance isOMReturnMacro
#include "AnimBooleanField.h"
//## auto_generated
#include "AnimField.h"
//## classInstance argDataList
#include "AnimListField.h"
//## operation clone()
#include "AnimMessage.h"
//## dependency AnimMessageField
#include "AnimMessageField.h"
//## operation addArgData(AnimNameValueData*)
#include "AnimNameValueData.h"
//## auto_generated
#include "AnimPointerField.h"
//## operation setReturnValue(const AnimStringOrPointerField&)
#include "AnimStringOrPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimOpReturn
AnimOpReturn AnimOpReturn::opReturnPrototype;

AnimOpReturn::AnimOpReturn() {
    initRelations();
    //#[ operation AnimOpReturn()
    code = opReturn;
    
    // set the names 
    retValue->setName("Return Value");     
    argDataList->setName("argDataList"); 
    isOMReturnMacro->setName("isOMReturnMacro");
    
    
    // set list prototype
    AnimMessageField msgField;
    argDataList->setFieldPrototype(&msgField);
    
    
    // add fields to container        
    addField(retValue);
    addField(argDataList);
    addField(isOMReturnMacro);
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimOpReturn::~AnimOpReturn() {
    cleanUpRelations();
}

void AnimOpReturn::addArg(char* argName, char* argValue) {
    //#[ operation addArg(char*,char*)
    AnimNameValueData argData;     
    argData.setTheName(argName);
    AnimStringOrPointerField valField;
    valField.setStringValue((gen_ptr)(rhp_long64_t)argValue);
    argData.setTheValue(valField);   
    addArgData(&argData);
    
    //#]
}

void AnimOpReturn::addArg(char* argName, void * argValue) {
    //#[ operation addArg(char*,void *)
    AnimNameValueData argData;     
    argData.setTheName(argName);
    AnimStringOrPointerField valField;
    valField.setPointerValue((gen_ptr)(rhp_long64_t)argValue);
    argData.setTheValue(valField);   
    addArgData(&argData);
    
    //#]
}

void AnimOpReturn::addArgData(AnimNameValueData* argData) {
    //#[ operation addArgData(AnimNameValueData*)
    AnimMessageField *msgField = new AnimMessageField(); 
    msgField->setValue((gen_ptr)(rhp_long64_t)argData);
    argDataList->addField(msgField);
    //#]
}

AnimMessage* AnimOpReturn::clone() {
    //#[ operation clone()
    AnimOpReturn *msg = new AnimOpReturn();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    
    // ret value
    msg->setReturnValue(*retValue); 
    
    msg->setIsOMReturnMacro(getIsOMReturnMacro()->getValue() != 0);
    
    //msg->argDataList = argDataList;
    return msg;
    //#]
}

void AnimOpReturn::setIsOMReturnMacro(OMBoolean value) {
    //#[ operation setIsOMReturnMacro(OMBoolean)
    *isOMReturnMacro = value;
    //#]
}

void AnimOpReturn::setReturnValue(const AnimStringOrPointerField& value) {
    //#[ operation setReturnValue(const AnimStringOrPointerField&)
    
    (*retValue) = value;
    //#]
}

void AnimOpReturn::setReturnValue(void * pValue) {
    //#[ operation setReturnValue(void *)
    retValue->setPointerValue((gen_ptr)(rhp_long64_t)pValue);
    //#]
}

void AnimOpReturn::setReturnValue(const char* cValue) {
    //#[ operation setReturnValue(const char*)
    retValue->setStringValue((gen_ptr)(rhp_long64_t)cValue);
    //#]
}

void AnimOpReturn::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimListField* AnimOpReturn::getArgDataList() const {
    return argDataList;
}

AnimListField* AnimOpReturn::newArgDataList() {
    argDataList = new AnimListField;
    return argDataList;
}

void AnimOpReturn::deleteArgDataList() {
    delete argDataList;
    argDataList = NULL;
}

AnimBooleanField* AnimOpReturn::getIsOMReturnMacro() const {
    return isOMReturnMacro;
}

AnimBooleanField* AnimOpReturn::newIsOMReturnMacro() {
    isOMReturnMacro = new AnimBooleanField;
    return isOMReturnMacro;
}

void AnimOpReturn::deleteIsOMReturnMacro() {
    delete isOMReturnMacro;
    isOMReturnMacro = NULL;
}

AnimStringOrPointerField* AnimOpReturn::getRetValue() const {
    return retValue;
}

AnimStringOrPointerField* AnimOpReturn::newRetValue() {
    retValue = new AnimStringOrPointerField;
    return retValue;
}

void AnimOpReturn::deleteRetValue() {
    delete retValue;
    retValue = NULL;
}

void AnimOpReturn::initRelations() {
    argDataList = newArgDataList();
    isOMReturnMacro = newIsOMReturnMacro();
    retValue = newRetValue();
}

void AnimOpReturn::cleanUpRelations() {
    {
        deleteRetValue();
    }
    {
        deleteIsOMReturnMacro();
    }
    {
        deleteArgDataList();
    }
}

/*********************************************************************
	File Path	: ../AnimOpReturn.cpp
*********************************************************************/
