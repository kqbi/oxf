/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimSimpleField
	File Path	: ../AnimSimpleField.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimSimpleField.h"
//## package RiCppAnimMessageTranslator

//## class AnimSimpleField
AnimSimpleField::AnimSimpleField() {
}

AnimSimpleField::~AnimSimpleField() {
}

/*********************************************************************
	File Path	: ../AnimSimpleField.cpp
*********************************************************************/
