/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimResumeThread
	File Path	: ../AnimResumeThread.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimResumeThread_H
#define AnimResumeThread_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimResumeThread
#include "AnimAbstractMessage.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## auto_generated
class AnimField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimResumeThread
// A command for resuming a thread.
class AnimResumeThread : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimResumeThread()
    AnimResumeThread();
    
    //## auto_generated
    virtual ~AnimResumeThread();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimResumeThread animResumeThread;		//## attribute animResumeThread
};

#endif
/*********************************************************************
	File Path	: ../AnimResumeThread.h
*********************************************************************/
