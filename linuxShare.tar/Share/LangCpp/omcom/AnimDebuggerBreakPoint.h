/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimDebuggerBreakPoint
	File Path	: ../AnimDebuggerBreakPoint.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimDebuggerBreakPoint_H
#define AnimDebuggerBreakPoint_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimDebuggerBreakPoint
#include "AnimAbstractMessage.h"
//## dependency AnimStringOrPointerField
#include "AnimStringOrPointerField.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## classInstance isRhapsodyBreak
class AnimBooleanField;

//## auto_generated
class AnimField;

//## classInstance taskID
class AnimIntField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimDebuggerBreakPoint
// A notification a debugger breakpoint is about to take place.
class AnimDebuggerBreakPoint : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimDebuggerBreakPoint()
    AnimDebuggerBreakPoint();
    
    //## auto_generated
    virtual ~AnimDebuggerBreakPoint();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    //## operation setIsRhapsodyBreak(OMBoolean)
    void setIsRhapsodyBreak(OMBoolean value);
    
    //## operation setTaskID(int)
    void setTaskID(int id);

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimBooleanField* getIsRhapsodyBreak() const;
    
    //## auto_generated
    AnimBooleanField* newIsRhapsodyBreak();
    
    //## auto_generated
    void deleteIsRhapsodyBreak();
    
    //## auto_generated
    AnimIntField* getTaskID() const;
    
    //## auto_generated
    AnimIntField* newTaskID();
    
    //## auto_generated
    void deleteTaskID();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimDebuggerBreakPoint animDebuggerBreakPointPrototype;		//## attribute animDebuggerBreakPointPrototype
    
    ////    Relations and components    ////

protected :

    // Indicates if an exception was raised.
    AnimBooleanField* isRhapsodyBreak;		//## classInstance isRhapsodyBreak
    
    AnimIntField* taskID;		//## classInstance taskID
};

#endif
/*********************************************************************
	File Path	: ../AnimDebuggerBreakPoint.h
*********************************************************************/
