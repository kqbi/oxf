/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimField
	File Path	: ../AnimField.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimField_H
#define AnimField_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## operation decode(AnimMessageTranslator*)
class AnimMessageTranslator;

//## package RiCppAnimMessageTranslator

//## class AnimField
class AnimField {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    AnimField();
    
    //## auto_generated
    virtual ~AnimField() = 0;
    
    ////    Operations    ////
    
    //## operation clone()
    virtual AnimField* clone() = 0;
    
    // Call translator to dencode field from its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to dencode field. 
    //## operation decode(AnimMessageTranslator*)
    virtual void decode(AnimMessageTranslator* translator) = 0;
    
    // Call translator to encode field to its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to encode field. 
    //## operation encode(AnimMessageTranslator*)
    virtual void encode(AnimMessageTranslator* translator) = 0;
    
    ////    Additional operations    ////
    
    //## auto_generated
    OMString getName() const;
    
    //## auto_generated
    void setName(OMString p_name);
    
    ////    Attributes    ////

protected :

    OMString name;		//## attribute name
};

#endif
/*********************************************************************
	File Path	: ../AnimField.h
*********************************************************************/
