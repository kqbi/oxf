/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimRegisterOperations
	File Path	: ../AnimRegisterOperations.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimRegisterOperations.h"
//## auto_generated
#include "AnimField.h"
//## classInstance opDataList
#include "AnimListField.h"
//## operation clone()
#include "AnimMessage.h"
//## dependency AnimMessageField
#include "AnimMessageField.h"
//## operation addOpData(AnimOperationData*)
#include "AnimOperationData.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimRegisterOperations
AnimRegisterOperations AnimRegisterOperations::opDataListPrototype;

AnimRegisterOperations::AnimRegisterOperations() {
    initRelations();
    //#[ operation AnimRegisterOperations()
    code = opList;
    
    // set the names      
    opDataList->setName("opDataList");
    
    
    // set list prototype
    AnimMessageField msgField;
    opDataList->setFieldPrototype(&msgField);
    
    
    // add fields to container
    addField(opDataList); 
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimRegisterOperations::~AnimRegisterOperations() {
    cleanUpRelations();
}

void AnimRegisterOperations::addOpData(AnimOperationData* opData) {
    //#[ operation addOpData(AnimOperationData*)
    AnimMessageField *msgField = new AnimMessageField(); 
    msgField->setValue((gen_ptr)(rhp_long64_t)opData);
    opDataList->addField(msgField);
    //#]
}

AnimMessage* AnimRegisterOperations::clone() {
    //#[ operation clone()
    AnimRegisterOperations *msg = new AnimRegisterOperations();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    return msg;
    //#]
}

void AnimRegisterOperations::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimListField* AnimRegisterOperations::getOpDataList() const {
    return opDataList;
}

AnimListField* AnimRegisterOperations::newOpDataList() {
    opDataList = new AnimListField;
    return opDataList;
}

void AnimRegisterOperations::deleteOpDataList() {
    delete opDataList;
    opDataList = NULL;
}

void AnimRegisterOperations::initRelations() {
    opDataList = newOpDataList();
}

void AnimRegisterOperations::cleanUpRelations() {
    {
        deleteOpDataList();
    }
}

/*********************************************************************
	File Path	: ../AnimRegisterOperations.cpp
*********************************************************************/
