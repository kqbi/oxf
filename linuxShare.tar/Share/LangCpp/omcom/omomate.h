#ifndef omomate_H
#define omomate_H "$Id: omomate.h 1.3 2007/03/11 12:34:37 ilgiga Exp $"

//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/omcom/rcs/omomate.h $
//	file version:	$Revision: 1.3 $
//
//	purpose: to be included in "omate" files which
//	themselve "#include" other "om" files
//
//	author(s):	Yachin Pnueli
//	date started:	21.5.96
//	date changed:	$Date: 2007/03/11 12:34:37 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//
#ifndef OMOMATE
#define OMOMATE
#endif
//
// $Log: omomate.h $
// Revision 1.3  2007/03/11 12:34:37  ilgiga
// Change copyright comment
// Revision 1.2  2007/03/01 16:43:32  ilgiga
// Telelogic instead of i-Logix
// Revision 1.1  1996/11/27 12:25:23  yachin
// Initial revision
//

#endif
