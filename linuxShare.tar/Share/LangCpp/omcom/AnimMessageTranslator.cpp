/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimMessageTranslator
	File Path	: ../AnimMessageTranslator.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimMessageTranslator.h"
//## operation decodeField(AnimBooleanField*)
#include "AnimBooleanField.h"
//## operation decodeField(AnimCodeField*)
#include "AnimCodeField.h"
//## operation decodeField(AnimIntField*)
#include "AnimIntField.h"
//## operation decodeField(AnimListField*)
#include "AnimListField.h"
//## operation decodeMessage(void *)
#include "AnimMessage.h"
//## operation decodeField(AnimMessageField*)
#include "AnimMessageField.h"
//## operation decodeField(AnimPointerField*)
#include "AnimPointerField.h"
//## operation decodeField(AnimStringField*)
#include "AnimStringField.h"
//## operation decodeField(AnimStringOrPointerField*)
#include "AnimStringOrPointerField.h"
//## operation decodeField(AnimTimestampField*)
#include "AnimTimestampField.h"
//## package RiCppAnimMessageTranslator

//## class AnimMessageTranslator

/*********************************************************************
	File Path	: ../AnimMessageTranslator.cpp
*********************************************************************/
