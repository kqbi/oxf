/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimTimeRequest
	File Path	: ../AnimTimeRequest.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimTimeRequest.h"
//## auto_generated
#include "AnimField.h"
//## classInstance timeInterval
#include "AnimIntField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimTimeRequest
AnimTimeRequest AnimTimeRequest::_timeRequest;

AnimTimeRequest::AnimTimeRequest() {
    initRelations();
    //#[ operation AnimTimeRequest()
    code = timeRequest;
    
    // set the names
    timeInterval->setName("timeInterval");
    
    // add fields to container
    addField(timeInterval);
    
    registerInTranslator();
    
    //#]
}

AnimTimeRequest::~AnimTimeRequest() {
    cleanUpRelations();
}

AnimMessage* AnimTimeRequest::clone() {
    //#[ operation clone()
    AnimTimeRequest *msg = new AnimTimeRequest();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    rhp_long64_t lInt = (rhp_long64_t)(getTimeInterval()->getValue());
    msg->setTimeInterval((int)lInt);
    return msg;
    //#]
}

void AnimTimeRequest::setTimeInterval(int value) {
    //#[ operation setTimeInterval(int)
    *timeInterval = value;
    //#]
}

void AnimTimeRequest::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimIntField* AnimTimeRequest::getTimeInterval() const {
    return timeInterval;
}

AnimIntField* AnimTimeRequest::createNewTimeInterval() {
    timeInterval = new AnimIntField;
    return timeInterval;
}

void AnimTimeRequest::deleteTimeInterval() {
    delete timeInterval;
    timeInterval = NULL;
}

void AnimTimeRequest::initRelations() {
    timeInterval = createNewTimeInterval();
}

void AnimTimeRequest::cleanUpRelations() {
    {
        deleteTimeInterval();
    }
}

/*********************************************************************
	File Path	: ../AnimTimeRequest.cpp
*********************************************************************/
