/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimMessage
	File Path	: ../AnimMessage.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimMessage_H
#define AnimMessage_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## operation getOrigSource()
#include <oxf/rawtypes.h>
//## operation getNextField()
class AnimField;

//## operation setNextField(AnimMessageField*)
class AnimMessageField;

//## operation getDestOrSource() const
class AnimPointerField;

//## operation getTimeStamp()
class AnimTimestampField;

//## package RiCppAnimMessageTranslator

//## class AnimMessage
class AnimMessage {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    AnimMessage();
    
    //## auto_generated
    virtual ~AnimMessage() = 0;
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone() = 0;
    
    //## operation getCode() const
    virtual int getCode() const = 0;
    
    //## operation getDestOrSource() const
    virtual AnimPointerField* getDestOrSource() const = 0;
    
    // return the next field in the message.
    //## operation getNextField()
    virtual AnimField* getNextField() = 0;
    
    //## operation getOrigSource()
    virtual gen_ptr getOrigSource() = 0;
    
    //## operation getTimeStamp()
    virtual AnimTimestampField* getTimeStamp() = 0;
    
    //## operation isConstructionMessage()
    virtual bool isConstructionMessage() = 0;
    
    //## operation resetFieldIterator()
    virtual void resetFieldIterator() = 0;
    
    //## operation setConstructionMessage(bool)
    virtual void setConstructionMessage(bool bInConstruction) = 0;
    
    //## operation setDestOrSource(const AnimPointerField&)
    virtual void setDestOrSource(const AnimPointerField& p_AnimPointerField) = 0;
    
    // Argument gen_ptr destOrSource :
    // destOrSource value.
    //## operation setDestOrSource(gen_ptr)
    virtual void setDestOrSource(gen_ptr destOrSource) = 0;
    
    // Set the next field value in the message.
    //## operation setNextField(AnimMessageField*)
    virtual void setNextField(AnimMessageField* field) = 0;
    
    //## operation setOrigSource(gen_ptr)
    virtual void setOrigSource(gen_ptr src) = 0;
    
    //## operation setTimeStamp(const AnimTimestampField&)
    virtual void setTimeStamp(const AnimTimestampField& timeStamp) = 0;
    
    //## operation setTimeStamp(timeUnit)
    virtual void setTimeStamp(timeUnit timeStamp) = 0;
};

#endif
/*********************************************************************
	File Path	: ../AnimMessage.h
*********************************************************************/
