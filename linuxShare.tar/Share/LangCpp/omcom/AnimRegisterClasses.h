/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimRegisterClasses
	File Path	: ../AnimRegisterClasses.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimRegisterClasses_H
#define AnimRegisterClasses_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimRegisterClasses
#include "AnimAbstractMessage.h"
//## attribute classDataListPrototype
#include "AnimListField.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## operation addClassData(AnimClassData*)
class AnimClassData;

//## auto_generated
class AnimField;

//## operation clone()
class AnimMessage;

//## dependency AnimMessageField
class AnimMessageField;

//## auto_generated
class AnimPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimRegisterClasses
// Used for registering classes in the animation browser.
class AnimRegisterClasses : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimRegisterClasses()
    AnimRegisterClasses();
    
    //## auto_generated
    virtual ~AnimRegisterClasses();
    
    ////    Operations    ////
    
    // Add a class data to list.
    //## operation addClassData(AnimClassData*)
    void addClassData(AnimClassData* classData);
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimListField* getClassDataList() const;
    
    //## auto_generated
    AnimListField* newClassDataList();
    
    //## auto_generated
    void deleteClassDataList();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimListField classDataListPrototype;		//## attribute classDataListPrototype
    
    ////    Relations and components    ////

protected :

    AnimListField* classDataList;		//## classInstance classDataList
};

#endif
/*********************************************************************
	File Path	: ../AnimRegisterClasses.h
*********************************************************************/
