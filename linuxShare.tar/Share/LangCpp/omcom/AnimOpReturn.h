/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimOpReturn
	File Path	: ../AnimOpReturn.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimOpReturn_H
#define AnimOpReturn_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimOpReturn
#include "AnimAbstractMessage.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## classInstance isOMReturnMacro
class AnimBooleanField;

//## auto_generated
class AnimField;

//## classInstance argDataList
class AnimListField;

//## operation clone()
class AnimMessage;

//## dependency AnimMessageField
class AnimMessageField;

//## operation addArgData(AnimNameValueData*)
class AnimNameValueData;

//## auto_generated
class AnimPointerField;

//## operation setReturnValue(const AnimStringOrPointerField&)
class AnimStringOrPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimOpReturn
// Reports the return values and output parameters
class AnimOpReturn : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimOpReturn()
    AnimOpReturn();
    
    //## auto_generated
    virtual ~AnimOpReturn();
    
    ////    Operations    ////
    
    // A helper routine to allow easy insertion of output string parameters.
    // Argument char* argValue :
    // Value after being serialized.
    //## operation addArg(char*,char*)
    void addArg(char* argName, char* argValue);
    
    // A helper routine to allow easy insertion of output string parameters.
    // Argument void * argValue :
    // Value after being serialized.
    //## operation addArg(char*,void *)
    void addArg(char* argName, void * argValue);
    
    // Add a class data to list.
    //## operation addArgData(AnimNameValueData*)
    void addArgData(AnimNameValueData* argData);
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    //## operation setIsOMReturnMacro(OMBoolean)
    void setIsOMReturnMacro(OMBoolean value);
    
    //## operation setReturnValue(const AnimStringOrPointerField&)
    void setReturnValue(const AnimStringOrPointerField& value);
    
    //## operation setReturnValue(void *)
    void setReturnValue(void * pValue);
    
    //## operation setReturnValue(const char*)
    void setReturnValue(const char* cValue);

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimListField* getArgDataList() const;
    
    //## auto_generated
    AnimListField* newArgDataList();
    
    //## auto_generated
    void deleteArgDataList();
    
    //## auto_generated
    AnimBooleanField* getIsOMReturnMacro() const;
    
    //## auto_generated
    AnimBooleanField* newIsOMReturnMacro();
    
    //## auto_generated
    void deleteIsOMReturnMacro();
    
    //## auto_generated
    AnimStringOrPointerField* getRetValue() const;
    
    //## auto_generated
    AnimStringOrPointerField* newRetValue();
    
    //## auto_generated
    void deleteRetValue();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimOpReturn opReturnPrototype;		//## attribute opReturnPrototype
    
    ////    Relations and components    ////

protected :

    // A list of AnimNameValueData to store name value pairs of the output parameters.
    AnimListField* argDataList;		//## classInstance argDataList
    
    AnimBooleanField* isOMReturnMacro;		//## classInstance isOMReturnMacro
    
    // The return value.
    AnimStringOrPointerField* retValue;		//## classInstance retValue
};

#endif
/*********************************************************************
	File Path	: ../AnimOpReturn.h
*********************************************************************/
