/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimProxyCreated
	File Path	: ../AnimProxyCreated.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimProxyCreated.h"
//## auto_generated
#include "AnimField.h"
//## classInstance interestMask
#include "AnimIntField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimProxyCreated
AnimProxyCreated AnimProxyCreated::proxyCreatedPrototype;

AnimProxyCreated::AnimProxyCreated() {
    initRelations();
    //#[ operation AnimProxyCreated()
    code = proxyCreated;
    
    // set the names
    proxy->setName("proxy");
    interestMask->setName("interestMask");
    
    // add fields to container
    addField(proxy);
    addField(interestMask);
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimProxyCreated::~AnimProxyCreated() {
    cleanUpRelations();
}

AnimMessage* AnimProxyCreated::clone() {
    //#[ operation clone()
    AnimProxyCreated *msg = new AnimProxyCreated();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    msg->setProxy(getProxy()->getValue());
    rhp_long64_t lVal = (rhp_long64_t)(getInterestMask()->getValue());
    msg->setInterestMask((int)lVal);
    return msg;
    //#]
}

void AnimProxyCreated::setInterestMask(int value) {
    //#[ operation setInterestMask(int)
    *interestMask = value;
    //#]
}

void AnimProxyCreated::setProxy(gen_ptr value) {
    //#[ operation setProxy(gen_ptr)
    *proxy = value;
    //#]
}

void AnimProxyCreated::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimIntField* AnimProxyCreated::getInterestMask() const {
    return interestMask;
}

AnimIntField* AnimProxyCreated::newInterestMask() {
    interestMask = new AnimIntField;
    return interestMask;
}

void AnimProxyCreated::deleteInterestMask() {
    delete interestMask;
    interestMask = NULL;
}

AnimPointerField* AnimProxyCreated::getProxy() const {
    return proxy;
}

AnimPointerField* AnimProxyCreated::newProxy() {
    proxy = new AnimPointerField;
    return proxy;
}

void AnimProxyCreated::deleteProxy() {
    delete proxy;
    proxy = NULL;
}

void AnimProxyCreated::initRelations() {
    interestMask = newInterestMask();
    proxy = newProxy();
}

void AnimProxyCreated::cleanUpRelations() {
    {
        deleteProxy();
    }
    {
        deleteInterestMask();
    }
}

/*********************************************************************
	File Path	: ../AnimProxyCreated.cpp
*********************************************************************/
