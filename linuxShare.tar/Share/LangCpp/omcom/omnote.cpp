#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: omnote.cpp 1.19 2007/03/11 12:34:37 ilgiga Exp $";
#endif 
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/omcom/rcs/omnote.cpp $
//	file version:	$Revision: 1.19 $
//
//	purpose: Methods of Class OMNotify	 	
//
//	author(s):		Yachin Pnueli
//	date started:	22.5.96
//	date changed:	$Date: 2007/03/11 12:34:37 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//

#include <oxf/rp_framework_dll_definition.h>

#ifndef OM_NO_OS_STDIO_INCLUDE
#ifdef OM_STL
#include <cstdio>
#else
#include <stdio.h>
#endif // OM_STL
#endif // OM_NO_OS_STDIO_INCLUDE

#ifdef _OM_UNICODE_ONLY
#include <oxf/omunicode.h>
#endif // _OM_UNICODE_ONLY

#include "omnote.h"

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = omnote_H;
#endif 

static char msg[40]; // BUG - String too small - Changed 20 to 40.
#ifdef _OM_UNICODE_ONLY
static wchar_t wmsg[40];
#endif // _OM_UNICODE_ONLY

const char * omnotify2String(OMNotify r) {
	switch (r) {
	case becameActivated:		return "Got Control";
	case becameDeactivated:		return "Lost Control"; 
	case controlModified:		return "Control Modified"; 
	case instanceCreated:		return "Instance Created";
	case instanceDeleted:		return "Instance Deleted";
	case enteredState:			return "State Entered";
	case exitedState:			return "State Exited";
	case stateModified:			return "State Modified";
	case terminationReached:	return "Termination Reached";
	case startedTransition:		return "Started Transition";
	case endedTransition:		return "Ended Transition";
	case relationConnected:		return "Relation Connected";
	case relationDisconnected:	return "Relation Disconnected";
	case relationCleared:		return "Relation Cleared";
	case relationModified:		return "Relation Modified";
	case breakpointActive:		return "Breakpoint Active";
	case methodCalled:			return "Method Called";
	case methodReturned:		return "Method Returned";
	case eventSent:				return "Event Sent";
	case eventTaken:			return "Event Taken";
	case setName:				return "Set Name";
	case updatedAttributeValues: return "Updated Attribute Values";
	case timeoutSet:			return "Timeout Set";
	case eventCancelled:		return "Event Canceled";
	case classList:				return "Class List";
	case supperClassList:		return "Super Class List";
	case instanceList:			return "Instance List";
	case attributeValues:		return "Attribute Values";
	case updatedRelationsValues:	return "Updated Relations Values";
	case relationValues:		return "Relation Values";
	case relationsValues:		return "Relations Values";
	case stateConfiguration:	return "State Configuration";
	case instanceValue:			return "Instance Value";
	case callStackValues:		return "Call Stack Values";
	case eventQueueValues:		return "Event Queue Values";
	case pendingTimeoutValues:	return "Pending Timeout Values";
	case classValues:			return "Class Values";
	case allValues:				return "All Values";
	case createProxy:			return "Create Proxy";
	case errorFound:			return "Error Found";
	case createInstance:		return"Create Instance";
	case deleteInstance:		return"Delete Instance";
	case connectToRelation:		return"Connect to relation";
	case disconnectFromRelation:return"Disconnect from relation";
	case clearRelation:			return"Clear relation";
	case callMethod:			return"call Method";
	case takeEvent:				return"take Event";
	case setAttributeValues:	return"Set attribute Values";
	case setStateConfiguration: return"Set state configuration";
	case setBreakpoint:			return"set Breakpoint";
	case proxyCreated:			return"Proxy Created";
	case newInterestMask:		return"New interest Mask";
	case sendYourself:			return"Send Yourself";
	case addEventToQueue:		return"add Event to Queue";
	case stoppedForStep:		return"stoppedForStep";
	case stoppedForEvent:		return"stoppedForEvent";
	case stoppedForIdle:		return"stoppedForIdle";
	case stoppedForBreakpoint:	return"stoppedForBreakpoint";
	case quitExecutable:		return"quitExecutable";
	case suspendThread:			return"suspendThread";
	case resumeThread:			return"resumeThread";
	case withTimeStamp:			return "with Time Stamp";
	case withoutTimeStamp:		return "without Time Stamp";
	case flowDataSend:			return "flow Data Send";
	case flowDataRecv:			return "flow Data Receive";
	case flowDataEnd:			return "flow Data End";
	case flowDataPopPartial:	return "flow Data Pop Parital";
	case msgCallDuringCtor:		return "msg call during ctor";
	case createInstRelations:	return "create Instance Relations";
	case tokenReady:			return "tokenReady";
	case tokenConsumed:			return "tokenConsumed";
	case actionReady:			return "actionReady";
	case actionDone:			return "actionDone";
	case actionStepStarted:		return "actionStepStarted";
	case stoppedForAction:		return "stoppedForAction";
	case tokenValues:			return "tokenValues";
	default:
#ifndef _OM_UNICODE_ONLY
		sprintf(msg,"Unrecognized Notify/Command %d",r);
#else
		swprintf(wmsg,L"Unrecognized Notify/Command %d",r);
		OMwtoc(msg, wmsg, 40);
#endif // _OM_UNICODE_ONLY
		return msg;
	}
}

//
// $Log: omnote.cpp $
// Revision 1.19  2007/03/11 12:34:37  ilgiga
// Change copyright comment
// Revision 1.18  2007/03/01 16:43:32  ilgiga
// Telelogic instead of i-Logix
// Revision 1.17  2005/08/23 14:55:25  amos
// bugfix 85444 to main branch
// Revision 1.16.1.2  2005/08/22 10:07:09  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.16  2002/07/15 12:30:39  avrahams
// Back to main
// Revision 1.15  2002/07/11 13:08:50  amos
// do not include omosconfig.h directly
// Revision 1.14  2002/07/09 11:50:45  amos
// framework cleanup from RTOS specific code - back to r41 main branch
// Revision 1.13.2.2  2002/07/09 11:50:45  amos
// replace adaptor specific #ifdef with generic statements
// Revision 1.13.2.1  2001/05/02 12:46:37  amos
// Revision 1.13.1.2  2002/07/04 11:34:41  avrahams
// Clanup std namespace usage
// Revision 1.13.1.1  2001/05/02 12:46:37  avrahams
// Duplicate revision
// Revision 1.13  2001/05/02 12:46:37  amos
// comment statements aftert #endif
// Revision 1.12  2000/10/19 07:29:58  vova
// Syntax error
// Revision 1.11  2000/07/11 09:23:50  amos
// the main change related to modify char* to const char*.
// there are some other changes related to assignment of static member function as extern "C" functions.
// Revision 1.10  2000/01/31 09:50:17  amos
// back to main branch
// Revision 1.9.1.2  2000/01/30 07:49:40  amos
// add withTimeStamp and withoutTimeStamp to OMNote - to support passing the timestamp intrest from TOM to AOM
// Revision 1.9.1.1  1999/05/11 09:54:34  amos
// Duplicate revision
// Revision 1.8  1998/05/21 12:32:23  yachin
// Notify Tom when events are canceled
// Revision 1.7  1998/04/13 07:59:30  ofer
// keep "using namespace std;"
// only after include to <XXXstream>
// Revision 1.6  1998/04/13 07:41:26  ofer
// added "using namespace std;" after each include to stl files
// Revision 1.5  1998/04/12 12:17:10  ofer
// Change includes to Stl format ifdefed by OM_USE_STL
// Revision 1.4  1997/07/20 11:37:24  yachin
// Adding globals to animation
// Revision 1.3  1997/02/27 11:56:43  yachin
// Change output notify to fit breakpoint names
// Revision 1.2  1996/12/26 09:47:23  yachin
// Revision 1.1  1996/11/24 12:37:20  yachin
// Initial revision
//
