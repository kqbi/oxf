/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimRemoveBreakpoint
	File Path	: ../AnimRemoveBreakpoint.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimRemoveBreakpoint_H
#define AnimRemoveBreakpoint_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimRemoveBreakpoint
#include "AnimAbstractMessage.h"
//## operation setAnimItem(gen_ptr)
#include "oxf/rawtypes.h"
//## classInstance breakpointCode
class AnimCodeField;

//## auto_generated
class AnimField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## classInstance breakpointData
class AnimStringField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimRemoveBreakpoint
// A message used for removing a breakpoint.
class AnimRemoveBreakpoint : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimRemoveBreakpoint()
    AnimRemoveBreakpoint();
    
    //## auto_generated
    virtual ~AnimRemoveBreakpoint();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    //## operation setAnimItem(gen_ptr)
    void setAnimItem(gen_ptr value);
    
    //## operation setBreakpointCode(unsigned char)
    void setBreakpointCode(unsigned char value);
    
    //## operation setBreakpointData(OMString)
    void setBreakpointData(OMString value);

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimPointerField* getAnimItem() const;
    
    //## auto_generated
    AnimPointerField* newAnimItem();
    
    //## auto_generated
    void deleteAnimItem();
    
    //## auto_generated
    AnimCodeField* getBreakpointCode() const;
    
    //## auto_generated
    AnimCodeField* newBreakpointCode();
    
    //## auto_generated
    void deleteBreakpointCode();
    
    //## auto_generated
    AnimStringField* getBreakpointData() const;
    
    //## auto_generated
    AnimStringField* newBreakpointData();
    
    //## auto_generated
    void deleteBreakpointData();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimRemoveBreakpoint animRemoveBreakpoint;		//## attribute animRemoveBreakpoint
    
    ////    Relations and components    ////

protected :

    AnimPointerField* animItem;		//## classInstance animItem
    
    AnimCodeField* breakpointCode;		//## classInstance breakpointCode
    
    AnimStringField* breakpointData;		//## classInstance breakpointData
};

#endif
/*********************************************************************
	File Path	: ../AnimRemoveBreakpoint.h
*********************************************************************/
