/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimNewInterestMask
	File Path	: ../AnimNewInterestMask.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimNewInterestMask.h"
//## auto_generated
#include "AnimField.h"
//## classInstance interestMask
#include "AnimIntField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimNewInterestMask
AnimNewInterestMask AnimNewInterestMask::_newInterestMask;

AnimNewInterestMask::AnimNewInterestMask() {
    initRelations();
    //#[ operation AnimNewInterestMask()
    code = newInterestMask;
    
    // set the names
    interestMask->setName("interestMask");
    
    // add fields to container
    addField(interestMask);
    
    registerInTranslator();
    
    //#]
}

AnimNewInterestMask::~AnimNewInterestMask() {
    cleanUpRelations();
}

AnimMessage* AnimNewInterestMask::clone() {
    //#[ operation clone()
    AnimNewInterestMask *msg = new AnimNewInterestMask();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    rhp_long64_t lVal = (rhp_long64_t)(getInterestMask()->getValue());
    msg->setInterestMask((int)lVal);
    return msg;
    //#]
}

void AnimNewInterestMask::setInterestMask(int value) {
    //#[ operation setInterestMask(int)
    *interestMask = value;
    //#]
}

void AnimNewInterestMask::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimIntField* AnimNewInterestMask::getInterestMask() const {
    return interestMask;
}

AnimIntField* AnimNewInterestMask::createNewInterestMask() {
    interestMask = new AnimIntField;
    return interestMask;
}

void AnimNewInterestMask::deleteInterestMask() {
    delete interestMask;
    interestMask = NULL;
}

void AnimNewInterestMask::initRelations() {
    interestMask = createNewInterestMask();
}

void AnimNewInterestMask::cleanUpRelations() {
    {
        deleteInterestMask();
    }
}

/*********************************************************************
	File Path	: ../AnimNewInterestMask.cpp
*********************************************************************/
