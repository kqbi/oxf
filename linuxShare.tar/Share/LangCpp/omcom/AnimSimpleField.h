/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimSimpleField
	File Path	: ../AnimSimpleField.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimSimpleField_H
#define AnimSimpleField_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## class AnimSimpleField
#include "AnimField.h"
//## operation getValue() const
#include <oxf/rawtypes.h>
//## package RiCppAnimMessageTranslator

//## class AnimSimpleField
class AnimSimpleField : public AnimField {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    AnimSimpleField();
    
    //## auto_generated
    virtual ~AnimSimpleField() = 0;
    
    ////    Operations    ////
    
    // Get the scalar value.
    //## operation getValue() const
    virtual gen_ptr getValue() const = 0;
    
    // Set the scalar value.
    // Argument gen_ptr value :
    // The value
    //## operation setValue(gen_ptr)
    virtual void setValue(gen_ptr value) = 0;
};

#endif
/*********************************************************************
	File Path	: ../AnimSimpleField.h
*********************************************************************/
