/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimOperationData
	File Path	: ../AnimOperationData.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimOperationData.h"
//## classInstance isStatic
#include "AnimBooleanField.h"
//## auto_generated
#include "AnimField.h"
//## classInstance numOfArgs
#include "AnimIntField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## classInstance opName
#include "AnimStringField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimOperationData
AnimOperationData AnimOperationData::opDataPrototype;

AnimOperationData::AnimOperationData() {
    initRelations();
    //#[ operation AnimOperationData()
    code = createProxyOperation;
    
    // set the names
    opName->setName("opName");
    isStatic->setName("isStatic");
    signature->setName("signature");   
    numOfArgs->setName("numOfArgs");
    
    // add fields to container
    addField(opName); 
    addField(isStatic);
    addField(signature);            
    addField(numOfArgs);
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimOperationData::~AnimOperationData() {
    cleanUpRelations();
}

AnimMessage* AnimOperationData::clone() {
    //#[ operation clone()
    AnimOperationData *msg = new AnimOperationData();   
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));   
    char *tmp = (char *)(rhp_long64_t)(getOpName()->getValue());
    msg->setOpName((OMString)(tmp));         
    delete[] tmp;
    msg->setIsStatic((getIsStatic()->getValue() != 0));
    tmp = (char *)(rhp_long64_t)(getSignature()->getValue());
    msg->setSignature((OMString)(tmp));
    delete[] tmp;
    rhp_long64_t lVal = (rhp_long64_t)(getNumOfArgs()->getValue());
    msg->setNumOfArgs((int)lVal);
    return msg;
    //#]
}

void AnimOperationData::setIsStatic(OMBoolean value) {
    //#[ operation setIsStatic(OMBoolean)
    *isStatic = value;
    //#]
}

void AnimOperationData::setNumOfArgs(int value) {
    //#[ operation setNumOfArgs(int)
    *numOfArgs=value;
    //#]
}

void AnimOperationData::setOpName(OMString value) {
    //#[ operation setOpName(OMString)
    *opName = value;
    //#]
}

void AnimOperationData::setSignature(OMString value) {
    //#[ operation setSignature(OMString)
    *signature = value;
    //#]
}

void AnimOperationData::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimBooleanField* AnimOperationData::getIsStatic() const {
    return isStatic;
}

AnimBooleanField* AnimOperationData::newIsStatic() {
    isStatic = new AnimBooleanField;
    return isStatic;
}

void AnimOperationData::deleteIsStatic() {
    delete isStatic;
    isStatic = NULL;
}

AnimIntField* AnimOperationData::getNumOfArgs() const {
    return numOfArgs;
}

AnimIntField* AnimOperationData::newNumOfArgs() {
    numOfArgs = new AnimIntField;
    return numOfArgs;
}

void AnimOperationData::deleteNumOfArgs() {
    delete numOfArgs;
    numOfArgs = NULL;
}

AnimStringField* AnimOperationData::getOpName() const {
    return opName;
}

AnimStringField* AnimOperationData::newOpName() {
    opName = new AnimStringField;
    return opName;
}

void AnimOperationData::deleteOpName() {
    delete opName;
    opName = NULL;
}

AnimStringField* AnimOperationData::getSignature() const {
    return signature;
}

AnimStringField* AnimOperationData::newSignature() {
    signature = new AnimStringField;
    return signature;
}

void AnimOperationData::deleteSignature() {
    delete signature;
    signature = NULL;
}

void AnimOperationData::initRelations() {
    isStatic = newIsStatic();
    numOfArgs = newNumOfArgs();
    opName = newOpName();
    signature = newSignature();
}

void AnimOperationData::cleanUpRelations() {
    {
        deleteSignature();
    }
    {
        deleteOpName();
    }
    {
        deleteNumOfArgs();
    }
    {
        deleteIsStatic();
    }
}

/*********************************************************************
	File Path	: ../AnimOperationData.cpp
*********************************************************************/
