/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimMessageField
	File Path	: ../AnimMessageField.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimMessageField.h"
//## dependency AnimAbstractMessage
#include "AnimAbstractMessage.h"
//## operation clone()
#include "AnimField.h"
//## attribute value
#include "AnimMessage.h"
//## operation decode(AnimMessageTranslator*)
#include "AnimMessageTranslator.h"
//## package RiCppAnimMessageTranslator

//## class AnimMessageField
AnimMessageField::AnimMessageField() : value(NULL) {
    //#[ operation AnimMessageField()
    //#]
}

AnimMessageField::~AnimMessageField() {
    //#[ operation ~AnimMessageField()
    delete value;
    //#]
}

AnimField* AnimMessageField::clone() {
    //#[ operation clone()
    AnimMessageField *mF = new AnimMessageField();
    mF->name = name;
    if (value != NULL)
    {
        mF->setValue((gen_ptr)(rhp_long64_t)(value->clone()));
    }
    return mF;
    //#]
}

void AnimMessageField::decode(AnimMessageTranslator* translator) {
    //#[ operation decode(AnimMessageTranslator*)
    translator->decodeField(this);
    //#]
}

void AnimMessageField::encode(AnimMessageTranslator* translator) {
    //#[ operation encode(AnimMessageTranslator*)
    translator->encodeField(this);
    
    //#]
}

gen_ptr AnimMessageField::getValue() const {
    //#[ operation getValue() const
    return (gen_ptr)(rhp_long64_t)value;
    
    //#]
}

AnimMessageField& AnimMessageField::operator=(const AnimMessageField& field) {
    //#[ operation operator=(const AnimMessageField&)
    if (this != &field)   
    {
      AnimMessage *msg = (AnimMessage *)(rhp_long64_t)(field.getValue());
      value = msg->clone();
    }      
    return *this;
    //#]
}

void AnimMessageField::setValue(gen_ptr p_value) {
    //#[ operation setValue(gen_ptr)
    AnimAbstractMessage *msg = (AnimAbstractMessage *)(rhp_long64_t)p_value;
    AnimMessage *clone = msg->clone();
    value = clone;
    
    //#]
}

/*********************************************************************
	File Path	: ../AnimMessageField.cpp
*********************************************************************/
