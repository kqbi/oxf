/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimBooleanField
	File Path	: ../AnimBooleanField.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimBooleanField_H
#define AnimBooleanField_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## class AnimBooleanField
#include "AnimSimpleField.h"
//## operation getValue() const
#include <oxf/rawtypes.h>
//## operation clone()
class AnimField;

//## operation decode(AnimMessageTranslator*)
class AnimMessageTranslator;

//## package RiCppAnimMessageTranslator

//## class AnimBooleanField
class AnimBooleanField : public AnimSimpleField {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    AnimBooleanField();
    
    //## auto_generated
    virtual ~AnimBooleanField();
    
    ////    Operations    ////
    
    //## operation clone()
    AnimField* clone();
    
    // Call translator to dencode field from its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to dencode field. 
    //## operation decode(AnimMessageTranslator*)
    virtual void decode(AnimMessageTranslator* translator);
    
    // Call translator to encode field to its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to encode field. 
    //## operation encode(AnimMessageTranslator*)
    virtual void encode(AnimMessageTranslator* translator);
    
    // Get the scalar value.
    //## operation getValue() const
    virtual gen_ptr getValue() const;
    
    //## operation operator=(const AnimBooleanField&)
    AnimBooleanField& operator=(const AnimBooleanField& field);
    
    // Argument OMBoolean val :
    // The value of the field.
    //## operation operator=(OMBoolean)
    AnimBooleanField& operator=(OMBoolean val);
    
    //## operation setValue(gen_ptr)
    void setValue(gen_ptr p_value);
    
    ////    Attributes    ////

protected :

    OMBoolean value;		//## attribute value
};

#endif
/*********************************************************************
	File Path	: ../AnimBooleanField.h
*********************************************************************/
