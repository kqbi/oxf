/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimCodeField
	File Path	: ../AnimCodeField.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimCodeField.h"
//## operation clone()
#include "AnimField.h"
//## operation decode(AnimMessageTranslator*)
#include "AnimMessageTranslator.h"
//## package RiCppAnimMessageTranslator

//## class AnimCodeField
AnimCodeField::AnimCodeField() : value(0) {
    //#[ operation AnimCodeField()
    //#]
}

AnimCodeField::~AnimCodeField() {
}

AnimField* AnimCodeField::clone() {
    //#[ operation clone()
    AnimCodeField *f = new AnimCodeField();
    f->name = name;
    f->value = value;
    return f;
    //#]
}

void AnimCodeField::decode(AnimMessageTranslator* translator) {
    //#[ operation decode(AnimMessageTranslator*)
    translator->decodeField(this);
    //#]
}

void AnimCodeField::encode(AnimMessageTranslator* translator) {
    //#[ operation encode(AnimMessageTranslator*)
    translator->encodeField(this);
    
    //#]
}

gen_ptr AnimCodeField::getValue() const {
    //#[ operation getValue() const
    return (gen_ptr)(rhp_long64_t)value;
    
    
    //#]
}

AnimCodeField& AnimCodeField::operator=(const AnimCodeField& field) {
    //#[ operation operator=(const AnimCodeField&)
    if (this != &field)   
    {   
        setName(field.getName());
        setValue(field.getValue());
    }
    return *this;
    //#]
}

AnimCodeField& AnimCodeField::operator=(unsigned char val) {
    //#[ operation operator=(unsigned char)
    setValue((gen_ptr)(rhp_long64_t)val);
    return *this;
    //#]
}

void AnimCodeField::setValue(gen_ptr p_value) {
    //#[ operation setValue(gen_ptr)
    value = (unsigned char)(rhp_long64_t)p_value;
    //#]
}

/*********************************************************************
	File Path	: ../AnimCodeField.cpp
*********************************************************************/
