/*********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimNameValueData
	File Path	: ../AnimNameValueData.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimNameValueData_H
#define AnimNameValueData_H

//## auto_generated
#include "RiCppAnimMessages.h"
//## class AnimNameValueData
#include "AnimAbstractMessage.h"
//## auto_generated
#include "oxf/rawtypes.h"
//## auto_generated
class AnimField;

//## operation clone()
class AnimMessage;

//## auto_generated
class AnimPointerField;

//## classInstance theName
class AnimStringField;

//## operation setTheValue(const AnimStringOrPointerField&)
class AnimStringOrPointerField;

//## auto_generated
class AnimTimestampField;

//## package RiCppAnimMessages

//## class AnimNameValueData
// Hold a name (AnimStringField) value (AnimStringOrPointerField) pair.
class AnimNameValueData : public AnimAbstractMessage {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimNameValueData()
    AnimNameValueData();
    
    //## auto_generated
    virtual ~AnimNameValueData();
    
    ////    Operations    ////
    
    // Clones the message object.
    //## operation clone()
    virtual AnimMessage* clone();
    
    // Set the class name.
    //## operation setTheName(OMString)
    void setTheName(OMString value);
    
    //## operation setTheValue(const AnimStringOrPointerField&)
    void setTheValue(const AnimStringOrPointerField& value);

protected :

    //## operation registerInTranslator()
    void registerInTranslator();
    
    ////    Additional operations    ////

public :

    //## auto_generated
    AnimStringField* getTheName() const;
    
    //## auto_generated
    AnimStringField* newTheName();
    
    //## auto_generated
    void deleteTheName();
    
    //## auto_generated
    AnimStringOrPointerField* getTheValue() const;
    
    //## auto_generated
    AnimStringOrPointerField* newTheValue();
    
    //## auto_generated
    void deleteTheValue();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////

private :

    // A static instance for registration.
    static AnimNameValueData nameValiePrototype;		//## attribute nameValiePrototype
    
    ////    Relations and components    ////

protected :

    // The name.
    AnimStringField* theName;		//## classInstance theName
    
    // The value.
    AnimStringOrPointerField* theValue;		//## classInstance theValue
};

#endif
/*********************************************************************
	File Path	: ../AnimNameValueData.h
*********************************************************************/
