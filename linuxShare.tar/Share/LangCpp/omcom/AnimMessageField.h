/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimMessageField
	File Path	: ../AnimMessageField.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimMessageField_H
#define AnimMessageField_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## class AnimMessageField
#include "AnimSimpleField.h"
//## operation getValue() const
#include <oxf/rawtypes.h>
//## dependency AnimAbstractMessage
class AnimAbstractMessage;

//## operation clone()
class AnimField;

//## attribute value
class AnimMessage;

//## operation decode(AnimMessageTranslator*)
class AnimMessageTranslator;

//## package RiCppAnimMessageTranslator

//## class AnimMessageField
class AnimMessageField : public AnimSimpleField {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimMessageField()
    AnimMessageField();
    
    //## operation ~AnimMessageField()
    virtual ~AnimMessageField();
    
    ////    Operations    ////
    
    //## operation clone()
    AnimField* clone();
    
    // Call translator to dencode field from its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to dencode field. 
    //## operation decode(AnimMessageTranslator*)
    virtual void decode(AnimMessageTranslator* translator);
    
    // Call translator to encode field to its specified protocol.
    // Argument AnimMessageTranslator* translator :
    // The translator to encode field. 
    //## operation encode(AnimMessageTranslator*)
    virtual void encode(AnimMessageTranslator* translator);
    
    // Get the scalar value.
    //## operation getValue() const
    virtual gen_ptr getValue() const;
    
    //## operation operator=(const AnimMessageField&)
    AnimMessageField& operator=(const AnimMessageField& field);
    
    //## operation setValue(gen_ptr)
    void setValue(gen_ptr p_value);
    
    ////    Attributes    ////

protected :

    AnimMessage* value;		//## attribute value
};

#endif
/*********************************************************************
	File Path	: ../AnimMessageField.h
*********************************************************************/
