/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimStoppedByUser
	File Path	: ../AnimStoppedByUser.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimStoppedByUser.h"
//## auto_generated
#include "AnimField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimStoppedByUser
AnimStoppedByUser AnimStoppedByUser::animStoppedByUser;

AnimStoppedByUser::AnimStoppedByUser() {
    //#[ operation AnimStoppedByUser()
    code = stoppedByUser;
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimStoppedByUser::~AnimStoppedByUser() {
}

AnimMessage* AnimStoppedByUser::clone() {
    //#[ operation clone()
    AnimStoppedByUser *msg = new AnimStoppedByUser();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    return msg;
    //#]
}

void AnimStoppedByUser::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

/*********************************************************************
	File Path	: ../AnimStoppedByUser.cpp
*********************************************************************/
