/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimTimestampField
	File Path	: ../AnimTimestampField.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimTimestampField.h"
//## operation clone()
#include "AnimField.h"
//## operation decode(AnimMessageTranslator*)
#include "AnimMessageTranslator.h"
//## package RiCppAnimMessageTranslator

//## class AnimTimestampField
AnimTimestampField::AnimTimestampField() : valueSet(FALSE) {
    //#[ operation AnimTimestampField()
    //#]
}

AnimTimestampField::~AnimTimestampField() {
}

AnimField* AnimTimestampField::clone() {
    //#[ operation clone()
    AnimTimestampField *f = new AnimTimestampField();
    f->name = name;
    f->valueSet = valueSet;
    f->value = value;
    return f;
    //#]
}

void AnimTimestampField::decode(AnimMessageTranslator* translator) {
    //#[ operation decode(AnimMessageTranslator*)
    translator->decodeField(this);
    //#]
}

void AnimTimestampField::encode(AnimMessageTranslator* translator) {
    //#[ operation encode(AnimMessageTranslator*)
    translator->encodeField(this);
    
    //#]
}

gen_ptr AnimTimestampField::getValue() const {
    //#[ operation getValue() const
    return (gen_ptr)value;
    
    //#]
}

AnimTimestampField& AnimTimestampField::operator=(const AnimTimestampField& timestampField) {
    //#[ operation operator=(const AnimTimestampField&)
    if (this != &timestampField)   
    {   
        setName(timestampField.getName());  
        value = timestampField.value;
        valueSet = timestampField.valueSet; 
    }
    return *this;
    //#]
}

AnimTimestampField& AnimTimestampField::operator=(timeUnit val) {
    //#[ operation operator=(timeUnit)
    setValue((gen_ptr)val);
    return *this;
    //#]
}

void AnimTimestampField::setValue(gen_ptr p_value) {
    //#[ operation setValue(gen_ptr)
    valueSet = TRUE;
    value = (timeUnit)p_value;
    
    //#]
}

OMBoolean AnimTimestampField::isValueSet() const {
    return valueSet;
}

/*********************************************************************
	File Path	: ../AnimTimestampField.cpp
*********************************************************************/
