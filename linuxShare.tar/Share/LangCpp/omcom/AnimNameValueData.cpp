/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimNameValueData
	File Path	: ../AnimNameValueData.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimNameValueData.h"
//## auto_generated
#include "AnimField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## classInstance theName
#include "AnimStringField.h"
//## operation setTheValue(const AnimStringOrPointerField&)
#include "AnimStringOrPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimNameValueData
AnimNameValueData AnimNameValueData::nameValiePrototype;

AnimNameValueData::AnimNameValueData() {
    initRelations();
    //#[ operation AnimNameValueData()
    code = omNameValue;
    
    // set the names
    theName->setName("Name");
    theValue->setName("Value");
    
    // add fields to container
    addField(theName); 
    addField(theValue);
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimNameValueData::~AnimNameValueData() {
    cleanUpRelations();
}

AnimMessage* AnimNameValueData::clone() {
    //#[ operation clone()
    AnimNameValueData *msg = new AnimNameValueData();   
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));   
    
    char *tmp = (char *)(rhp_long64_t)(getTheName()->getValue());
    msg->setTheName((OMString)(tmp));         
    delete[] tmp;    
    
    msg->setTheValue(*theValue);
    
    return msg;
    //#]
}

void AnimNameValueData::setTheName(OMString value) {
    //#[ operation setTheName(OMString)
    *theName = value;
    //#]
}

void AnimNameValueData::setTheValue(const AnimStringOrPointerField& value) {
    //#[ operation setTheValue(const AnimStringOrPointerField&)
    
    (*theValue) = value;
    //#]
}

void AnimNameValueData::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimStringField* AnimNameValueData::getTheName() const {
    return theName;
}

AnimStringField* AnimNameValueData::newTheName() {
    theName = new AnimStringField;
    return theName;
}

void AnimNameValueData::deleteTheName() {
    delete theName;
    theName = NULL;
}

AnimStringOrPointerField* AnimNameValueData::getTheValue() const {
    return theValue;
}

AnimStringOrPointerField* AnimNameValueData::newTheValue() {
    theValue = new AnimStringOrPointerField;
    return theValue;
}

void AnimNameValueData::deleteTheValue() {
    delete theValue;
    theValue = NULL;
}

void AnimNameValueData::initRelations() {
    theName = newTheName();
    theValue = newTheValue();
}

void AnimNameValueData::cleanUpRelations() {
    {
        deleteTheValue();
    }
    {
        deleteTheName();
    }
}

/*********************************************************************
	File Path	: ../AnimNameValueData.cpp
*********************************************************************/
