/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimQuitExecutable
	File Path	: ../AnimQuitExecutable.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimQuitExecutable.h"
//## auto_generated
#include "AnimField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimQuitExecutable
AnimQuitExecutable AnimQuitExecutable::quitExecutablePrototype;

AnimQuitExecutable::AnimQuitExecutable() {
    //#[ operation AnimQuitExecutable()
    code = quitExecutable;
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimQuitExecutable::~AnimQuitExecutable() {
}

AnimMessage* AnimQuitExecutable::clone() {
    //#[ operation clone()
    AnimQuitExecutable *msg = new AnimQuitExecutable();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    return msg;
    //#]
}

void AnimQuitExecutable::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

/*********************************************************************
	File Path	: ../AnimQuitExecutable.cpp
*********************************************************************/
