#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: omsdata.cpp 1.19 2007/03/11 12:34:37 ilgiga Exp $";
#endif
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/omcom/rcs/omsdata.cpp $
//	file version:	$Revision: 1.19 $
//
//	purpose: Methods of Class OMSData	 and related services
//
//	author(s):		Yachin Pnueli
//	date started:	21.5.96
//	date changed:	$Date: 2007/03/11 12:34:37 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1995, 2008. All Rights Reserved.
//

#include "omsdata.h"
#include "om2str.h"

#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *hrcsid = omsdata_H;
#endif

//
//	General macros and definitions
//
#ifndef MIN
#define MIN(a,b) ( ((a)<(b)) ? (a) : (b) )
#endif

const int OMSListData::countUnknown = (-1);	
const int OMSListData::positionUnneeded = (-1);


void lostSyncError(OMString& errMsg, OMSPosition position){
	errMsg += "\nSynchronization Error in OMSData at position ";
	x2String(position,errMsg);
	errMsg += ":\n";
}

OMBoolean OMSData::badPosition(OMString& errMsg, OMSPosition position) {
	// Check correctness of position - place error in errMsg
	if (isEmpty(position)) {
		lostSyncError(errMsg,position);
		errMsg += "Position exceeds data length ";
		x2String(data.GetLength(),errMsg);
		errMsg += "\n";
		return TRUE;
	} else
		return FALSE;
}

OMBoolean OMSData::badPosition(OMSPosition position) {
	OMString errMsg;
	// Check correctness of position - send error to sendError()
	if (badPosition(errMsg,position)) {
		sendError(errMsg.GetBuffer(0));
		return TRUE;
	} else 
		return FALSE;
}

OMBoolean OMSData::badPositionOrCode(OMSPosition position, OMSCode expected) {
	if (badPosition(position))
		return TRUE;
	else 
	// Check correctness of "code" - send error to sendError()
		if ( (data[position]==expected) || 
		     ((data[position] == pointer64Code) && (expected==pointerCode)) ||
		     (expected==stringCode && isString(position)) ||
		     (expected==sdataCode && isSData(position)) ||
		     (expected==maxCode && isCode(position)) 
		)
			return FALSE;
	else {
		OMString errMsg;
		lostSyncError(errMsg,position);
		errMsg += "\n";
		errMsg += (char*)omscode2String((OMSCode)data[position]);
		errMsg += " found where ";
		errMsg += (char*)omscode2String(expected);
		errMsg += " was expected";
		sendError(errMsg.GetBuffer(0));
		return TRUE;
	}
}

OMBoolean OMSData::isStringOrPointer(OMString& errMsg, OMSPosition position) {
	if (badPosition(errMsg, position))
		return FALSE;
	else if ( isString(position) || isPointer(position) )
			return TRUE;
	else {
		lostSyncError(errMsg,position);
		errMsg += (char*)omscode2String((OMSCode)data[position]);
		errMsg += " found where String or Pointer was expected\n";
		return FALSE;
	}
}

// All the addItems should be improved for efficency.

#define DivisionFactor 128
#define Shift 1
#define charsPerPointer 5	// Roof of 32/log2(128)
#define charsPerPointer64 9	
#define charsPerTimeUnit 9
#define Max32bitValue 0xffffffff

void OMSData::addItemAtPosition(const timeUnit item, OMSPosition p) {
	timeUnit theItem = item;
	for(OMSPosition i = p + charsPerTimeUnit; i > p; i--) {
// disable warning about conversion from 'int' to 'unsigned char' - this is safe

#ifdef OM_WIN32_COMPILER_DISABLE_WARNING_4244
#pragma warning ( push )
#pragma warning ( disable : 4244 )
#endif // OM_WIN32_COMPILER_DISABLE_WARNING_4244

		unsigned char c = (unsigned char) theItem % DivisionFactor + Shift;

#ifdef OM_WIN32_COMPILER_DISABLE_WARNING_4244
#pragma warning ( pop )
#endif // OM_WIN32_COMPILER_DISABLE_WARNING_4244

		data.SetAt(i,c);
		theItem /= DivisionFactor;
	}
}

void OMSData::addItemAtPosition(const gen_ptr item, OMSPosition p) {
	rhp_long64_t theItem = (rhp_long64_t)item;

	int pointerStrLength;
	if (data[p]==pointerCode)
		pointerStrLength = charsPerPointer;
	else
		pointerStrLength = charsPerPointer64;
	for(OMSPosition i = p + pointerStrLength; i > p; i--) {
		unsigned char c = (unsigned char)(theItem % DivisionFactor + Shift);
		data.SetAt(i,c);
		theItem /= DivisionFactor;
	}
}

void OMSData::addItem(const timeUnit item) {
	// add pointerCode + charsPerPointer places
	OMSPosition p = data.GetLength();
	data = data + (char) timeunitCode + "987654321";
	addItemAtPosition(item,p);
}

void OMSData::addItem(const gen_ptr item) {
	// add pointerCode + charsPerPointer places
	OMSPosition p = data.GetLength();
	
	if ( item <= (gen_ptr)Max32bitValue)
		data = data + (char)pointerCode + "54321";
	else
		data = data + (char)pointer64Code + "987654321";

	addItemAtPosition(item,p);
}

timeUnit OMSData::getTimeUnit(OMSPosition& position){
	timeUnit tu = 0;
	position++;		// Skip over the timeUnit code
	for(int i = 0; i < charsPerTimeUnit; i++) {

// disable warning about conversion from 'int' to 'unsigned char' - this is safe
#ifdef OM_WIN32_COMPILER_DISABLE_WARNING_4244
#pragma warning ( push )
#pragma warning ( disable : 4244 )
#endif //OM_WIN32_COMPILER_DISABLE_WARNING_4244

		unsigned char c = (unsigned char)(data[position++]) - Shift;

#ifdef OM_WIN32_COMPILER_DISABLE_WARNING_4244
#pragma warning ( pop )
#endif // OM_WIN32_COMPILER_DISABLE_WARNING_4244

		tu = (tu * DivisionFactor) + c;
	}
	return tu;
}

gen_ptr OMSData::getPointer(OMSPosition& position){
	rhp_long64_t p=0;
	int pointerStrLength;
	if (data[position]==pointerCode) {
		pointerStrLength = charsPerPointer;
	}
	else {
		pointerStrLength = charsPerPointer64;
	}
	position++;		// Skip over the pointer code
	for(int i=0; i<pointerStrLength; i++) {

// disable warning about conversion from 'int' to 'unsigned char' - this is safe
#ifdef OM_WIN32_COMPILER_DISABLE_WARNING_4244
#pragma warning ( push )
#pragma warning ( disable : 4244 )
#endif // OM_WIN32_COMPILER_DISABLE_WARNING_4244

		unsigned char c = (unsigned char)(data[position++])-Shift;

#ifdef OM_WIN32_COMPILER_DISABLE_WARNING_4244
#pragma warning ( pop )
#endif // OM_WIN32_COMPILER_DISABLE_WARNING_4244

			p=(p*DivisionFactor)+c;
	}

	return (gen_ptr)p;
}

const unsigned char maxBlkSize = (unsigned char)255;


void OMSData::addItem(const char * item, int size) {
	if (size==0) {
		addEmptyString();
		return;
	}

	// Write the non-empty string as a sequence of string block +
	// and continuation blocks.
	char block[256];
	char headerSymbol = stringCode;

	for(; size > 0; size = size - maxBlkSize) {
		// 1.1 Write header for this block
		data += (char)headerSymbol;
		// 1.2 Write size of this block and the block itself
		if (size <=maxBlkSize) {
			data += (char)size;
			data += (char*)item;
		} else {
			// create a block
			strncpy(block,item,maxBlkSize);
			block[maxBlkSize]='\0';
			data += (char)maxBlkSize;
			data += block;
		}
		item += maxBlkSize;
		// Set continuation mark (if neccesary)
		headerSymbol = continueCode;
	}
}


OMString OMSData::getString(OMSPosition& position) {
	OMString s="";
	if (data[position++]==emptyCode)
		return s;

	char block[256]; // Guaranteed to be no more than 255 +'\0'

	for(;;) {
		// Find the size of the current block
		int blkSize = (unsigned char)data[position++];
		// Add so many chars to "s"
		strncpy(block, data.GetBuffer(0)+position, blkSize);
		block[blkSize]='\0';
		s += block;
		// Increment position to end of this block
		position+=blkSize;
		// Continue to next block if it exists and is a continuation block;
		if (blkSize<maxBlkSize || // Not a full block
			isEmpty(position) || // End of data
			data[position]!=continueCode) // Next item not a continuation
			break;
		else
			position++; // Skip over the continuation symbol;
	}
	return s;
}

char * OMSData::getChar(OMSPosition& position) {
	OMString s = getString(position);
	char * c = new char[s.GetLength()+1];
	strcpy(c,s.GetBuffer(0));
	return c;
}

OMSData * OMSData::getOMSData(OMSPosition& position) {
	// Check if the OMSData is empty (else skip the header code)
	if (data[position++]==emptyCode)
		return NULL;
	OMSData *s = new OMSData;
	s->data = getString(position); // Copy the remaining data
	return s;
}

// This piece is unsafe in multi-thread 
static OMString errMsg;

const char * OMSData::omscode2String(OMSCode c) {
	switch (c) {
	case pointer64Code:
	case pointerCode:	return "Pointer Code";
	case stringCode:	return "String Code";
	case continueCode:	return "Continue Code";
	case emptyCode:	return "Empty Code";
	case sdataCode:	return "Serialized Data Code";
	case timeunitCode:	return "Time Unit Code";
	default:
		errMsg.Empty();
		errMsg = "Special Code ";
		x2String((char)c,errMsg);
		errMsg += " = ";
		x2String((char)(c-maxCode),errMsg);
		return errMsg.GetBuffer(0);
	}
}


#ifdef omsdata_Debug
void main() {
}
#endif


//
// $Log: omsdata.cpp $
// Revision 1.19  2007/03/11 12:34:37  ilgiga
// Change copyright comment
// Revision 1.18  2007/03/01 16:43:32  ilgiga
// Telelogic instead of i-Logix
// Revision 1.17  2005/08/23 14:55:26  amos
// bugfix 85444 to main branch
// Revision 1.16.1.2  2005/08/22 10:07:09  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.16  2005/02/22 08:38:35  eldad
// Fixed warning.
// Revision 1.15  2002/09/30 11:58:32  Eldad
// 1.14.1.2 to main branch.
// Revision 1.14.1.2  2002/09/29 13:11:44  Eldad
// Fixed format of error message.
// Revision 1.14.1.1  2002/07/07 14:06:52  Eldad
// Duplicate revision
// Revision 1.13.1.2  2002/07/07 14:06:52  amos
// replace adaptor specific #ifdef with generic statements
// Revision 1.13.1.1  2001/04/02 07:51:30  amos
// Duplicate revision
// Revision 1.12.1.1  2000/12/25 08:20:11  Eldad
// Duplicate revision
// Revision 1.11  2000/11/08 17:19:13  amos
// back to main branch
// Revision 1.10.1.2  2000/11/08 17:19:13  amos
// remove redundat declaration of a local variable
// Revision 1.10.1.1  2000/07/11 09:23:50  amos
// Duplicate revision
// Revision 1.9  2000/01/31 09:49:39  amos
// merge 1.7.1.3 with 1.8
// Revision 1.8  1999/12/08 09:02:11  sasha
// Use "unsigned long int" for conevert pointer to number.
// The problem in bug.33456 was that some pointer (0xeffff974) 
// was converted to -268437132.
//  After using "unsigned long int" the pointer is converted
// to the 4026530164.
// Revision 1.7  1999/05/11 09:54:35  ofer
// Windows CE changes
// no iostream support and unicode ONLY ( no exceptions)
// Revision 1.7.1.3  2000/01/27 09:09:13  amos
// fix bug in addItemAtPosition() - prvent it from over write on the message code.
// add the time unit code to omscode2String()
// Revision 1.7.1.2  2000/01/26 14:26:37  amos
// add timeUnit to OMSData - all the standard interfaces
// Revision 1.7.1.1  1999/05/11 09:54:35  amos
// Duplicate revision
// Revision 1.6  1998/08/02 15:08:58  beery
// changing boolean->OMBoolean
// Revision 1.5  1997/03/09 08:13:06  yachin
// added windu include for unix port
// Revision 1.4  1997/02/27 09:58:01  yachin
// fixed bug in addItem(char *)
// Revision 1.3  1997/02/26 07:59:13  yachin
// added x2String which takes 2 parameters
// Revision 1.2  1996/11/27 06:23:13  yachin
// Revision 1.1  1996/11/24 12:37:21  yachin
// Initial revision
// Revision 1.12  1996/10/13 11:41:02  yachin
// Bug fixes
// Revision 1.11  1996/10/10 08:42:15  yachin
// Revision 1.10  1996/10/09 07:34:01  yachin
// Revision 1.9  1996/08/28 05:35:32  ofer
// Revision 1.8  1996/08/14 12:07:06  yachin
// Small changes for Ofer
// Revision 1.7  1996/08/06 12:49:54  yachin
// Tracer for Prototype 4
// Revision 1.6  1996/07/18 10:48:57  yachin
// Post Prototype 3 rewrite: virtual destructors, remarks, type changes and safe programing on deleted items
// Revision 1.5  1996/07/15 12:38:42  yachin
// Revision 1.4  1996/07/03 12:44:40  yachin
// Fixing bugs for "const" and "static" functions
// Revision 1.3  1996/06/20 10:21:56  yachin
// Revision 1.2  1996/06/19 10:18:55  yachin
// Revision 1.1  1996/06/17 05:33:25  yachin
// Initial revision
//
