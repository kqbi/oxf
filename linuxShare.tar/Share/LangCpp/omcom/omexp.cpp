#if ((!defined lint) && (!defined OM_NO_RCS_ID))
static const char *rcsid = "$Id: omexp.cpp 1.15 2007/03/11 12:34:36 ilgiga Exp $";
#endif 
//
//	file name   :	$Source: R:/StmOO/Master/cg/LangCpp/omcom/rcs/omexp.cpp $
//	file version:	$Revision: 1.15 $
//
//	purpose: Handling unix exceptions in animation 	
//
//	author(s):		Yachin Pnueli
//	date started:	27.10.97
//	date changed:	$Date: 2007/03/11 12:34:36 $
//	last change by:	$Author: ilgiga $
//
//	Licensed Materials - Property of IBM
//	(c) Copyright IBM Corporation 1997, 2008. All Rights Reserved.
//
#include "omexp.h"

#ifdef HAS_EXP_NOT_CATCHING_SIGNALS

#ifdef OM_STL
#include <csetjmp>
#include <csignal>
#else
#include <setjmp.h>
#include <signal.h>
#endif // OM_STL

void OMOsExpcetionHandler_signalHandler(int sig) {
	throw sig;
}

OMOsExpcetionHandler::OMOsExpcetionHandler() {
	// Store the old state and set new signal handlers
	oldSegHandler = signal(SIGSEGV, OMOsExpcetionHandler_signalHandler);
#ifdef OM_CATCH_SIGFPE
	oldFpeHandler = signal(SIGFPE, OMOsExpcetionHandler_signalHandler);
#endif
#ifdef OM_CATCH_SIGBUS
	oldBusHandler = signal(SIGBUS, OMOsExpcetionHandler_signalHandler);
#endif // define OM_CATCH_SIGBUS
#ifdef OM_CATCH_SIGILL
	oldIllHandler = signal(SIGILL, OMOsExpcetionHandler_signalHandler);
#endif // define OM_CATCH_SIGILL
#ifdef OM_CATCH_SIGABRT
	oldAbrtHandler = signal(SIGABRT, OMOsExpcetionHandler_signalHandler);
#endif // define OM_CATCH_SIGABRT
	

}

OMOsExpcetionHandler::~OMOsExpcetionHandler() {
	// ReStore the old state
	(void) signal(SIGSEGV, oldSegHandler);
#ifdef OM_CATCH_SIGFPE
	(void) signal(SIGFPE, oldSegHandler);
#endif 
#ifdef OM_CATCH_SIGBUS
	(void) signal(SIGBUS, oldBusHandler);
#endif // define OM_CATCH_SIGBUS
#ifdef OM_CATCH_SIGILL
	(void) signal(SIGILL, oldIllHandler);
#endif // define OM_CATCH_SIGILL
#ifdef OM_CATCH_SIGABRT
	(void) signal(SIGABRT, oldAbrtHandler);
#endif // define OM_CATCH_SIGABRT
}

#else
	// dummy fuction to avoid link warning
	void fummyF(int& i) { ++ i; }
#endif // HAS_EXP_NOT_CATCHING_SIGNALS
//
// $Log: omexp.cpp $
// Revision 1.15  2007/03/11 12:34:36  ilgiga
// Change copyright comment
// Revision 1.14  2007/03/01 16:43:32  ilgiga
// Telelogic instead of i-Logix
// Revision 1.13  2005/08/23 14:55:25  amos
// bugfix 85444 to main branch
// Revision 1.12.1.2  2005/08/22 10:07:09  amos
// provide a compilation switch (OM_NO_RCS_ID) to remove the definitions of the rcsid and hrcsid variables
// this is done to prevent compiler warnings for defined but not used global variables
// Revision 1.12  2003/01/20 15:18:03  avrahams
// bug fix 61035- add more signals catching for omtry
// Revision 1.11  2003/01/09 12:28:54  Eldad
// Fix b#61053
// Revision 1.10  2002/07/16 06:59:08  amos
// fix syntax error
// Revision 1.9  2002/07/15 12:30:38  avrahams
// Back to main
// Revision 1.8  2002/07/09 16:20:51  amos
// framework cleanup from RTOS specific code - back to r41 main branch
// Revision 1.7.2.2  2002/07/09 16:20:51  amos
// replace adaptor specific #ifdef with generic statements
// Revision 1.7.2.1  2001/05/02 12:46:36  amos
// Revision 1.7.1.2  2002/07/04 11:32:56  avrahams
// Clanup std namespace usage
// Revision 1.7.1.1  2001/05/02 12:46:36  avrahams
// Duplicate revision
// Revision 1.7  2001/05/02 12:46:36  amos
// comment statements aftert #endif
// Revision 1.6  2000/07/12 05:44:09  amos
// the main change related to modify char* to const char*.
// there are some other changes related to assignment of static member function as extern "C" functions.
// Revision 1.5  1998/06/23 12:31:39  yachin
// fix VX virtual table problem bug
// Revision 1.4  1997/12/29 13:28:52  ofer
// implement exception handling on unix the right way !!!!
// modif the macros of OMTRY and OM_CATCH_ALL
// omexp.cpp/h
// Revision 1.3  1997/10/29 13:29:39  yachin
// rewritten so signal is called on try
// Revision 1.2  1997/10/28 09:50:01  yachin
// Revision 1.1  1997/10/28 08:43:04  yachin
// Initial revision
//
