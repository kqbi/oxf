/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimResumeThread
	File Path	: ../AnimResumeThread.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimResumeThread.h"
//## auto_generated
#include "AnimField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimResumeThread
AnimResumeThread AnimResumeThread::animResumeThread;

AnimResumeThread::AnimResumeThread() {
    //#[ operation AnimResumeThread()
    code = resumeThread;
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimResumeThread::~AnimResumeThread() {
}

AnimMessage* AnimResumeThread::clone() {
    //#[ operation clone()
    AnimResumeThread *msg = new AnimResumeThread();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    return msg;
    //#]
}

void AnimResumeThread::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

/*********************************************************************
	File Path	: ../AnimResumeThread.cpp
*********************************************************************/
