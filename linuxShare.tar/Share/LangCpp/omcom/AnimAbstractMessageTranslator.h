/*********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimAbstractMessageTranslator
	File Path	: ../AnimAbstractMessageTranslator.h
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.		
*********************************************************************/

#ifndef AnimAbstractMessageTranslator_H
#define AnimAbstractMessageTranslator_H

//## auto_generated
#include "RiCppAnimMessageTranslator.h"
//## auto_generated
#include <oxf/ommap.h>
//## class AnimAbstractMessageTranslator
#include "AnimMessageTranslator.h"
//## link messagePrototypes
class AnimAbstractMessage;

//## operation getMessageClone(int)
class AnimMessage;

//## package RiCppAnimMessageTranslator

//## class AnimAbstractMessageTranslator
// An abstract translator. Implements 'common' translator mechanism. 
class AnimAbstractMessageTranslator : public AnimMessageTranslator {
    ////    Constructors and destructors    ////
    
public :

    //## operation AnimAbstractMessageTranslator()
    AnimAbstractMessageTranslator();

protected :

    // Copy constructor.
    //## operation AnimAbstractMessageTranslator(const AnimAbstractMessageTranslator& /*  */)
    AnimAbstractMessageTranslator(const AnimAbstractMessageTranslator& /* _translator */);

public :

    //## auto_generated
    virtual ~AnimAbstractMessageTranslator();
    
    ////    Operations    ////
    
    //## operation getLastErrorMessage() const
    virtual OMString getLastErrorMessage() const;
    
    // Get a clone of the message according to code.
    //## operation getMessageClone(int)
    AnimMessage* getMessageClone(int code);
    
    // Register message prototypes to be 'cloned' for message decoding.
    // Argument AnimMessage* animMessage :
    // Message to be registered.
    //## operation registerMessagePrototype(AnimMessage*)
    virtual void registerMessagePrototype(AnimMessage* animMessage);

protected :

    //## operation operator=(const AnimAbstractMessageTranslator& /*  */)
    void operator=(const AnimAbstractMessageTranslator& /* _translator */);
    
    ////    Additional operations    ////

public :

    //## auto_generated
    void setLastErrorMessage(OMString p_lastErrorMessage);
    
    //## auto_generated
    OMIterator<AnimAbstractMessage*> getMessagePrototypes() const;
    
    //## auto_generated
    void clearMessagePrototypes();
    
    //## auto_generated
    void removeMessagePrototypes(AnimAbstractMessage* p_AnimAbstractMessage);
    
    //## auto_generated
    AnimAbstractMessage* getMessagePrototypes(int key) const;
    
    //## auto_generated
    void addMessagePrototypes(int key, AnimAbstractMessage* p_AnimAbstractMessage);

protected :

    //## auto_generated
    void cleanUpRelations();
    
    ////    Attributes    ////
    
    // A string containing the last error message during encoding\decoding. 
    OMString lastErrorMessage;		//## attribute lastErrorMessage
    
    ////    Relations and components    ////
    
    OMMap<int, AnimAbstractMessage*> messagePrototypes;		//## link messagePrototypes
};

#endif
/*********************************************************************
	File Path	: ../AnimAbstractMessageTranslator.h
*********************************************************************/
