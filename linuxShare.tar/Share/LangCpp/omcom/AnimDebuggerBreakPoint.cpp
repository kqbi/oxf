/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimDebuggerBreakPoint
	File Path	: ../AnimDebuggerBreakPoint.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimDebuggerBreakPoint.h"
//## classInstance isRhapsodyBreak
#include "AnimBooleanField.h"
//## auto_generated
#include "AnimField.h"
//## classInstance taskID
#include "AnimIntField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimDebuggerBreakPoint
AnimDebuggerBreakPoint AnimDebuggerBreakPoint::animDebuggerBreakPointPrototype;

AnimDebuggerBreakPoint::AnimDebuggerBreakPoint() {
    initRelations();
    //#[ operation AnimDebuggerBreakPoint()
    code = debuggerBreak;
    
    // set the names      
    taskID->setName("taskID");
    isRhapsodyBreak->setName("isRhapsodyBreak");
    
    *isRhapsodyBreak = TRUE;
    
    // add fields to container  
    addField(taskID);
    addField(isRhapsodyBreak); 
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimDebuggerBreakPoint::~AnimDebuggerBreakPoint() {
    cleanUpRelations();
}

AnimMessage* AnimDebuggerBreakPoint::clone() {
    //#[ operation clone()
    AnimDebuggerBreakPoint *msg = new AnimDebuggerBreakPoint();   
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));   
    
    // request id
    rhp_long64_t id = (rhp_long64_t)(getTaskID()->getValue());
    msg->setTaskID((int)id);
    
    // isRhapsodyBreak
    OMBoolean b = (getIsRhapsodyBreak()->getValue() != 0);
    msg->setIsRhapsodyBreak(b);
    
    return msg;
    //#]
}

void AnimDebuggerBreakPoint::setIsRhapsodyBreak(OMBoolean value) {
    //#[ operation setIsRhapsodyBreak(OMBoolean)
    (*isRhapsodyBreak) = value;
    //#]
}

void AnimDebuggerBreakPoint::setTaskID(int id) {
    //#[ operation setTaskID(int)
    *taskID = id;
    //#]
}

void AnimDebuggerBreakPoint::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimBooleanField* AnimDebuggerBreakPoint::getIsRhapsodyBreak() const {
    return isRhapsodyBreak;
}

AnimBooleanField* AnimDebuggerBreakPoint::newIsRhapsodyBreak() {
    isRhapsodyBreak = new AnimBooleanField;
    return isRhapsodyBreak;
}

void AnimDebuggerBreakPoint::deleteIsRhapsodyBreak() {
    delete isRhapsodyBreak;
    isRhapsodyBreak = NULL;
}

AnimIntField* AnimDebuggerBreakPoint::getTaskID() const {
    return taskID;
}

AnimIntField* AnimDebuggerBreakPoint::newTaskID() {
    taskID = new AnimIntField;
    return taskID;
}

void AnimDebuggerBreakPoint::deleteTaskID() {
    delete taskID;
    taskID = NULL;
}

void AnimDebuggerBreakPoint::initRelations() {
    isRhapsodyBreak = newIsRhapsodyBreak();
    taskID = newTaskID();
}

void AnimDebuggerBreakPoint::cleanUpRelations() {
    {
        deleteTaskID();
    }
    {
        deleteIsRhapsodyBreak();
    }
}

/*********************************************************************
	File Path	: ../AnimDebuggerBreakPoint.cpp
*********************************************************************/
