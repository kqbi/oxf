/********************************************************************
	Component	: MessageTranslator 
	Configuration 	: DefaultConfig
	Model Element	: AnimRhapTranslator
	File Path	: ../AnimRhapTranslator.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimRhapTranslator.h"
//## auto_generated
#include "AnimAbstractMessage.h"
//## operation decodeField(AnimBooleanField*)
#include "AnimBooleanField.h"
//## operation decodeField(AnimCodeField*)
#include "AnimCodeField.h"
//## operation decodeField(AnimIntField*)
#include "AnimIntField.h"
//## operation decodeField(AnimListField*)
#include "AnimListField.h"
//## operation decodeMessage(void *)
#include "AnimMessage.h"
//## operation decodeField(AnimMessageField*)
#include "AnimMessageField.h"
//## operation decodeField(AnimPointerField*)
#include "AnimPointerField.h"
//## operation decodeField(AnimStringField*)
#include "AnimStringField.h"
//## operation decodeField(AnimStringOrPointerField*)
#include "AnimStringOrPointerField.h"
//## operation decodeField(AnimTimestampField*)
#include "AnimTimestampField.h"
//## auto_generated
#include <oxf/os.h>
//## package RiCppAnimMessageTranslator

//## class AnimRhapTranslator
AnimRhapTranslator* AnimRhapTranslator::_instance = NULL;

AnimRhapTranslator::AnimRhapTranslator() {
    //#[ operation AnimRhapTranslator()
    encodedData = NULL;
    decodedMessage = NULL;
    encodeMutex = NULL;
    decodeMutex = NULL;
    
    #ifdef OMAPPLICATION
    #ifndef OM_NO_PRE_MAIN_RTOS_RESOURCES
    encodeMutex = OMOSFactory::instance()->createOMOSMutex();
    decodeMutex = OMOSFactory::instance()->createOMOSMutex();
    #endif // !OM_NO_PRE_MAIN_RTOS_RESOURCES
    #endif // OMAPPLICATION
    //#]
}

AnimRhapTranslator::~AnimRhapTranslator() {
    //#[ operation ~AnimRhapTranslator()
    if (encodeMutex != 0)
    {
    	delete encodeMutex;
    	encodeMutex = 0;
    }
    if (decodeMutex != 0)
    {
    	delete decodeMutex;
    	decodeMutex = 0;
    }
    _instance = NULL;
    //#]
}

void AnimRhapTranslator::decodeField(AnimIntField* field) {
    //#[ operation decodeField(AnimIntField*)
    if (field == NULL) return;
    
    rhp_long64_t val = (rhp_long64_t)omsData->safeGetInt(omsDataPosition);
    field->setValue((gen_ptr)val);
    //#]
}

void AnimRhapTranslator::decodeField(AnimPointerField* field) {
    //#[ operation decodeField(AnimPointerField*)
    if (field == NULL) return;
    
    gen_ptr val = omsData->safeGetPointer(omsDataPosition);
    field->setValue((gen_ptr)val);
    
    //#]
}

void AnimRhapTranslator::decodeField(AnimListField* field) {
    //#[ operation decodeField(AnimListField*)
    if (field == NULL) return;    
    int count = omsData->safeGetInt(omsDataPosition);
    int i;
    for (i=0; i<count; ++i)
    {
        AnimSimpleField *f = field->getFieldPrototypeClone();
        f->decode(this);
        field->addField(f); 
    }
    
    
    
    
    //#]
}

void AnimRhapTranslator::decodeField(AnimStringField* field) {
    //#[ operation decodeField(AnimStringField*)
    if (field == NULL) return;
    
    OMString tmp = omsData->safeGetString(omsDataPosition);
    const char *str = (const char *)(tmp);
    field->setValue((gen_ptr)(rhp_long64_t)str);
    //#]
}

void AnimRhapTranslator::decodeField(AnimTimestampField* field) {
    //#[ operation decodeField(AnimTimestampField*)
    if (field == NULL) return;
    
    timeUnit val = omsData->safeGetTimeUnit(omsDataPosition);
    field->setValue((gen_ptr)val);
    
    //#]
}

void AnimRhapTranslator::decodeField(AnimMessageField* field) {
    //#[ operation decodeField(AnimMessageField*)
    if (field == NULL) return;   
    
    OMSData *newOmsData = omsData->getOMSData(omsDataPosition);
    
    if (newOmsData != NULL)
    {
        OMSData *oldOmsData = omsData;
        OMSPosition oldOmsDataPosition = omsDataPosition;
        
        AnimMessage *oldDecodedMessage = decodedMessage;
        decodeMessage(newOmsData);       
        field->setValue((gen_ptr)(rhp_long64_t)decodedMessage); 
        delete decodedMessage;              
        decodedMessage = oldDecodedMessage;
        
        oldOmsData->addItem((gen_ptr)(rhp_long64_t)omsData);
    
        omsData = oldOmsData;
        omsDataPosition = oldOmsDataPosition;
    }
     
    
    //#]
}

void AnimRhapTranslator::decodeField(AnimBooleanField* field) {
    //#[ operation decodeField(AnimBooleanField*)
    if (field == NULL) return;
    
    OMBoolean value = (omsData->getCode(omsDataPosition) != 0);
    field->setValue((gen_ptr)value);
    //#]
}

void AnimRhapTranslator::decodeField(AnimCodeField* field) {
    //#[ operation decodeField(AnimCodeField*)
    if (field == NULL) return;
    
    unsigned char val = omsData->getCode(omsDataPosition);
    field->setValue((gen_ptr)(rhp_long64_t)val);
    //#]
}

void AnimRhapTranslator::decodeField(AnimStringOrPointerField* field) {
    //#[ operation decodeField(AnimStringOrPointerField*)
    if (field == NULL) return;
    
    gen_ptr value = NULL;
    
    if (omsData->isPointer(omsDataPosition)) {    
    	value = omsData->safeGetPointer(omsDataPosition);
    	field->setPointerValue(value);
    }
    else if (omsData->isString(omsDataPosition)) {
    	field->setAsString();
    	OMString tmp = omsData->safeGetString(omsDataPosition);
    	const char * str = (const char *)(tmp);
    	field->setStringValue((gen_ptr)(rhp_long64_t)str);
    }  
    
    //#]
}

AnimMessage* AnimRhapTranslator::decodeMessage(void * data) {
    //#[ operation decodeMessage(void *)
    if (data == NULL) return NULL;
    
    if (decodeMutex != 0)
    	decodeMutex->lock();
    
    omsData = (OMSData *)data;
    omsDataPosition = omsData->getFirst();
    
    // try and see if there isf a time stamp
    OMBoolean timeUnitSet = FALSE;
    timeUnit timestamp = 0;
    if (omsData->isTimeUnit(omsDataPosition))
    {    
      timeUnitSet = TRUE;
      timestamp = omsData->safeGetTimeUnit(omsDataPosition);
    #ifdef OMANIMATOR
      OMSData* tmp = omsData;
    #endif
      omsData = omsData->safeGetOMSData(omsDataPosition);   
      
    #ifdef OMANIMATOR
    	// delete the old message.
    	// In animator the socket creates s item so we must delete it
    	// In tracer we use the "memory" of the caller to handle
    	delete tmp;
    #endif 
      // reset position
      omsDataPosition = omsData->getFirst();
    }
    
    gen_ptr dest = omsData->safeGetPointer(omsDataPosition);
    // if the dest equals OMInConstruction then the next field is the source
    // the TOM will have to call TOMSystem::instance()->getInstanceByReal(p);
    // to get the TOM proxy  
    bool bInConstruction = false;
    if (dest == (gen_ptr)OMUnderConstruction) {  
    	bInConstruction = true;
    	dest = omsData->safeGetPointer(omsDataPosition);
    }
    
    
    int code = omsData->safeGetOMNotify(omsDataPosition);
    
    decodedMessage  = getMessageClone(code);
    
    if (decodedMessage != NULL)
    {     
    	decodedMessage->setConstructionMessage(bInConstruction);
        decodedMessage->setDestOrSource(dest);                       
        if (timeUnitSet)
            decodedMessage->setTimeStamp(timestamp);
        AnimField *field = NULL;
        decodedMessage->resetFieldIterator();
        while ((field = decodedMessage->getNextField()) != NULL)
        {
            field->decode(this);
        }
    }
    
    AnimMessage *retVal = decodedMessage;
    
    if (decodeMutex != 0)
    	decodeMutex->unlock();       
                            
    return retVal;
    //#]
}

void AnimRhapTranslator::encodeField(AnimIntField* field) {
    //#[ operation encodeField(AnimIntField*)
    if (field == NULL) return;
    rhp_long64_t value = (rhp_long64_t)(field->getValue());
    encodedData->addItem((int)value);
    
    //#]
}

void AnimRhapTranslator::encodeField(AnimListField* field) {
    //#[ operation encodeField(AnimListField*)
    if (field == NULL) return;
    
    int size = field->getSize();
    OMSData *oldEncodedData = encodedData;
    encodedData = new OMSListData(size);
    
    AnimField *f;
    while (( f = field->getNextField() ) != NULL)
    {
        f->encode(this);
    }        
    ((OMSListData *)encodedData)->end();
    
    oldEncodedData->concatData(*encodedData);
    delete encodedData;
    encodedData = oldEncodedData;
    
    //#]
}

void AnimRhapTranslator::encodeField(AnimPointerField* field) {
    //#[ operation encodeField(AnimPointerField*)
    if (field == NULL) return;
    gen_ptr value = field->getValue();
    encodedData->addItem(value);
    
    //#]
}

void AnimRhapTranslator::encodeField(AnimStringField* field) {
    //#[ operation encodeField(AnimStringField*)
    if (field == NULL) return;           
    char *tmp = (char *)(rhp_long64_t)(field->getValue());
    OMString value = (OMString)(tmp);
    encodedData->addItem(value);   
    delete[] tmp;
    
    //#]
}

void AnimRhapTranslator::encodeField(AnimTimestampField* field) {
    //#[ operation encodeField(AnimTimestampField*)
    if (field == NULL) return;
    
    
    if (field->isValueSet()) 
    {
      timeUnit time = (timeUnit)(field->getValue());
      OMSData *oldData = encodedData;
      encodedData = new OMSData();
      encodedData->addItem(time);
      encodedData->addItem(*oldData);
    }
    //#]
}

void AnimRhapTranslator::encodeField(AnimMessageField* field) {
    //#[ operation encodeField(AnimMessageField*)
    if (field == NULL) return;
    
    AnimMessage *msg = (AnimMessage *)(rhp_long64_t)(field->getValue());
    
    if (msg != NULL)
    {
        OMSData *oldEncodedData = encodedData;
        
        encodeMessage(msg);
        
        oldEncodedData->addItem(*encodedData);  
        delete encodedData;
        encodedData = oldEncodedData;
    }
    //#]
}

void AnimRhapTranslator::encodeField(AnimBooleanField* field) {
    //#[ operation encodeField(AnimBooleanField*)
    if (field == NULL) return;
    OMBoolean value = (field->getValue() != 0);
    encodedData->addCode((unsigned char)value);
    
    //#]
}

void AnimRhapTranslator::encodeField(AnimCodeField* field) {
    //#[ operation encodeField(AnimCodeField*)
    if (field == NULL) return;
    unsigned char value = (unsigned char)(rhp_long64_t)(field->getValue());
    encodedData->addCode(value);
    
    //#]
}

void AnimRhapTranslator::encodeField(AnimStringOrPointerField* field) {
    //#[ operation encodeField(AnimStringOrPointerField*)
    if (field == NULL) return;           
    if (field->isString()) 
    {
    	char *tmp = (char *)(rhp_long64_t)(field->getValue());
    	OMString value = (OMString)(tmp);
    	encodedData->addItem(value);   
    	delete[] tmp;
    }
    else if (field->isPointer()) 
    {   
    	gen_ptr value = field->getValue();
    	encodedData->addItem(value);
    }
    //#]
}

void * AnimRhapTranslator::encodeMessage(AnimMessage* message) {
    //#[ operation encodeMessage(AnimMessage*)
    
    if (message == NULL) return NULL;   
    if (encodeMutex != 0)
    	encodeMutex->lock(); 
    
    void* retVal = NULL; 
    
    // Allocate a new OMSData. 
    // The user is responsible to free this
    encodedData = new OMSData();   
    
    AnimPointerField *destF = 
      message->getDestOrSource();
    
    gen_ptr dest = (gen_ptr)destF->getValue();
    if (dest == (gen_ptr)OMUnderConstruction && (message->getOrigSource() != NULL))
    { 
    	dest = message->getOrigSource();
    	encodedData->addItem((gen_ptr)0x1);	
    }
    encodedData->addItem(dest);
                                 
    unsigned char code = (unsigned char)(message->getCode());
    
    encodedData->addCode(code);       
    
    AnimField *field = NULL;         
    message->resetFieldIterator();
    while ((field = message->getNextField()) != NULL)
    {
        field->encode(this);
    }
    
    // time stamp                 
    AnimTimestampField* timestampF = 
        message->getTimeStamp();
    
    if (timestampF->isValueSet())
        timestampF->encode(this);            
        
    retVal = (void *)encodedData;
    
    if (encodeMutex != 0)
    	encodeMutex->unlock();
    
    return retVal;
    //#]
}

void AnimRhapTranslator::initializeMultiThreadedProtection() {
    //#[ operation initializeMultiThreadedProtection()
    #ifdef OMAPPLICATION
    
    if (encodeMutex == NULL)
        encodeMutex = OMOSFactory::instance()->createOMOSMutex();
    if (decodeMutex == NULL)
        decodeMutex = OMOSFactory::instance()->createOMOSMutex();
    
    #endif // OMAPPLICATION
    //#]
}

AnimRhapTranslator* AnimRhapTranslator::instance() {
    //#[ operation instance()
    if (_instance == NULL)
      _instance = new AnimRhapTranslator();
    return _instance;
    //#]
}

OMSData* AnimRhapTranslator::getEncodedData() const {
    return encodedData;
}

void AnimRhapTranslator::setEncodedData(OMSData* p_encodedData) {
    encodedData = p_encodedData;
}

/*********************************************************************
	File Path	: ../AnimRhapTranslator.cpp
*********************************************************************/
