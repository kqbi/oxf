/********************************************************************
	Component	: AnimMessages 
	Configuration 	: DefaultConfig
	Model Element	: AnimRemoveBreakpoint
	File Path	: ../AnimRemoveBreakpoint.cpp
	
	Licensed Materials - Property of IBM
	(c) Copyright IBM Corporation 2009. All Rights Reserved.	
*********************************************************************/

//## auto_generated
#include "AnimRemoveBreakpoint.h"
//## classInstance breakpointCode
#include "AnimCodeField.h"
//## auto_generated
#include "AnimField.h"
//## operation clone()
#include "AnimMessage.h"
//## auto_generated
#include "AnimPointerField.h"
//## classInstance breakpointData
#include "AnimStringField.h"
//## auto_generated
#include "AnimTimestampField.h"
//## auto_generated
#include "omnote.h"
//## package RiCppAnimMessages

//## class AnimRemoveBreakpoint
AnimRemoveBreakpoint AnimRemoveBreakpoint::animRemoveBreakpoint;

AnimRemoveBreakpoint::AnimRemoveBreakpoint() {
    initRelations();
    //#[ operation AnimRemoveBreakpoint()
    code = removeBreakpoint;
    
    // set the names
    breakpointCode->setName("breakpointCode");
    animItem->setName("animItem");
    breakpointData->setName("breakpointData");
    
    // add fields to container
    addField(breakpointCode);
    addField(animItem);
    addField(breakpointData);
    
    // register in translator
    registerInTranslator();
    
    //#]
}

AnimRemoveBreakpoint::~AnimRemoveBreakpoint() {
    cleanUpRelations();
}

AnimMessage* AnimRemoveBreakpoint::clone() {
    //#[ operation clone()
    AnimRemoveBreakpoint *msg = new AnimRemoveBreakpoint();
    msg->setDestOrSource(*(getDestOrSource()));
    msg->setTimeStamp(*(getTimeStamp()));
    msg->setBreakpointCode((unsigned char)(rhp_long64_t)(getBreakpointCode()->getValue()));
    msg->setAnimItem(getAnimItem()->getValue());   
    char *tmp = (char *)(rhp_long64_t)(getBreakpointData()->getValue());
    msg->setBreakpointData((OMString)(tmp));   
    delete[] tmp;
    return msg;
    //#]
}

void AnimRemoveBreakpoint::setAnimItem(gen_ptr value) {
    //#[ operation setAnimItem(gen_ptr)
    *animItem = value;
    //#]
}

void AnimRemoveBreakpoint::setBreakpointCode(unsigned char value) {
    //#[ operation setBreakpointCode(unsigned char)
    *breakpointCode= value;
    //#]
}

void AnimRemoveBreakpoint::setBreakpointData(OMString value) {
    //#[ operation setBreakpointData(OMString)
    *breakpointData = value;
    //#]
}

void AnimRemoveBreakpoint::registerInTranslator() {
    //#[ operation registerInTranslator()
    static OMBoolean isRegistered = FALSE;
    
    if (isRegistered == FALSE)
    {
        AnimMessageTranslator *trans = AnimTranslatorFactory::instance()->getDefaultTranslator();
        if (trans != NULL) {
            trans->registerMessagePrototype(this);  
            isRegistered = TRUE;
        }    
    }
    //#]
}

AnimPointerField* AnimRemoveBreakpoint::getAnimItem() const {
    return animItem;
}

AnimPointerField* AnimRemoveBreakpoint::newAnimItem() {
    animItem = new AnimPointerField;
    return animItem;
}

void AnimRemoveBreakpoint::deleteAnimItem() {
    delete animItem;
    animItem = NULL;
}

AnimCodeField* AnimRemoveBreakpoint::getBreakpointCode() const {
    return breakpointCode;
}

AnimCodeField* AnimRemoveBreakpoint::newBreakpointCode() {
    breakpointCode = new AnimCodeField;
    return breakpointCode;
}

void AnimRemoveBreakpoint::deleteBreakpointCode() {
    delete breakpointCode;
    breakpointCode = NULL;
}

AnimStringField* AnimRemoveBreakpoint::getBreakpointData() const {
    return breakpointData;
}

AnimStringField* AnimRemoveBreakpoint::newBreakpointData() {
    breakpointData = new AnimStringField;
    return breakpointData;
}

void AnimRemoveBreakpoint::deleteBreakpointData() {
    delete breakpointData;
    breakpointData = NULL;
}

void AnimRemoveBreakpoint::initRelations() {
    animItem = newAnimItem();
    breakpointCode = newBreakpointCode();
    breakpointData = newBreakpointData();
}

void AnimRemoveBreakpoint::cleanUpRelations() {
    {
        deleteBreakpointData();
    }
    {
        deleteBreakpointCode();
    }
    {
        deleteAnimItem();
    }
}

/*********************************************************************
	File Path	: ../AnimRemoveBreakpoint.cpp
*********************************************************************/
