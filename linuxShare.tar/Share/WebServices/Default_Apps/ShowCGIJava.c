/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

#include <string.h>

extern void Find_Arg(char *value_name, void *args,char **valpp);
extern int HTML_Write_text(void *fp,  char data[]);
extern int HTML_Write_Header(void *fp);
extern int ABS_GetAggregateSons (int papaId, char ***children);
extern int absmib_get_permission(int id);
extern void absmib_update_relations();
extern int type2metatype(char **metatype, int type_id);
int ABS_GetChoiceList_by_typeId(int key,char *listp[]);
extern void Write_Head_CSS(void *fp);
extern int HTML_Write_Tail(void *fp);
extern void Write_Signature(void *fp);
extern int absmib_get_value_type_by_name(char *name,char** value,int* type_id);
extern void free_strings_array(char **raw_pairs,int num);
extern void free_string(char *s);


extern int showAgg(void *client, char *var_name, int MibId, char *index, char *pref);
extern int setFlatComp (void *client, char *var_name, char *meta, int MibId, char *val, int type_id, int aSts, char *index, char *pref);
extern void writeNA (void *client, char *ind, char *pref);
extern int show_aggregate_request(void *client, void *args);



int App_SetCompJava(void *client, void *args)
{
	char *var_name;
    int type_id;
    
    int MibId;
    char *metaType;
    char *valstr;
	char *index;
	int accessStatus;

	Find_Arg("mibvar", args,&var_name);
	Find_Arg("index", args, &index);
	MibId  = absmib_get_value_type_by_name(var_name,&valstr, &type_id);
    
	
	if (MibId < 0)
		writeNA(client, index, "window");
	else
	{
		type2metatype(&metaType, type_id);
		accessStatus = absmib_get_permission(MibId);
		if (!strcmp(metaType, "aggr") || !strcmp(metaType, "spaggr") || !strcmp(metaType, "view"))
		{
			showAgg(client, var_name, MibId, index, "window");
		}
		else
		{
			setFlatComp(client, var_name, metaType, MibId, valstr, type_id, accessStatus, index, "window");
		}
	}

	return 1;
}



int App_SetCompCollJava(void *client, void *args)
{
    int MibId;
    char *metaType;
    char *valstr;
	int type_id;
	char *var_name;
	char *index;
	int accessStatus;

	Find_Arg("mibvar", args,&var_name);
	Find_Arg("index", args, &index);
	MibId  = absmib_get_value_type_by_name(var_name,&valstr, &type_id);

	if (MibId < 0)
		writeNA(client, index, "window");
	else
	{
		type2metatype(&metaType, type_id);
		accessStatus = absmib_get_permission(MibId);
		setFlatComp(client, var_name, metaType, MibId, valstr, type_id, accessStatus, index, "window");
	}
	
	return 1;
}




