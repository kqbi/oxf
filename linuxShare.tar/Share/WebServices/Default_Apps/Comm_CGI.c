/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/
#include <stdlib.h>
#include <stdio.h>



extern int HTML_Write_text(void *fp,  char data[]);
extern int HTML_Write_Header(void *fp);
extern int HTML_Write_Tail(void *fp);

extern void Find_Arg(char *value_name, void *args,char **valpp);
extern void ST_add_refresh_hits();
extern int absmib_set_value_by_id(int id,char* valuep);
	
extern int getIdsVals (void *client, void *args);
extern int getAndPrintVals(void *client, void *args);
extern int changesInAggregate (char *agg_name, char *sts);



int App_GetMibIds (void *client, void *args)
{
	HTML_Write_text(client, "<html><head></head><body><script>\n");
	HTML_Write_text (client, "parent.document.docMng.setIds(\n");
	getIdsVals(client, args);
	HTML_Write_text(client, ");\n</script>");
	HTML_Write_Tail(client);

	return 1;
}



int App_Refresh(void *client, void *args)
{
	char buff[120];
	char *aggr_name = "agg";
	char *status = "2";
	char *tmId;
	
	
	Find_Arg("tmID", args, &tmId);
	HTML_Write_text(client, "<html><head></head><body>\n<script>\n");

	if (changesInAggregate(aggr_name, status))
	{
		sprintf (buff, "parent.clearTimeout(%s);\n", tmId);
		HTML_Write_text(client,"parent.location.reload ()");
	}
	else
	{
		HTML_Write_text(client,"parent.document.docMng.updateValues(\n");
		sprintf (buff, "%s,", tmId);
		HTML_Write_text (client, buff);

		getAndPrintVals(client, args);
	}
	HTML_Write_text(client, ");\n</script>");
	HTML_Write_Tail(client);
	ST_add_refresh_hits();

	return(1);
}


int App_MibSaveVal(void *client, void *args)
{
	char *MibId, *val;

	Find_Arg("id", args, &MibId);
	Find_Arg("val", args, &val);
	absmib_set_value_by_id(atoi(MibId), val);


	HTML_Write_text (client, "<html><head></head><body><script>");
	HTML_Write_text (client, "parent.document.docMng.immUpdateValues(");
	getAndPrintVals (client, args);
	HTML_Write_text (client, ");\n</script>");
	HTML_Write_Tail(client);

	return(1);
 
}
