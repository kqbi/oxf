/******************************************************************************
*	file name   :	CgiService.c 
*
*	purpose: Contains CGI functions
*	portability:	Machine Independent
*
*
*	author(s):	 George Bilkis   
*	date started:	30-Jan-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <stdio.h>
#include <string.h>
/*******************************************************************************/

int Agg_GetChilds(int id,int out_childs[],int max_childs);
char **alloc_strings_array(int len);
int absmib_get_name_by_id(int id,char** namep);
