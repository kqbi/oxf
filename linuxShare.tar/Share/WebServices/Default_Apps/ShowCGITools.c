/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

#include <stdio.h>
#include <string.h>

#define MAX_CHILDS 100
#define MAX_CHOICES 20

extern void Find_Arg(char *value_name, void *args,char **valpp);
extern int HTML_Write_text(void *fp,  char data[]);
extern int HTML_Write_Header(void *fp);
extern int ABS_GetAggregateSons (int papaId, char ***children);
extern int absmib_get_permission(int id);
extern void absmib_update_relations();
extern int type2metatype(char **metatype, int type_id);
int ABS_GetChoiceList_by_typeId(int key,char *listp[]);
extern void Write_Head_CSS(void *fp);
extern int HTML_Write_Tail(void *fp);
extern void Write_Signature(void *fp);
extern int absmib_get_value_type_by_name(char *name,char** value,int* type_id);
extern void free_strings_array(char **raw_pairs,int num);
extern void free_string(char *s);


static int isChoiceList(char *type)
{
	return (!strcmp(type, "choice") || !strcmp(type, "bool"));
}

/****************************************************************
pref - is a prefix for the commlayer: "window" in case of java layer
"parent" in case of JS layer
******************************************************************/
int showAgg(void *client, char *var_name, int MibId, char *index, char *pref)
{
	int i, j;
	char buff[500];
	char shortChildVal[100];
	int numberOfSons;
	char **aggregateSons;
	
	int childId;
	char *childType;
	char *childVal;
	int type_id;
	int accessStatus;
	char *vals[MAX_CHOICES];
	int isCList;
	
	sprintf (buff, "%s.document.docMng.defComp(", pref);
	HTML_Write_text(client, buff);
	sprintf (buff, "%s, %d, 0, 'aggr', 0, 0, 'self'", index, MibId);
	HTML_Write_text(client, buff);
	HTML_Write_text(client, ");\n");
	HTML_Write_text(client, "var indices = new Array;\n");
	
	absmib_update_relations();
	
	numberOfSons = ABS_GetAggregateSons (MibId, &aggregateSons);
	for (i = 0; i < numberOfSons; i++)
	{
		if ((childId = absmib_get_value_type_by_name(aggregateSons[i], &childVal, &type_id)) >= 0)
		{
			accessStatus = absmib_get_permission(childId);
			type2metatype(&childType, type_id);
			if ((isCList = isChoiceList(childType)) && (accessStatus == 1))
				sprintf (buff, "indices[indices.length] = %s.document.docMng.defObj ('%s', '%d', '%s', 'int', %d, 1, '%s');\n", pref, aggregateSons[i], childId, childVal, accessStatus, var_name);
			else 
			{
				strncpy(shortChildVal, childVal, 80);
				shortChildVal[80] = 0;
				sprintf (buff, "indices[indices.length] = %s.document.docMng.defObj ('%s', '%d', '%s', '%s', %d, 1, '%s');\n", pref, aggregateSons[i], childId, shortChildVal, childType, accessStatus, var_name);
			}
			HTML_Write_text (client, buff);
			if (isCList)
			{
				sprintf (buff, "%s.document.docMng.fillChoices(indices[indices.length - 1], ", pref);
				HTML_Write_text (client, buff);
				ABS_GetChoiceList_by_typeId (type_id, vals);
				for (j = 0; vals[j]; j++)
				{
					if (vals[j + 1])
						sprintf (buff, "'%s', ", vals[j]);
					else
						sprintf (buff, "'%s'", vals[j]);
					HTML_Write_text (client, buff);
				}
				HTML_Write_text (client, ");\n");
			}
			if(childVal)
				free_string(childVal);
		}
		else
		{
			sprintf (buff, "window.alert('%s does not exist in device');\n", aggregateSons[i]);
			HTML_Write_text (client, buff);
		}
	}
	sprintf (buff, "%s.document.docMng.drawAggExp(%s, indices);\n", pref,index);
	HTML_Write_text (client, buff);
	
	free_strings_array(aggregateSons,numberOfSons);
	
	return 1;
}



/*********************************************************************
* This function is called from SetCompJava or SetCompJS: and is a building block called 
* from JS function show(component).
* 
* This function creates flat representation of the component which it required to show.
* I.E. flat types or flat (folder) representation of the aggregates.
*
* ARGS:
* @param client   - HTML page to send to
* @param var_name - Varaiable's name
* @param meta     - MetaType of a variable
* @param MibId    - mib id of a variable
* @param val      - value of a varaiable
* @param type_id  - type id of a variable
* @param aSts     - variable permissions: 0 Not Accessible
*                                         1 Read Only
*                                         2 Write Only
* @param pref     - Comm Layer prefix: in case JAVA: window
*                                      in case JS:   parent
************************************************************************/
int setFlatComp (void *client, char *var_name, char *meta, int MibId, char *val, int type_id, int aSts, char *index, char *pref)
{
	char buff[256];
	int sts, j;
	char *vals[MAX_CHOICES];
	int bIsUnsignedNumberMetaType = (!strcmp (meta, "unsigned long")  || !strcmp (meta, "unsigned int") || !strcmp (meta, "unsigned char") || !strcmp (meta, "unsigned short"));

	sprintf (buff, "%s.document.docMng.defComp(", pref);
	HTML_Write_text(client, buff);
	sprintf(buff, "'%s', %d, '", index, MibId);
	HTML_Write_text (client, buff);
	HTML_Write_text(client, val);
	sprintf(buff, "', '%s',%d, 0, 'self'", meta, aSts);
	HTML_Write_text(client, buff);
	HTML_Write_text(client, ");\n");
	
	sts = (!strcmp(meta, "choice") || !strcmp(meta, "bool"));

	if(!strcmp (meta, "char") || !strcmp(meta, "int") || !strcmp(meta, "double") || !strcmp(meta, "long") || bIsUnsignedNumberMetaType || (sts && aSts == 1))
	{	
		sprintf (buff, "%s.document.docMng.drawNum(%s);\n", pref, index);
		HTML_Write_text (client, buff);
	}
	else if (sts && aSts != 1)
	{
		sprintf (buff, "%s.document.docMng.fillChoices(%s, ", pref, index);
		HTML_Write_text (client, buff);
		ABS_GetChoiceList_by_typeId (type_id, vals);
		for (j = 0; vals[j]; j++)
		{
			if (vals[j + 1])
				sprintf (buff, "'%s', ", vals[j]);
			else
				sprintf (buff, "'%s'", vals[j]);
			HTML_Write_text (client, buff);
		}
		HTML_Write_text (client, ");\n");
		sprintf (buff, "%s.document.docMng.drawCList(%s);\n", pref, index);
		HTML_Write_text(client, buff);
	}
	else if (!strcmp(meta, "string"))
	{
		sprintf (buff, "%s.document.docMng.drawStr(%s);\n", pref, index);
		HTML_Write_text(client, buff);
	}
	else if (!strcmp(meta, "unari"))
	{
		sprintf (buff, "%s.document.docMng.drawBut(%s);\n", pref,index);
		HTML_Write_text(client, buff);
	}
	else /*if(!strcmp(meta, "undefined"))*/
	{
		sprintf (buff, "%s.document.docMng.drawUndef(%s);\n", pref,index);
		HTML_Write_text(client, buff);
	}
	return 1;
}


void writeNA (void *client, char *ind, char *pref)
{
	char buff[256];
	sprintf(buff, "%s.document.docMng.defNA(", pref);
	HTML_Write_text(client, buff);
	sprintf (buff, "'%s');\n", ind);
	HTML_Write_text(client, buff);
}


int show_aggregate_request(void *client, void *args)
{
	char buff[256];
	char *var_name;   
	
	Find_Arg("mibvar", args, &var_name);
	
	HTML_Write_Header(client);
	HTML_Write_text(client, "<script src='manage.inc'></script></head><body>\n");
	HTML_Write_text(client, "<script>\n");
	sprintf (buff, "show('%s');</script>", var_name);
	HTML_Write_text(client, buff);
	
	return 1;
}

int App_ShowAgg(void *client, void *args)
{
	show_aggregate_request(client, args);
	Write_Signature (client);
	HTML_Write_Tail(client);
	
	return 1;
}


int App_ShowFAgg(void *client, void *args)
{
	show_aggregate_request(client, args);
	HTML_Write_Tail(client);
	return 1;
}

