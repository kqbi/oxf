/******************************************************************************
*	file name   :	ABS_CgiFunc.c 
*
*	purpose: Contains CGI functions
*	portability:	Machine Independent
*
*
*	author(s):	 George Bilkis   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/

/*******************************************************************************/


extern int App_AllTree(void *client, char *cgi_name, void *args);




/**********************************************************/
void main_page(void *client, void *args)
{
	App_AllTree(client, "cgibin", args);
}
/**********************************************************/
void Abstract_Default(void *client, void *args)
{
	main_page(client, args);
}
