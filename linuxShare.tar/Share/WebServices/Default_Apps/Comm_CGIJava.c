/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

#include <stdlib.h>
#include <stdio.h>


extern int HTML_Write_text(void *fp,  char data[]);
extern int HTML_Write_Header(void *fp);
extern int HTML_Write_Tail(void *fp);

extern void Find_Arg(char *value_name, void *args,char **valpp);
extern void ST_add_refresh_hits();
extern int absmib_set_value_by_id(int id,char* valuep);
	
extern int getIdsVals (void *client, void *args);
extern int getAndPrintVals(void *client, void *args);
extern int changesInAggregate (char *agg_name, char *sts);




int App_GetMibIdsJava (void *client, void *args)
{
	HTML_Write_text(client, "window.document.docMng.setIds(");
	getIdsVals(client, args);
	HTML_Write_text(client, ");");

	return 1;
}

int App_RefreshJava(void *client, void *args)
{
	char buff[120];
	char *aggr_name = "agg";
	char *status = "2";
	char *tmId;
	
	
	Find_Arg("tmID", args, &tmId);

	if (changesInAggregate(aggr_name, status))
	{
		sprintf (buff, "window.clearTimeout(%s);\n", tmId);
		HTML_Write_text(client,"window.location.reload ()");
	}
	else
	{
		HTML_Write_text(client,"window.document.docMng.updateValues(\n");
		sprintf (buff, "%s,", tmId);
		HTML_Write_text (client, buff);

		getAndPrintVals(client, args);
	}
	HTML_Write_text(client, ");");
	ST_add_refresh_hits();

	return(1);
}


int App_MibSaveValJava(void *client, void *args)
{
	char *MibId, *val;

	Find_Arg("id", args, &MibId);
	Find_Arg("val", args, &val);
	absmib_set_value_by_id(atoi(MibId), val);


	HTML_Write_text (client, "window.document.docMng.immUpdateValues(");
	getAndPrintVals (client, args);
	HTML_Write_text (client, ");");

	return(1);
 
}

