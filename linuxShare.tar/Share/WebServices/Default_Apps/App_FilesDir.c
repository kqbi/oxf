/******************************************************************************
*	file name   :	App_FilesDir.c 
*
*	purpose: Contains access to file system
*	portability:	Windows ?
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <stdio.h>
/*******************************************************************************/
extern void ABSDirList(char **names,int sizes[],int types[],char *ext);
extern int HTML_Write_text(void *fp,  char data[]);
extern int HTML_Write_Tail(void *fp);
extern void Find_Arg(char *value_name, void *args,char **valpp);
extern int FS_memory_get_current_size();
extern void Write_Signature(void *fp);
extern void Write_Head_CSS(void *fp);

#define MAX_FILES 80


int App_FilesDir(void *fp, char *exename, void *args)
{
    char *names[MAX_FILES];
	int  sizes[MAX_FILES];
	int  types[MAX_FILES];
    char buff[256];
	int i;
	

	Write_Head_CSS(fp);
	HTML_Write_text (fp, "</head><body>");
	HTML_Write_text(fp, "<div id=div_0><h3 class=IT>Files on server</h3><hr noshade>\n");
#ifdef WIN_DEBUG_MODE
	char *fname;
    Find_Arg("Fname", args, &fname);
	if(fname)
		save_to_disk(fp, fname);
#endif
    ABSDirList(names,sizes,types,0);
	HTML_Write_text (fp, "<table border=0 cellspacing=0 cellpadding=1  class=InnerText>");
    for (i = 0; names[i]; i++)
    {

		sprintf(buff, "<li class=InnerText><input type=button value=Save onClick=\"document.bgColor='red'\">");
#ifdef WIN_DEBUG_MODE
		sprintf(buff, 
			"<li><A HREF=cgibin?Abs_App=Abstract_DIR&Fname=%s>Save</A> &nbsp",names[i]);
		HTML_Write_text(fp, buff);
#endif
       
		sprintf(buff,"<tr><td><li class=InnerText><A HREF=%s>%s</A></td><td>%d</td><td>%s</td></tr>", names[i], names[i],sizes[i],types[i]?"RES":"FS");
		HTML_Write_text(fp, buff);
    }

   if(i == 0) /* no such files */     
      HTML_Write_text(fp, "<h1> 0 files");

      sprintf(buff,"<tr><td colspan=3><li class=InnerText>Total FS alloc = %d</td></tr>",FS_memory_get_current_size());
	  HTML_Write_text(fp, buff);
	  HTML_Write_text(fp, "</table>");
	  Write_Signature(fp);
	  HTML_Write_text(fp, "</div>");
	  HTML_Write_Tail(fp);
	return(1);   
}
