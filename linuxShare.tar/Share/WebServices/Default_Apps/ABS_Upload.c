/******************************************************************************
*	file name   :	ABS_Upload.c 
*
*	purpose: Upload
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/*******************************************************************************/
extern void ABSWebDebug_s_s(char *s1, char *s2);
extern void Find_Arg(char *value_name, void *args,char **valpp);
extern int HTML_Write_Header(void *fp);
extern int HTML_Write_text(void *fp,  char data[]);
extern int HTML_Write_Tail(void *fp);
extern char *find_token_start (char *inp, int len,const char *tok, int tok_len);
extern char *find_token_end(char *inp, int len,const char *tok, int tok_len);
extern void copy_word(char *outp, char *inp);
extern char *ABS_getlne();
extern void Write_Signature(void *fp);
extern void Split_upload_query(char *msg, int len, char boundary[],void* args);
extern void SetHttpMsgSize(int size);
extern int C_RegisterFunc(char* name,void *func);
extern int abs_isspace(int c);

static const char upload_id[]= "Content-Type: multipart/form-data";
static const char boundary_id[]="boundary=";


static void do_upload(char *file_name)
{
   ABSWebDebug_s_s( "File_name = %s\n", file_name);
}

char *skip_spaces(char *p)
{
	while (*p && abs_isspace((int)(*p)))  
      p++;
	return(p);
}

char *find_token_in_block(char *inp, char *end_inpp, char *tok, int tok_len)
{
  return(find_token_start (inp, (int)(end_inpp - inp), tok, tok_len));
}

/*********************************************************************/
char *ABS_end_line(char *p)
{
	   char line[512];
       p = ABS_getlne(line,p);
	   return(p);
}

/********************************************************************/
int ABS_multipart(char *msg, int len, char boundary[])
{
char *p;
	/* check iff content type is multipart */
  if(!find_token_start(msg, len, upload_id, sizeof(upload_id) - 1))
	  return(0);
	  /* check and fetch boundary string */
  p = find_token_end( msg, len, 
	                  boundary_id, sizeof(boundary_id) -1 );
  if(!p)
	return(0);

  copy_word(boundary, p);

  return(1);
}
 void Abstract_upload(void *client, void *args)
  {
	 static const char html_upload_body[]=
"<div id=div_0><h3 class=IT> Upload a file to server </h1>\
<hr noshade> <center>\
<FORM NAME=\"oForm\"\
 Method=POST Action=cgibin \
ENCTYPE=\"multipart/form-data\">\
 <table class=InnerText border = 0 width=60%>\
 <th ALIGN=LEFT> File:<td>\
 <input type=HIDDEN name=\"Abs_App\" value=\"Abstract_Upload\" >\
 <input class=InnerText type=\"file\" name=\"ofile1\">\
  <input class=InnerText type=\"text\" name=\"TargetURL\" value = abstract.txt maxlength=30>\
<INPUT class=InnerText TYPE=\"submit\" VALUE=\"Upload File\">\
 </table></form></center></hr noshade></div>";
 char file_name[255];


     file_name[0] = 0;
	 Find_Arg("file", args,(char**)&file_name);
     if(file_name[0])
	 {
		 do_upload(file_name);
	 }

	 HTML_Write_Header(client);
	 HTML_Write_text(client, "</head>");
	 HTML_Write_text(client, (char*)html_upload_body);
	 Write_Signature (client);
	 HTML_Write_Tail(client);
  }
/*********************************************************************/
void RegisterUpload()
{
 SetHttpMsgSize(1024 * 17);
 C_RegisterFunc("ILUploadSplitQuery",(void*)Split_upload_query);
 C_RegisterFunc("ILMultipart",(void*)ABS_multipart);
 C_RegisterFunc("ILUpload",(void*)Abstract_upload);
}
