/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

#include <stdio.h>
#include <string.h>

extern int absmib_get_value_type_by_name(char *name,char** value,int* type_id);
extern int HTML_Write_text(void *fp,  char data[]);
extern int HTML_Write_Tail(void *fp);
extern int HTML_Write_Header(void *fp);
extern int CRF_GetPairs(int parent_ids[],int child_ids[],int maxlen);
extern int type2metatype(char **metatype, int type_id);
extern int absmib_get_type_by_id(int id,int* type_id);
extern void Write_Head_CSS(void *fp);
extern void Write_Signature(void *fp);
extern char* GetDeviceName();
extern int ABS_GetAggregateSons (int papaId, char ***children);
extern void absmib_update_relations();
extern char *GetFlatRootName();
extern void free_strings_array(char **raw_pairs,int num);
extern int absmib_get_id_by_name(char* name);
extern int absmib_get_type_by_name(char *name,int* type_id);
extern int absmib_get_root_sons_ids(int out_childs[],int max_childs);

#define MAX_ELEMENTS 300



static int getNamesAndTypes_Tbl (void *client)
{
	int cId, pId, i, type_id, len;
	char buff[256];
	char *metaType;
	char **aggSons;

	HTML_Write_text(client, "var n = crIdsNmsTps(");
	pId = absmib_get_id_by_name(GetDeviceName());
	sprintf (buff, "%d,'%s','aggr'", pId,GetDeviceName());
	HTML_Write_text (client, buff);
	pId  = absmib_get_id_by_name(GetFlatRootName());
	len = ABS_GetAggregateSons (pId, &aggSons);
	for (i = 0; i < len; i++)
	{
		cId = absmib_get_type_by_name(aggSons[i], &type_id);
		type2metatype(&metaType, type_id);
		if ((strcmp(metaType, "aggr")==0) || (strcmp(metaType, "view")==0)) 
		{
			sprintf (buff, ",%d,'%s','%s'", cId, aggSons[i], metaType);
			HTML_Write_text (client, buff);
		}
	}
	HTML_Write_text(client, ");\n");

	free_strings_array(aggSons,len);

	return 1;
}

static int getCRF_Tbl (void *client)
{
	int parent_ids[MAX_ELEMENTS];
	int child_ids[MAX_ELEMENTS];
	int i,pId, len_upper_childs,len_childs, type_id;
	char buff[256];
	int tmpChild[400];
	char* metaType;


	HTML_Write_text(client, "\nvar t = crCRF_New(");
	pId  = absmib_get_id_by_name(GetDeviceName());
	
	/*printing upper floor*/
	
	len_upper_childs = absmib_get_root_sons_ids(tmpChild, sizeof(tmpChild)/sizeof(tmpChild[0]));
	for (i = 0; i < len_upper_childs; i++)
	{
		sprintf (buff, "%d,%d ", pId, tmpChild[i]);
		HTML_Write_text(client, buff);
		if ((i + 1) < len_upper_childs) HTML_Write_text (client, ",");
	}
	/*printing lower floors*/
	len_childs = CRF_GetPairs(parent_ids,child_ids, MAX_ELEMENTS);
	for (i = 0; i < len_childs; i++)
	{
		absmib_get_type_by_id(child_ids[i], &type_id);
		type2metatype(&metaType, type_id);
		if ((strcmp(metaType, "aggr")==0) || (strcmp(metaType, "view")==0)) 
		{
			sprintf (buff, ",%d, %d",parent_ids[i], child_ids[i]);
			HTML_Write_text(client, buff);
		}
	}
	HTML_Write_text(client, ");\n");
	return 1;
}

int App_BuildTree(void *client, char *cgi_name, void *args)
{
	char buff[256];

	Write_Head_CSS(client);
	HTML_Write_text(client, "<script src='tree.inc'></script>\n<script>if (!document.getElementById) {window.location.replace ('wrong.htm');}</script></head>\n");
	/*HTML_Write_text(client, "<script>preloadImages();</script>\n");*/
	HTML_Write_text(client, "<body class=InnerText><div id=gogi></div>\n<script>\n");
	absmib_update_relations();

	/*names and types table */
	getNamesAndTypes_Tbl (client);

	/* crf table */
	getCRF_Tbl (client);

	/* draw tree from the top */
	sprintf (buff, "sh('%s', t, n, 'gogi');\n", GetDeviceName());
	HTML_Write_text(client, buff);
	HTML_Write_text (client, "</script>");
	HTML_Write_Tail(client);
	return 1;
}



int App_WriteSig(void *client, char *cgi_name, void *args)
{
	Write_Signature(client);
	return 1;
}

int App_AllTree(void *client, char *cgi_name, void *args)
{
	HTML_Write_Header(client);
	HTML_Write_text(client, "</head><frameset rows='80%, 20%'><frameset cols='180, *'><frame name='treefrm' src='cgibin?Abs_App=BuildTree'>");
	HTML_Write_text(client, "<frame name='basefrm' src=''>");
	HTML_Write_text(client, "</frameset><frame name='sigfrm' src='cgibin?Abs_App=WriteSig'></frameset></html>");
	return 1;
}

