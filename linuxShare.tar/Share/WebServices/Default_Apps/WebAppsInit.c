/******************************************************************************
*	file name   :	WebAppsInit.c 
*
*	purpose: Contains initialization of CGI functions
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <stdio.h>
/*******************************************************************************/

extern int App_FilesDir(void *fp, char *cgi_name, void *args);
extern int App_CreateAgg(void *fp, char *cgi_name, void *args);
extern int App_GetAll(void *fp, char *cgi_name, void *args);
extern int App_CheckUsrPswd(void *fp, char *cgi_name, void *args);
extern int App_PswdPage(void *fp, char *cgi_name, void *args);
extern int App_CgiList(void *fp, char *cgi_name, void *args);
extern int App_MainPage(void *fp, char *cgi_name, void *args);
extern int App_BuildTree(void *fp, char *cgi_name, void *args);
extern int App_MainPage(void *fp, char *cgi_name, void *args);
extern int App_WriteSig(void *fp, char *cgi_name, void *args);
extern int App_AllTree(void *client, char *cgi_name, void *args);
extern int App_ShowAgg(void *client, void *args);
extern int App_ShowFAgg(void *client, void *args);
extern int ABSWebAddApp(char *name, void (* appfunc)(),int isVisible);

extern void init_gifs();
extern int InitJavaSManager();
extern void ST_PrintTable(void* client);
extern void* Fetch_func(char* name);

/*******************************************************************************/
extern void Abstract_Default();

extern void setJavaCommLayer();
extern long FindCGIEntry(char *cginame);


void Abstract_dir(void *fp, void *s)
{
	App_FilesDir(fp, "cgibin", s);
}

int Init_Resource_Files()
{
   init_gifs();
   return(InitJavaSManager());
}

/****************************************/



static void Statistic(void *fp, void *args)
{
    ST_PrintTable(fp);
}


static void  CreateAgg(void *fp, void *args)
{
/*	printf ("\nCreateAgg\n");*/
	App_CreateAgg(fp, "cgibin", args);
}
/*************************************/

static void  GetAll(void *fp, void *args)
{
/*	printf("\nGetAll\n");*/
	App_GetAll(fp, "cgibin", args);
}


/*static void  MainPage(void *fp, void *args)
{

	App_MainPage(fp, "cgibin", args);
}*/

static void  BuildTree(void *fp, void *args)
{
/*	printf ("\nBuildTree\n");*/
	App_BuildTree(fp, "cgibin", args);
}
static void WriteSig(void *fp, void *args)
{
	App_WriteSig(fp, "cgibin", args);
}

static void AllTree(void *fp, void *args)
{
	App_AllTree(fp, "cgibin", args);
}

static void ABSAddUploadApp()
{
 static void(*AbstractUpload)() = 0;

 if(!AbstractUpload)
 {
   AbstractUpload =(void(*)())Fetch_func("ILUpload");
 };
 if(AbstractUpload)
  ABSWebAddApp("Abstract_Upload",AbstractUpload,1);
}


static void ShowAgg(void *client, void *args)
{
	App_ShowAgg(client, args);
}

static void ShowFAgg(void *client, void *args)
{
	App_ShowFAgg(client, args);
}

void WebAppsInit()
{
	long javaLayer = 0L;
	long jsLayer = 0L;
	
	ABSWebAddApp("Abstract_Default", Abstract_Default,0);
	ABSAddUploadApp();
	ABSWebAddApp("Abstract_DIR", Abstract_dir,1);
	ABSWebAddApp("Statistic",Statistic,1);

  
	ABSWebAddApp("CreateAgg", CreateAgg,0);
	ABSWebAddApp("GetAll", GetAll,0);
	ABSWebAddApp("BuildTree", BuildTree, 0);
	ABSWebAddApp("WriteSig", WriteSig, 0);
	ABSWebAddApp("AllTree", AllTree, 0);
	ABSWebAddApp("ShowAgg", ShowAgg,0);
	ABSWebAddApp("ShowFAgg", ShowFAgg, 0);
	javaLayer = FindCGIEntry("SetCompJava");
	jsLayer = FindCGIEntry("SetComp");
	if (!javaLayer && !jsLayer) setJavaCommLayer();
}
