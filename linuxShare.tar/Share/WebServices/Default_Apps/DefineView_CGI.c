/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

#include <stdio.h>
#include <string.h>

extern int HTML_Write_text(void *fp,  char data[]);
extern int HTML_Write_Header(void *fp);
extern int HTML_Write_Tail(void *fp);
extern void Write_Head_CSS(void *fp);
extern void Write_Signature(void *fp);
extern int absmib_get_all(char ***elements);
extern int ABSGetAggFromArgs(void* args,char** agg_name,char** names,int max_lines);
extern int RegisterView(char *agg_name, char **names, int len);
extern int type2metatype(char **metatype, int type_id);
extern int absmib_get_type_by_name(char *name,int* type_id);
extern char* GetDeviceName();
extern char *GetFlatRootName();
extern void free_strings_array(char **raw_pairs,int num);
extern int RegisterViewIds(char *agg_name, char **ids, int len);
extern int RegisterViewNames(char *agg_name, char **names, int len);

static int is_valid_viewname(char* name)
{
   if(!strcmp(name, ""))
	 return(0);
   return(1);
}

int App_GetAll(void *client, char *cgi_name, void *args)
{
	int numberOfSons;
	int type_id;
	char **aggSons;
	int j, cId;
	char *metaType;
	char buff[256];


	Write_Head_CSS(client);
	HTML_Write_text(client, "<script src=\"tools.js\"></script><script src=\"defView.js\"></script>\n");
	HTML_Write_text(client, "<script>var t = crIdsNmsTps(");
	
	/*Special aggregates */
	sprintf (buff, "'%s', 'spaggr', '-1',", GetDeviceName());
	HTML_Write_text(client, buff);
	sprintf (buff, "'%s', 'spaggr', '-2'", GetFlatRootName());
	HTML_Write_text(client, buff);
	
	/* All Elements*/
	numberOfSons = absmib_get_all(&aggSons);
	for (j = 0; j < numberOfSons; j++)
	{
		if ((j + 1) <= numberOfSons) HTML_Write_text(client, ",");
		cId = absmib_get_type_by_name(aggSons[j],&type_id);
		type2metatype(&metaType, type_id);
		sprintf (buff, "'%s', '%s', '%d'", aggSons[j], metaType, cId);
		HTML_Write_text (client, buff);
	}
	free_strings_array(aggSons, numberOfSons);
	HTML_Write_text(client, ");\n");
	HTML_Write_text (client, "</script></head>");

	/*********/
	HTML_Write_text(client, "<body class=InnerText>");
	HTML_Write_text(client, "<div id=div_0><h3 class=IT>Define Views</h3><hr noshade>");
	HTML_Write_text(client, "<form action=\"cgibin\" method=GET onsubmit='return validate(t)'>");
	HTML_Write_text(client, "<input type=hidden name=Abs_App value=CreateAgg>\n");
	/*The main table header*/
	HTML_Write_text(client, "<table border=0 cellpadding=20><tr><td valign=top>");
	/*The cell of the submission*/
	HTML_Write_text(client, "<table border=1 bordercolor=black cellspacing=0 cellpadding=0 rules='none'>");
	HTML_Write_text(client, "<tr><td><table class=InnerText border=0 cellspacing=0 cellpadding=8>");
	HTML_Write_text(client, "<tr><td colspan=2 align=center>Name of view</td></tr>");
	HTML_Write_text(client, "<tr><td colspan=2 align=center><input class=InnerText type=text name=agg_name maxlength=30></td></tr>");
	HTML_Write_text(client, "<tr><td colspan=2 align=center><input class=InnerText type=submit value='Submit'></td></tr>");
	HTML_Write_text(client, "<tr><td align=center><input class=InnerText type=button value='Select All' onclick=selectAll()></td>");
	HTML_Write_text(client, "<td align=center><input class=InnerText type=reset></td></tr>");
	HTML_Write_text(client, "</table></td></tr></table></td>");
	HTML_Write_text(client, "<td valign=top><div id=main></div></td></tr></table></form>\n<br></div>");
	HTML_Write_text(client, "<script>drawDVTbl(t, document.getElementById('main'));</script>");
	Write_Signature(client);
	HTML_Write_Tail(client);
	return 1;
}

/**
 * Cgi that registers (creates) aggregate.
 *
 * @param client   the taget to write to (HTML page)
 * @param cgi_name the cgibin dir
 * @param args     the arguments of the cgi
 * @return 1 succeded
 */
int App_CreateAgg (void *client, char *cgi_name, void *args)
{
	char *ids[400];
	int num;
	char *agg_name;

	num = ABSGetAggFromArgs(args,&agg_name,ids,sizeof(ids)/sizeof(ids[0]));
	
	if (is_valid_viewname(agg_name))
		RegisterViewIds(agg_name, ids, num);

	App_GetAll(client, cgi_name, args);
	return 1;
}
