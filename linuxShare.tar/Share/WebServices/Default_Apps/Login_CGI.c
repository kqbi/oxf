/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

#include <string.h>


extern int App_AllTree(void *client, char *cgi_name, void *args);
extern void Write_Signature(void *fp);
extern int HTML_Write_text(void *fp,  char data[]);
extern int AC_FindUser(char* login,char* password);
extern void Write_Head_CSS(void *fp);
extern void Find_Arg(char *value_name, void *args,char **valpp);
extern void main_page(void *client, void *args);



static void printPswdPage (void *client, int flag)
{
	Write_Head_CSS(client);
	HTML_Write_text(client, "<script>window.status = 'IBM Device';</script><script src=\"tools.js\"></script></head>");
	HTML_Write_text(client, "<body class=InnerText>");
	HTML_Write_text(client, "<center><u><h2>Welcome</center><center>To Device</h2></u></center><br><br><br>\n");

	if (flag)
	{
		HTML_Write_text(client, "<center><h3 class=reds>You are not authorized to get in</h3></center>");
		HTML_Write_text(client, "<center><h3 class=reds>Re Enter the username and password</h3></center>");
	}
	HTML_Write_text(client, "<form method=POST action='cgibin' name=PS>\n<input type=hidden name=Abs_App value=CheckUsrPswd>\n");
	HTML_Write_text(client, "<table class=InnerText cellspacing=0 cellpadding=3>\n<tr><td>User name</td>");
	HTML_Write_text(client, "<td><input type=text name=user class=InnerText></td></tr>\n<tr><td>Password</td>");
	HTML_Write_text(client, "<td><input type=password name=pswd class=InnerText></td></tr>\n</table>\n<input type=submit value=Submit class=InnerText>\n</form>\n</body>\n</html>");
}

int App_CheckUsrPswd(void *client, char *cgi_name, void *args)
{
	char *user_name;
	char *pswd;

	Find_Arg ("user", args, &user_name);
	Find_Arg ("pswd", args, &pswd);
	
	
	if(AC_FindUser(user_name,pswd) != -1)
		main_page(client, args);
	else 
	   printPswdPage(client, 1);
	

	return 1;
}

int App_PswdPage (void *client, char *cgi_name, void *args)
{
	printPswdPage(client, 0);
	return 1;
}
