/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

#include <stdio.h>
#include <string.h>


extern int HTML_Write_text(void *fp,  char data[]);
extern int HTML_Write_Tail(void *fp);
extern int HTML_Write_Header(void *fp);
extern void Write_Signature(void *fp);

typedef struct
{
	char app_name[20];
	void  (* app_func)(void *client, void *args);
	unsigned char  visebility; /*1 - is visible in browser,0 - not visible*/
} Server_Apps;

extern const char Abstract_APP[];
extern Server_Apps apps_table[20];

#define MAX_Server_Apps (sizeof(apps_table)/sizeof(apps_table[0]))


static void HT_Create_Index(void *client, const char *cgi_name, const char *app_stamp, char **app_names)
{
	char buff[256];
	static char html_shell[]=	"\
<div id=div_0><h3 class=IT>Welcome to your Appliance. Your Options are as follows</h1><hr noshade>";
     
   HTML_Write_Header(client);
   HTML_Write_text (client, "</head>");
   HTML_Write_text(client, html_shell);
   HTML_Write_text(client, "<body>");
   HTML_Write_text(client, "<ul>");
   for( ; *app_names; app_names++)
   {
    sprintf(buff, "<li class=InnerText><A HREF=\"%s?%s=%s\"> %s </A>\n",
	                 cgi_name,
                     app_stamp,
					 *app_names,
					 *app_names
					 );
   HTML_Write_text(client, buff);
   }
   HTML_Write_text(client, "</ul></div>");
   Write_Signature(client);
   HTML_Write_Tail(client);
}


int App_CgiList (void *client, char *cgi_name, void *args)
{
	const char exe_name[]="cgibin"; 
	char *app_names[MAX_Server_Apps];
    int   i,j;

    for(i = 0 ,j = 0; apps_table[i].app_name[0] ;i++){
	  if(apps_table[i].visebility)
		  app_names[j++] = apps_table[i].app_name;	
	}
    app_names[j] = 0;
	HT_Create_Index(client, exe_name, Abstract_APP, app_names);
	return(1);
}
