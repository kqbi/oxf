/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

#include <stdlib.h>
#include <stdio.h>


extern int Args_Select_by_val(void *p,char *val, char **lines, int max_lines);
extern int absmib_get_value_type_by_name(char *name,char** value,int* type_id);
extern int type2metatype(char **metatype, int type_id);
extern int absmib_get_value_by_id(int id,char** value);
extern char *alloc_string(int len);
extern char *string_dup(char *s);
extern void free_memory(void *p, int len);
extern int HTML_Write_text(void *fp,  char data[]);


int changesInAggregate (char *agg_name, char *sts)
{	
	return 0;
}

/***********************
 * getAndPrintVals: this function extracts ids from arguments and gets values for extracted ids.
 * It sends the id - value pairs to the client.
 ***********************/
int getAndPrintVals(void *client, void *args)
{
	char buff[256];
	char *ids[400];
	char *valstr;
	int selected_num;
	int i;

	selected_num = Args_Select_by_val(args,"R", ids, sizeof(ids)/sizeof(ids[0]));
	for(i = 0; i < selected_num; i++)
	{	
		if(absmib_get_value_by_id(atoi(ids[i]),&valstr) < 0)
			valstr = string_dup("del");
		sprintf (buff, "%s,'", ids[i]);
		HTML_Write_text(client, buff);
		HTML_Write_text(client, valstr);
		if((i + 1) < selected_num)
			HTML_Write_text(client, "',");
		else
			HTML_Write_text(client, "'");

		free_memory(valstr,0);
	}
	return(1);
}

/*********************
 * Function getIdsVals: this function actually gets the ids and values per ids
 * and sends them to client.
 *********************/
int getIdsVals (void *client, void *args)
{
	char buff[120];
	char *names[50];
	int selected_num;
	int i,id;
	char *valstr;
	int type_id;
	char *metaType;

	selected_num = Args_Select_by_val(args,"R", names, sizeof(names)/sizeof(names[0]));
	
	for (i = 0; i < selected_num; i++)
		if ((id = absmib_get_value_type_by_name(names[i], &valstr, &type_id)) >= 0) /* Var exists in server table */
		{
			type2metatype(&metaType, type_id);
			
			sprintf (buff, "'%s','%d','",names[i], id);
			HTML_Write_text(client, buff);
			HTML_Write_text(client, valstr);
			sprintf(buff, "', '%s'", metaType);
			HTML_Write_text(client, buff);
			
			if ((i + 1) < selected_num) HTML_Write_text (client, ",");
		}
	 	else 
		{/* var does not exist in server table */
			sprintf (buff, "'%s', 'n/a', '0', 'undef'", names[i]);
			HTML_Write_text(client, buff);
			if ((i + 1) < selected_num) HTML_Write_text (client, ",");
		}

		return 1;
}

