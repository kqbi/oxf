/******************************************************************************
*	file name   :	FS_Memory.c 
*
*	purpose: Contains access to MIB DB
*	portability:	Machine Independent
*
*
*	author(s):	Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/

void *alloc_memory(int len);
void free_memory(void *p, int len);
void *realloc_memory(void* addr,int len);



#define MEM_BLOCK 512
/*******************************************************************************/
static int total_size = 0;
static int current_size = 0;
/*******************************************************************************/
int append_to_block(int len)
{
	return(len - (len % MEM_BLOCK) + MEM_BLOCK);
}
void FS_memory_init(int size)
{
	total_size = size * 1024;
}
/*******************************************************************************/

void* FS_memory_alloc(int len,int *block_len)
{
	void* p;	
    int blk_len;

	blk_len = append_to_block(len);
	if(current_size + blk_len >= total_size)
		return(0);

	if(!(p = alloc_memory(blk_len)))
		return(0);

	current_size+=blk_len;

	*block_len = blk_len;

   return(p);
}
/*******************************************************************************/

void* FS_memory_realloc(void* addr,int len,int *block_len)
{
	void* p;
	int blk_len;
	blk_len = append_to_block(len);

	if((current_size + blk_len - *block_len) >= total_size)
		return(0);

	if(!(p = realloc_memory(addr,blk_len)))
		return(0);

    current_size = current_size - *block_len + blk_len;

	*block_len = blk_len;

   return(p);

}
/*******************************************************************************/
void FS_memory_free(void* addr,int blk_len)
{
	current_size-=blk_len;
	free_memory(addr,blk_len);
}
/*******************************************************************************/
int FS_memory_get_current_size()
{
	return(current_size);
}
