
/******************************************************************************
*	file name   :	ABSWebFiles.c 
*
*	purpose: Contains FS API
*
*	API Functions:
*			 InitFs();
*			 ABSDirList(char **names,int sizes[],int types[],char *ext);
*			 ABSFileSave(char *name, char data[], int len);
*			 ABSFileAppend(char *name, char data[], int len);
*			 ABSFileReadFrom(char *name, char data[], int from, int *lenp,int max_len);
*			 ABSFileRead(char *name, char data[], int *lenp,int max_len);
*			 char *GetWebPath();
*
*	portability:	Machine Independent
*
*
*	author(s):	 Gadi Veazovsky   
*	date started:	04-Jan-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <string.h>
#include <stdio.h>
/********************************************************************************/
extern char *string_dup();
extern void free_string(char *s);
extern char *get_extension(char *name);
extern void* Fetch_func(char* name);
extern int HTML_Write_bytes(void *fp, char *data, int len);
extern void ABS_Write_HTML_header(void *fp,char *fname,int len);
extern int ABS_stricmp(char* name1,char* name2);


/********************************************************************************/

#define MAX_FILES 80 
/*definition of maximal nambers of files*/

#define PATH_MAX_LEN 256
/*maximal len of web path*/
typedef struct {
	char* name;
	char* data;
	int size;
	int type; /*const file*/
}FileTbl;

static FileTbl Mib_dir[MAX_FILES];

static char WebPath[PATH_MAX_LEN];

static int init_dir = 0;

/***********************************************************************/
static void DirInit()
{
	int i;
	if(!init_dir)
	{
		for(i=0;i<MAX_FILES;i++){
			Mib_dir[i].name = 0;
			Mib_dir[i].size = 0;
			Mib_dir[i].data = 0;
			Mib_dir[i].type = 0;
		}
		init_dir = 1;
	}
}
/***********************************************************************/
static int DirFindFile(char *name)
{
	int i;
	for(i=0;i<MAX_FILES;i++){
		if(Mib_dir[i].name)
			if(!ABS_stricmp(Mib_dir[i].name,name))
				return(i);
	}		
	return(-1);
}
/***********************************************************************/
static  int DirAddFile(char *name,char* data,int size,int type)
{
	int i;
	if((i = DirFindFile(name)) != -1)  /*the name is in table*/
	{
		Mib_dir[i].size = size;
		Mib_dir[i].data = data;
		Mib_dir[i].type = type;
		return(1);
	}
	
	for(i=0;i<MAX_FILES - 1;i++)
		if(Mib_dir[i].name == 0)
		{
			Mib_dir[i].name = string_dup(name);
			Mib_dir[i].size = size;
			Mib_dir[i].data = data;
			Mib_dir[i].type = type;
			return(1);
		}
		return(0);
}
/***********************************************************************/
static void SetDefaultWebPath()
{
	strcpy(WebPath,"");
	/*printf("Default path is current directory...\n");*/
}
/***********************************************************************/
static void SetWebPath(char *path)
{
	strcpy(WebPath,path); 
}
/***********************************************************************/
static int ResFileReadFrom(int index, char data[], int from, int *lenp,int max_len)
{
	int temp_len = Mib_dir[index].size - from;
	if(temp_len <= max_len)
		*lenp = temp_len;
	else
		*lenp = max_len;
	memcpy(data, Mib_dir[index].data + from, *lenp);
	return(1);
}
int ABSResFileSave(const char *name,const unsigned char data[], int len)
{
	return(DirAddFile((char *)name,(char *)data,len,1)); /*1-is resouce file*/
}
/*******************************************************************************/
/*FS API functions															   */
/*******************************************************************************/
void InitFs(char *path)
{
	if(!path || (strlen(path) > (PATH_MAX_LEN - 1))) 
		SetDefaultWebPath();
	else
		SetWebPath(path);
	
	DirInit();
}
/*******************************************************************************/
int ABS_IsResourceFile(char *name)
{
	int index;
	if(((index=DirFindFile(name))!=-1) && Mib_dir[index].type)
		return(1);
	return(0);
}
/*******************************************************************************/
int ABSResourceFileSend(char *name,void *fp)
{
	int index;
	if((index = DirFindFile(name)) != -1)
	{
		/*	ABS_Write_HTML_header(fp,name,Mib_dir[index].size);*/
		return(HTML_Write_bytes(fp, Mib_dir[index].data, Mib_dir[index].size));
		  }
	return(-1);
}
/*******************************************************************************/
void ABSDirList(char **names,int sizes[],int types[],char *ext)  
{
	int i,j=0;
	if(!ext)
		for(i=0;i<MAX_FILES;i++){
			if(Mib_dir[i].name)
			{
				types[j] = Mib_dir[i].type;
				sizes[j] = Mib_dir[i].size;
				names[j++] = Mib_dir[i].name;
			}
		}
		else
			for(i=0;i<MAX_FILES;i++){
				if(Mib_dir[i].name && !strcmp(get_extension(Mib_dir[i].name),ext))
				{
					types[j] = Mib_dir[i].type;
					sizes[j] = Mib_dir[i].size;
					names[j++] = Mib_dir[i].name;
				}
			}
			names[j] = 0;
}
/*******************************************************************************/

int ABSFileSave(char *name, char data[], int len)
{ 
	static int(*f_save)() = 0;
	
	if(!f_save)
	{
		f_save = (int(*)())Fetch_func("ILFileWrite");
	}
	if(f_save)
	{
		if(f_save(name,data,len))
			return(DirAddFile(name,0,len,0)); /*0- is no resource file*/
	}
	return(0);
}

/******************************************************************/
int ABSFileAppend(char *name, char data[], int len)
{
	static int(*f_append)() = 0;
	int index;
	
	if(!f_append)
	{
		f_append = (int(*)())Fetch_func("ILFileAppend");
	}
	if(f_append)
	{
		if(f_append(name,data,len))
		{
			if((index = DirFindFile(name))!=-1)
			{
				Mib_dir[index].size += len;
				return(1);
			}
			else
				return(DirAddFile(name,0,len,0)); /*0- is no resource file*/
		}
	}
	return(0);
}
/***********************************************************************/
int ABSFileReadFrom(char *name, char data[], int from, int *lenp,int max_len)
{	
	static int(*f_read_from)() = 0;
	int index;
	
	if((index = DirFindFile(name)) != -1)
		if(Mib_dir[index].type){
			return(ResFileReadFrom(index,data,from,lenp,max_len));
		}
		
		if(!f_read_from)
		{
			f_read_from = (int(*)())Fetch_func("ILFileReadFrom");
		};
		if(f_read_from)
			return(f_read_from(name,data,from,lenp,max_len));
		return(0);
}

/***********************************************************************/
int ABSFileRead(char *name, char data[], int *lenp,int max_len)
{	
	return(ABSFileReadFrom(name,data,0,lenp,max_len));
}
/***********************************************************************/
char *GetWebPath()
{
	return(WebPath);
}
/***********************************************************************/
