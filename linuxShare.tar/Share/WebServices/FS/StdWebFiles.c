
/******************************************************************************
*	file name   :	StdWebFiles.c 
*
*	purpose: Contains standard (stdlib) FS wrapper
*
*	API Functions:
*			 InitStdFs();
*			 int StdFileAppend(char *name, char data[], int len);
*			 int StdFileReadFrom(char *name, char data[],int from, int *lenp,int max_len);
*			 int StdFileSave(char *name, char data[], int len);
*
*			 
*	portability:	Machine Independent
*
*
*	author(s):	 Gadi Veazovsky   
*	date started:	04-Jan-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************/
#include <stdio.h>
#include <string.h>
/*******************************************************************************/

extern char *GetWebPath();
extern void SIAddElem(char* fname,void *func);
/*******************************************************************/
int StdFileAppend(char *name, char data[], int len)
{
	char full_name[256];
	void *fp;
	full_name[0] = 0;
	strcat(full_name,GetWebPath());
	strcat(full_name,name);
	
	
	if((fp = fopen( full_name,"a+b")))
	{
		fwrite( data, sizeof( char ), len, fp );
		fclose( fp );
	}
	return(1);
}
/*******************************************************************/
int StdFileReadFrom(char *name, char data[],int from, int *lenp,int max_len)
{
	char full_name[256];
	void *fp;
	
	
	full_name[0] = 0;
	strcat(full_name,GetWebPath());
	strcat(full_name,name);
	
	
	
	/* Open file for input: */
	if(!(fp = fopen( full_name, "r+b" )))
	{
		/*printf("Can't open file %s!",full_name);*/
		return(0);
	}
	
	fseek( fp, from, 0);
	/* Read in input: */
	*lenp = (int)(fread(data, sizeof(char) ,max_len,fp));
	
	fclose( fp );
	
	return(1);
	
	
}
/***********************************************************************/
int StdFileSave(char *name, char data[], int len)
{
	void* fp;
	char full_name[256];
	full_name[0] = 0;
	strcat(full_name,GetWebPath());
	strcat(full_name,name);
	
	
	if((fp = fopen( full_name,"w+b")))
	{
		fwrite( data, sizeof( char ), len, fp );
		fclose( fp );
	}
	return(1);
}
/***********************************************************************/

void InitStdFs(){
	SIAddElem("ILFileAppend",(void*)StdFileAppend);
	SIAddElem("ILFileReadFrom",(void*)StdFileReadFrom);
	SIAddElem("ILFileWrite",(void*)StdFileSave);
}
/***********************************************************************/
