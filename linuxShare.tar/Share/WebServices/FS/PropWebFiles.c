
/******************************************************************************
*	file name   :	PropWebFiles.c 
*
*	purpose: Proprietary FS (based on RAM)
*	portability:	Machine Independent
*
*	API Functions:
*			 InitPropFs();
*			 int PropFileAppend(char *name, char data[], int len);
*			 int PropFileReadFrom(char *name, char data[],int from, int *lenp,int max_len);
*			 int PropFileSave(char *name, char data[], int len);
*
*	author(s):	 Gadi Veazovsky   
*	date started:	04-Jan-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************/
#include <string.h>
#include <stdio.h>
/*******************************************************************************/
extern void SIAddElem(char* fname,void *func);

extern void* FS_memory_alloc(int len,int *block_len);
extern void* FS_memory_realloc(void* addr,int len,int *block_len);
extern void FS_memory_free(void* addr,int blk_len);
extern void FS_memory_init(int size);
extern int ABS_stricmp(char* name1,char* name2);


/*******************************************************************************/
typedef struct {
      unsigned short year;
      unsigned char month;
      unsigned char day;
      unsigned char hour;
      unsigned char minute;
      unsigned char second;
} Time_Date;

typedef struct {
   char name[64];
   Time_Date date;
   int len;
   int block_len;
   char *data;

} ABSFile;
#define TOTAL_FILE_NUMBER 50

ABSFile abs_files[TOTAL_FILE_NUMBER];

/*******************************************************/
static void ABSFilesInit()
{
   int i; 
   for(i = 0;i < TOTAL_FILE_NUMBER;i++)
   {
      abs_files[i].name[0] = 0;
      abs_files[i].len = 0;
      abs_files[i].data = 0;
      abs_files[i].block_len = 0;;
   }
}
/*******************************************************/
static ABSFile *ABSFindEmpty()
{
   int i;
   for (i = 0 ; i < (TOTAL_FILE_NUMBER); i++)
   {
      if(!abs_files[i].name[0] && !abs_files[i].len)
         break;
   }
   if(i < (TOTAL_FILE_NUMBER))
      return(&abs_files[i]);
   else
      return(0);

}
/*******************************************************/
static ABSFile *ABSFileFind(char *name)
{
   int i;
   for (i = 0 ; i < (TOTAL_FILE_NUMBER); i++)
   {
      if(!ABS_stricmp(abs_files[i].name, name))
       return(&abs_files[i]);
   }
   return(0);
}
/*******************************************************/

/*******************************************************
*  Warning !! this operation should be RealTime protected
*  since we are relocation file if space is too small
*
********************************************************/
void* PropFileNew(char *name, int len)
{
   ABSFile *p;

   p = ABSFileFind(name);
   if(p)
   {
		if(!(p->data = FS_memory_realloc(p->data,len,&p->block_len)))
		{
			printf("Realloc Faild! : no enough memory");
			return(0);
		}		
   }
   else if((p = ABSFindEmpty()))
	{
		if(!(p->data = FS_memory_alloc(len,&p->block_len)))
		{
			printf("Alloc Faild! : no enough memory");
			return(0);
		}
		strcpy(p->name, name);
	}
   else 
		return(0);/* no space available */
   p->len = 0;  
   
   return(p);
}
/*******************************************************************/
/*******************************************************************/
/********************************************************************/
int PropFileSave(char *name, char data[], int len)
{
   ABSFile *p;

 p =  (ABSFile *)PropFileNew(name, len);

 if(p)
 {
    memcpy(p->data, data, len);
    p->len = len;
 }

 return(p ? 1: 0);
    
}
/************************************************************************/
int PropFileReadFrom(char *name, char data[],int from, int *lenp,int max_len)
{
      ABSFile *p;
	  int temp_len;

      p = ABSFileFind(name);
      if(!p)
         return(0);

	  temp_len = p->len - from;
	  if(temp_len <= max_len)
		 *lenp = temp_len;
	  else
		*lenp = max_len;
 
      memcpy(data, p->data + from, *lenp);

     return(1);

}
/*******************************************************************/
int PropFileAppend(char *name, char data[], int len)
{
   ABSFile *p;

   p = ABSFileFind(name);
   if(!p)       
     return(PropFileSave(name,data,len));  

   if(p->len + len >= p->block_len)
   {                 /* no room so relocate file*/
      if(!(p->data = FS_memory_realloc(p->data,p->len + len,&p->block_len)))
	  {
			printf("Realloc Faild! : no enough memory");
			return(0);
	  }	
   }
   memcpy(p->data+p->len, data, len);
   p->len += len;

   return(1);
}
/*******************************************************************/
void InitPropFs(){
	FS_memory_init(50); /*size in KB*/
	SIAddElem("ILFileAppend",(void*)PropFileAppend);
	SIAddElem("ILFileReadFrom",(void*)PropFileReadFrom);
	SIAddElem("ILFileWrite",(void*)PropFileSave);
	ABSFilesInit();
}
/*
$Log: PropWebFiles.c $   
Revision 1.9  2001/08/21 15:20:12  gadi   
Porting to solaris   
Revision 1.8.2.2  2001/08/21 14:41:57  gadi   
Revision 1.8  2001/07/30 12:51:00  gadi   
invoke ABS_stricmp   
Revision 1.7  2001/07/22 18:39:13  gadi   
Revision 1.6.1.2  2001/07/22 18:35:00  gadi   
fix AppenfFile()   
Revision 1.6  2001/07/18 13:06:56  gadi   
compere files names in lowercase   
Revision 1.5  2001/07/17 15:39:48  gadi   
use stricmp() to compire filenames and fele extensions   
Revision 1.4  2001/05/30 18:16:50  gadi   
Limit PropFS Size   
Revision 1.3.1.2  2001/05/29 14:28:32  gadi   
Revision 1.3  2001/05/23 07:36:27  gadi   
Revision 1.2.1.2  2001/05/23 07:34:55  gadi   
clean up and separate files(Add file Memory.c)   
Revision 1.2.1.1  2001/04/03 15:46:23  gadi   
Duplicate revision   
Revision 1.1  2001/02/11 13:28:48  roman   
Initial revision   
Revision 1.3  2001/02/11 13:28:47  gadi   
Revision 1.2  2001/01/11 14:54:43  gadi   
Revision 1.1  2001/01/09 12:43:52  gadi   
Initial revision   
*/
