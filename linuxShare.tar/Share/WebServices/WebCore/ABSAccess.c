/******************************************************************************
*	file name   :	ABSAccess.c 
*
*	purpose: Device access table
*	portability:	Machine Independent
*
*
*	author(s):	Doron Green   
*	date started:	30-May-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
********************************************************************************/
#include <string.h>

/*******************************************************************************/

#define MAX_PSWD_LEN 10
#define MAX_ACCESS_ELEMENTS 20

typedef struct {
   char login[MAX_PSWD_LEN];
   char password[MAX_PSWD_LEN];
}AccessRow;


static AccessRow AccessTable[MAX_ACCESS_ELEMENTS];

static int access_rows = 0;

int AC_AddUser(char* login, char* password)
{
  if(access_rows > MAX_ACCESS_ELEMENTS)
	return(-1);
  strcpy(AccessTable[access_rows].login,login);
  strcpy(AccessTable[access_rows].password,password);
  
  return(access_rows++);
}

int AC_FindUser(char* login,char* password)
{
 int i;
 
	for(i = 0; i < MAX_ACCESS_ELEMENTS; i++)
	{
		if(!strcmp(AccessTable[i].login,login) &&
			!strcmp(AccessTable[i].password,password))
			return(i);

	}
  return(-1);
}
