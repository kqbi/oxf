/******************************************************************************
*	file name   :	Http_Table.c 
*
*	purpose: Various write functions to browser
*                   The most usefull:
*                   int HTML_Write_bytes( void *fp, char *data, int len)
*                   int HTML_Write_text(void *fp,  char data[])

*	portability:	Machine independent.
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <stdio.h>
#include <string.h>
/*******************************************************************************/

void* Fetch_func(char* name);
int ST_get_user_hist();


/***************************
send to client
****************************/
int HTML_Write_bytes(void *fp, char *data, int len)
{
	static int(*func)() = 0;
	
	if(!func)
	{
		func = (int(*)())Fetch_func("ILCgiWriteResponse");
	};
	if(func && fp)
		return(func(fp,data,len));
	return(-1);
}

void HTML_Write_NL(void *fp)
{
	HTML_Write_bytes(fp,"\r\n", 2);
}

int HTML_Write_text(void *fp,  char data[])
{
	
	return(HTML_Write_bytes(fp, data, (int)strlen(data))); 
	
}

void HTML_Write_mime_text(void *fp)
{
	HTML_Write_text(fp, "Content-type: text/html");
	HTML_Write_NL(fp);
	HTML_Write_NL(fp);
	
}


int HTML_Write_Header(void *fp)
{
	static char *headp=
		"<HTML><HEAD><link rel='stylesheet' type='text/css' href='style.css'><script>if (!document.getElementById) {window.location.replace ('wrong.htm');}</script>\n";
	return(HTML_Write_text(fp,headp));
}



int HTML_Write_Tail(void *fp)
{
	static char *tailp=
		"</BODY></HTML>\n";
	return(HTML_Write_text(fp,tailp));
}


void Write_Head_CSS (void *fp)
{
	HTML_Write_text(fp, "<html><head><link rel='stylesheet' type='text/css' href='style.css'>");
}

int HTTP_Error (void *fp, char* errorMsg, char *errorAdd)
{
	char buff[256];
	size_t len;
	
	
	Write_Head_CSS(fp);
	HTML_Write_text(fp, "<title>");
	if ((len = strlen(errorAdd)) < 256) sprintf (buff, "%s", errorAdd);
	HTML_Write_text(fp, buff);
	HTML_Write_text(fp, "</title></head><body><h4 class=IT>");
	if (strlen(errorMsg) < 256) sprintf (buff, "%s", errorMsg);
	HTML_Write_text (fp, buff);
	HTML_Write_text (fp, "</h4><hr noshade><font class=InnerText>");
	if (len) sprintf (buff, "%s", errorAdd);
	HTML_Write_text (fp, buff);
	HTML_Write_Tail(fp);
	return 1;
}
/***************************************************************/




/*****************************************************************/
