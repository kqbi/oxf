/******************************************************************************
*	file name   :	Nu_Memory.c 
*
*	purpose: Public functions for memory alloc/free:
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00

*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

#include "nucleus.h"
#include <string.h> 
#include <stdlib.h>
/*******************************************************************************/

/***************************************************/
/****           Memory interface                ****/
/***************************************************/
extern NU_MEMORY_POOL System_Memory ;

#define RiCBoolean int

/*///////////Method to Allocate Memory////////////////////////////////////////*/

static void *Allocate_Memory(size_t size)
{
	VOID *new_mem = NULL;
	STATUS status;
	if(size == 0) {
		size = 1;
	}
	status = NU_Allocate_Memory(&System_Memory, &new_mem, size, NU_NO_SUSPEND);
	if(status==NU_SUCCESS) {
		memset( new_mem, 0, size );
		return new_mem;
	}
	else
		return NULL ;
}


/*//////////////End Method Allocate_Memory////////////////////////////////////*/


/*//////////////Method To Free Memory///////////////////////////////*/

static void Free_Memory(void *p)
{
	if(p) {
		NU_Deallocate_Memory( p ) ;
	}
}

/*///////////////End Method Free_Memory/////////////////////////*/
static void * ricRealloc(void * old_ptr, size_t old_size, size_t new_size)
{
	void * new_ptr = NULL;
	size_t i;
	size_t copy_size = (new_size >= old_size) ? old_size : new_size;
	RiCBoolean shouldCopyMemory = ((new_size != 0) && (old_size != 0));
 
	if (new_size > 0) new_ptr = Allocate_Memory( new_size ) ;
 
	if(shouldCopyMemory) {
		for(i = 0 ; i != copy_size; i++ ) {
			/*copy old size bytes to new allocted memory*/
			*((char*)(new_ptr+i)) = *((char*)(old_ptr+i) );
		}
	}
	Free_Memory(old_ptr); /* free old memory */
	return new_ptr;
}

static void *ReAlloc_Memory( void *old_ptr, size_t new_size ) //*Web_ReAlloc_Memory( void *old_ptr, size_t new_size )
{
	void * result = malloc(new_size);
	if (!result)
		return result;
	memcpy(result, old_ptr, new_size);
	free(old_ptr);
	return result;
}

static void *CAllocate_Memory(size_t size,int type) 
{

	return(Allocate_Memory(size));
}

/********************************************************
*   Public functions for memory alloc/free:
*
*  extern  void free_memory(void *p, int len)
*  extern  void *alloc_memory(int len)
*  extern  char *alloc_string(int len)
*  extern  void free_string(char *s)
*  extern  char **alloc_strings_array(int len)
*  extern void free_strings_array(char **raw_pairs,int num)
*
**********************************************************/

/*******************************************************************************/

#define malloc( size ) Allocate_Memory( size )
#define free( ptr ) Free_Memory( ptr )
#define realloc( ptr, size ) ReAlloc_Memory( ptr, size )
#define calloc(size ,type) CAllocate_Memory(size ,type)

/********************************************************
*   Public functions for memory alloc/free:
*
*  extern  void free_memory(void *p, int len)
*  extern  void *alloc_memory(int len)
*  extern  char *alloc_string(int len)
*  extern  void free_string(char *s)
*  extern  char **alloc_strings_array(int len)
*  extern void free_strings_array(char **raw_pairs,int num)
*
**********************************************************/

/*********************************************************
* free_memory(void *p, int len)
* Note: Platform dependent !!!!!!!!!
**********************************************************/
void free_memory(void *p, int len)
{
   free(p);
}

void *alloc_memory(int len)
{
   void *p;

   p = calloc(len, 1);

   return(p);
}
/********************************************************/
void *realloc_memory(void* addr,int len)
{
	return(realloc(addr,len));
}
/********************************************************/

char *alloc_string(int len)
{
  return(alloc_memory(len+1));  /* add 1 len for termination */
}

char *string_dup(char *s)
{
  char *p;
 
   if(!s) s = "";  /*Protect from NULL pointer convert to empty string */
   
   p = alloc_memory(strlen(s) + 1);
   if(p)
      strcpy(p, s);
   return(p);
}

/********************************************************/

void free_string(char *s)
{
	if(s)
	{
	  free_memory(s, strlen(s));
	}
}

/********************************************************/
char **alloc_strings_array(int len)
{
	 return(alloc_memory(len* sizeof(char *)));
}
/********************************************************/

/*********************************************************
* 
**********************************************************/
void free_strings_array(char **raw_pairs,int num)
{
	int i ;

	for(i = 0 ; i < num; i++)
		free_string(raw_pairs[i]);
	free_memory(raw_pairs, num * sizeof(char *));

}

 void *alloc_rows(int sizeofRow, int len)
{
    int sizeofRows;
    void *p;
    
 	 sizeofRows = len *sizeofRow;
    p = alloc_memory(sizeofRows);
    memset(p  , 0 ,sizeofRows);
    return(p);
}
/*********************************************************
*********************************************************
*********************************************************
*   Allocation of http message
**********************************************************/
static int HttpMsgSize = 2048;


void SetHttpMsgSize(int size)
{
	HttpMsgSize = size;
}
/*********************************************************
* 
**********************************************************/
char *alloc_HttpMsg(int* len)
{
 static char* msg = 0;
 if(!msg)
   msg = alloc_memory(HttpMsgSize);
 *len = HttpMsgSize;
 return(msg);
}
/*********************************************************
* 
**********************************************************/
