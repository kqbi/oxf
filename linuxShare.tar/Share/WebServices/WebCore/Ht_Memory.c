/******************************************************************************
*	file name   :	Ht_Memory.c 
*
*	purpose: Public functions for memory alloc/free:
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <string.h> 
#include <stdlib.h>
/*******************************************************************************/

/********************************************************
*   Public functions for memory alloc/free:
*
*  extern  void free_memory(void *p, int len)
*  extern  void *alloc_memory(int len)
*  extern  char *alloc_string(int len)
*  extern  void free_string(char *s)
*  extern  char **alloc_strings_array(int len)
*  extern void free_strings_array(char **raw_pairs,int num)
*
**********************************************************/

/*********************************************************
* free_memory(void *p, int len)
* Note: Platform dependent !!!!!!!!!
**********************************************************/
void free_memory(void *p, int len)
{
   free(p);
}

void *alloc_memory(len)
{
   void *p;

   p = calloc(len, 1);

   return(p);
}
/********************************************************/
void *realloc_memory(void* addr,int len)
{
	return(realloc(addr,len));
}
/********************************************************/

char *alloc_string(int len)
{
  return(alloc_memory(len+1));  /* add 1 len for termination */
}

char *string_dup(char *s)
{
  char *p;
 
   if(!s) s = "";  /*Protect from NULL pointer convert to empty string */
   
   p = alloc_memory(strlen(s) + 1);
   if(p)
      strcpy(p, s);
   return(p);
}

/********************************************************/

void free_string(char *s)
{
	if(s)
	{
	  free_memory(s, (int)strlen(s));
	}
}

/********************************************************/
char **alloc_strings_array(int len)
{
	 return(alloc_memory(len* sizeof(char *)));
}
/********************************************************/

/*********************************************************
* 
**********************************************************/
void free_strings_array(char **raw_pairs,int num)
{
	int i ;

	for(i = 0 ; i < num; i++)
		free_string(raw_pairs[i]);
	free_memory(raw_pairs, num * sizeof(char *));

}

 void *alloc_rows(int sizeofRow, int len)
{
    int sizeofRows;
    void *p;
    
 	 sizeofRows = len *sizeofRow;
    p = alloc_memory(sizeofRows);
    memset(p  , 0 ,sizeofRows);
    return(p);
}
/*********************************************************
*********************************************************
*********************************************************
*   Allocation of http message
**********************************************************/
static int HttpMsgSize = 2048;


void SetHttpMsgSize(int size)
{
	HttpMsgSize = size;
}
/*********************************************************
* 
**********************************************************/
char *alloc_HttpMsg(int* len)
{
 static char* msg = 0;
 if(!msg)
   msg = alloc_memory(HttpMsgSize);
 *len = HttpMsgSize;
 return(msg);
}
/*********************************************************
* 
**********************************************************/
