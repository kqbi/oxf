/******************************************************************************
*	file name   :	ABSGetRequest.c 
*
*	purpose: Contains access to MIB DB
*	portability:	using many #if
*
*   CAUTIONS      :  Hides machine specific dirt

*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <stdio.h>
#include <string.h>

extern int RTOSGetLastError();
extern int RTOSSockPreInit();
extern int RTOSCreateSocket();
extern void RTOSSetSockOpt(int sd);
extern int RTOSBind(int sd,unsigned short port_number);
extern int RTOSListen(int sd,int num_of_connects);
extern int RTOSAccept(int sd);
extern int RTOSCloseSocket(int sd);
extern int RTOSRecv(int sd,char* msg,int len, int flags);
extern int RTOSGetCurrentClientIP(int sock);
extern void RTOSULongToHost(unsigned long IP,char host[]);
extern int RTOSSend(int sd, char* data,int len,int flags);

extern void ABSWebDebug_s(char *s);
extern void ABSWebDebug_s_i(char *s, int i);
extern int ABS_find_content(char *msg, int *content_lenp, int *content_offsetp);
extern int ABSDebug_set_resive_flag(int ClientSock);
extern void ST_AddIP(long userIP);
extern int IsLicensed(long client_addr);





#define PORTNUM               8000    /* Port number  */
#define MAX_PENDING_CONNECTS  5       /* Maximum length of the queue */

static unsigned short port_number = PORTNUM;

void SetPropPortNumber(unsigned short num)
{
	port_number = num;
}
/**************** Machine Specific: close socket *************/

void ABSCloseSocket(int Client)
{
  int ret;
	if((ret = RTOSCloseSocket(Client)))
	 ABSWebDebug_s_i("ABSCloseSocket = %d\n", ret);
}


/***************************************************************
* ABS_Rec_exact(Socket soc, char *out_msg, int len)
* Description:   Fetch exactly len bytes from socket to out_msg 
****************************************************************/
static void ABS_Rec_exact(int ClientSock, char *msg, int exact_len)
{
int len;

	if(exact_len <= 0)
		return;
	
    len = RTOSRecv(ClientSock, msg, exact_len, 0); 
	ABS_Rec_exact(ClientSock, msg + len, exact_len - len);
   
}

/***************************************************************
* ABS_Rec_data(Socket soc, char *out_msg, int len)
* Description:   Fetch an entire HTTP message up to max_len
*                Assumes socket is already open an initialized.
****************************************************************/ 

static int ABS_Rec_data(int ClientSock, char *msg, int max_len)
{
	int len,len2;
    int content_len;
    int content_offset;
    int total_msg;
    int left_len;
    extern char *ABS_get_method();

         /* Get first fragment of HTTP */
    len = RTOSRecv(ClientSock, msg, max_len, 0);
	
	/* printf("\nlen = %ld\n",len);*/

    if(len <= 0)
       return(len); /* Error */

    msg[len] = 0;

	/* printf("<%s>\n",msg); */

	 if(!strcmp("GET", ABS_get_method(msg)))
	 {
		 return(len);  /* Full HTTP arrived */
	 }

	 if(!ABS_find_content(msg,  &content_len, &content_offset))
	{
	  len2 = RTOSRecv(ClientSock, msg + len, max_len - len, 0);
	  len += len2;

      if(!ABS_find_content(msg,  &content_len, &content_offset))
           return(len);  /* assumes that all message has been received */
	}

    total_msg = content_offset + content_len;
	if(total_msg > max_len)
		total_msg = max_len;
	left_len = total_msg - len;
	/* drink rest of data */

	ABS_Rec_exact(ClientSock, msg + len, left_len);

	msg[total_msg] = 0;
	return(total_msg);
}



/*************************************************************/
static int ABSBind(int *ServeSocketp)
{
  int sock  = -1;  /* Window socket */

  if(!RTOSSockPreInit())
  {
    ABSWebDebug_s_i ( "ERR!! WSAStartup failed. Error: 0x%x\n",RTOSGetLastError());
    return 0;
  }

  /* Create a TCP/IP socket*/
  if((sock = RTOSCreateSocket()) == -1){
	 ABSWebDebug_s_i ("Allocating socket failed. Error: %d\n",RTOSGetLastError());
     return 0;
  }

  RTOSSetSockOpt(sock);

  /* Associate the local address with socket*/
  if(RTOSBind(sock,port_number)== -1){
	ABSWebDebug_s_i ("Binding socket failed. Error: %d\n",RTOSGetLastError());
    RTOSCloseSocket(sock);
    return 0;
  }

  /* Establish a socket to listen for incoming connections.*/
  if(RTOSListen(sock,MAX_PENDING_CONNECTS)==-1)
  {
    ABSWebDebug_s_i ("Listening to the client failed. Error: %d\n",RTOSGetLastError());
    RTOSCloseSocket(sock);
    sock = -1;
    return 0;
  
  }
  *ServeSocketp = sock;
  return 1;

}

/*************************************************************/
static int _Port_Sock = -1;
int ABSClosePortSocket()
{
	return RTOSCloseSocket(_Port_Sock);
}


/*************************************************************/
int ABSServerRequest(int *clientp,char* msg,int *lenp,int max_len)
{

  int ClientSock = -1;  /* Socket for communicating */
                        /* between the server and client*/

   if(_Port_Sock <  0)
   {
    if(!ABSBind(&_Port_Sock))
		{
			ABSWebDebug_s("ABSBind faild\n");
			return(0);
		}
   }
   
  ClientSock = RTOSAccept(_Port_Sock);


  if (ClientSock == -1) 
  {
    ABSWebDebug_s_i ("ERR!! Accepting connection with client failed Error: %d\n",
			            RTOSGetLastError ());
    return 0;
  }

    ABSDebug_set_resive_flag(ClientSock);

    /* Receive data from the client.*/
    *lenp = ABS_Rec_data(ClientSock, msg, max_len);

    if(*lenp < 0)
    {
    ABSWebDebug_s("ERR!! ABS_Rec_data Fail\n");
    ABSWebDebug_s_i ( "ERR!! Socket Error: %d\n",RTOSGetLastError());
    return 0;
    }

    if(*lenp >= max_len)
    {
     ABSWebDebug_s ( "ERR!! Message too long\n");
     return 0;
    }
 
    if(!*lenp)
    {
     ABSWebDebug_s_i ( "ERR!! Message empty: socno=%ld\n",ClientSock);
     return 0;
    } /*empty message*/

     msg[*lenp] = 0;
    *clientp = ClientSock;

    return(1);  

}
/****************************************************************************/
int ABSCloseSession(int Client)
{
	
  /* Disable both sending and receiving on ClientSock.*/
  /* shutdown (Client, 0x02);*/
  

   ABSCloseSocket(Client);
#ifdef WIN32
 /* WSACleanup ();*/
#endif

  return 1;

}
/****************************************************************************/
int GetCurrentClientIP(int sock)
{
	return(RTOSGetCurrentClientIP(sock));
}
/****************************************************************************/
void ULongToHost(unsigned long IP,char host[])
{
	RTOSULongToHost(IP,host);
}
/****************************************************************************/
int PropCgiPResponseWrite(void *fp, char *data, int len)
{
	unsigned int client;
	client =  *((unsigned int *)fp);
    return((RTOSSend(client, data, len, 0) != -1));
}
/****************************************************************************/
