/******************************************************************************
*	file name   :	Query_Process.c 
*
*	purpose: conatins receiving/parsing the QUERY_STRING
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <stdio.h>
#include <string.h>
/*******************************************************************************/
extern void HTML_Write_Table(void *fp, int rows, int cols, char **hp, char ***p);

/********************************************************
* This file conatins receiving/parsing the QUERY_STRING
* from the browser to the server breaking it into 
* Name/Value pair.
*
*  Public functions:
*  void Split_Query(
*        char *in_query_string, 
*        void  **outpairs, -hidden type is (Value_Pair **)-)
*
*
*  int Pairs_count(void * value_pairs_arr) - returns number of pairs.
*
*  int Pairs_get(
*        void *value_pairs_arr,
*        int index,           - index to the array
*        char **namep,        - returned name
*        char **valp,         - returned valp
*        int *valp_len        - returned len of valp
*        )
*
*   void free_pairs(void *p)
*
*********************************************************/

/********************************************************
*  Extern definitions of memory handling functions
********************************************************/
extern  void free_memory(void *p, int len);
extern  void *alloc_memory(int len);
extern  char *alloc_string(int len);
extern  void free_string(char *s);
extern  char **alloc_strings_array(int len);
extern void free_strings_array(char **raw_pairs,int num);


typedef struct
{
	char *valuep;
	char value_name[64];
	int  value_len;
} Value_Pair;

int IsQueryEnd(void* args)
{
	if(args == 0)
		return(1);
	return(!((Value_Pair*)args)->value_name[0]);
}
/*********************************************************
* 
* 
**********************************************************/
void Find_Arg(char *value_name, void *args,char **valpp)
{
	Value_Pair *p;
	
	if(args)
	   {
		for (p = args; p->value_name[0] && 
			strcmp(value_name,p->value_name);
		p++)
		;
		
		*valpp = p->valuep; 
	   }
	else
		*valpp = 0;
}
/*********************************************************
* 
* 
**********************************************************/
int Args_Select_by_val(Value_Pair *p,char *val, char **lines, int max_lines)
{
	int j;
	
	max_lines--; 
    for (j = 0 ; j < max_lines && (p && p->value_name[0]) ; p++)
	{
		if(!strcmp(p->valuep, val))
			lines[j++] = p->value_name;
	}
	lines[j] = 0;
    return(j);
}

/*********************************************************
* 
* 
**********************************************************/
int Pairs_count(void * value_pairs_arr)
{
	Value_Pair *p = value_pairs_arr;
	int i;
	
	if (!value_pairs_arr) return (0);
	for (i = 0, p = value_pairs_arr; 
	p->valuep ; 
	p++,i++);
	return(i);
}
/*********************************************************
* 
* 
**********************************************************/

int Pairs_get(
			  void *value_pairs_arr,
			  int index,           /* index to the array */
			  char **namep,        /* returned name */
			  char **valp,         /* returned valp */
			  int *valp_len        /* returned len of valp */
			  )
{
	Value_Pair *p;
	
	if(!value_pairs_arr)
		return(0);
	
	p = ((Value_Pair *)value_pairs_arr) + index;
	
	*namep = p->value_name;
	*valp = p->valuep;
	*valp_len = p->value_len;
	
	return(!!p->valuep); /* YES iff valid value pair */ 
	
}
/*
may be deleted
*/
void Pairs_List_free(char **name_list, char **val_list)
{
	free_memory(name_list, 0);
	free_memory(val_list, 0);
}

int Pairs_List_get(
				   void *value_pairs_arr,
				   char ***out_name_list,/* returned names list */
				   char ***out_val_list, /* returned values list*/
				   int *list_len         /* returned list len   */
				   )
{
	int i, len;
	char **names_list;
	char **vals_list;
	char *namep;
	char *valp;
	int val_len;
	
	len = Pairs_count(value_pairs_arr);
	names_list =  alloc_strings_array(len + 1);
	vals_list  =  alloc_strings_array(len + 1);
	
	for(i = 0 ; i < len ; )
	{
        if(Pairs_get(value_pairs_arr, i, &namep, &valp, &val_len) > 0)
        {
			names_list[i] = namep;
			vals_list[i]  = valp;
			i++;
        }
	}
	names_list[i] = vals_list[i] = 0;
	*out_name_list = names_list;
	*out_val_list = vals_list;
	*list_len = i;
	return(i);
}

/*********************************************************
* 
* 
**********************************************************/
Value_Pair *alloc_pairs(int num)
{
	Value_Pair *p;
	
	/* alloc one more item as a delimiter */
	p = alloc_memory((num + 1)*  sizeof(Value_Pair));
	memset(&p[num], sizeof(*p), 0);
	return(p);
}
/******************************************************
* warning: Destroys the value_pairs and all its STRINGS
*          If the strings (valuep, name) are used
*          directly after this function it will CRASH!!!
********************************************************/


void free_pairs(void *pairs)
{
	Value_Pair *p ;
	int size;
	
	if (!pairs) return ;
	
	for ( p = pairs; p->valuep ; p++)
		free_string(p->valuep);
	
	size = (int)(((unsigned char *)(p+1)) - ((unsigned char *)pairs));
	free_memory(pairs, size);
}


/*********************************************************
* 
**********************************************************/
static int query_item_len (char *p)
{
	int i = 0;
	if(p)
		for (; *p && *p != '&' && *p !=' '; i++, p++);
		
		return(i);
}
/*********************************************************
* 
**********************************************************/


static void  raw_split_query(char *query,int query_len, char ***raw_pairs,int *pair_num)
{
	int i,arg_len = 0;
	char *p;
	char *temp_p = query + query_len;
	char **tmp_pairs;
	
	if(!query_len) 
	{
		*pair_num = 0;
		*raw_pairs = 0;
		return;
	}
	
	/* find how many value pairs */
	for (i = 1 , p = query; *p && (p < temp_p); p++)
		if(*p == '&') i++;
		*pair_num = i;
		tmp_pairs = alloc_strings_array(*pair_num);
		for(i = 0 , p = query; i < *pair_num;  i++, p += (arg_len+1))
		{
			arg_len = query_item_len(p);
			tmp_pairs[i] = alloc_string(arg_len);
			memcpy(tmp_pairs[i], p, arg_len);
			tmp_pairs[i][arg_len] = 0;
		}
		
		*raw_pairs = tmp_pairs;
		
}
/*********************************************************
* static clean_hex(char *s)
* Note: Should add some checks and improve performance !!!!
**********************************************************/
static int clean_hex(char *s)
{
	
	char *p;
	unsigned int i, tmp;
	for(i= 0 , p = s; *p; i++, p++)
	{
		if (*p == '%')
		{
			
			sscanf((p + 1), "%2x", &tmp);
			(*p) = (unsigned char)(tmp & 0xff);
			strcpy((p + 1), (p + 3));
		}
	}
	
    return(i);
	
}
static void SingleQuery2Value_Pair(char *s,Value_Pair *pair)
{
	char *p;
	int len, name_len, value_len;
    
	/* replace '+' with space*/
	/*  for(p = s; *p; p++) if(*p == '+')   *p = ' '; */
	
	/* replace hex with ascii*/
    len = clean_hex(s);
    for(p = s; *p && *p != '='; p++) ;
    name_len = (int)(p - s);
    value_len = len - (name_len + 1);
	if (value_len < 0) value_len = 0;
    pair->valuep = alloc_memory(value_len + 1);
	if(name_len >= sizeof( pair->value_name))
		name_len = sizeof( pair->value_name) - 1;
	/* Fill output pairs */
	memcpy(pair->value_name, s, name_len);
    pair->value_name[name_len] = 0;
	
	pair->value_len = value_len;
    memcpy(pair->valuep, (p + 1),value_len);
    pair->valuep[value_len] = 0;
	
	
}
/*********************************************************
* name: Split_Query(char *in, Value_Pair **outpairs)
**********************************************************/
void Split_Query(char *query,int query_len,void* args)
{
	char **raw_pairs;
	int  pairs_num, i;
	Value_Pair **outpairs;
	Value_Pair  *pairs;
	
	outpairs = (Value_Pair **)args;
	if(!query_len)
	{
		*outpairs= 0;
		return;
	}
	
	raw_split_query(query,query_len, &raw_pairs,&pairs_num);
	
	pairs = alloc_pairs( pairs_num);
	
	for(i = 0 ; i < pairs_num; i++)
		SingleQuery2Value_Pair(raw_pairs[i], &pairs[i]);
	
	free_strings_array(raw_pairs, pairs_num);
	/*initial output params */
	*outpairs = pairs;
	
	
	
}


/*******************************************************************************/
int ABSGetAggFromArgs(void* args,char** agg_name,char** names,int max_lines)
{
	Find_Arg("agg_name", args, agg_name);
	
	return(Args_Select_by_val(args,"R", names,max_lines));
}
