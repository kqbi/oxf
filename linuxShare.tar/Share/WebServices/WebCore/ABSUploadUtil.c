/******************************************************************************
*	file name   :	ABSUploadUtil.c 
*
*	purpose: Contains access to MIB DB
*	portability:	Machine Independent
*
*
*	author(s):	Gadi Veazovsky   
*	date started:	01-Apr-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <stdio.h>
#include <string.h>
/*******************************************************************************/
char *find_token_in_block(char *inp, char *end_inpp, char *tok, int tok_len);
void copy_word(char *outp, char *inp);
char *ABS_end_empty_line(char *msg);
char *skip_spaces(char *p);
void ABSWebDebug_s_s(char *s1, char *s2);
void ABSWebDebug_s(char *s);
char *ABS_end_line(char *p);
int ABSFileSave(char *name, char data[], int len);
void Split_Query(char *query,int query_len,void* args);






const char CType[]="Content-Type: ";

/*********************************************************************/
static char *section_fetch_name(char *startp,char  *endp, char *arg_name)
{
	    static char content_disposition[] =
		"Content-Disposition: form-data; name=";
        char *p;

   p = find_token_in_block(startp, endp, content_disposition, sizeof(content_disposition) - 1);
   if(!p )
       return(0); /* Invalid Section */
   p += (sizeof(content_disposition) -1);

   if(p >= endp)
	   return(0);  /* Invalid section */
   copy_word(arg_name, p);
   p += strlen(arg_name);
   if(p >= endp)
	   return(0);
   else
	   return(p);  
}

/*********************************************************************/
static int Analyze_Section(char *startp, char *endp, char *arg_name, char *arg_val)
{
    char *p;
	static char ofile[]= "\"ofile1\";";


/*  ABSWebDebug_s_section(startp, endp);*/
    p = section_fetch_name(startp, endp, arg_name);
	if(!p)
		return(0);

/*  ABSWebDebug_s_s("name = [%s]\n", arg_name);*/
   *arg_val = 0;
   if(!strcmp(arg_name, ofile))
	   return(0);  /* this is a file section not a value pair section */

    p = ABS_end_empty_line(p -2);
	if(p >= endp)
		return(0);
    copy_word(arg_val, p);
	return(1);

}
/*********************************************************************/
static int handle_file_section(char *startp, char *endp, char *out_name)
{
	static char filename[]= "filename=";
	char *start_file, *end_file;
    char *p;
	int file_len;
	char type[30];

    type[0] = 0;


	p = skip_spaces(startp);
    if(memcmp(p, filename, sizeof(filename) - 1))
      return(0);

	/* get to content type*/

	p = ABS_end_line(p);

	if(memcmp(CType, p, sizeof(CType) - 1))
		return(0);
	p += (sizeof(CType) - 1);
	copy_word(type, p);


	
	start_file = ABS_end_empty_line(p);


	if(start_file >= endp)
		return(0);

   end_file = endp;
   	/*for some reason we need to go to end of previous line*/
	for( ; *end_file != '\n' && *end_file != '\r'; end_file--);
    if(*end_file == '\n' && *end_file == '\r') end_file--;
   
	file_len = (int)(end_file - start_file);
    /*printf("Fname=%s, Flen=%d\n",out_name, file_len);*/
	if(!ABSFileSave(out_name, start_file, file_len))
	{
		ABSWebDebug_s_s("Can't save File:%s\n", out_name);
        return(0);
	}
	return(1);
}

/*********************************************************************/
static int Analyze_File_Section(char *startp, char *endp, char *file_name)
{
	char arg_name[64];
    char *p;
	static char ofile[]= "\"ofile1\";";


   p = section_fetch_name(startp, endp, arg_name);
	if(!p)
		return(0);

   if(strcmp(arg_name, ofile))
	   return(0);

    return(handle_file_section(p, endp, file_name));

}

/*********************************************************************/

/*********************************************************************/
static int create_upload_query(char *msg, char *query, char boundary[], int len)
{
  char *p, *endp;
   int bound_len;
  char *sections[20];
  int j, last_section;
  char arg_name[64];
  char arg_val[128];
  char targetname[128];

  bound_len = (int)strlen(boundary);
  p = msg;
  endp = p + len;
    /* skip firt boundary occurance which is its definition*/
  p = find_token_in_block(p, endp, boundary, bound_len);
  p++;

  for(j = 0; j < 19 && p;  )
  {
     p = find_token_in_block(p, endp, boundary, bound_len);
     sections[j] = p;
     if(p)
	 {
		 p++; /* move a little for not re-finding the same token*/
         j++;
	 }
  }

  last_section = j-2;  
  if(j >= 20)  
  {
	  ABSWebDebug_s("ERR!! Too many boundary sections\n");
      return(0);
  }
 
  /* last section should be TargetURL so here we fetch it*/ 
 if(!Analyze_Section(sections[last_section], sections[last_section+1],
	 arg_name, targetname))
      return(0);

 if(strcmp("\"TargetURL\"",arg_name))
      return(0);  /* last argument must be target name */


 if(!Analyze_File_Section(sections[last_section - 1], sections[last_section],targetname))
	 return(0);

  /*****  Analyze each section & convert it into args */

  for (j = 0 ; j <= (last_section - 2); j++)
  {
		  if(Analyze_Section(sections[j], sections[j+1],arg_name, arg_val))
		  {
           ABSWebDebug_s_s("arg_name=%s\n", arg_name);
           ABSWebDebug_s_s("arg_val=%s\n", arg_val);

		  } 
  }
   sprintf(query, "Abs_App=Abstract_Upload&ABSFile=%s", targetname);
   return(1);
 
}
void Split_upload_query(char *msg, int len, char boundary[],void* args)
{
	char upl_query[256];
	if(create_upload_query(msg, upl_query, boundary, len /*content_len*/))
		Split_Query(upl_query,sizeof(upl_query), args);
}

