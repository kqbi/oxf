/******************************************************************************
*	file name   :	Intf_WebCore.c 
*
*	purpose: Contains external function interface
*			 1) interface for comercial WebServer 
*	portability:	Machine Independent except CgiPResponceWrite function
*
*
*	author(s):	 Gadi Veazovsky   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/

/*******************************************************************************/

/*WebCore Interface
1)Interface of user defined functions for system integration. 
2)External function interface
*/

/****************************************************************************/
/*1)Interface of user defined functions for system integration.				*/
/****************************************************************************/
#define SI_MAX_INDEX 64
#define SI_ERROR     -1
#define SI_SUCCESS    0

#include <string.h>

int HTML_Write_bytes(void *fp, char *data, int len);
char *string_dup(char *s);



typedef struct _sysIntf{
	char* name;
	void* func;
}sysIntf;

static sysIntf SysIntTable[SI_MAX_INDEX];
static int tindex = 0;


sysIntf* SIFindElem(char* name)
{
 int i;
	for(i=0;i<tindex;i++)
	{
		if(!strcmp(SysIntTable[i].name,name))
			return(&SysIntTable[i]);
	}
	return(NULL);
}

void SIAddElem(char* fname,void *func)
{
	sysIntf* el;

	if((el = SIFindElem(fname)))
	{
	   el->func = func;
	}
	else
	{
	  if(tindex < SI_MAX_INDEX){
		SysIntTable[tindex].name = string_dup(fname);
		SysIntTable[tindex].func = func;
		tindex++;
	  }
	}
}
/*User functions															*/
/****************************************************************************/

int Bind_func(char* name,void *func)
{
  sysIntf* pIntf;
  if(((pIntf = SIFindElem(name)) != NULL))
	{
	  pIntf->func = func;
	  return(SI_SUCCESS);
	}
  return(SI_ERROR);
}
void* Fetch_func(char* name)
{
  sysIntf* pIntf;
  if((pIntf = SIFindElem(name)) != NULL)
	{
	  return(pIntf->func);
	}
  return(NULL);
}
/****************************************************************************/
/*2)External function interface.											*/
/****************************************************************************/

/************************************************************************/
/*******************************************************************************/
/*							FS overides										   */ 
/*																			   */
/*******************************************************************************/
