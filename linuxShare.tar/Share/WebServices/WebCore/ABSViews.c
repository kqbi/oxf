/******************************************************************************
*	file name   :	ABSViews.c 
*
*	purpose:		store and restore of user defined views.
*	portability:	Machine Independent
*
*
*	author(s):	Gadi Veazovsky   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <string.h>
/*******************************************************************************/

extern char *ABS_getlne(char *line, char *msg);
extern char *string_dup(char *s);
extern int RegisterViewNames(char *agg_name, char **names, int len);
extern void free_string(char *s);
extern int ABSGetAggFromArgs(void* args,char** agg_name,char** names,int max_lines);
extern int absmib_get_name_by_id(int id,char** namep);
extern int absmib_get_id_by_name(char* name);
extern char* GetDeviceName();
extern int Agg_GetChilds(int id,int out_childs[],int max_childs);
extern int absmib_get_type_by_id(int id,int* type_id);
extern int type2metatype(char **metatype, int type_id);



/*******************************************************************************/
static void ABSSaveViewToBuffer(int vId, int childs_Ids[],int len, char buff[],int buff_len)
{
	char *name;
	int i;

  	strcpy(buff,"@");
	absmib_get_name_by_id(vId,&name);
	strcat(buff,name);
	strcat(buff,"\r\n");
    free_string(name);

	for(i = 0;i < len ;i++){
		 absmib_get_name_by_id(childs_Ids[i],&name);
		 strcat(buff,name);
		 strcat(buff,"\r\n");
		 free_string(name);
	}
}
/*******************************************************************************/
void BackupViews(char buff[],int max_len)
{
	int i,pId,views_len,childs_len,type,tmp_len;
	int tmp_views[400];
	int tmp_childs[400];
	char vbuff[64*400+16];
	char* metatype;

	buff[0]=0;
	tmp_len = 0;
	pId = absmib_get_id_by_name(GetDeviceName());
	views_len = Agg_GetChilds(pId,tmp_views,sizeof(tmp_views)/sizeof(tmp_views[0]));
	for(i = 0; i < views_len; i++)
	{
	  	absmib_get_type_by_id(tmp_views[i],&type);
	    type2metatype(&metatype,type);
        if(!strcmp(metatype, "view"))
		{
		  childs_len = Agg_GetChilds(tmp_views[i],tmp_childs,sizeof(tmp_childs)/sizeof(tmp_childs[0]));
		  ABSSaveViewToBuffer(tmp_views[i],tmp_childs,childs_len, vbuff,64*400+16);
		  if(((int)strlen(vbuff) + tmp_len + 1) <  max_len)
			  strcat(buff,vbuff);
		  else
			  return;
		}
	}
}
/*******************************************************************************/
void RestoreViews(char* str)
{
	int i,j;
	char tmp_line[50];
	char *names[50];
	char *pTmp,*aggr_name;

	pTmp = str;
	while(pTmp && *pTmp)
	{
	    pTmp = ABS_getlne(tmp_line,pTmp);
		aggr_name = string_dup(tmp_line +1);
		for(i = 0; pTmp && *pTmp != '@';i++)
		{
			pTmp = ABS_getlne(tmp_line,pTmp);
			names[i] = string_dup(tmp_line);
		}
		RegisterViewNames(aggr_name,names,i);

		free_string(aggr_name);
		for(j = 0; j < i; j++)
			free_string(names[j]);
	}
}
/*******************************************************************************/
