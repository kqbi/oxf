/******************************************************************************
*	file name   :	ABS_WebServer.c 
*
*	purpose: MainLoop of webserver
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/

/*******************************************************************************/
extern int ABSServerRequest(int *clientp,char* msg,int *lenp,int max_len);
extern void ST_increase_hits();
extern int ABSHttpDecode( char url[], void* args, char  msg[], int len);
extern int Do_Application(void  *client, char *url, void *args);
extern void free_pairs(void *pairs);
extern void ABSWebDebug_s(char *s);
extern int ABSCloseSession(int Client);
extern int IsValidIP(long cl_ip);
extern int GetCurrentClientIP(int sock);
extern char *alloc_HttpMsg(int* len);


static int ABSGetRequest(void *clientp,char* url,void* args)
{
  int len;
  int msg_len = 0;
  char *msg;
  msg = alloc_HttpMsg(&msg_len);

  if(!msg)
	  return 0;
  
  if(!ABSServerRequest(clientp,msg, &len,msg_len))
   {
    /*ABSWebDebug_s("ABSServerRequest faild\n");*/
	  return(0);
   }
  ST_increase_hits();

  if(!ABSHttpDecode( url,args,msg,len))
   {
    /*ABSWebDebug_s("ABSHttpDecode faild\n");*/
	  return(0);
   }
  return(1);  

}
/*************************************************************/
int ABSProcessRequest(void* client, char *url,void* args)
{
  Do_Application(client,  url, args);

  free_pairs(args);

  return 1;
}

/*************************************************************/
static int ABSDispatch()
{
   int client;
   void *args = 0;
   char url[256];
								
   if(ABSGetRequest(&client,url,&args))
   { 
	    if(IsValidIP(GetCurrentClientIP(client)))
		{
			if(!ABSProcessRequest(&client,  url, args))
			{
				ABSWebDebug_s("ABSProcessRequest");
			}
		}
   }
   else
   {
	      ABSWebDebug_s("ABSGetRequest faild\n");
   }

   if(!ABSCloseSession(client))
	{
		ABSWebDebug_s("ABSCloseSession");
		return(0);
	}
   return(1);
}

/*************************************************************/
void WebServerGo()
{
	while( 1 )
	  ABSDispatch();
}
