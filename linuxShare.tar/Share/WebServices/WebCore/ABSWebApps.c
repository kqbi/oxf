/******************************************************************************
*	file name   :	ABSWebApps.c 
*
*	purpose: Contains Applicator's API
*                   ABSClear_Apps()
*                   ABSWebAddApp(char *name, void (* appfunc)(),int visibylity)
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <string.h>
/*******************************************************************************/
extern int IsQueryEnd(void* args);
extern long ABS_URL_Valid(char *url);
extern int ABS_URL_Fetch(void *fp, char *url);
extern void Find_Arg(char *value_name, void *args,char **valpp);
extern void HTML_DOCNOTFOUND(void* fp,char* url);
extern int ABSProcessRequest(void* client, char *url,void* args);
extern char* decode_get_url(char url[],char* start_url,void* args);
extern int Send_File(char* url,void *fp);
extern char *ABS_strlwr(char *string);
extern void HTML_Write_NL(void *fp);
extern void HTML_DocNotFoundNoHeader(void* fp,char* url);

/****************************************************
*  This file is for adding applications to the web 
*  Server.
*
*
*****************************************************/

typedef struct
{
	char app_name[20];
	void  (* app_func)(void *client, void *args);
	unsigned char  visebility; /*1 - is visible in browser,0 - not visible*/
} Server_Apps;


const char Abstract_APP[] = "Abs_App"; /* ValuePair's Name*/

Server_Apps apps_table[20];

#define MAX_Server_Apps (sizeof(apps_table)/sizeof(apps_table[0]))

char *ABS_Upload_query()
{
	return("Abs_App=Abstract_Upload&ABSFile=%s");
}

int ABSClear_Apps()
{
	memset (apps_table, 0, sizeof(apps_table));
	return 1;
}

int ABSWebAddApp(char *name, void (* appfunc)(void *, void *),int isVisible)
{
	int i;
	static int flag = 0;
	if (!flag) flag = ABSClear_Apps();
	

	for (i = 0 ;
	     (i < MAX_Server_Apps) && apps_table[i].app_name[0] && strcmp(apps_table[i].app_name, name); 
		 i++);

    if(i >= MAX_Server_Apps)
		return (0); /* No room */

    apps_table[i].app_func = appfunc;
	strcpy(apps_table[i].app_name, name);
	apps_table[i].visebility = isVisible;
    return(1);

}
/**********************************************************/
static Server_Apps *StFindCGIEntry(char *cginame)
{
	  Server_Apps *p;
 	  for(p = apps_table; p->app_name[0] && strcmp(cginame, p->app_name); p++);

	  if (p->app_name[0]) return(p);
	  else return 0;
}

long FindCGIEntry(char *cginame)
{
	return ((long)StFindCGIEntry(cginame));
}

void* GetCgiFunction(void* args)
{
	char *valuep;
	Server_Apps *p;

	Find_Arg((char*)Abstract_APP, args,&valuep);   
	if(!valuep)  
	   return(0);
    p = StFindCGIEntry(valuep);

	if (p) return((void*)p->app_func);
	else return 0;

}
/*******************************************************************************/
static char SignPageUrl[256];
void SetSignaturePageUrl(char *name)
{
	strcpy(SignPageUrl, name);
}


char* GrtSignaturePageUrl()
{
	return(SignPageUrl);
}

void Write_Signature (void *client)
{
	void *args = 0;
	char url[256];


    decode_get_url(url,GrtSignaturePageUrl(),&args);
	if(strlen(url))
	{
		if(ABS_URL_Valid(url))
		{
			HTML_Write_NL(client);
			HTML_Write_NL(client);
			Send_File(url,client);
		}
		else
			HTML_DOCNOTFOUND(client,url);
	}
}

/*******************************************************************************/
static char HomePageUrl[256];
void SetHomePageUrl(char *name)
{
	if (name == 0 || name[0] == 0)
		strcpy(HomePageUrl, "cgibin?Abs_App=Abstract_Default");
	else
		strcpy(HomePageUrl,name);
}
/*******************************************************************************/
char* GrtHomePageUrl()
{
	return(HomePageUrl);
}
/**********************************************************/
void GoToHomePage(void  *client)
{
  void *args = 0;
  char url[256];


    decode_get_url(url,GrtHomePageUrl(),&args);
	if (strlen(url))
		ABSProcessRequest(client,url, args);
}
/**********************************************************/
int Do_Application(void  *client, char *url, void *args)
{
 void (*cgi_func)();

    if(IsQueryEnd(args) )
	{  /*check and fetch file*/
		if(url && strlen(url))
		{
			if(ABS_URL_Valid(url))
				ABS_URL_Fetch(client, url);
			else
				HTML_DocNotFoundNoHeader(client, url);
		}
		else
		  GoToHomePage(client);
	
		return(1);
	}
	if((cgi_func = (void(*)())GetCgiFunction(args)))
		cgi_func(client,args);
	else
	   HTML_DocNotFoundNoHeader(client, url);

	return(1);
}
