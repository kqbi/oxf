/******************************************************************************
*	file name   :	ABS_URL.c 
*
*	purpose: process url
*	portability:	Machine Independent

*   Functions: 
*       ABS_URL_Valid(char *url)  - check supported ext.
*
*       ABS_URL_Fetch(void *fp_out, char *url) - send file to browser
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <string.h>
#include <stdio.h>
/*******************************************************************************/
extern int HTML_Write_bytes(void *fp, char *data, int len);
extern int HTML_Write_text(void *fp,  char data[]);
extern int ABSFileReadFrom(char *name, char data[], int from, int *lenp,int max_len);
extern void ABSWebDebug_s(char *s);
extern void ABSWebDebug_s_i(char *s, int i);
extern char *ABS_getlne(char *line, char *msg);
extern int ABSResourceFileSend(char *name,void *fp);
extern int ABS_IsResourceFile(char *name);
extern char *GetMimeTypeByName(char* name);
extern int HTML_Write_text(void *fp,  char data[]);
extern void HTML_DOCNOTFOUND(void* fp,char* url);
extern void Write_Head_CSS(void *fp);
extern int HTML_Write_Tail(void *fp);
extern int HTTP_Error (void *fp, char* errorMsg, char *errorAdd);


char *get_extension(char *url)
{
	char *ext;  /* extension of the url */

	for ( ext = 0; *url ; url++)
		if(*url == '.')
			ext = url;
    if(!ext)
		return("");
	return(ext+1);
}


/********************************************************
* Supported extensions
*********************************************************/

void ABS_Write_HTML_header(void *fp,char *fname,int len)
{
   char buff[256];
   char *Ctype = 0;
 
    if(!(Ctype = GetMimeTypeByName(fname)))
		return;
 
 /*   sprintf(buff, "HTTP/1.1 200 OK\r\nContent-Length: %d\r\nExpires: Tue, 31 Dec 2002 17:04:19 GMT\r\nContent-Type: %s\r\n\r\n",len,Ctype);*/

	HTML_Write_text(fp,"HTTP/1.1 200 OK\r\n");
/*	if(len >= 0){
       sprintf(buff, "Content-Length: %d\r\n",len);
        HTML_Write_text(fp,buff);
	}*/
    HTML_Write_text(fp,"Expires: Tue, 31 Dec 2009 17:04:19 GMT\r\n");
    sprintf(buff, "Content-Type: %s \r\n\r\n",Ctype);
    HTML_Write_text(fp,buff);
}


/*********************************************************/

static int ABS_SendFile(char *url,void *fp)
{
  int sts;
  char buff[4000];
  int len,from = 0;

	do{
	  sts = ABSFileReadFrom(url, buff,from, &len, sizeof(buff) - 1);

      if(!sts)
	  {
	   HTML_DOCNOTFOUND(fp,url);
       return(0);
	  }

      buff[len] = 0;

      HTML_Write_bytes(fp, buff, len);
      from += len;
	}while(len == sizeof(buff)-1);

	return(1);
}

/*********************************************************/

int Send_File(char* url,void *fp)
{
	if(ABS_IsResourceFile(url))
			return(ABSResourceFileSend(url,fp));
		else
			return(ABS_SendFile(url,fp));
}


/*********************************************************/

static int ABS_process_link_file(void *fp, char *url)
{
	char buff[256];
	char line[16];
	char *p;
	int len;

	ABSFileReadFrom(url, buff,0, &len, sizeof(buff) - 1);
	
	buff[len]=0;
	
	p = buff;
	do{
		p = ABS_getlne(line,p);
		Send_File(line,fp);

	}while(p);

	return(1);
}

/********************************************************
* ABS_URL_Fetch(void *fp, char *url)
* Fetch the named url and send it to the browser (*fp)
* 
* Limited to 16000 bytes.
*
* Attention: Currently uses inhouse WebServer +FileSystem
*            In case will use external, this function 
*            will be eliminated
*********************************************************/

int ABS_URL_Fetch(void *fp, char *url)
{


/*		----------  Write header ------------- */
/*	sprintf (header, fetch_header, len);  */

/*		----------  Write body -------------   */

	/* printf("<--fetch %s>\n",url); */
	ABS_Write_HTML_header(fp,url,0);
	if(!strcmp(get_extension(url), "inc"))
		ABS_process_link_file(fp,url);
	else
		Send_File(url,fp);

	return(1);
}


/*********************************************************/
void HTML_DOCNOTFOUND(void* fp,char* url)
{
	/*"404 - File not found"*/
	HTTP_Error(fp, "Requested url was not found on the device.", "HTTP 404 - File not found");
}

void HTML_DocNotFoundNoHeader(void* fp,char* url)
{
	HTML_Write_text(fp,"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n");
	HTML_DOCNOTFOUND(fp, url);
}
