/******************************************************************************
*	file name   :	ABSHttpUtil.c 
*
*	purpose: Various decoding + Http utilities analyzers.
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <stdlib.h>
#include <string.h>

/*******************************************************************************/
extern void ABSWebDebug_s_i(char *s, int i);
extern void Split_Query(char *query,int query_len,void* args);
extern int create_upload_query(char *msg, char *query, char boundary[], int len);
extern void Split_upload_query(char *msg, int len, char boundary[],void* args);
extern char *ABS_getlne();
extern int ABS_multipart(char *msg, int len, char boundary[]);
extern void* Fetch_func(char* name);



/***********************************used only for upload*********************************/
static int(*upl_multipart)() = 0;
static int(*upl_SplitQ)() = 0;


int abs_isspace(int c)
{
	if ((c > 8 && c < 14) || c == 32) return 1;
	return 0;
}


/*******************************************************
*  Copy word to outp null terminated.
*  copy all printable characters (non white)
*********************************************************/
void copy_word(char *outp, char *inp)
{
	while (*inp && !abs_isspace((int)(*inp)))
	{
       *outp = *inp;
	   outp++,inp++;
	}
	*outp = 0;
}

char *find_token_start (char *inp, int len, 
						const char *tok, int tok_len)
{
   for( ;  len; inp++,len--)
	   if(!memcmp(inp, tok, tok_len))
		   return(inp);
   return(0);
}

char *find_token_end(char *inp, int len,
					 const char *tok, int tok_len)
{
	char *p;
    if((p = find_token_start(inp, len, tok, tok_len)))
		p += tok_len;
	return(p);
}
/*************************************************/
char *find_token_start_in_str (char *inp, 
						       const char *tok, 
							   int tok_len)
{
   int i = 0;

	for( ;  *inp; inp++,i++)
		if(*inp == *tok)
	       if(!memcmp(inp, tok, tok_len))
		      return(inp);

   ABSWebDebug_s_i("Token not found = %d\n", i);

   return(0);
}

char *find_token_end_in_str(char *inp,
					       const char *tok,
							int tok_len)
{
	char *p;
    if((p = find_token_start_in_str(inp, tok, tok_len)))
		p+= tok_len;
	return(p);
}
/*********************************************************************/

/*********************************************************************/
char *ABS_end_empty_line(char *msg)
{
    char *p;
    char line[512];

    for (p = ABS_getlne(line,msg); p && line[0]; p = ABS_getlne(line, p))
                ;
    return(p);
}
/*********************************************************************/
static char *find_start_url(char *msg)
{
	for ( ; *msg  ; msg++)
	{
		if(*msg == 'G'  && !memcmp("GET /",msg,5))
			return(msg + 5);
	}

	return(0);
}
/*********************************************************************/
static char *ABS_find_content_len(char *msg, int len, int *content_lenp)
{
char *p;
const char Clength[] = "Content-Length: ";

    p = find_token_end(msg, len, Clength, sizeof(Clength) - 1);
    if(p)
       *content_lenp = atoi(p );
	 return(p);

}
/*********************************************************************/
int ABS_find_content(char *msg, int *content_lenp, int *content_offsetp)
{
char *p;

    p = ABS_find_content_len(msg, 1024, content_lenp);
    if(!p)
		return(0);

	/* find begining of actual content which starts after empty line*/
	p = ABS_end_empty_line(msg); 
    if(p)
      *content_offsetp = (int)(p - msg);
    else
	  *content_offsetp = (int)strlen(msg);

	return(1);

}
/*********************************************************************/
static int ABS_find_query_len(char* query_start)
{
  int len = 0;
  char* q;
   if(*query_start != '?'){
	   return 0; /*no query*/
   }
   for(q = (query_start++);!abs_isspace((int)(*query_start));query_start++,len++);
   return (int)(query_start - q);

}
/*********************************************************************/
char *ABS_get_method( char *msg)
{
 
	if(!memcmp("GET", msg, 3))
        return("GET");

	if(!memcmp("POST", msg, 4))
        return("POST");

    return("");
}
/*********************************************************************/
static char *copy_url(char *to, char *from)
{
     for (; *from && *from != ' ' && *from != '?';from++,to++)
		 *to = *from;
      *to = 0;
	 return(from); /*return start of next token */ 
}
/*********************************************************************/

static int IsUploadInitialized()
{
 if(!upl_multipart)
 {
   upl_multipart = (int(*)())Fetch_func("ILMultipart");
 };
 if(!upl_SplitQ)
 {
   upl_SplitQ =(int(*)())Fetch_func("ILUploadSplitQuery");
 };

 return(upl_multipart && upl_SplitQ);
}
/*********************************************************************/
static int ABSHttpMultipart(char *msg, int len, char boundary[])
{
 if(!upl_multipart)
 {
   upl_multipart = (int(*)())Fetch_func("ILMultipart");
 };
 if(upl_multipart)
  return(upl_multipart(msg,len,boundary));
 return(0);
}
/*********************************************************************/
static void ABSHttpUploadSplitQuery(char *msg, int len, char boundary[],void* args)
{
 if(!upl_SplitQ)
 {
   upl_SplitQ = (int(*)())Fetch_func("ILUploadSplitQuery");
 };
 if(upl_SplitQ)
  upl_SplitQ(msg,len, boundary,args);
}
/*********************************************************************/
static int decode_post(char url[], void* args, char  msg[], int len)
{
	 int content_len;
     char boundary[64];
	 char *p;


     copy_url(url, &msg[6]);

     if(!ABS_find_content_len(msg, len, &content_len))
        return(0); /* invalid message */


   if(IsUploadInitialized() && ABSHttpMultipart(msg, len, boundary))
   {
		 ABSHttpUploadSplitQuery(msg,len, boundary,args);
   }
   else
   { 
     /* find start of content */
   	   p = ABS_end_empty_line(msg); 
       if(!p)
			return(0);
	   Split_Query(p,content_len, args);
	}	

  return(1);
}
/*********************************************************************/
char* decode_get_url(char url[],char* start_url,void* args)
{
	 char *start_query;
	 int  query_len = 0;


     start_query = copy_url(url, start_url);
	 if((query_len = ABS_find_query_len(start_query)))
	 {
	     start_query++;
		 Split_Query(start_query,query_len, args);
	 }
	 return(start_query);
}
/*********************************************************************/
static void decode_get(char url[], void* args, char  msg[])
{
	 char *start_url;

	 start_url = find_start_url(msg);

	 decode_get_url(url,start_url,args);

}
/*********************************************************************/
int ABSHttpDecode( char url[], void* args, char  msg[], int len)
 {

     char *method;

	 method = ABS_get_method(msg);

	 if(!strcmp("GET", method))
		 decode_get(url, args, msg);
	 else if(!strcmp("POST", method))
		 decode_post(url, args, msg, len);
	 else
		return(0); /*error is not HTTP*/

	 return(1);

 }
/*********************************************************************/


#ifdef old_code
/*********************************************************************/
/*mauy be deleted													  */
/*********************************************************************/
static int ABS_linecount(char *msg)
{
  char line[256], *p;
  int i;

  p = ABS_getlne(line, msg);
  for(p = msg, i = 0 ; p ; i++,  p = ABS_getlne(line, p))
     ;
  return(i);
  
}
/*********************************************************************/
/* may be deleted														*/
/*********************************************************************/

int copy_query ( char *to, char *from)
{
   if(*from != '?')
   {
	   *to = 0;
	   return 0;
   }

   from++;
   copy_word(to, from);
   return(1);
}
#endif
