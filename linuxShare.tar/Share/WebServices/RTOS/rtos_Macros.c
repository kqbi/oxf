/******************************************************************************
*	file name   :	rtos_Macros.c 
*
*	purpose: Contain usage precompiled macros
*	portability:	Machine Independent
*
*
*	author(s):	Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/

/*******************************************************************************/

#ifdef VxWorks
#define MYOS "RPGetConnectedVxw"
#else
#ifdef WIN32
#define MYOS "RPGetConnectedWind"
#else
#ifdef Nucleus
#define MYOS "RPGetConnectedN"
#define UNIX
#else
#ifdef UNIX
#define MYOS "RPGetConnectedSol" 
#else
#ifdef General
#define MYOS "RPGetConnectedG"
#define UNIX
#else 
#define MYOS "none"
#endif
#endif
#endif
#endif
#endif

char *my_os()
{
  static char s[]= MYOS;
  
  return(s);

}

/********
char *my_machine()
{
static char s[]= T(MYMACHINE);
  
  return(s);

}

char *my_buildversion()
{
static char s[]= T(MYVERSION);
  
  return(s);

}

char *my_date()
{
static char s[]= T(MYDATE);
  
  return(s);

}

**********/
