/******************************************************************************
*	file name   :	abs_rtos_wrappers.c 
*
*	purpose: Wrappers OS dependent
*	portability:	???
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/


 
/*************************************************
* char *abs_rtos_get_server_name()
*
* returns either server name or ip address
*
*  Usefull for codebase 
**************************************************/
#include <stdio.h>
#include <string.h>
#ifdef VxWorks
/* #include "routeLib.h" */
#endif
/**************************************************/

static char server_name[20]= "None";

void abs_rtos_set_server_name(char *host_name)
{
    strcpy(server_name, host_name);
}
char *abs_rtos_get_server_name()
{

	return server_name;
}

int SetRoute(char* gateway)
{
/* For VxWorks it used to be but this seems to be obsolete
	fprintf(stderr,"gateway = 194.90.28.1\n");
	return(routeAdd("0.0.0.0",gateway));
*/
	return(0);
}
