/******************************************************************************

*	file name   :	Nucleus_Net.c 
*
*	purpose: Wrapers for network fanctions
*	portability:	Machine dependent
*
*
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
/*******************************************************************************/


#include <stdio.h> /* Used by RTOSULongToHost to do sprintf. */
#include <nucleus.h>
#include <externs.h>
#include <socketd.h> 

#define INET_IRQ            0	//5 
#define INET_IO_ADDR        0	//0x0300L 
#define INET_SUBMASK		{255,255,252,0}	// Subnet mask							
#define SYS_HEAP            1000000         // Total App Heap: 1MB (modify as needed)
#define OXF_STACKSIZE       100000          // "numain" Task Stack: 100K (Huge! modify as needed)

extern char __NOCACHE_END[];
extern char __NOCACHE_START[];
extern NU_MEMORY_POOL    Noncached_Memory;
extern NU_QUEUE          socketQueue;

extern int g_iWebFlag;

extern CHAR INET_SERVER_IP_ADDR[];

extern STATUS  PQUICC_Init(DV_DEVICE_ENTRY *device);
void NU_Delay ( void );

/************************************************************************/

/************************************************************************/

int RTOSGetLastError()
{
  int err;
  err = -1;
  return err; 
}

int RTOSSockPreInit()
{

	if(g_iWebFlag==0) //network not initialised
	{


		NU_DEVICE           devices[1];
		CHAR                subnet[] = INET_SUBMASK;
		VOID                *pointer;
		STATUS              status;
		unsigned long  nocacheSize = (((unsigned long)(__NOCACHE_END)) -
			((unsigned long)(__NOCACHE_START)));
 
		g_iWebFlag=1;

		//
		// Create Socket queue.
		//
		status = NU_Allocate_Memory(&System_Memory, &pointer, 10*sizeof(UNSIGNED),
			NU_NO_SUSPEND);
		if (status != NU_SUCCESS)
		{
			printf ("Cannot create memory for SocQueue.\n");
			NU_Terminate_Task( NU_Current_Task_Pointer() );      // Terminate the calling thread
		}
  
		status = NU_Create_Queue(&socketQueue, "SocQueue", pointer, 10, NU_FIXED_SIZE,
			1, NU_FIFO);
		if (status != NU_SUCCESS)
		{
			printf ("Cannot create Socket Queue.\n");
			NU_Terminate_Task( NU_Current_Task_Pointer() );      // Terminate the calling thread

		}
  
		//
		// Create a memory pool from the non-cached memory. 
		// This will be used by the TCP/IP stack and the Ethernet driver.
		//
	    status = NU_Create_Memory_Pool(&Noncached_Memory, "NOCACHE",
		(void*)(__NOCACHE_START), nocacheSize, 8, NU_FIFO);
  
		if (status != NU_SUCCESS)
		{
		    printf ("Cannot create the Non-Cached Memory Pool.\n");
			NU_Terminate_Task( NU_Current_Task_Pointer() );      // Terminate the calling thread
		}
  
		if (NU_Init_Net(&Noncached_Memory) != NU_SUCCESS)
		{
			printf("NU_Init_Net() failed in Application_Init.\n");
		    NU_Terminate_Task( NU_Current_Task_Pointer() );      // Terminate the calling thread

		}
  
		//
  		// Initialize the PowerQuicc ethernet controller
		//
		devices[0].dv_name = "PQUICC_0";
		devices[0].dv_hw.ether.dv_irq = INET_IRQ;
		devices[0].dv_hw.ether.dv_io_addr = INET_IO_ADDR;
		devices[0].dv_hw.ether.dv_shared_addr = 0;
		devices[0].dv_init = PQUICC_Init;
		devices[0].dv_flags = 0;
		memcpy (devices[0].dv_ip_addr, INET_SERVER_IP_ADDR, 4);
		memcpy (devices[0].dv_subnet_mask, subnet, 4);
  
		if (NU_Init_Devices(devices, 1) != NU_SUCCESS)
		{
			printf("NU_Init_Devices failed!\n");
			NU_Terminate_Task( NU_Current_Task_Pointer() );      // Terminate the calling thread
		}
  
	}

	return 1;
}

/************************************************************************/

int RTOSCreateSocket()

{
  /* Create a TCP/IP socket*/

	return(NU_Socket( NU_FAMILY_IP, NU_TYPE_STREAM, NU_NONE )); 
}

/************************************************************************/

void RTOSSetSockOpt(int sd)

{
}

/************************************************************************/

int RTOSBind(int sd,unsigned short port_number)
{

	struct addr_struct local_sin; 
	memset(&local_sin, 0, sizeof(local_sin));
  	local_sin.family = NU_FAMILY_IP; 
    local_sin.port=port_number;
	*(UINT32 *)local_sin.id.is_ip_addrs= IP_ADDR_ANY;
	local_sin.name       = "TCP_Echo";

    return(NU_Bind(sd,&local_sin,0));
}

/************************************************************************/

int RTOSListen(int sd,int num_of_connects)

{
  /* Establish a socket to listen for incoming connections.*/
	return(NU_Listen (sd, num_of_connects));
}

/************************************************************************/

int RTOSAccept(int sd)

{

  int ClientSock;
  struct addr_struct accept_sin; 
  int accept_sin_len;             /* Length of accept_sin */
  accept_sin_len = sizeof (accept_sin);

  /* Accept an incoming connection attempt on socket.*/

  ClientSock=NU_Accept(sd,&accept_sin,0);
  NU_Delay();
  return(ClientSock);

  //return(NU_Accept(sd,&accept_sin,0));
}

/************************************************************************/

int RTOSCloseSocket(int sd)

{
	return(NU_Close_Socket (sd));
}

/************************************************************************/

int RTOSRecv(int sd,char* msg,int len, int flags)
{
	return(NU_Recv(sd, msg, len, 0));
}

/************************************************************************/

int RTOSSend(int sd, char* data,int len,int flags)

{      
    return((NU_Send (sd, data, len, 0) != -1));
}

/************************************************************************/

int RTOSGetCurrentClientIP(int sd)

{
    struct addr_struct cl_addr; 

	int	 cl_addr_len;
	int err = 0;
	long dig_IP;

	cl_addr_len = sizeof (cl_addr);

	err = NU_Get_Peer_Name(sd,&cl_addr,(int*)&cl_addr_len);

	dig_IP = IP_ADDR(cl_addr.id.is_ip_addrs);
	return(dig_IP);
}

/************************************************************************/

void RTOSULongToHost(unsigned long IP,char host[])
{
/* The following implementation is based upon the description provided at
 * http://www.microsoft.com/windows2000/en/server/help/default.asp?url=/windows2000/en/server/help/sag_TCPIP_add_BinaryToDecimal.htm
 */
	sprintf(host, "%d.%d.%d.%d",
		(int)((IP>>24) & (unsigned long)255),
		(int)((IP>>16) & (unsigned long)255),
		(int)((IP>>8) & (unsigned long)255),
		(int)(IP & (unsigned long)255)
		);
}



void NU_Delay ( void )
{
	NU_Sleep(10);
}
