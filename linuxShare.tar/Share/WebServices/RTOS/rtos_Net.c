/******************************************************************************
*	file name   :	rtos_Net.c 
*
*	purpose: Wrapers for network fanctions
*	portability:	Machine dependent
*
*	author(s):	Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/

/*******************************************************************************/

#include <stdio.h> /* Used by RTOSULongToHost to do sprintf. */
#include <string.h>

#ifdef VxWorks

/* test the network stack implementation according to vxworks version */
#include <version.h>
#ifdef _WRS_VXWORKS_MAJOR
#if (_WRS_VXWORKS_MAJOR == 6) && (_WRS_VXWORKS_MINOR < 5)
#define BSD_NETWORK_STACK
#endif /* (_WRS_VXWORKS_MAJOR == 6) && (_WRS_VXWORKS_MINOR < 5) */
#else /* _WRS_VXWORKS_MAJOR */
#define BSD_NETWORK_STACK /* Tornado */
#endif

#ifdef _WRS_KERNEL
#include <socket.h>
#include <rpc/rpc.h>
#include <in.h>
#else
#include <sys/socket.h>
#endif /* _WRS_KERNEL */

#include <sys/types.h>
#include <ioLib.h>
#include <sockLib.h>
#include <inetLib.h>
#include <errnoLib.h>
#endif

#ifdef WIN32
#include <windows.h> 
#include <winsock.h>
#endif

#ifdef UNIX
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#endif

#ifdef INTEGRITY
#include "INTEGRITY.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#endif

#define TCP 0
/************************************************************************/
/************************************************************************/
int RTOSGetLastError()
{
  int err = -1;
#ifdef WIN32
  err = WSAGetLastError();
#endif

#ifdef VxWorks
 /* return(errno);*/                      /*check it*/
  err = errnoGet();
#endif

#ifdef INTEGRITY
  err = errno;
#endif
	return err; 
}
/**************** Windows Specific: Init windows socket *************/

int RTOSSockPreInit()
{
#ifdef WIN32
     WSADATA WSAData;                 /* Contains details of the Windows */
                                      /* Sockets implementation */

  /* Initiate Windows Sockets. */
  if (WSAStartup (MAKEWORD(1,1), &WSAData) != 0) 
    return 0;
#endif
  return 1;
}
/************************************************************************/
int RTOSCreateSocket()
{
  /* Create a TCP/IP socket*/
   return (int)socket (AF_INET, SOCK_STREAM, TCP);
}
/************************************************************************/
void RTOSSetSockOpt(int sd)
{
  int rc = 1;
/*
  optval.l_onoff = 0;
  optval.l_linger = 0;

  setsockopt (sd, SOL_SOCKET, SO_LINGER, &optval, sizeof (optval));
*/
  setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, (char *)&rc, sizeof(rc));
}
/************************************************************************/
int RTOSBind(int sd,unsigned short port_number)
{
  struct sockaddr_in	 local_sin;    /* Local socket address */

  /* Fill out the local socket's address information.*/
  memset(&local_sin, 0, sizeof(local_sin));
  local_sin.sin_family = AF_INET;
  local_sin.sin_port = htons (port_number);  
  local_sin.sin_addr.s_addr = htonl (INADDR_ANY);



  /* Associate the local address with socket*/
  return(bind(sd,(struct sockaddr *) &local_sin,sizeof (local_sin)));
}
/************************************************************************/
int RTOSListen(int sd,int num_of_connects)
{
  /* Establish a socket to listen for incoming connections.*/
  return(listen (sd, num_of_connects));
}
/************************************************************************/
int RTOSAccept(int sd)
{
  struct sockaddr_in	 accept_sin;     /* Receives the address of the */
                                      /* connecting entity */
  int accept_sin_len;                 /* Length of accept_sin */

  accept_sin_len = sizeof (accept_sin);
  
  /* Accept an incoming connection attempt on socket.*/
  return(int)accept (sd,(struct sockaddr *) &accept_sin,(void *) &accept_sin_len);
}
/************************************************************************/
int RTOSCloseSocket(int sd)
{
#ifndef WIN32
 /*---->>>> Patch by Greg from Windriver support info.*/
 /*---->>>> This prevents an accumulation of system 'clusters' due to closed
 **         socket resources remaining for 60s after closure.
 **         Such an accumulation was work-roundable via tweaking vxworks conf NUM_SYS_64/128/256/512.
 **         Such an accumulation can be monitored using 'netStackSysPoolShow' from vxWorks shell.
 **         With this patch the clusters reduced from hundreds to about 30.
 **         GJI 13/04/06
 **
 **	   According to WindRiver support, the following patch relates only to BSD  network stack.
 **	  The BSD  stack was replaced by ipnet stack on VxWorks 6.5. The patch causes a loss of information on ipnet stack.
 **	  11/12/07
 */
 #ifdef VxWorks
 #ifdef BSD_NETWORK_STACK  
  int off = 0;
  struct linger ling = { 1, 0 };
  /* shut off linger and keepalive */
  setsockopt(sd, SOL_SOCKET, SO_LINGER, (void *)&ling, sizeof (ling));
  setsockopt(sd, SOL_SOCKET, SO_KEEPALIVE, (char *)&off, sizeof(off));

  /* Now that we have said we do not want to keep the PCBs around
   * for 60 seconds (which is what happens if SO_LINGER is enabled
   * in vxWorks), we need to call shutdown to gracefully terminate
   * the connection without loosing any data.... */
  shutdown( sd, 2 );
 #endif /* BSD_NETWORK_STACK  */
 #endif /* VxWorks */
 /*----<<<<*/
  return(close (sd));
#else /* ifndef WIN32 */  
  return(closesocket (sd));
#endif /* ifndef WIN32 */
}
/************************************************************************/
int RTOSRecv(int sd,char* msg,int len, int flags)
{
   return(recv(sd, msg, len, 0));
}
/************************************************************************/
int RTOSSend(int sd, char* data,int len,int flags)
{      
    return((send (sd, data, len, 0) != -1));
}
/************************************************************************/
int RTOSGetCurrentClientIP(int sd)
{
	struct sockaddr_in	 cl_addr;
	int	   cl_addr_len;
	long dig_IP;

	cl_addr_len = sizeof (cl_addr);

	getpeername(sd,(struct sockaddr *) &cl_addr,(void*)&cl_addr_len);
#ifdef WIN32
	dig_IP = cl_addr.sin_addr.S_un.S_addr;
#else
	dig_IP = cl_addr.sin_addr.s_addr;
#endif
	return(dig_IP);
}
/************************************************************************/
void RTOSULongToHost(unsigned long IP,char host[])
{
/* The following implementation is based upon the description provided at
 * http://www.microsoft.com/windows2000/en/server/help/default.asp?url=/windows2000/en/server/help/sag_TCPIP_add_BinaryToDecimal.htm
 */
	sprintf(host, "%d.%d.%d.%d",
		(int)((IP>>24) & (unsigned long)255),
		(int)((IP>>16) & (unsigned long)255),
		(int)((IP>>8) & (unsigned long)255),
		(int)(IP & (unsigned long)255)
		);
}
