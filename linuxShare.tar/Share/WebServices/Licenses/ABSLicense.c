/******************************************************************************
*	file name   :	ABSLicense.c 
*
*	purpose: Contains access to MIB DB
*	portability:	Machine Independent
*
*
*	author(s):	Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
extern void ST_AddIP(long userIP);
extern int OSIsLicensed(long client_addr);


int IsValidIP(long cl_ip)
{
   if(OSIsLicensed(cl_ip)){
	 ST_AddIP(cl_ip);
     return(1);
   }
   return(0);
}  
