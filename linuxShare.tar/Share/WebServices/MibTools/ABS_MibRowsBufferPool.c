/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

#define DEFAULT_BUFFER_SIZE 11400

extern int set_mib_rows_buffer_pool(void* buffer, int buffer_size);

static char default_mib_table[DEFAULT_BUFFER_SIZE]={0};

void set_mib_default_size()
{
	set_mib_rows_buffer_pool((void*)default_mib_table, DEFAULT_BUFFER_SIZE);
}
