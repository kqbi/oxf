/******************************************************************************
*	file name   :	ABS_Mib.c 
*
*	purpose: Contains access to MIB DB
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/

/*******************************************************************************/


#include <stdlib.h>
#include <string.h>
#include <stdio.h>
/*******************************************************************************/


char *string_dup();
extern void *alloc_memory();
extern double Mib_intf_get_double(void *pObj);
extern void Mib_intf_set_double(double val,void *pObj);
extern int type2metatype(char **metatype, int type_id);
extern int Mib_intf_get_int(void *pObj);
extern long Mib_intf_get_long(void *pObj);
extern char *ValType2Str(int type_id, int val);
extern char Mib_intf_get_char(void *pObj);
extern char* Mib_intf_get_string(void *pObj);
extern void Mib_intf_set_int(int val,void *pObj);
extern void Mib_intf_set_string(char* val,void *pObj);
extern void Mib_intf_set_double(double val,void *pObj);
extern void Mib_intf_set_void(void *pObj);
extern void Mib_intf_set_char(char val,void *pObj);
extern void Mib_intf_set_long(long val,void *pObj);
extern int Mib_intf_get_permission(void *pObj);
extern int CRF_IsChild(int id);
extern char **alloc_strings_array(int len);
extern int CRF_GetChilds(int id,int out_childs[],int max_childs);
extern void* Fetch_func(char* name);
extern int ValueOfType(int type_id, char *choice_str);
extern void CRF_DeleteChilds(int id);
extern char *string_dup_esc_backslash(char *s);
extern void Mib_intf_set_ulong (unsigned long val, void *pObj);
extern unsigned long Mib_intf_get_ulong(void *pObj);
extern int set_mib_default_size();

int absmib_get_id_by_name(char* name);
int absmib_modify_row(int id,char *name,int type,void* pObj);





#define ROW_ACTIVE  0 
#define ROW_BUSY    1
#define ROW_DELETED 2
#define MAX_NAME_LEN 64
#define MAX_VALUE_LEN 256
#define MAX_ROWS 400

enum {NOACCESS_PERMISSION=0, READ_PERMISSION=1, WRITE_PERMISSION=2, READ_WRITE_PERMISSION=3};

typedef struct {
	char name[MAX_NAME_LEN];
	int  type_id;       
	unsigned short mib_id;
	unsigned short mib_status;/* ROW_ACTIVE,ROW_BUSY,ROW_DELETED*/
	void* pObj;
} MIB_Row;


typedef struct {
    char *name;
	int (*get)();
	void (*set)();
} Name_Set_Get;

/* DB Tables */

static MIB_Row* mib_table = NULL;
static int mib_tableSize = 0;
static int mib_rows = 0;


static Name_Set_Get mib_GetSet[30]={
	{0,0,0}
};

/*******************************************************************************/
/*Access functions to  Device Name and Flat root name */
static char DevName[50];

static int user_def_flag = 0;

void SetDeviceName(char *name)
{
	if(!user_def_flag)
		strcpy(DevName,name);
}
/*******************************************************************************/
void SetDeviceTitle(char *name)
{
	user_def_flag = 1;
	strcpy(DevName,name);
}
/*******************************************************************************/

char* GetDeviceName()
{
	return(DevName);
}

char *GetFlatRootName()
{
	static char FlatRootName[] = "root";
	return FlatRootName;
}
/*******************************************************************************/

/****************************************************/
int FindSetGet(char *name, int (**get)(),void  (**set)())
{
	Name_Set_Get *p;
	for (p = &mib_GetSet[0]; p->name && strcmp(name, p->name); p++);
	if(p->name)
	{
		if(get) *get = p->get;
		if(set) *set = p->set;
		return(1); /* found */
	}
	else
		return (0);  /* not found */
}
/*******************************************************************************/
static Name_Set_Get *NewSetGet()
{
	Name_Set_Get *p;
	for (p = &mib_GetSet[0]; p->name ; p++);
	return(p);
}
/*******************************************************************************/

int Add_SetGet(char *name, int (*get)(),void  (*set)())
{
	Name_Set_Get *p;
	
	if(FindSetGet(name, 0, 0))
		return(1); /* already exists */
	p = NewSetGet();
	p->name = name;
	p->get = get;
	p->set =set;
	
	p++;
	p->name = 0;
	return(1);
}
/*******************************************************************************/
/*******************************************************************************/
static MIB_Row *get_new_row()
{
    return(&mib_table[mib_rows]);
}
/****************************************/
static int generate_new_id()
{
	if(mib_rows < mib_tableSize)
		return(mib_rows++);
	else
		return(-1);
}

static int find_deleted_row()
{
	int i;

	for(i = 0; i < mib_rows; i++)
		if((mib_table[i].mib_status == ROW_DELETED))
			return(i);
		return(-1);
}


/****************************************/
static MIB_Row *get_row_by_id(int id)
{
	return(&mib_table[id]);
}
/****************************************/
static void mib_insert_name(MIB_Row *p_row,char* name)
{
	strncpy(p_row->name,name,MAX_NAME_LEN);
	p_row->name[MAX_NAME_LEN - 1] = 0; 
}
/****************************************/
static int is_valid_id(int id)
{
	if((id<0) || (id>mib_rows) || (id>mib_tableSize))
		return(0);
	return(1);
}
/****************************************/
static MIB_Row *get_valid_row_by_id(int id)
{
	MIB_Row *p_row;
	
	if(!is_valid_id(id))
		return(0);
	p_row = get_row_by_id(id);
	
	if(p_row->mib_status == ROW_DELETED)
		return(0); 
	return(p_row);
}
/*******************************************************************************/
/**
@return error code.If return value is -1 the id is not finded.
return data is must be freed.
@arg char** value(output): 0 for elements with follow types:
" aggr,spaggr,unari,view " or for write only elements
*/
static int mib_get_value_by_id(int id,char** value) 
{
	MIB_Row *p_row;
	char* metatype;
	double test_double;
	char value_buff[MAX_VALUE_LEN];
	
	if(!value)
		return(-1);
	
	if(!(p_row = get_valid_row_by_id(id)))
		return(-1);
	
	if(!(Mib_intf_get_permission(p_row->pObj) & READ_PERMISSION)){
		*value = 0;
		
		return(id);
	}
	
	type2metatype(&metatype, p_row->type_id);
	if(!strcmp(metatype, "int")){
		sprintf(value_buff, "%d", Mib_intf_get_int(p_row->pObj));
		*value = string_dup(value_buff);
	}
	else if(!strcmp(metatype, "aggr") || !strcmp(metatype, "spaggr") 
		|| !strcmp(metatype, "view") || !strcmp(metatype, "unari")){
		*value = 0;
	}
	else if(!strcmp(metatype, "string")){
		*value = string_dup_esc_backslash(Mib_intf_get_string(p_row->pObj));
	}
	else if(!strcmp(metatype, "char")){
		sprintf(value_buff, "%c", Mib_intf_get_char(p_row->pObj));
		*value = string_dup_esc_backslash(value_buff);
	}
	else if(!strcmp(metatype, "double"))	{
		test_double = Mib_intf_get_double(p_row->pObj);
		sprintf(value_buff,"%g",test_double);
		*value = string_dup(value_buff);
	}
    else if(!strcmp(metatype, "long")){
		sprintf(value_buff, "%ld", Mib_intf_get_long(p_row->pObj));
		*value = string_dup(value_buff);
	}
	else if (!strcmp(metatype,"unsigned long")) {
		sprintf(value_buff, "%lu", Mib_intf_get_ulong(p_row->pObj));
		*value = string_dup(value_buff);
	}
	else{
		strncpy(value_buff, ValType2Str(p_row->type_id, Mib_intf_get_int(p_row->pObj)),MAX_VALUE_LEN); 
		value_buff[MAX_VALUE_LEN - 1] = 0;
		*value = string_dup(value_buff);
	}
	
	
	return(id);
	
}
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
int absmib_is_valid_id(int id)
{
	return(is_valid_id(id));
}
int absmib_insert_row(char *name,int type,void* pObj)
{
	MIB_Row *p_row;
	int id;
	
	if((id = absmib_get_id_by_name(name)) == -1)
	{
		p_row = get_new_row();	
		id = generate_new_id();
		if(!is_valid_id(id))
		{
			id = find_deleted_row();
			if(!is_valid_id(id))
				return(-1);
			else
				p_row = get_row_by_id(id);
		}

		p_row->mib_id = id;
		mib_insert_name(p_row,name);
		p_row->type_id = type;
		p_row->pObj = pObj;
		p_row->mib_status = ROW_ACTIVE;
		return(p_row->mib_id);
	}
	else
		return(absmib_modify_row(id,name,type,pObj));
}
/*******************************************************************************/
int absmib_modify_row(int id,char *name,int type,void* pObj)
{
	MIB_Row *p_row;
	char* new_metatype;
	
	type2metatype(&new_metatype, type);
	if(!strcmp(new_metatype,"undefined"))
		return(id);
	
	p_row = get_row_by_id(id);
	if(!strcmp(new_metatype,"view") && (p_row->type_id != type))  /*modification of any type to view type is not permitted*/
		return(id);
	
	CRF_DeleteChilds(id);
	
	p_row->type_id = type;
	p_row->pObj = pObj;
	return(id);
}
/*******************************************************************************/
void absmib_delete_row(int id)
{
	MIB_Row *p_row;
	if(is_valid_id(id))
	{
		p_row = get_row_by_id(id);
		p_row->mib_status = ROW_DELETED;
	}

}
/*******************************************************************************/
int absmib_get_id_by_name(char* name)
{
	int i;
	for(i = 0; i < mib_rows; i++)
		if(!strcmp(mib_table[i].name, name) && (mib_table[i].mib_status == ROW_ACTIVE))
			return(i);
		return(-1);
}
/*******************************************************************************/
int absmib_get_name_by_id(int id,char** namep)
{
	MIB_Row *p_row;
	
	if((p_row = get_valid_row_by_id(id)) && namep){
		*namep = string_dup(p_row->name);
		return(id);
	}
	return(-1);	
}
/*******************************************************************************/
int absmib_get_type_by_id(int id,int* type_id)
{
	MIB_Row *p_row;
	if(!(p_row = get_valid_row_by_id(id)))
		return(-1);
	if(type_id) *type_id = p_row->type_id;
	return(id);
}
/*******************************************************************************/
/**
@return error code.If return value is -1 the id is not finded.
return data is must be freed.
*/
int absmib_get_value_by_id(int id,char** value)
{
	int sts = mib_get_value_by_id(id,value);
	if(*value == 0)
		*value = string_dup("");
    return(sts);
}
/*******************************************************************************/
int absmib_get_value_by_name(char *name,char** value)
{
	int id;
	if((id = absmib_get_id_by_name(name))<0)
		return(-1);
	else
		return(absmib_get_value_by_id(id,value));
}
/*******************************************************************************/
int absmib_get_value_type_by_name(char *name,char** value,int* type_id)
{
    int id;
	if((id = absmib_get_value_by_name(name,value)) >= 0)
		absmib_get_type_by_id(id,type_id);
    return(id);
}
/*******************************************************************************/
int absmib_get_type_by_name(char *name,int* type_id)
{
    int id;
	if((id = absmib_get_id_by_name(name))<0)
		return(-1);
	   absmib_get_type_by_id(id,type_id);
	   return(id);
}
/*******************************************************************************/

/**
@param id id of element
@param valuep value string
@return error code:if seccessful 0 else -1
*/
int absmib_set_value_by_id(int id,char* valuep)
{
	MIB_Row *p_row;
	char *metatype;
	
	if(!is_valid_id(id))
		return(-1);
	
	if(!(p_row = get_valid_row_by_id(id)))
		return(-1);
	
	
	type2metatype(&metatype, p_row->type_id);
	
	if(!strcmp(metatype, "int")){
		Mib_intf_set_int(atoi(valuep), p_row->pObj);
	}
	else if(!strcmp(metatype, "unari")){
		Mib_intf_set_void(p_row->pObj);
	}
	else if(!strcmp(metatype, "long")){
		Mib_intf_set_long(atol(valuep),p_row->pObj);
	}
	else if (!strcmp(metatype, "unsigned long")) {
		Mib_intf_set_ulong(strtoul(valuep, NULL, 0), p_row->pObj);
	}
	else if(!strcmp(metatype, "char")){
		Mib_intf_set_char(*valuep,p_row->pObj);
	}
	else if(!strcmp(metatype, "string")){
		Mib_intf_set_string(valuep,p_row->pObj);
	}
	else if(!strcmp(metatype, "double")){
		Mib_intf_set_double(atof(valuep),p_row->pObj);
	}
	else if(!strcmp(metatype, "choice") || !strcmp(metatype, "bool")){
		Mib_intf_set_int(ValueOfType(p_row->type_id,valuep),p_row->pObj);
	}
	else Mib_intf_set_int(atoi(valuep),p_row->pObj); /*chioselist, bool, e.t.c*/
	return(0);
}
/*******************************************************************************/
int absmib_get_permission(int id)
{
	MIB_Row *p_row;
	p_row = get_row_by_id(id);
	
	return(Mib_intf_get_permission(p_row->pObj));
}

/*******************************************************************************/
int absmib_get_root_sons_ids(int out_childs[],int max_childs)
{
	int i,j = 0;
	char* metatype;
	
	for(i = 0; i < mib_rows; i++){
		type2metatype(&metatype, mib_table[i].type_id);
		if((mib_table[i].mib_status == ROW_ACTIVE) && (!CRF_IsChild(mib_table[i].mib_id)) && strcmp(metatype, "spaggr") ){
			if(j < max_childs)
				out_childs[j++] = mib_table[i].mib_id;
			else
				return(max_childs);
		}
	}
	return(j);
}
/*******************************************************************************/
int absmib_get_flat_root_sons_ids(int out_childs[],int max_childs)
{
	int i,j = 0;
	char* metatype;
	
	for(i = 0; i < mib_rows; i++){
		type2metatype(&metatype, mib_table[i].type_id);
		if((mib_table[i].mib_status == ROW_ACTIVE) && strcmp(metatype, "spaggr")){
			if(j < max_childs)
				out_childs[j++] = mib_table[i].mib_id;
			else
				return(max_childs);
		}
	}
	return(j);
}
/*******************************************************************************/
int Agg_GetChilds(int id,int out_childs[],int max_childs)
{
	char* metatype;
	int (*get_childs)() = 0;
	MIB_Row * p_row = get_row_by_id(id);
	
	type2metatype(&metatype, p_row->type_id);
	if(!strcmp(metatype, "spaggr")){
		if(!get_childs)
		{
			get_childs = (int(*)())Fetch_func(p_row->name);
		};
		if(get_childs)
			return(get_childs(out_childs,max_childs));
		return(0);
	}
	else
		return(CRF_GetChilds(id,out_childs,max_childs));
}
/*******************************************************************************/
/**
* This function gets the aggregates' children by the id.
*
* @param id       the mib id of the aggregate
* @param children the children of the aggregate
* @return count   the number of children
*/
int ABS_GetAggregateSons (int papaId, char ***children)
{
	int count = 0,i;
	char **tmpStr;
	int tmpChild[MAX_ROWS];
	
	count = Agg_GetChilds(papaId,tmpChild,MAX_ROWS);
	
	*children = alloc_strings_array(count);                /*memory for cells in array allocated in side */
	/*memory is freed in function App_ShowAgg */
	tmpStr = *children;
	
	for(i = 0; i < count;i++,tmpStr++)
	{
		absmib_get_name_by_id(tmpChild[i],tmpStr);
	}
	
	return count;
}

/*******************************************************************************/
int absmib_get_all(char ***elements)
{
	return(ABS_GetAggregateSons(absmib_get_id_by_name(GetFlatRootName()), elements));
	
}

/*******************************************************************************/
void absmib_update_relations()
{
	static void(*f_update_relation)() = 0;
	static unsigned short(*f_get_relation_version)() = 0;
	static int r_version = 0;
	int temp_version;
	int i;
	char* metatype;
	
	
   	if(!f_get_relation_version)
	{
		f_get_relation_version = (unsigned short(*)())Fetch_func("ILGetRelationsStateVersion");
	};
	if(!f_get_relation_version)
		return;
	temp_version = f_get_relation_version();
	
	if(temp_version!=r_version)
	{
		if(!f_update_relation)
		{
			f_update_relation =(void(*)()) Fetch_func("ILUpdateRelations");
		};
		if(f_update_relation)
		{
			for(i = 0; i < mib_rows; i++)
				if(mib_table[i].mib_status == ROW_ACTIVE){
					type2metatype(&metatype, mib_table[i].type_id);
					if(!strcmp(metatype, "aggr") && mib_table[i].pObj){
						f_update_relation(mib_table[i].pObj);
					}
				} 
		}
		r_version = temp_version;
	}
}
/*******************************************************************************/
void mib_init()
{
	set_mib_default_size();
}
/*******************************************************************************/
int set_mib_rows_buffer_pool(void* buffer, int buffer_size)
{
	mib_tableSize = buffer_size/sizeof(MIB_Row);
	if ((buffer == NULL) || (buffer_size <= 0))
	{
		return 0;
	}
	mib_table = (MIB_Row*)buffer;
	if (mib_tableSize > MAX_ROWS)
	{
		mib_tableSize = MAX_ROWS;
	}
	return mib_tableSize;
}
