/******************************************************************************
*	file name   :	ABS_MibTypes.c 
*
*	purpose: Habdle Mib Types definitions
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/ 
#include <stdio.h>
#include <string.h>
/*******************************************************************************/

extern char *string_dup(char *s);
int ABS_Register_Simple_Type(char *metatype);

/*******************************************************************************/

static int RegPermission = 0;

void SetRegPermission(int permission)
{
	RegPermission = permission;
}

int IsRegPermission()
{return(!RegPermission);}

void RegisterPredefineTypes()
{
	static char *types[]={
     "spaggr",
	 "undefined",
	 "aggr",
	 "view",
	 "int",
	 "char",
	 "long",
	 "double",
	 "string",
	 "unsigned long",
	 "unari"
	};
    int i;

	for(i = 0 ; i <sizeof(types)/sizeof(types[0]);i++)
        ABS_Register_Simple_Type(types[i]);



}

typedef struct {
   int value;
   char *choice_name;
}  ABS_Choice;


typedef struct {
   int id;
   char *meta_type;         /* "int", "bool" "choice" "int_range" */ 
                            /* choice list is relevant only with meta == choice */
   ABS_Choice *choicelist;  /* List of choices  such as "YES"/"NO"/...*/
   int choice_len;          /* number of choices */

   int min;                 /* min/max relevant only with meta=int_range */
   int max;

} Types_Dict;

/*******************************************************************************/
#define ARRSize(x) (sizeof(x)/sizeof(x[0]))
#define MAX_NUMBER_OF_TYPES 50

void *key_name_tbl = 0;
static  Types_Dict global_tbl[MAX_NUMBER_OF_TYPES]={ {0} };

extern void *alloc_memory();
extern char *TypeId2Name(int );

/*******************************************************************************/

static void ABS_Get_Mib_Types( Types_Dict  **types, int *lenp)
{
   int i;
   *types = global_tbl;
   for(i=0; global_tbl[i].meta_type;i++);
   *lenp = i;
}
/*******************************************************************************/

int Same_type_definition(char *metatype, char **names, int names_len, Types_Dict *p)
{

	int i;

	if(strcmp(metatype, p->meta_type))
		return(0);
	if(names_len != p->choice_len)
		return(0);
	
	for (i = 0; i < names_len; i++)
	{
		if (strcmp(names[i], p->choicelist[i].choice_name))
			return 0;
	}
	return(1);
	
}

		   
		   
/************* ******************************************************************/

static int Type_Add_type_definition(char *metatype, char **names)
{
   Types_Dict *p;
   ABS_Choice *new_choice_list;
   int names_len, i;
   static int key_index = 0;


   names_len = 0;
   if(names)
      for(names_len = 0; names[names_len]; names_len++);

   for(p = &global_tbl[0]; p->meta_type; p++)
   {
	   if(Same_type_definition(metatype, names, names_len, p))
			return(p->id);
   }


   if(p > (&global_tbl[0] + MAX_NUMBER_OF_TYPES*sizeof(Types_Dict)));

   memset(p, 0,sizeof(Types_Dict));
   p->id = ++key_index;
   p->meta_type = metatype;
   if(names)
   {
      p->choice_len = names_len;
      new_choice_list = alloc_memory(sizeof(ABS_Choice) * names_len);
      for(i = 0; i < names_len; i++)
      {   /* copy */
         new_choice_list[i].choice_name = names[i];
         new_choice_list[i].value = i;
      }
      p->choicelist = new_choice_list;
   }
  return(key_index);

}
/*******************************************************************************/
int ABS_Register_Simple_Type(char *metatype)
{
 Types_Dict *p;
 int i;

   for(p = &global_tbl[0],i = 1; p->meta_type; p++,i++)
      if(!strcmp(p->meta_type,metatype))
		  return(i);
	return(Type_Add_type_definition(metatype,0));
}
/*******************************************************************************/
int Register_Complex_Type(char *metatype, char **names)
{
    return(Type_Add_type_definition(metatype, names));
}
/*******************************************************************************/
static Types_Dict *ABS_Types_Table(int *lenp)
{
   static Types_Dict *_types_tbl = 0;
   static int types_len = 0;
  
   /*if(!_types_tbl)*/
      ABS_Get_Mib_Types(&_types_tbl, &types_len);

   *lenp = types_len;
   return(_types_tbl);
}
/*******************************************************************************/
int type2metatype(char **metatype, int type_id)
{
  int len, i;
  Types_Dict *types_dict;
  types_dict = ABS_Types_Table(&len);

  for(i = 0 ; i < len; i++)
	  if(type_id == types_dict[i].id)
	  {
		  *metatype = types_dict[i].meta_type;
		  return(1);
	  }
  *metatype = "int"; /* Not found we return default type (int)*/
  return(0);
}
/*******************************************************************************/
char *ValType2Str(int type_id, int val)
{
    int len, i;
  Types_Dict *types_dict;
  char *p = "";
  types_dict = ABS_Types_Table(&len);
  for(i = 0 ; i < len; i++)
	  if(type_id == types_dict[i].id)
         break;
  if(i >= len)
	  return(p);
  types_dict = &types_dict[i];
  for(i = 0 ; i < types_dict->choice_len; i++)
	   if(val == types_dict->choicelist[i].value)
      {
         p = types_dict->choicelist[i].choice_name;
         break;
      }
  return(p);
}

/******************************************************************************
*  Function: ABS_GetChoiceList(char *typename, char *list[])
*  Params: char *typename - identification input
*          char *listp[] - Assign choicelist names into arry.
* 
*  Attention: Prealocated array of pointers sufficient enough
*             to hold the list. Listp[] items will be const so
*             no need to alloc and free.
*
******************************************************************************
*/
int ABS_GetChoiceList_by_typeId(int key,char *listp[])
{
   Types_Dict *typep;
   int len, i;

   if(!key)
   {
	   listp[0] =0;
        return(0);
   }
   for(typep = ABS_Types_Table(&len),i = 0; 
          i < len && (typep->id != key) ; 
		  i++,typep++)
	;
    if(i == len)
	{
		listp[0] = 0;
        return(0);
	}

   for(i= 0 ; i < typep->choice_len; i++)
	   listp[i] = typep->choicelist[i].choice_name;
   listp[i] = 0;
   return(1);

}

/*******************************************not using**************************/
int ValueOfType(int type_id, char *choice_str)
{

  int len, i;
  Types_Dict *types_dict;
  types_dict = ABS_Types_Table(&len);

  for(i = 0 ; i < len; i++)
	  if(type_id == types_dict[i].id)
         break;
  if(i >= len)
	  return(-1);

  types_dict = &types_dict[i];
  for(i = 0 ; i < types_dict->choice_len; i++)
  {
	   if(!strcmp(choice_str, types_dict->choicelist[i].choice_name))
		   return(types_dict->choicelist[i].value);
  }

  return(-1);

}
/*****************************************************************/

/*************************************************************\
*  Design of tables
*  ----------------
* each type has the following attributes:       
* int  id
* char *name
* int metatype
* int min   only in case of metatype == int_range 
* int max   only in case of metatype == int_range 
* List choiceList - list of names
* List of corresponding values to the choicelist

  This will be implemented through the following tables:

  1. name = "TypeDef"
     id ,       name,     metatype    (int, char *, const *str)
     Unique     Unique,   Multiple
  2. name = "ChoiceList"
     id,        choice_name, value     (int, char *, int)
     Multiple   Multiple,    Multipe
  3. name=  "RangeList"
     id,        min,      max         (int, int, int)
     Unique     Multiple, Multiple

  How it will be inserted ?
  one table:
  type_name,     metatype_name      (char *, char *)
  
  second table (For choices:)
  type_name,     choice_name, value       (char *, char *, int)

  third table: (For int_range)
  type_name,     min,         max




*************************************************************/
