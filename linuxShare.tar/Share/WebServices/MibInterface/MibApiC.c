/******************************************************************************
*	file name   :	MibApiC.c 
*
*	purpose: Standard Api. Registration by "name" , "seter" and "geter"
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green 
*	date started:	22-Jan-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
extern char *generate_type_name();
extern int ABS_Register_Simple_Type(char *metatype);
extern int Register_Complex_Type(char *metatype, char **names);
extern int Add_SetGet(char *name, void **,void  (*set)());
extern int absmib_insert_row(char *name,int type,void* pObj);
extern int absmib_get_id_by_name(char* name);
extern void CRF_DeleteChilds(int id);
extern int Register_Mib_Aggregate_Row(char *name,void* pAdapter);


/*************************************************************************************/
int Register_Mib_Choice_Row(char *name,  char *permis,
                        char* (*get)(),void  (*set)(),
						char **choices)
{
int  type_key;

  type_key = Register_Complex_Type("choice", choices);
  if(set || get)
      Add_SetGet(name, (void**)get,set);
  return(absmib_insert_row(name, type_key,name));/*for C interface void* pObj = char* name*/
}
/*************************************************************************************/
unsigned short C_RegisterCWebChoiceList(char* NameOfComp,char* (*get)(), void  (*set)(),char** choices)
{
  return(Register_Mib_Choice_Row(NameOfComp,"rw",get,set,choices));
}
/*************************************************************************************/
int Register_Mib_Int_Row(char *name, char *permis, int (*get)(), void  (*set)())
{
  int key_int;
  key_int = ABS_Register_Simple_Type("int");

  Add_SetGet(name, (void**)get,set);
  return(absmib_insert_row(name,key_int,name));/*for C interface void* pObj = char* name*/
}
/*************************************************************************************/
int Register_Mib_Char_Row(char *name, char *permis, char (*get)(), void  (*set)())
{
  int key_char;
  key_char = ABS_Register_Simple_Type("char");

  Add_SetGet(name, (void**)get,set);
  return(absmib_insert_row(name,key_char,name));/*for C interface void* pObj = char* name*/
}
/*************************************************************************************/
int Register_Mib_Long_Row(char *name, char *permis, long (*get)(), void  (*set)())
{
  int key_long;
  key_long = ABS_Register_Simple_Type("long");

  Add_SetGet(name, (void**)get,set);
  return(absmib_insert_row(name,key_long,name));/*for C interface void* pObj = char* name*/
}
/*************************************************************************************/
int Register_Mib_Bool_Row(char *name,char *permis, int (*get)(),void  (*set)())
{
  int key;
  char *names[3];

  names[0] = "Off";
  names[1] = "On";
  names[2] = 0;

  key = Register_Complex_Type("bool", names);

  Add_SetGet(name, (void**)0,set);
  return(absmib_insert_row(name, key,name));/*for C interface void* pObj = char* name*/
}
/*************************************************************************************/
int Register_Mib_Button_Row(char *name, void  (*set)())
{
  int key;
  char *names[2];

  names[0] = name;
  names[1] = 0;
  key = Register_Complex_Type("unari", names);

  Add_SetGet(name, (void**)0,set);
  return(absmib_insert_row(name, key,name));/*for C interface void* pObj = char* name*/
}
/*************************************************************************************/
int Register_Mib_Double_Row(char *name, char *permis, double (*get)(), void  (*set)())
{
  int key;
  key = ABS_Register_Simple_Type("double");

  Add_SetGet(name,(void**) get,set);
  return(absmib_insert_row(name,key,name));/*for C interface void* pObj = char* name*/
}
/*************************************************************************************/
int Register_Mib_String_Row(char *name, char *permis, char* (*get)(), void  (*set)())
{
  int key;
  key= ABS_Register_Simple_Type("string");

  Add_SetGet(name,(void**) get,set);
  return(absmib_insert_row(name,key,name));/*for C interface void* pObj = char* name*/
}

/*************************************************************************************/

/** Registers an web integer by name, set and get methods. The data exchange supplying
    by "seter" and "geter" usage.
	
	@param NameOfComp  name of registered component.
	@param get  get data method of registrated element.
	@param set  set data method of registrated element.
    @return  handle to the registered web component.
    @see C_RegisterCWebButton
  	@see C_RegisterCWebDouble
  	@see C_RegisterCWebString
  	@see C_RegisterCWebChoiceList
	@see C_RegisterCWebAggregate

*/
unsigned short C_RegisterCWebInteger(char* NameOfComp,int (*get)(), void  (*set)())
{
	return(Register_Mib_Int_Row(NameOfComp,"rw",get,set));
}
/*************************************************************************************/
/** Registers an web integer by name, set and get methods. The data exchange supplying
    by "seter" and "geter" usage.
	
	@param NameOfComp  name of registered component.
	@param get  get data method of registrated element.
	@param set  set data method of registrated element.
    @return  handle to the registered web component.
    @see C_RegisterCWebButton
  	@see C_RegisterCWebDouble
  	@see C_RegisterCWebString
  	@see C_RegisterCWebChoiceList
	@see C_RegisterCWebAggregate

*/
unsigned short C_RegisterCWebChar(char* NameOfComp,char (*get)(), void  (*set)())
{
	return(Register_Mib_Char_Row(NameOfComp,"rw",get,set));
}
/*************************************************************************************/
/** Registers an web integer by name, set and get methods. The data exchange supplying
    by "seter" and "geter" usage.
	
	@param NameOfComp  name of registered component.
	@param get  get data method of registrated element.
	@param set  set data method of registrated element.
    @return  handle to the registered web component.
    @see C_RegisterCWebButton
  	@see C_RegisterCWebDouble
  	@see C_RegisterCWebString
  	@see C_RegisterCWebChoiceList
	@see C_RegisterCWebAggregate

*/
unsigned short C_RegisterCWebLong(char* NameOfComp,long (*get)(), void  (*set)())
{
	return(Register_Mib_Long_Row(NameOfComp,"rw",get,set));
}
/*************************************************************************************/
/** Registers an web integer by name, set and get methods. The data exchange supplying
    by "seter" and "geter" usage.
	
	@param NameOfComp  name of registered component.
	@param get  get data method of registrated element.
	@param set  set data method of registrated element.
    @return  handle to the registered web component.
    @see C_RegisterCWebButton
  	@see C_RegisterCWebDouble
  	@see C_RegisterCWebString
  	@see C_RegisterCWebChoiceList
	@see C_RegisterCWebAggregate

*/
unsigned short C_RegisterCWebBool(char* NameOfComp,int (*get)(), void  (*set)())
{
	return(Register_Mib_Bool_Row(NameOfComp,"rw",get,set));
}
/*************************************************************************************/
/** Registers an web button by name, set and get methods. The data exchange supplying
    by "seter" and "geter" usage.    
	
	@param NameOfComp  name of registered component.
	@param set  set data method of registrated element.
	@see C_RegisterCWebInteger
  	@see C_RegisterCWebDouble
  	@see C_RegisterCWebString
  	@see C_RegisterCWebChoiceList
	@see C_RegisterCWebAggregate

*/
unsigned short C_RegisterCWebButton(char* NameOfComp,void  (*set)())
{
    return(Register_Mib_Button_Row(NameOfComp,set));
}
/*************************************************************************************/
/** Registers an web double by name, set and get methods. The data exchange supplying
    by "seter" and "geter" usage.    
	
	@param NameOfComp  name of registered component.
	@param get  get data method of registrated element.
	@param set  set data method of registrated element.
    @return  handle to the registered web component.
	@see C_RegisterCWebInteger
    @see C_RegisterCWebButton
  	@see C_RegisterCWebString
  	@see C_RegisterCWebChoiceList
	@see C_RegisterCWebAggregate

*/
unsigned short C_RegisterCWebDouble(char* NameOfComp,double (*get)(), void  (*set)())
{
	return(Register_Mib_Double_Row(NameOfComp,"rw",get,set));
}
/*************************************************************************************/
/** Registers an web string by name, set and get methods. The data exchange supplying
    by "seter" and "geter" usage.    
	
	@param NameOfComp  name of registered component.
    @param get  get data method of registrated element.
	@param set  set data method of registrated element.
    @return  handle to the registered web component.
	@see C_RegisterCWebInteger
    @see C_RegisterCWebButton
  	@see C_RegisterCWebDouble
  	@see C_RegisterCWebChoiceList
	@see C_RegisterCWebAggregate
*/
unsigned short C_RegisterCWebString(char* NameOfComp,char* (*get)(), void  (*set)())
{
  return(Register_Mib_String_Row(NameOfComp,"rw",get,set));
}
/*************************************************************************************/
/** Registers an web aggregate by name.    
	
	@param NameOfComp  name of registered component.
	@param pComponent  pointer to aggregate adaptor class.
    @return  handle to the registered web component.
	@see C_RegisterCWebInteger
    @see C_RegisterCWebButton
  	@see C_RegisterCWebDouble
  	@see C_RegisterCWebString
  	@see C_RegisterCWebChoiceList
*/
unsigned short C_RegisterCWebAggregate(char* NameOfComp)
{
   return(Register_Mib_Aggregate_Row(NameOfComp,0));
}
/*************************************************************************************/
/** Registers an web choicelist by name, set and get methods. The data exchange supplying
    by "seter" and "geter" usage.    
	
	@param NameOfComp  name of registered component.
    @param get  get data method of registrated element.
	@param set  set data method of registrated element.
	@param choices     table of string thad define choiselist
    @return  handle to the registered web component.
	@see C_RegisterCWebInteger
    @see C_RegisterCWebButton
  	@see C_RegisterCWebDouble
  	@see C_RegisterCWebString
	@see C_RegisterCWebAggregate

*/
