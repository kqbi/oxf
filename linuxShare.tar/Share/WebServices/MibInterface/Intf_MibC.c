/******************************************************************************
*	file name   :	Intf_MibC.c 
*
*	purpose: C interface of Mib app
*	portability:	Machine Independent
*
*
*	author(s):	Gadi Veazosky   
*	date started:	15-May-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/

/*******************************************************************************/

/****************************************************************/
/*								                                */
/*                        C interface				            */
/*                                                              */
/****************************************************************/
/****************************************************************/
extern int FindSetGet(void *, void **, void  (**set)());
extern int C_RegisterFunc(char* name,void *func);

double GetValueDouble(void *  pObj)
{
 void *f;

 double  (*get)();
  if(FindSetGet(pObj,&f,0) && f){
      get = (double(*)())f; 
	  return((*get)());
  }
	return(0);
}
/****************************************************************/

char GetValueChar(void *  pObj)
{
 char  (*get)();
 void *f;
  if(FindSetGet(pObj,&f,0) && f){
      get = (char(*)())f; 
	  return((*get)());
  }
  return(0);
}
/****************************************************************/

long GetValueLong(void *  pObj)
{
 long  (*get)();
  void *f;
  if(FindSetGet(pObj,&f,0) && f){
      get = (long(*)())f; 
	  return((*get)());
  }
  return(0);
}
/****************************************************************/
int GetValueInt(void *  pObj) 
{
 int  (*get)();
   void *f;
  if(FindSetGet(pObj,&f,0) && f){
      get = (int(*)())f; 
	  return((*get)());
  }
  return(0);
}
/****************************************************************/
char* GetValueStr(void *  pObj)
{
 char*  (*get)();
   void *f;
  if(FindSetGet(pObj,&f,0) && f){
      get = (char*(*)())f; 
	  return((*get)());
  }
  return(0);
}
/****************************************************************/
void SetDouble(double  val, void *  pObj)
{
  void  (*set)() = 0;

  if(FindSetGet((char*)pObj, 0 ,&set) && set)
	  (*set)(val);
      
}
/****************************************************************/
void SetChar(char  val, void *  pObj)
{
  void  (*set)() = 0;

  if(FindSetGet((char*)pObj, 0 ,&set) && set)
	  (*set)(val);
      
}
/****************************************************************/
void SetLong(long  val, void *  pObj)
{
  void  (*set)() = 0;

  if(FindSetGet((char*)pObj, 0 ,&set) && set)
	  (*set)(val);
      
}
/****************************************************************/
void SetInt(int  val, void*  pObj) 
{
  void  (*set)() = 0;

  if(FindSetGet((char*)pObj, 0 ,&set) && set)
	  (*set)(val);
}
/****************************************************************/
void SetStr(char *  str, void *  pObj)
{  
  void  (*set)() = 0;

  if(FindSetGet((char*)pObj, 0 ,&set) && set)
	  (*set)(str);
}
/****************************************************************/
void SetVoid(void *  pObj)
{  
  void  (*set)() = 0;

  if(FindSetGet((char*)pObj, 0 ,&set) && set)
	  (*set)();
}
/****************************************************************/
int GetPermission(void *  pObj)
{
  void *f;
  void  (*set)() = 0;
  int   (*get)() = 0;


  FindSetGet((char*)pObj, &f ,&set);

  get = (int(*)())f;

  if(get){
	  if(set)
		  return(3); /*read and write*/
	  else
		  return(1); /*read only*/
	}
  else
	if(get)
		return(2); /*write only*/
	else 
		return(0); /*non read non write*/
}
/****************************************************************/
void RegisterCIntf_Set_Get(){
C_RegisterFunc("ILGetValueDouble",(void*)GetValueDouble); 
C_RegisterFunc("ILGetValueInt",(void*)GetValueInt);
C_RegisterFunc("ILGetValueStr",(void*)GetValueStr);
C_RegisterFunc("ILGetValueChar",(void*)GetValueChar);
C_RegisterFunc("ILGetValueLong",(void*)GetValueLong);
C_RegisterFunc("ILSetValueDouble",(void*)SetDouble);
C_RegisterFunc("ILSetValueInt",(void*)SetInt);
C_RegisterFunc("ILSetValueStr",(void*)SetStr);
C_RegisterFunc("ILSetValueVoid",(void*)SetVoid);
C_RegisterFunc("ILSetValueChar",(void*)SetChar);
C_RegisterFunc("ILSetValueLong",(void*)SetLong);
C_RegisterFunc("ILGetPermission",(void*)GetPermission);
}
/****************************************************************/
