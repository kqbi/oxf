/******************************************************************************
*	file name   :	Intf_Mib.c 
*
*	purpose:  Mib Interface
*
*
*	author(s):	 Gadi Veazovsky   
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
/****************************************************************/
/*																*/
/*			Mib Interface										*/
/*																*/
/****************************************************************/
#include <stdlib.h>

extern void* Fetch_func(char* name);
extern char *string_dup(char *s);
extern void SIAddElem(char* fname,void *func);
extern int FindSetGet(void *, void **, void  (**set)());
extern int ABS_Register_Simple_Type(char *metatype);
extern int Register_Complex_Type(char *metatype, char **names);
extern int absmib_insert_row(char *name,int type,void* pObj);
extern int absmib_get_id_by_name(char* name);
extern int absmib_modify_row(int id,char *name,int type,void* pObj);
extern void C_AssociateParentWithChild(unsigned short parentID,unsigned short childId);
extern void RegisterPredefineTypes();
extern void mib_init();



/****************************************************************/

void Mib_intf_set_void(void *pObj)
{
	static int(*set_void)() = 0;
	
	if(!pObj)
		return;
	if(!set_void)
	{
		set_void = (int(*)())Fetch_func("ILSetValueVoid");
	};
	if(set_void)
		set_void(pObj);
}

/******************************************************************************/
void Mib_intf_set_ulong (unsigned long val, void *pObj)
{
	static int(*set_ulong)() = 0;
	
	if(!pObj)
		return;
	if(!set_ulong)
	{
		set_ulong = (int(*)())Fetch_func("ILSetValueULong");
	};
	if(set_ulong)
		set_ulong(val, pObj);	
}
/*******************************************************************************/
void Mib_intf_set_char(char val,void *pObj)
{
	static int(*set_char)() = 0;
	
	if(!pObj)
		return;
	if(!set_char)
	{
		set_char = (int(*)())Fetch_func("ILSetValueChar");
	};
	if(set_char)
		set_char(val,pObj);
}
/*******************************************************************************/
void Mib_intf_set_long(long val,void *pObj)
{
	static int(*set_long)() = 0;
	
	if(!pObj)
		return;
	if(!set_long)
	{
		set_long = (int(*)())Fetch_func("ILSetValueLong");
	};
	if(set_long)
		set_long(val,pObj);
}
/*******************************************************************************/
void Mib_intf_set_int(int val,void *pObj)
{
	static int(*set_int)() = 0;
	if(!pObj)
		return;
	if(!set_int)
	{
		set_int = (int(*)())Fetch_func("ILSetValueInt");
	};
	if(set_int)
		set_int(val,pObj);
}
/*******************************************************************************/
void Mib_intf_set_string(char* val,void *pObj)
{
	static int(*set_string)() = 0;
	
	if(!pObj)
		return;
	
	if(!set_string)
	{
		set_string = (int(*)())Fetch_func("ILSetValueStr");
	};
	if(set_string)
		set_string(string_dup(val),pObj);
}
/*******************************************************************************/
void Mib_intf_set_double(double val,void *pObj)
{
	static int(*set_double)() = 0;
	
	if(!pObj)
		return;
	
	if(!set_double)
	{
		set_double = (int(*)())Fetch_func("ILSetValueDouble");
	};
	if(set_double)
		set_double(val,pObj);
}

/*******************************************************************************/
/** These functions fetch the getters for different types:                    **/
/*  short, char, int -> long.                                                 **/
/*                                                                            **/
/*******************************************************************************/
unsigned long Mib_intf_get_ulong(void *pObj)
{
	static unsigned long(*get)() = 0;
	
	if(!pObj)
		return(0);
	
	if(!get)
	{
		get =(unsigned long(*)()) Fetch_func("ILGetValueULong");
	};
	if(get)
		return(get(pObj));
	return(0);
}

/*******************************************************************************/
int Mib_intf_get_int(void *pObj)
{
	static int(*get_int)() = 0;
	
	if(!pObj)
		return(0);
	
	if(!get_int)
	{
		get_int = (int(*)())Fetch_func("ILGetValueInt");
	};
	if(get_int)
		return(get_int(pObj));
	return(0);
}
/*******************************************************************************/

char Mib_intf_get_char(void *pObj)
{
	static int(*get_char)() = 0;
	
	if(!pObj)
		return(0);
	
	if(!get_char)
	{
		get_char =(int(*)()) Fetch_func("ILGetValueChar");
	};
	if(get_char)
		return(get_char(pObj));
	return(0);
}
/*******************************************************************************/

long Mib_intf_get_long(void *pObj)
{
	static long(*get_long)() = 0;
	

	if(!pObj)
		return(0);
	
	if(!get_long)
	{
		get_long = (long(*)())Fetch_func("ILGetValueLong");
	};
	if(get_long)
		return(get_long(pObj));
	return(0);
}
/*******************************************************************************/
double Mib_intf_get_double(void *pObj)
{
	static double(*get_double)() = 0;
	
	if(!pObj)
		return(0);
	
	if(!get_double)
	{
		get_double = (double(*)())Fetch_func("ILGetValueDouble");
	};
	if(get_double)
	{
		get_double(pObj);
		return(get_double(pObj));
	}
	return(0);
}
/*******************************************************************************/
char* Mib_intf_get_string(void *pObj)
{
	static char*(*get_string)() = 0;
	
	if(!pObj)
		return(0);
	
	if(!get_string)
	{
		get_string = (char*(*)())Fetch_func("ILGetValueStr");
	};
	if(get_string)
		return(get_string(pObj));
	return(0);
}
/*******************************************************************************/
int Mib_intf_get_permission(void *pObj)
{
	static int(*get_perm)() = 0;
	
	if(!pObj)
		return(0);
	
	if(!get_perm)
	{
		get_perm = (int(*)())Fetch_func("ILGetPermission");
	};
	if(get_perm)
		return(get_perm(pObj));
	else 
		return(3); /*Temporrary only, mast be 0);*/
	
}
/****************************************************************/
int C_RegisterFunc(char* name,void *func)
{ 
	SIAddElem(name,(void*)func);
	return(1);
}
/*************************************************************************************/
int Register_Mib_SPAggregate_Row(char *name)
{
	int   type_key;
	
	type_key = ABS_Register_Simple_Type("spaggr");
	return( absmib_insert_row(name, type_key, 0)); /*for C interface void* pObj = char* name */
	
}
/*************************************************************************************/
int Register_UndefineType_Row(char *name)
{
	int   type_key;
	type_key = ABS_Register_Simple_Type("undefined");
	return( absmib_insert_row(name, type_key, 0)); /*for C interface void* pObj = char* name */
	
}
/*************************************************************************************/
int Register_Mib_Aggregate_Row(char *name,void* pAdapter)
{
	int   type_key;
	
	type_key = ABS_Register_Simple_Type("aggr");
	return( absmib_insert_row(name, type_key, pAdapter)); /*for C interface void* pObj = char* name */
}
/****************************************************************/
int Register_Mib_View_Row(char *name)
{
	int   type_key;
	type_key = ABS_Register_Simple_Type("view");
	return( absmib_insert_row(name, type_key, 0)); /*for C interface void* pObj = char* name */
}
/****************************************************************/
int RegisterViewNames(char *agg_name, char **names, int len)
{
	int papaId,childId,i;
	
	papaId = Register_Mib_View_Row(agg_name);
	for (i = 0; i < len; i++)
	{
		if((childId = absmib_get_id_by_name(names[i])) == -1)  /*element is not registered in Mib */
			childId = Register_UndefineType_Row(names[i]);
		C_AssociateParentWithChild((unsigned short)papaId,(unsigned short)childId);
	}
	return(papaId);
}

int RegisterViewIds(char *agg_name, char **ids, int len)
{
	int papaId, i;
	
	papaId = Register_Mib_View_Row(agg_name);
	for (i = 0; i < len; i++)
		C_AssociateParentWithChild((unsigned short)papaId,(unsigned short)atoi(ids[i]));
	
	return (papaId);
}
/****************************************************************/
void C_PreInit()
{
	mib_init();
	RegisterPredefineTypes();
}
/****************************************************************/
