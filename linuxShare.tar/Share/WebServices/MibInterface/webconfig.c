/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

/****************************************************************************/
#ifdef __cplusplus
extern "C"{
#endif 
/****************************************************************************/
extern void SetDeviceTitle(char *title);
extern void SetHomePageUrl(char *name);
extern void SetSignaturePageUrl(char *name);
extern void SetRefreshTimeout(int time);
extern void SetPropPortNumber(unsigned short num);
extern void InitFs(char *path);
extern void InitPropFs();
extern void InitStdFs();
extern void WebServerGo();
extern int C_RegisterFunc(char* name, void * operation);
extern int PropCgiPResponseWrite(void *fp, char *data, int len);
extern void RegisterUpload();
extern void setJSCommLayer();
extern void setJavaCommLayer();
extern void ClearExternalWebConfig();
 /****************************************************************************/
void WebConfig()
{
/*
 *	Configure the web server options before invoking the web server.
 */
 
/* Setting the default home page. */
   SetHomePageUrl("cgibin?Abs_App=Abstract_Default");

/* Setting the signature page. */
   SetSignaturePageUrl("sign.htm");

/* Binding the web server's response procedure. */
   C_RegisterFunc("ILCgiWriteResponse",(void*)PropCgiPResponseWrite);

/* Setting the timeout period for pages' updates. */
   SetRefreshTimeout(1000);

/* Setting the web-server's port. */
   SetPropPortNumber(80);

/* Configuring the file system. */
   InitFs(0); /*if 0 -init default path */

/* Bind file system operations */
   InitPropFs();
   /*InitStdFs(); *//* using stdlib */
   
/* Setting the communicatiopn layer type. */
   setJSCommLayer(); /*setJavaCommLayer()*/

   /* INTERNAL USE ONLY */
   ClearExternalWebConfig(); 
}
/****************************************************************************/
void StartWebServer()
{
  WebServerGo();
}
/****************************************************************************/
#ifdef __cplusplus
}
#endif

/****************************************************************************/


