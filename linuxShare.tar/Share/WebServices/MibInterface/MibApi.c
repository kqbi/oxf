/******************************************************************************
*	file name   :	MibApi.c 
*
*	purpose: Registration Api using Adaptor classes.(Rhapsody usage)
*	portability:	Machine Independent
*
*
*	author(s):	 Gadi Veazovsky   
*	date started:	22-Jan-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/

extern int ABS_Register_Simple_Type(char *metatype);
extern int Register_Complex_Type(char *metatype, char **names);
extern int absmib_insert_row(char *name,int type,void* pObj);
extern char *generate_type_name();
extern int Register_Mib_Aggregate_Row(char *name,void* pAdapter);
extern int CRF_Insert(int id1, int id2);
extern void CRF_DeleteChilds(int id);
extern void absmib_delete_row(int id);
extern void CRF_DeleteElement(int id);
extern int absmib_is_valid_id(int id);

/*******************************************************************************/
/*************************************************************************************/
/** Registers an integer adapter to the web management. The data exchange supplying
    by rhapsody adapters usage.This API function for rhapsody C++
	usage only.    
	
	@param NameOfComp  name of registered component.
	@param pComponent  pointer to integer adaptor class.
    @return  handle to the registered web component.
    @see C_RegisterWebButton
  	@see C_RegisterWebDouble
  	@see C_RegisterWebString
  	@see C_RegisterWebChoiceList

*/
unsigned short C_RegisterWebInteger(char* NameOfComp,void *pAdapter)
{
  int key_int;
  key_int = ABS_Register_Simple_Type("int");

  return(absmib_insert_row(NameOfComp,key_int,pAdapter));
}
/*************************************************************************************/
/** Registers an char adapter to the web management. The data exchange supplying
    by rhapsody adapters usage.This API function for rhapsody C++
	usage only.    
	
	@param NameOfComp  name of registered component.
	@param pComponent  pointer to integer adaptor class.
    @return  handle to the registered web component.
    @see C_RegisterWebButton
  	@see C_RegisterWebDouble
  	@see C_RegisterWebString
  	@see C_RegisterWebChoiceList

*/
unsigned short C_RegisterWebChar(char* NameOfComp,void *pAdapter)
{
  int key_char;
  key_char = ABS_Register_Simple_Type("char");

  return(absmib_insert_row(NameOfComp,key_char,pAdapter));
}
/*************************************************************************************/
/** Registers an long adapter to the web management. The data exchange supplying
    by rhapsody adapters usage.This API function for rhapsody C++
	usage only.    
	
	@param NameOfComp  name of registered component.
	@param pComponent  pointer to integer adaptor class.
    @return  handle to the registered web component.
    @see C_RegisterWebButton
  	@see C_RegisterWebDouble
  	@see C_RegisterWebString
  	@see C_RegisterWebChoiceList

*/
unsigned short C_RegisterWebLong(char* NameOfComp,void *pAdapter)
{
  int key_long;
  key_long = ABS_Register_Simple_Type("long");

  return(absmib_insert_row(NameOfComp,key_long,pAdapter));
}
/*************************************************************************************/
/** Registers an unsigned long adapter to the web management. The data exchange supplying
    by rhapsody adapters usage.This API function for rhapsody C++
	usage only.    
	
	@param NameOfComp  name of registered component.
	@param pComponent  pointer to string adaptor class.
    @return  handle to the registered web component.
	@see C_RegisterWebInteger
    @see C_RegisterWebButton
  	@see C_RegisterWebDouble
  	@see C_RegisterWebChoiceList
*/
unsigned short C_RegisterWebULong(char* NameOfComp,void *pAdapter)
{
  int key_string;
  key_string = ABS_Register_Simple_Type("unsigned long");

  return(absmib_insert_row(NameOfComp,key_string,pAdapter));
}
/*************************************************************************************/
/** Registers an bool adapter to the web management. The data exchange supplying
    by rhapsody adapters usage.This API function for rhapsody C++
	usage only.    
	
	@param NameOfComp  name of registered component.
	@param pComponent  pointer to integer adaptor class.
    @return  handle to the registered web component.
    @see C_RegisterWebButton
  	@see C_RegisterWebDouble
  	@see C_RegisterWebString
  	@see C_RegisterWebChoiceList

*/
unsigned short C_RegisterWebBool(char* NameOfComp,void *pAdapter)
{
  int key;
  char *names[3];

  names[0] = "Off";
  names[1] = "On";
  names[2] = 0;

  key = Register_Complex_Type("bool", names);
  return(absmib_insert_row(NameOfComp,key,pAdapter));
}
/*************************************************************************************/
/** Registers an button adapter to the web management. The data exchange supplying
    by rhapsody adapters usage.This API function for rhapsody C++
	usage only.    
	
	@param NameOfComp  name of registered component.
	@param pComponent  pointer to button adaptor class.
    @return  handle to the registered web component.
	@see C_RegisterWebInteger
  	@see C_RegisterWebDouble
  	@see C_RegisterWebString
  	@see C_RegisterWebChoiceList
*/
unsigned short C_RegisterWebButton(char* NameOfComp,void *pAdapter)
{
  int key;
 
  key = ABS_Register_Simple_Type("unari");

  return(absmib_insert_row(NameOfComp,key,pAdapter));
}
/*************************************************************************************/
/** Registers an double adapter to the web management. The data exchange supplying
    by rhapsody adapters usage.This API function for rhapsody C++
	usage only.    
	
	@param NameOfComp  name of registered component.
	@param pComponent  pointer to double adaptor class.
    @return  handle to the registered web component.
	@see C_RegisterWebInteger
    @see C_RegisterWebButton
  	@see C_RegisterWebString
  	@see C_RegisterWebChoiceList
*/
unsigned short C_RegisterWebDouble(char* NameOfComp,void *pAdapter)
{
  int key_double;
  key_double = ABS_Register_Simple_Type("double");

  return(absmib_insert_row(NameOfComp,key_double,pAdapter));
}
/*************************************************************************************/
/** Registers an string adapter to the web management. The data exchange supplying
    by rhapsody adapters usage.This API function for rhapsody C++
	usage only.    
	
	@param NameOfComp  name of registered component.
	@param pComponent  pointer to string adaptor class.
    @return  handle to the registered web component.
	@see C_RegisterWebInteger
    @see C_RegisterWebButton
  	@see C_RegisterWebDouble
  	@see C_RegisterWebChoiceList
*/
unsigned short C_RegisterWebString(char* NameOfComp,void *pAdapter)
{
  int key_string;
  key_string = ABS_Register_Simple_Type("string");

  return(absmib_insert_row(NameOfComp,key_string,pAdapter));
}
/*************************************************************************************/
/** Registers an aggregate adapter to the web management. The data exchange supplying
    by rhapsody adapters usage.This API function for rhapsody C++
	usage only.    
	
	@param NameOfComp  name of registered component.
	@param pComponent  pointer to aggregate adaptor class.
    @return  handle to the registered web component.
	@see C_RegisterWebInteger
    @see C_RegisterWebButton
  	@see C_RegisterWebDouble
  	@see C_RegisterWebChoiceList
*/
unsigned short C_RegisterWebAggregate(char* NameOfComp,void *pAdapter)
{
 /* the adaptor is no using*/
  return(Register_Mib_Aggregate_Row(NameOfComp,pAdapter));
}
/*************************************************************************************/
/** Registers an choicelist adapter to the web management. The data exchange supplying
    by rhapsody adapters usage.This API function for rhapsody C++
	usage only.    
	
	@param NameOfComp  name of registered component.
	@param pComponent  pointer to choiselist adaptor class.
	@param choices     table of string thad define choiselist
    @return  handle to the registered web component.
	@see C_RegisterWebInteger
    @see C_RegisterWebButton
  	@see C_RegisterWebDouble
  	@see C_RegisterWebString
*/
unsigned short C_RegisterWebChoiceList(char* NameOfComp,void *pAdapter,char** choices)
{
  int  type_key;

  type_key = Register_Complex_Type("choice", choices);
  return(absmib_insert_row(NameOfComp, type_key,pAdapter));
}
/*************************************************************************************/
/** Associate parent and child elements using parent and child ID's.

	@param parentID a handle of parent.
	@param parentID a handle of child.
	@see C_RegisterWebComponentRh
	@see C_RegisterWebComponent
*/
void C_AssociateParentWithChild(unsigned short parentID,unsigned short childId)
{ 

	if(absmib_is_valid_id(parentID) && absmib_is_valid_id(childId))
		CRF_Insert(parentID, childId);
}
/*************************************************************************************/
/** Separate parent and child elements using parent and child ID's.

	@param parentID a handle of parent.
	@param parentID a handle of child.
	@see C_RegisterWebComponentRh
	@see C_RegisterWebComponent
*/
void C_SeparateParentFromChild(unsigned short parentID,unsigned short childId)
{

}
/*************************************************************************************/
/** Break all reletions of element using ID.

	@param elementID a handle of parent.
	@see C_RegisterWebComponentRh
	@see C_RegisterWebComponent
*/
void  C_BreakAllAssociations(unsigned short elementID)
{
	CRF_DeleteChilds(elementID);
}
/*************************************************************************************/

/** Unregisters web element by nID handle.
	
	@param nID handle of registered element.

	@see C_RegisterWebComponentRh
	@see C_RegisterWebComponent
*/
void C_UnregisterWebComponent(unsigned short nID)
{
  absmib_delete_row(nID);
  CRF_DeleteElement(nID);
}
/*************************************************************************************/
