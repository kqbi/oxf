/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

extern void WebAppsInit();
extern int C_RegisterFunc(char* name, void * operation);
extern int Init_Resource_Files();
extern int absmib_get_root_sons_ids(int out_childs[],int max_childs);
extern int absmib_get_flat_root_sons_ids(int out_childs[],int max_childs);
extern int Register_Mib_SPAggregate_Row(char *name);
extern int Register_SPFunction(int id,int(*sp_func)());
extern void CreateConfigFile();
extern void* Fetch_func(char* name);
extern void CreateLinkFile();
extern void SetRegPermission(int permission);
extern int  SetRoute(char* gateway);
extern int  InitTreeRes();
extern char* GetDeviceName();
extern int AC_AddUser(char* login, char* password);
extern void WebLicense(int numberOfUsers);
extern void WebConfig();
extern void StartWebServer();



static void(*f_init_web_resources)() = 0;


/****************************************************************************/

void Init_special_agg()
{
	Register_Mib_SPAggregate_Row(GetDeviceName());/*hierarchical root*/
	C_RegisterFunc(GetDeviceName(),(void*)absmib_get_root_sons_ids);
	Register_Mib_SPAggregate_Row("root");/*hierarchical root*/
	C_RegisterFunc("root",(void*)absmib_get_flat_root_sons_ids);

	SetRegPermission(1);
}
/****************************************************************************/



/****************************************************************************/
void PreInit()
{
/*Define initialized logins*/

   AC_AddUser("admin","admin");
   AC_AddUser("Ilogix","Ilogix");

/* define gateway : only for "VXWORKS" temporary */
   /*SetRoute("194.90.28.1");*/

}
/****************************************************************************/

void PostInit()
{

 /* Init additional resources */
   Init_Resource_Files();
   InitTreeRes();

if(!f_init_web_resources)
	{
		f_init_web_resources = (void(*)())Fetch_func("ILInitWebResources");
	};
if(f_init_web_resources)
	f_init_web_resources();

   /*extract backup views*/
 /*  ABS_ExtractAggrFromFile("default.view");  temporary deleted */

  /* Init special aggregate views*/
   Init_special_agg();

  /*create JS config file*/
   CreateConfigFile();
   CreateLinkFile();
}
/****************************************************************************/

/* Exaple for binding */
/* 
    C_RegisterFunc("ILFileAppend",MyFileAppend);
	C_RegisterFunc("ILFileReadFrom",MyFileReadFrom);
	C_RegisterFunc("ILFileWrite",MyopFileSave);
*/

/****************************************************************************/


int WebMain(){


PreInit();

/*
 * for user modification
 */
WebConfig();

PostInit();


WebAppsInit();

StartWebServer();

return(1);
}
/****************************************************************************/

