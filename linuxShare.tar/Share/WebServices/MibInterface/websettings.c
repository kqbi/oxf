/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

static int ExternalWebconfig = 1;


void ClearExternalWebConfig() 
{  
	ExternalWebconfig = 0; 
}


int IsExternalWebconfig() 
{ 
	return ExternalWebconfig ; 
}
