/******************************************************************************
*	file name   :	DbgFunc.c 
*
*	purpose: Debug tools
*	portability:	Machine Independent
*
*
*	author(s):	 Gadi Veazovsky   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <string.h>
/*******************************************************************************/

#include <stdio.h>
#ifdef WEB_DEBUG
#define QUERY_BUFF_SIZE 512
#define BUFFER_SIZE     512 

char DbgBuffer[BUFFER_SIZE];
char DbgQueryBuf[QUERY_BUFF_SIZE];
int  DbgValue;
#endif


void dbg_set_label(int label)
{
#ifdef WEB_DEBUG
	DbgValue = label;
#endif
}

void dbg_set_buffer(char* buf)
{
#ifdef WEB_DEBUG
	strncpy(DbgBuffer,buf,500);
	DbgBuffer[500] = 0;
#endif
} 

void dbg_set_query(char* buf)
{
#ifdef WEB_DEBUG
   strncpy(DbgQueryBuf,buf,500);
   DbgQueryBuf[500] = 0;
   fprintf(stderr,"%s",DbgQueryBuf);
   printf("%s",DbgQueryBuf);
#endif
}

/*******************************************************************************/
#ifdef WIN_DEBUG_MODE
save_to_disk(void *fp, char *fname)
{
	char buff[200];
    unsigned char data[20000];
	char full_name[100];
    void *fp_out;
	int len;

	strcpy(full_name,"tmp/");
	strcat(full_name, fname);
	strcat(full_name, ".c");

    fp_out = fopen(full_name, "r");	
	if(fp_out)
	{  /* file exist do nothing */
     fclose(fp_out);
     sprintf(buff,"<h1>%s already exists </h1>", full_name);
     HTML_Write_text(fp, buff);
     return(0);
	}

	if(ABSFileRead(fname, data,  &len, sizeof(data) -1))
     data[len] = 0;
    else
	{ 
     sprintf(buff,"<h1>%s is not in memory</h1>", full_name);
     HTML_Write_text(fp, buff);
     return(0);
	}		

    fp_out = fopen(full_name, "w");	
    if(!fp_out)
	{ 
     sprintf(buff,"<h1>%s can not be written</h1>", full_name);
     HTML_Write_text(fp, buff);
     return(0);
	}
/*******************************/
	{
		int i;
		fprintf(fp_out, "unsigned char %s[]={\n", fname);
		for(i = 0 ; i < len; i++)
		{
		   if((i + 1) == len)
		   {
            fprintf(fp_out, "0x%x\n};", data[i]);
            break;
		   }
		   if(i %20 == 0)
             fprintf(fp_out, "\n");
           fprintf(fp_out, "0x%x,", data[i]);
		}
	}

/*****************************/

    fclose(fp_out);
    sprintf(buff,"<h1>%s has been saved</h1>", full_name);
     HTML_Write_text(fp, buff);
	 return(1);
}
#endif
