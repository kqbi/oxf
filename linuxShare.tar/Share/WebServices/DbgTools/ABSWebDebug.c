/******************************************************************************
*	file name   :	ABSWebDebug.c 
*
*	purpose: Wrappers for print_log (Debug printing only)
*	portability:	Contain #Ifdefs 
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.	
*******************************************************************************
*/
#ifdef WEB_DEBUG
#include <string.h>
#include <stdio.h>
#endif
/*******************************************************************************/
int HTML_Write_text(void *fp,  char data[]);
/*******************************************************************************/

#define LOG_WEBSERVER -1
#define INFO_LOG -2
#define print_log(x,y,z) printf("[%d][%d][%s]", x, y, z)


#ifndef WIN32
#ifdef __PSOS
#include <logsrv.h>      /* Spool logging facility */
#include <spooler.h>     /* Spool facility */
#endif
#endif



#define MAX_LOGLINE 200


void ABSWebDebug_s(char *s)
{
#ifdef WEB_DEBUG
   char buff[2048];

   memcpy(buff, s, MAX_LOGLINE);
   
   strcpy(&buff[MAX_LOGLINE], "...");
   /*print_log( LOG_WEBSERVER, INFO_LOG, buff );*/
   printf("Error: %s",buff);
#endif
}


void ABSWebDebug_s_s(char *s1, char *s2)
{
#ifdef WEB_DEBUG
     char buff[2048];
      char buff2[1024];

   memcpy(buff2, s2, 1000);
   buff2[1000] = 0;
 

   sprintf(buff, s1, buff2);

   strcpy(&buff[MAX_LOGLINE], "...");

   print_log(LOG_WEBSERVER, INFO_LOG, buff);
#endif
}

void ABSWebDebug_s_i(char *s, int i)
{
#ifdef WEB_DEBUG
   char buff[2048];
      char buff2[1024];

   memcpy(buff2, s, 1000);
   buff2[1000] = 0;
   sprintf(buff,buff2, i);

   strcpy(&buff[MAX_LOGLINE], "...");
 
 	print_log(LOG_WEBSERVER, INFO_LOG, buff);
#endif
}

void ABSWebDebug_s_i_s(char *s1, int i, char *s2)
{
#ifdef WEB_DEBUG
   char buff[2048];
   char buff2[1024];

   memcpy(buff2, s2, 1000);
   buff2[1000] = 0;
   sprintf(buff, s1, i, buff2);
   strcpy(&buff[MAX_LOGLINE], "...");
 
 
   print_log(LOG_WEBSERVER, INFO_LOG, buff); 
#endif
}

#ifdef WEB_DEBUG
static int global_soc = 0;
#endif

void ABSDebug_set_resive_flag(int ClientSock)
{
#ifdef WEB_DEBUG
 if(global_soc)
	/*ABSWebDebug_s("ACCEPT ERROR!!!");*/
  global_soc  = ClientSock;
#endif

}

void ABSDebug_clear_resive_flag(int ClientSock)
{
#ifdef WEB_DEBUG
	global_soc = 0;
#endif

}
int ABS_HTML_write_log(void *fp,  char data[])
{
#ifdef WEB_DEBUG
	/*printf("%s",data);*/
#endif
	return(HTML_Write_text(fp,data));
}

void ABSWebDebug_s_section(char *startp, char *endp)
{
#ifdef WEB_DEBUG
   char line[6000];
   char total[10000];
   char *p;
   extern char *ABS_getlne();

   memcpy(total, startp, endp - startp);
   total[endp - startp] = 0;
   p = total;
   while((p = ABS_getlne(line, p)))
   {
	   ABSWebDebug_s_s("%s\n", line);
       if(p >= endp)
		   break;
   }
#endif
}
