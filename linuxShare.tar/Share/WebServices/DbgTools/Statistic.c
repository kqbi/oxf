/******************************************************************************
*	file name   :	Statistic.c 
*
*	purpose: Contains statistic utilites
*	portability:	Machine Independent
*
*
*	author(s):	Gadi Veazovsky   
*	date started:	13-May-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/

#include <stdio.h>

extern int HTML_Write_text(void *fp,  char data[]);
extern int HTML_Write_Tail(void *fp);
extern void ULongToHost(unsigned long IP,char host[]);
extern void Write_Signature(void *fp);

/*******************************************************************************/


#define MAX_USERS 100

static int global_hits = 0;
static int refresh_hits = 0;
/****************************************************************************/
/**************************hits processing**************************/
void ST_PrintTable();

typedef struct {
	long UserIP;
	int  NumberOfHits;
} UserInfo;

UserInfo UInfoList[MAX_USERS];
int lastIPindex = 0;
int curentIPindex = 0;


int ST_get_hits()
{
	return(global_hits);
}
void ST_set_hits(int hits)
{
	global_hits = hits;
}

void ST_reset_hits()
{
	global_hits = 0;
}

void ST_increase_hits()
{
	UInfoList[curentIPindex].NumberOfHits++;
	global_hits++;
}
void ST_add_refresh_hits()
{
	UInfoList[curentIPindex].NumberOfHits--;
	refresh_hits++;
}
int ST_get_user_hist()
{
	return(global_hits - refresh_hits);
}
/****************************************************************************/


void ST_Init_InfoList(){
	int i;
	
	for(i = 0; i < MAX_USERS; i++){
		UInfoList[i].UserIP = 0;
		UInfoList[i].NumberOfHits = 0;
	}
}
static int ST_FindIPinList(long userIP)
{
	int i;
	
	for(i = 0; (i < MAX_USERS) && (UInfoList[i].UserIP != 0); i++){
		if(UInfoList[i].UserIP == userIP)
			return(i);
	}
	return(-1);
}

void ST_AddIP(long userIP)
{
	int index;
	if (lastIPindex >= MAX_USERS) return;
	if((index = ST_FindIPinList(userIP)) == -1){
		UInfoList[lastIPindex].UserIP = userIP;
		curentIPindex = lastIPindex;
		lastIPindex++;
	}
	else
		curentIPindex = index;
}

void ST_PrintTable(void* client){
	char buff[256];
	char host_buf[16];
	int i;
	
	sprintf(buff,"<link rel='stylesheet' type='text/css' href='style.css'>\n");
	HTML_Write_text(client, buff);
	HTML_Write_text(client, "<script src='tools.js'></script>");
	
	HTML_Write_text(client, "<div id=div_0><h3 class=IT>Statistics</h3><hr noshade>\n");
	sprintf(buff, "<table class=InnerText border=1 bordercolor=black cellspacing=0 cellpadding=5>\n<tr>\n<th> Host\n<th> Hits\n");
	HTML_Write_text(client, buff);
	
	for(i = 0; (i < MAX_USERS) && (UInfoList[i].UserIP != 0); i++){
		
		ULongToHost(UInfoList[i].UserIP,host_buf);
		sprintf(buff,"<tr>\n<td> %10s\n<td> %10d\n",host_buf,UInfoList[i].NumberOfHits);
		
		HTML_Write_text(client,buff);
	}
	HTML_Write_text(client, "</TABLE>\n");
	
	sprintf(buff, "<h3 class=IT>Hits = %d\n</h2></div>", ST_get_user_hist());
	HTML_Write_text(client, buff);
	Write_Signature(client);
	HTML_Write_Tail(client);
}
