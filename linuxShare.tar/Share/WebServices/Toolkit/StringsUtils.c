/******************************************************************************
*	file name   :	StringsUtils.c 
*
*	purpose: string utils
*	portability: Machine Independent
*
*
*	author(s):	George Bilkis   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/

/*******************************************************************************/


#include <string.h>
extern void *alloc_memory(int len);

char *string_dup_esc_backslash(char *s)
{
	char c;
	int len;
	char *p, *tmp;
	if (!s) s = "";
	len = (int)strlen(s);

	tmp = p = alloc_memory(len * 2 + 1);
	if (p) 
	{
		for (; *s; tmp++,s++)
		{
			c = *s;
			if (c == '\\' || c == '\'' || c == '"')
			{
				*tmp = '\\';
				tmp++;
				*tmp = c;
			}
			else if (c == '\n')
			{
				*tmp++ = '\\';
				*tmp = 'n';
			}
			else 
			{
				*tmp = c;
			}
		}
        *tmp = '\0';
	}
	return (p);
}

/************************************
* transfer string to lowercase
************************************/
char *ABS_strlwr(char *string)
{
	char *p = string;

	for(p = string;*p;p++){
		if((*p >= 'A') && (*p <= 'Z'))
			*p = 'a' + (*p - 'A');
	}
	return(string);
}
/************************************
* 0 string1 identical to string2 
* > 0 string1 not identical string2 
************************************/
int ABS_stricmp(char* name1,char* name2) /*name2 in lowercase*/
{
  int diff = 0;

   for(; *name1 ; name1++, name2++) 
   {
	 diff = *name1 - *name2;
	 if(!diff)
		 continue;

	 if(diff == 32)
		 if('a' <= *name1 &&  *name1 <= 'z')
			 continue;

	 if(diff == -32)
		 if('a' <= *name2 &&  *name2 <= 'z')
		    continue;

	 return(-1);
   }


  return(*name2);
}
