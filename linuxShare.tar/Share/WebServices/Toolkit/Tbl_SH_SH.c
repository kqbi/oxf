/******************************************************************************
*	file name   :	Tbl_SH_SH.c 
*
*	purpose: APIs for table handling
*                   This table has 2 colomns 
*                   per row [short, short]
*
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	17-Jan-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <string.h>

/*******************************************************************************/


#define ROW_ACTIVE  0 
#define ROW_BUSY    1
#define ROW_DELETED 2

#define OffsetOf(p,field) (&(p)->field - (p)) 

/*  API for table with two colomns [int, string]*/
/*  Table is unsafe, assumes no collisions      */


typedef struct {
    short id1;
	short id2;
} Row_US_US;  /* Row_IS stands for Row with Int, String */

typedef struct {
	char *name;
	int  allocated_lines;
	int  first_empty_row;
	Row_US_US  *rows;
	char *Row_Status;  /* array corresponding to Rows*/ 
	                   /* Active - 0, 1 - Deleted, 2 - Unstable  */
} TBL_US_US_Header;

		extern  void *alloc_memory(int len);


static void *_alloc_US_US_rows(int len)
{

    extern void *alloc_rows(int, int);
    
    return(alloc_rows(sizeof(Row_US_US), len));

}
/*********************************************************************/


 
/***********************************************************/
/* Constructions of table*/
/***********************************************************/

/* API*/void *TBL_US_US_New(char *name, int recommened_lines_number)
{
	char *string_dup(char *s);
    TBL_US_US_Header *header;
	
    header = alloc_memory(sizeof(TBL_US_US_Header));
	header->name = string_dup(name);
    header->rows = _alloc_US_US_rows( recommened_lines_number);
    header->allocated_lines = recommened_lines_number;
	header->first_empty_row = 0;

	header->Row_Status = alloc_memory(recommened_lines_number);
	memset(header->Row_Status, ROW_DELETED, recommened_lines_number);

	return(header);
}


/* API*/int TBL_US_US_Insert(TBL_US_US_Header *header, int id1, int id2)
{
   Row_US_US *p;
   int index;

    if(header->allocated_lines <= header->first_empty_row)
		/* no room so we reallocate the table's rows*/
	{
     /** Reallocate the Rows **/
		return(0);
	}
    index = header->first_empty_row++;
	p = &header->rows[index];
	p->id1 = id1;
	p->id2 = id2;
	header->Row_Status[index] = ROW_ACTIVE;
    return(1);
}
/*************************************************************************/
/* API*/int TBL_US_US_Insert_childs(TBL_US_US_Header *header, int id1, int id2[],int max_childs)
{
   Row_US_US *p;
   int index,i;

   for(i = 0; i < max_childs;i++)
   {
    if(header->allocated_lines <= header->first_empty_row)
		/* no room so we reallocate the table's rows*/
	{
     /** Reallocate the Rows **/
		return(0);
	}
    index = header->first_empty_row++;
	p = &header->rows[index];
	p->id1 = id1;
	p->id2 = id2[i];
	header->Row_Status[index] = ROW_ACTIVE;
   }
    return(1);
}

/*************************************************************************/
/* API*/void TBL_US_US_Delete_relation(TBL_US_US_Header *h, int id1, int id2)
{
    Row_US_US *row, *last;
    int i;

	row = h->rows;
	last = h->rows + h->first_empty_row;

    for(i = 0; row < last; row++)
      if(row->id1 == id1 && row->id2 == id2)
	  {
		  i = (int)(row - h->rows);
		  h->Row_Status[i] = ROW_DELETED;
	  }
	return;
}
/*************************************************************************/
/* API*/void TBL_US_US_Delete_id(TBL_US_US_Header *h, int id)
{
    Row_US_US *row, *last;
    int i;
	row = h->rows;
	last = h->rows + h->first_empty_row;

    for(i = 0; row < last; row++)
      if(row->id1 == id || row->id2 == id)
	  {
		  i = (int)(row - h->rows);
		  h->Row_Status[i] = ROW_DELETED;
	  }
	return;
}

/*************************************************************************/
/* API*/void TBL_US_US_Delete_childs(TBL_US_US_Header *h, int id)
{
    Row_US_US *row, *last;
    int i;
	row = h->rows;
	last = h->rows + h->first_empty_row;

    for(i = 0; row < last; row++)
      if(row->id1 == id)
	  {
		  i = (int)(row - h->rows);
		  h->Row_Status[i] = ROW_DELETED;
	  }
	return;
}

/*************************************************************************/
/* API*/void TBL_US_US_Delete_Element(TBL_US_US_Header *h, int id)
{
    Row_US_US *row, *last;
    int i;
	row = h->rows;
	last = h->rows + h->first_empty_row;

    for(i = 0; row < last; row++)
      if(row->id1 == id || row->id2 == id)
	  {
		  i = (int)(row - h->rows);
		  h->Row_Status[i] = ROW_DELETED;
	  }
	return;
}
/*************************************************************************/
int TBL_US_US_get_all_fathers(TBL_US_US_Header *h,int id,int fathers[],int max_fathers)
{
    Row_US_US *row, *last;
    int i,j = 0;

	row = h->rows;
	last = h->rows + h->first_empty_row;

    for(i = 0; (row < last) && (j < max_fathers); row++, i++){
		if((row->id2 == id) && (h->Row_Status[i] == ROW_ACTIVE))
			fathers[j++] =  row->id1;
;	}
	return(j);
}
/***********************************************************/
/*  return in id2_out[] all id2s with the same id1			*/
/*  return number of matches								*/
/*															*/
/* Note: No allocation is done								*/
/*        Caller should supply id2_out[] array for output.	*/
/***********************************************************/

/* API*/
int TBL_US_US_Get_by_id1(TBL_US_US_Header *h, int id1, int max_len,int *id2_out )
{
    int i, j;
    Row_US_US *row;
    char  *sts_arr;

	row = h->rows;
	sts_arr = h->Row_Status;

    for(i = 0, j = 0; i < h->first_empty_row;i++, row++)
	 
      if(row->id1 == id1 && sts_arr[i] == ROW_ACTIVE)
	  {
		  id2_out[j] = row->id2;
          if( j < max_len)
			  j++;
	  }
	 return(j); /* number of matches but no more than max_len */
}
int TBL_US_US_GetActivePairs(TBL_US_US_Header *h,int id_parent[],int id_child[],int maxlen)
{
	Row_US_US *row, *last;
    int i,j;
	row = h->rows;
	last = h->rows + h->first_empty_row;

    for(i = 0,j=0; (row < last) && (j < maxlen); row++,i++)
      if(h->Row_Status[i] == ROW_ACTIVE){
		  id_parent[j] = row->id1;
		  id_child[j++] = row->id2;
	  }
	  return(j);
}
