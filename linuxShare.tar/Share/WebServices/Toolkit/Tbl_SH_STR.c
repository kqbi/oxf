/******************************************************************************
*
*
*   FILE NAME     : Tbl_SH_STR.c
*
*   PROGRAMMER(S) : Doron Green
*
*   DESCRIPTION   : APIs for tables handling
*                   Currently tables with two colomns
*                   per row [Int, Char *]
*
*   CAUTIONS      : 
*
*   Portability   : Machine Independent
*
*   Licensed Materials - Property of IBM
*   (c) Copyright IBM Corporation 2009. All Rights Reserved.
******************************************************************************
*
*   MODIFICATION HISTORY:
*
*   Date        Person         Change
*   ----------  -------------  -----------------------------------------------
******************************************************************************
*/

/*  API for table with two colomns [int, string]*/
/*  Table is unsafe, assumes no collisions      */

/******************************************************************************/
#include <string.h>
/******************************************************************************/


extern void free_memory(void *p, int len);
extern 	char *string_dup(char *s);

/******************************************************************************/


typedef struct {
    int num;
	char *s;
} Row_IS;  /* Row_IS stands for Row with Int, String */

typedef struct {
	char *name;
	int  allocated_lines;
	int  first_empty_row;
	Row_IS  *rows;
} TBL_Header;

		extern  void *alloc_memory(int len);


static void *_alloc_IS_rows(int len)
{

    extern void *alloc_rows(int, int);
    
    return(alloc_rows(sizeof(Row_IS), len));

}
/***********************************************************/
/* Constructions of table*/
/***********************************************************/

/* API*/void *TBL_SH_STR_New(char *name, int recommened_lines_number)
{
    TBL_Header *header;
		
    header = alloc_memory(sizeof(TBL_Header));
	header->name = string_dup(name);
    header->rows = _alloc_IS_rows( recommened_lines_number);
    header->allocated_lines = recommened_lines_number;
	header->first_empty_row = 0;
	return(header);
}
/***********************************************************/
/* API*/int TBL_SH_STR_Insert(TBL_Header *header, int number, char *str)
{
   Row_IS *p;

    if(header->allocated_lines <= header->first_empty_row)
		/* no room so we reallocate the table's rows*/
	{
    Row_IS *old_rows,*new_rows;

	  old_rows = header->rows;
	  header->allocated_lines += 10;
      new_rows = _alloc_IS_rows(header->allocated_lines);
	  if(!new_rows)
		  return(0); /* no space */
      memcpy(new_rows, old_rows, sizeof(Row_IS) *header->first_empty_row);
	  header->rows = new_rows;
      free_memory(old_rows,0);
	}

	p = &header->rows[header->first_empty_row];
	p->num = number;
	p->s = string_dup(str);
	header->first_empty_row++;
    return(1);

}

/* Assumes little deletes so performance of delete is slow*/
/* API*/void TBL_SH_STR_Delete(int id, char *str)
{
	return;
}
int TBL_SH_STR_Increase_Num_by_Str(TBL_Header *h, char *str)
{
     Row_IS *p, *lastp;

     p = h->rows;
     lastp = p + h->first_empty_row;
     for( ; p < lastp; p++)
        if(!strcmp(str, p->s))
          return(++p->num);
	 TBL_SH_STR_Insert(h,0,str);
     return(0);
}

int TBL_SH_STR_Exist_Name(TBL_Header *h, char *name)
{
     Row_IS *p, *lastp;

     p = h->rows;
     lastp = p + h->first_empty_row;
     for( ; p < lastp; p++)
        if(!strcmp(name, p->s))
          return(p->num);
     return(0);
}

char * TBL_SH_STR_Exist_Id(TBL_Header *h, int id)
{
     Row_IS *p, *lastp;

     p = h->rows;
     lastp = p + h->first_empty_row;
     for( ; p < lastp; p++)
        if(p->num == id)
          return(p->s);
     return(0);
}
