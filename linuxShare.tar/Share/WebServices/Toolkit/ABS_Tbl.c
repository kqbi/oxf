/******************************************************************************
*
*
*   FILE NAME     : ABS_Tbl.c
*
*   PROGRAMMER(S) : Doron Green
*
*   DESCRIPTION   : APIs for tables handling
*                   Currently tables with two colomns
*                   per row [Int, Char *]
*
*   CAUTIONS      : 
*
*   Portability   : Machine Independent
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
******************************************************************************
*/
#include <string.h>
/******************************************************************************/


/******************************************************************************/
extern char *string_dup(char *s);

#define OffsetOf(p,field) (&(p)->field - (int*)(p))   /*check it*/

/*  API for table with two colomns [int, string]*/
/*  Table is unsafe, assumes no collisions      */


typedef struct {
    int id;
	char *s;
} Row_IS;  /* Row_IS stands for Row with Int, String */

typedef struct {
	char *name;
	int  allocated_lines;
	int  first_empty_row;
    int is_sorted;
	Row_IS  *rows;
	Row_IS  **sorted_rows;
} TBL_Header;

extern int TBL_IS_Insert(TBL_Header *header, int id, char *str);
extern void *alloc_memory(int len);
extern void free_memory(void *p, int len);



static void *_alloc_IS_rows(int len)
{

    extern void *alloc_rows(int, int);
    
    return(alloc_rows(sizeof(Row_IS), len));

}

/* Assumes table is sorted */
static void _TBL_IS_Find(TBL_Header *h, int id, Row_IS ***first_match_p, int *matches_p)
 {
     Row_IS **p, **lastp;
     int i;

     p = h->sorted_rows;
     lastp = p + h->first_empty_row;
     for( ; p < lastp && (*p)->id < id; p++);

      if((*p)->id != id)
      {
         *matches_p = 0;
         return;
      }
  
      *first_match_p = p;
      for(i=0 ; p < lastp && (*p)->id == id; p++,i++);

      *matches_p = i;
 }

 static void _TBL_IS_Sort(TBL_Header *header)
{
 extern   void ABS_Sort_VoidArr(void **, int ,  int );
 Row_IS **arr;
 int i, len;

   if(header->is_sorted)
	   return;
   if(header->sorted_rows)
	   free_memory(header->sorted_rows,0);

   len = header->first_empty_row;
   arr = (void *)alloc_memory( len * sizeof(arr[0]));
   for (i = 0 ; i < len; i++)
     arr[i] = &header->rows[i];
   /* Warning!! Assumes offset of &Row_IS[0].id == &Row_IS[0] 
      Since it is first argument in array*/
    

  ABS_Sort_VoidArr((void**)arr, (int)OffsetOf(arr[0],id), len); /*arr will point ids in growing order */

  header->sorted_rows = arr;
   header->is_sorted = 1;

}
/***********************************************************/
/* Constructions of table*/
/***********************************************************/

/* API*/void *TBL_IS_New(char *name, int recommened_lines_number)
{
    TBL_Header *header;
	
    header = alloc_memory(sizeof(TBL_Header));
	header->name = string_dup(name);
    header->rows = _alloc_IS_rows( recommened_lines_number);
    header->allocated_lines = recommened_lines_number;
	header->first_empty_row = 0;
	header->is_sorted = 0;
	header->sorted_rows = 0;
	return(header);
}
/***********************************************************/
static int TBL_IS_Generate_key(TBL_Header *h)
{
     Row_IS *p, *lastp;
     int max_id = 1;

     p = h->rows;
     lastp = p + h->first_empty_row;
     for( ; p < lastp; p++)
        if(p->id >= max_id)
           max_id = p->id + 1;
     return(max_id);
}

int TBL_IS_Insert_Name(TBL_Header *h,  char *str)
{
   int id;

   id = TBL_IS_Generate_key(h);
   if(!TBL_IS_Insert(h, id, str) )
     return(0);
   return(id);  /* generated new key for that name */
}


/* API*/int TBL_IS_Insert(TBL_Header *header, int id, char *str)
{
   Row_IS *p;

    if(header->allocated_lines <= header->first_empty_row)
		/* no room so we reallocate the table's rows*/
	{
    Row_IS *old_rows,*new_rows;

	  old_rows = header->rows;
	  header->allocated_lines += 10;
      new_rows = _alloc_IS_rows(header->allocated_lines);
	  if(!new_rows)
		  return(0); /* no space */
      memcpy(new_rows, old_rows, sizeof(Row_IS) *header->first_empty_row);
	  header->rows = new_rows;
      free_memory(old_rows,0);
	}

	p = &header->rows[header->first_empty_row];
	p->id = id;
	p->s = string_dup(str);
	header->first_empty_row++;
	header->is_sorted = 0;
    return(1);

}

/* Assumes little deletes so performance of delete is slow*/
/* API*/void TBL_IS_Delete(int id, char *str)
{
	return;
}



int TBL_IS_Exist_Name(TBL_Header *h, char *name)
{
     Row_IS *p, *lastp;

     p = h->rows;
     lastp = p + h->first_empty_row;
     for( ; p < lastp; p++)
        if(!strcmp(name, p->s))
          return(p->id);
     return(0);
}

char * TBL_IS_Exist_Id(TBL_Header *h, int id)
{
     Row_IS *p, *lastp;

     p = h->rows;
     lastp = p + h->first_empty_row;
     for( ; p < lastp; p++)
        if(p->id == id)
          return(p->s);
     return(0);
}

/***********************************************************/
/*  return is str[] all strings with this id */
/***********************************************************/

/* API*/
int TBL_IS_Get_by_id(TBL_Header *header, int id, char **str[])
{

		Row_IS **first_match;
        extern  char **alloc_strings_array(int len);
        char **out_strings;
        int i, number_of_matched;

   if(!header->is_sorted)
	   _TBL_IS_Sort(header);

   _TBL_IS_Find(header, id, &first_match, &number_of_matched);
   if(!number_of_matched)
	   return(0);  /* not found */

   if(str)
   {
     *str = out_strings = alloc_strings_array(number_of_matched);
     for(i = 0 ; i < number_of_matched; i++)
	   out_strings[i] = string_dup(first_match[i]->s); 
   }
   return(number_of_matched);
}
