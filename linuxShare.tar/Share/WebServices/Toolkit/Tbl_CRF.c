/******************************************************************************
*	file name   :	Tbl_CRF.c 
*
*	purpose: Contains access to Tbl_SH_SH table.
*			 This table has 2 colomns per row [short, short]
*	usage: (cross referense table)
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	17-Jan-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <string.h>
/*******************************************************************************/

extern int TBL_US_US_Insert(void *, int , int );
extern int TBL_US_US_Insert_childs(void *header, int id1, int id2[],int max_childs);
extern int TBL_US_US_Get_by_id1(void *h, int id1, int max_len,int *id2_out );
extern int TBL_US_US_is_child(void *h,int id);
extern void TBL_US_US_Delete_childs(void *h, int id);
extern void TBL_US_US_Delete_Element(void *h, int id);
extern int TBL_US_US_GetActivePairs(void *h,int id_parent[],int id_child[],int maxlen);
extern int TBL_US_US_get_all_fathers(void *h,int id,int fathers[],int max_fathers);
extern int absmib_get_type_by_id(int id,int* type_id);
extern int type2metatype(char **metatype, int type_id);


#define MAX_FATHERS 100
/*******************************************************************************/

static void *CRF_Open()
{
static void *tbl = 0;
extern void *TBL_US_US_New();
 
if(!tbl)
   tbl = TBL_US_US_New("CRF", 1000);
return(tbl);
}
 
int CRF_Insert(int id1, int id2)
{
return(TBL_US_US_Insert(CRF_Open(), id1, id2));
}
int CRF_Insert_childs(int id1,int id2[],int max_childs)
{
return(TBL_US_US_Insert_childs(CRF_Open(),id1,id2,max_childs));
}

int CRF_GetChilds(int id,int out_childs[],int max_childs)
{
return(TBL_US_US_Get_by_id1(CRF_Open(),id,max_childs,out_childs));	
}
int CRF_IsChild(int id)
{
  int len,i;
  int fathers_ids[MAX_FATHERS];
  int type;
  char* metatype;
  
  len = TBL_US_US_get_all_fathers(CRF_Open(),id,fathers_ids,sizeof(fathers_ids)/sizeof(fathers_ids[0]));

  for(i = 0;i < len; i++ ){
  	absmib_get_type_by_id(fathers_ids[i],&type);
	type2metatype(&metatype,type);
     if(strcmp(metatype, "view"))
		  return(1);
  }

  return(0);
}
void CRF_DeleteChilds(int id)
{
  TBL_US_US_Delete_childs(CRF_Open(),id);
}
void CRF_DeleteElement(int id)
{
  TBL_US_US_Delete_Element(CRF_Open(),id);
}
int CRF_GetPairs(int parent_ids[],int child_ids[],int maxlen)
{
	return(TBL_US_US_GetActivePairs(CRF_Open(),parent_ids,child_ids,maxlen));
}
