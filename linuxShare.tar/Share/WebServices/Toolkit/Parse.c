/******************************************************************************
*	file name   :	Parse.c 
*
*	purpose: parse functions
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
extern char *string_dup(char *s);
extern void free_string(char *s);
/*******************************************************************************/
/************************************
* return pointer to next line       *
************************************/
#include <string.h>
/*******************************************************************************/
char *ABS_getlne(char *line, char *msg)
{

	if(!msg)
		return(0);

	for ( ;*msg && (*msg != '\r') && (*msg != '\n'); line++, msg++)
		*line = *msg;
	*line = 0;
    if(!*msg)
		return(0);
	else
	{
        msg++;
		if(*msg == '\r' || *msg == '\n') msg++;
      
      return(*msg ? msg: 0);
	}
}

/************************************
* return pointer to next line       *
************************************/
char *ABS_getlne_n(char *line, char *msg,int n)
{

	if(!msg)
		return(0);

	for ( ;n && *msg && (*msg != '\r') && (*msg != '\n'); line++, msg++,n--)
		*line = *msg;
	*line = 0;
    if(!*msg)
		return(0);
	else
	{
        msg++;
		if(*msg == '\r' || *msg == '\n') msg++;
      
      return(*msg ? msg: 0);
	}
}
