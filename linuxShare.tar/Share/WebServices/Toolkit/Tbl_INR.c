
/******************************************************************************
*	file name   :	Tbl_INR.c 
*
*	purpose: Instanse name resolver
*	portability:	Machine Independent
*
*
*	author(s):	Gadi Veazovsky  
*	date started:	16-Oct-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/

/*******************************************************************************/
int TBL_SH_STR_Increase_Num_by_Str(void *h, char *str);

/*******************************************************************/
static void *INR_Open()
{
static void *tbl = 0;
extern void *TBL_SH_STR_New();
 
if(!tbl)
   tbl = TBL_SH_STR_New("INR", 400);
return(tbl);
}

int ResolveInstanceCount(char* instname)
{
	return(TBL_SH_STR_Increase_Num_by_Str(INR_Open(),instname));
}
