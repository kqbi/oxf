/******************************************************************************
*	file name   :	Memory.c 
*
*	purpose: Memory allocation tools
*	portability:	Machine Independent
*
*
*	author(s):	Gadi Veazovsky   
*	date started:	21-MAy-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <string.h>

/*******************************************************************************/
int cycmem_to_mem(char to[], char from[], int from_size, int start, int len)
{
   char *p;
   int part1;
   int new_pos;

   p = &from[start];

   part1 = from_size - start;
   if(part1 >= len)
   {
      memcpy(to, p , len);
      new_pos = start + len;
   }
   else
   {
      memcpy(to, p, part1);
      memcpy(&to[part1], from, len - part1);
      new_pos = len - part1;
   }

   return(new_pos);
}


int mem_to_cycmem(char to[], int wr_pos, int to_size, char *from, int len)
{
   int left_len;

   if(len >= to_size)
   {
    char *endfrom;
      endfrom = &from[len];
      len = to_size - 1;  /* make sure we fit into cyclic buffer */
      from = &endfrom[-len]; /* take just the suffix of buff */
   }

   left_len = to_size - wr_pos;
   if(left_len >= len)
   {
      memcpy(&to[wr_pos], from, len);
      wr_pos += len;
   }
   else
   {
      memcpy(&to[wr_pos], from, left_len);
      wr_pos = len - left_len;
      memcpy(to, &from[left_len], wr_pos);
   }

   return(wr_pos);  /* return new write position ready for new write */
}
