/******************************************************************************
*	file name   :	Sort.c 
*
*	purpose: Csort functions
*	portability:	Machine Independent
*
*
*	author(s):	 Doron Green   
*	date started:	20-Sep-00
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <string.h>
/*******************************************************************************/

/* bubble sort for pointer to integers array*/
void ABS_Sort_IntArr(int **a, int len)
{
   int i,j;
   int *t;


   for(i = len -1; i >=1 ; i--)
      for(j = 1; j <= i; j++)
         if(*a[j-1] > *a[j])
         {
            t = a[j-1];
            a[j-1] = a[j];
            a[j] = t;
         }
}


/* bubble sort for pointer to integers array*/
/**************************************************
 Bubble sort an array of pointers to any structure.
 The sort is done on an Integer field which correspond the
 offset parameter from the begining of the unknown structure
***************************************************/

void ABS_Sort_VoidArr(char **a, int offset, int len)
{
   int i,j;
   void *t;
   int *int_j_p;
   int *int_prev_j_p;

   for(i = len -1; i >=1 ; i--)
      for(j = 1; j <= i; j++)
      {
         int_j_p = (int *)(a[j] + offset);
         int_prev_j_p = (int *)(a[j - 1] + offset);
         if(*int_prev_j_p > *int_j_p)
         {
            t = a[j-1];
            a[j-1] = a[j];
            a[j] = t;
         }
      }
}


#if 0
void ABS_Find_int_in_Sort(char **p, int len, int offset, int id, char  **first,int *matches_p)
{
     char **lastp;
     int *intp = 0;
     int i;

     lastp = p + len;

     for( ; p < lastp ; p++)
     {
        intp = (int *)(*p +offset);
        if((*intp) >= id)
           break;
     }
     if(!intp ||(*intp != id))
      {
         *matches_p = 0;
         return;
      }
     first = p++; /*mast be checked  *first or first*/
     for(i = 1 ; p < lastp ; p++,i++)
     {
        intp = (int *)(*p +offset);
        if((*intp) != id)
           break;
     }
      *matches_p = i;
 }
#endif
