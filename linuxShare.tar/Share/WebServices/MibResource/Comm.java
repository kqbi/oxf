/******************************************************************************
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2009. All Rights Reserved.
*******************************************************************************
*/

import java.applet.*;
import java.io.*;
import java.net.*;
import java.awt.*;

public class Comm extends Applet{
	
	private String content="";
	private URL trg;
	
	public String sendReq (String req)
	{
		content = "";		
		trg = getCodeBase();
		try 
		{
			trg = new URL(trg + req);
		}
		catch (MalformedURLException e) {}
		try {
			
			URLConnection con = trg.openConnection();
			byte b[] = new byte [20000];
			int nbytes = 0;
			int i = 0;
			
			BufferedInputStream in =
			new BufferedInputStream(con.getInputStream(), 20000);
			
			while((nbytes = in.read(b, 0, 20000)) != -1){
				content+= new String (b, 0, nbytes);
			}
		}
		catch (IOException e) {}
		return content;
	}
	
}