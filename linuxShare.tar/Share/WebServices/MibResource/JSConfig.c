/******************************************************************************
*	file name   :	JSConfig.c 
*
*	purpose: Contains access to MIB DB
*	portability:	Machine Independent
*
*
*	author(s):	Gadi Veazovsky   
*	date started:	12-Mar-01
*
*	Licensed Materials - Property of IBM
*	(c) Copyright IBM Corporation 2000, 2009. All Rights Reserved.
*******************************************************************************
*/
#include <string.h>
#include <stdio.h>
/*******************************************************************************/

extern int ABSFileSave(char *name, char data[], int len);
extern int ABSResFileSave(const char *name,const char data[], int len);
/*******************************************************************************/
static int refresh_timeout = 1000;
static int refresh_max_number  = -1;

void SetRefreshTimeout(int time)
{
	refresh_timeout = time;
}

void SetRefrehTimeout(int time)
{
	refresh_timeout = time;
}

/** Keep this functions for backward compatibility reasons.
 */
void SetRefrehMaxNumber(int number)
{
	refresh_max_number = number;
}

void CreateConfigFile()
{
 char buff[1024];

 sprintf(buff,"function setup (obj){obj.refreshTimeout = %d;obj.maxRefs = %d;}",
			refresh_timeout,refresh_max_number);

 ABSFileSave( "config.js", buff, (int)strlen(buff));
}

void CreateLinkFile()
{
 static const char manage_inc[]="config.js\ntools.js\nmng.js";
 static const char tree_inc[]="tools.js\ndecl.js";
 
   ABSResFileSave( "manage.inc", manage_inc, sizeof(manage_inc));
   ABSResFileSave( "tree.inc", tree_inc, sizeof(tree_inc));
}
